$compress = @{
LiteralPath= "en-US\Microsec.XSign4Net.resources.dll", "IFSZ_EbizServ.exe", "IFSZ_EbizServ.exe.config", "IFSZ_EbizServ.pdb", "IFSZ_EbizServ.xml", "Microsec.Localization.dll", "Microsec.Sdk.Commons.dll", "Microsec.XSign4Net.dll", "Microsoft.Owin.dll", "Microsoft.Owin.Host.HttpListener.dll", "Microsoft.Owin.Host.HttpListener.xml", "Microsoft.Owin.Hosting.dll", "Microsoft.Owin.Hosting.xml", "Microsoft.Owin.xml", "Newtonsoft.Json.dll", "Newtonsoft.Json.xml", "Owin.dll", "System.Net.Http.Formatting.dll", "System.Net.Http.Formatting.xml", "System.Web.Http.dll", "System.Web.Http.Owin.dll", "System.Web.Http.Owin.xml", "System.Web.Http.xml"
DestinationPath = "IFSZ_EbizServ.zip"
}
Compress-Archive @compress
# Copy-Item -Path ".\IFSZ_EbizServ.zip" -Destination "\\develop\BinaryDistributor" -Force -PassThru
