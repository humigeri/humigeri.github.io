$compress = @{
LiteralPath= "IFSZ_AddOn_Ebiz.ard", "IFSZ_AddOn_Ebiz_Installer.exe", "mssql_db.sql", "hana_db.sql"
DestinationPath = "IFSZ_AddOn_Ebiz_Installer.zip"
}
Compress-Archive @compress
# Copy-Item -Path ".\IFSZ_AddOn_Ebiz_Installer.zip" -Destination "\\develop\BinaryDistributor" -Force -PassThru
