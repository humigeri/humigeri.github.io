﻿### Átadási (Implementációs) dokumentum

### SAP üzletág

#

# Projekt:

# IFSZ eBiz modul - xxdoksi nevexx

## Ügyfél: -

## Verziószám: xxverzióxx

#

### Fejezetek

[Üzleti igény](#uzleti_igeny)  
[Megoldás összefoglalása](#megoldas)  
[Biztonság, jogosultságok](#jogosultsag)  
[Alkalmazás felhasználói felülete](#felulet)  
[Funkciók](#funkciok)  
[Beállítások, paraméterek](#parameterek)  
[Adatbázis objektumok](#dbobj)  
[Alkalmazás objektumok](#alkobj)  
[Érintett területek](#erintett)  
[Ismert problémák](#problemak)  
[Telepítés](#telepites)  
[Egyéb információk](#egyeb)  
[Projekt résztvevői](#resztvevo)  
[Kapcsolódó dokumentumok](#kapcsdok)  
[Verziótörténet](#verzio)  

#########

