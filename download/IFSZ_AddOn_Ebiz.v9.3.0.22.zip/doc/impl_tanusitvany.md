﻿### Átadási (Implementációs) dokumentum

### SAP üzletág

#

# Projekt:

# IFSZ eBiz modul - Tanúsítvány igénylése

## Ügyfél: -

## Verziószám: v20

#

### Fejezetek

[Üzleti igény](#uzleti_igeny)  
[Megoldás összefoglalása](#megoldas)  
[Biztonság, jogosultságok](#jogosultsag)  
[Alkalmazás felhasználói felülete](#felulet)  
[Funkciók](#funkciok)  
[Beállítások, paraméterek](#parameterek)  
[Adatbázis objektumok](#dbobj)  
[Alkalmazás objektumok](#alkobj)  
[Érintett területek](#erintett)  
[Ismert problémák](#problemak)  
[Telepítés](#telepites)  
[Egyéb információk](#egyeb)  
[Projekt résztvevői](#resztvevo)  
[Kapcsolódó dokumentumok](#kapcsdok)  
[Verziótörténet](#verzio)  

#########

### Üzleti igény {#uzleti_igeny}

Jelen modulfejlesztés azon célból valósult meg, hogy az SAP Business One
rendszerből (továbbiakban SAPB1) akár tömegesen lehessen kiküldeni
emailben bizonylatokat.

A jogosult felhasználó egy formon leszűri, hogy milyen típusú
dokumentumokat akar kiküldeni. A leszűrt dokumentumokból kijelöli a
valóban küldendő bizonylatokat, ezt követően egy gombnyomásra
legenerálja és elküldi azokat a partnernek. A küldési dokumentum
bizonylat mentésre kerül, ezáltal lekérdezhető, hogy melyik bizonylat
mikor és milyen címre lett elküldve.

Az eBIZ modul csak Crystal Reportos nyomtatási képeket tud kiküldeni

Jelen dokumentum az IFSZ eBIZ modul felhasználói szintű leírását
tartalmazza.

### Megoldás összefoglalása {#megoldas}

### Tanúsítványok igénylése

Az elektronikus aláírás bizosításához két tanúsítvány megszerzésére
van szükség:

-   Szervezeti bélyegző tanúsítványra

-   Időbélyeg tanúsítvány csomagra (tranzakciós) az egyes
    dokumentumokhoz

Ezeket jelenleg a Microsec Zrt. tanúsító szervezet tanúsítványaival
biztosíthatjuk (e-Szignó).

**A szervezeti bélyegző tanúsítvány igénylési folyamata a következő:**

Link:
<https://srv.e-szigno.hu/index.php?lap=szoftveres_automata_igenyles>

Ezt a linket az alapértelmezett böngésző azonnal megnyitja. (Itt még
mindegy, hogy milyen böngészőt indítunk.) Meg kell adnunk egy e-mail
címet, melyet azonnal tudunk olvasni, valamint ez az email cím fog
bekerülni a tanúsítványba is. Legyen most ez az e-mail cím a
<penzugy@ifsz.hu>.

![](media/image28.png){width="4.854166666666667in"
height="2.4791666666666665in"}

A link megnyitásakor a szervezeti bélyegző igénylésének éves díja is
azonnal látható.

Ezután a megadott címre érkezik egy email, melyben lesz egy link, amire
rákattintva folytatni lehet az igénylést. Erre a linkre rákattintva már
nem mindegy, melyik böngészőből folytatjuk az igénylést: Internet
Explorer-be, vagy 58-as verziótól régebbi Mozilla FireFox böngészőbe
kell a kapott linket másolnunk és megnyitnunk. Ha ezt követjük, akkor a
böngésző megcsinálja a párosító kulcs generálását, egyébként külön
kódoló algoritmusokat kell alkalmaznunk.

![](media/image29.png){width="5.097222222222222in"
height="2.7708333333333335in"}

Az igénylőnél azt a személyt kell megadnunk, aki az igénylésnél el fog
járni (számára meghatalmazást kell kiállítani, melyről formanyomtatvány
fog érkezni a MICROSEC-től).

A kitöltés menete a következőképpen folytatódik:

![](media/image30.png){width="5.284722222222222in"
height="4.256944444444445in"}

![](media/image31.png){width="4.972222222222222in"
height="4.111111111111111in"}

![](media/image32.png){width="4.965277777777778in"
height="4.069444444444445in"}

Ha rossz böngészőben vagyunk, akkor a Kulcsgenerálás módja blokknál
kapunk egy piros üzenetet. Ezt rögtön az adatrögzítés legelején le lehet
ellenőrizni, ha legörgetünk a lentebb látható pontig:

![](media/image33.png){width="5.138888888888889in"
height="4.208333333333333in"}

A megjegyzésbe írjuk be: *„Minősített időbélyegzés szolgáltatást is
fogunk igényelni IFSZ eBIZ modulhoz; kérjük ennek megfelelő dokumentum
csomagot küldeni."*

Így az Ügyfélszolgálat a Szolgáltatási szerződés időbélyeg tanúsítvány
csomagra vonatkozó mellékletét is elküldi emailben.

Ezután fogadjuk el a nyilatkozatokat:

![](media/image34.png){width="5.263888888888889in"
height="4.319444444444445in"}

![](media/image35.png){width="4.973611111111111in"
height="3.752083333333333in"}

![](media/image36.png){width="5.166666666666667in"
height="3.1041666666666665in"}

![](media/image37.png){width="4.875in" height="3.2291666666666665in"}

![](media/image38.png){width="4.840277777777778in" height="3.125in"}

![](media/image39.png){width="4.979166666666667in"
height="3.2708333333333335in"}

![](media/image40.png){width="4.590277777777778in"
height="2.7291666666666665in"}

A sikeres megrendelést követően az alábbi üzenet fogjuk kapni az
igénylés első lépése során megadott e-mail címre:

![](media/image41.png){width="5.506944444444445in"
height="2.3680555555555554in"}

A kapott dokumentumokat ki kell tölteni, aláírni, majd személyes
azonosításra kerül sor. Ehhez lépjen kapcsolatba a Microsec
[Ügyfélszolgálattal](https://srv.e-szigno.hu/index.php?lap=ugyfelszolgalat),
és egyeztesse kollégákkal, hogy az Ön személyes azonosítására mikor
kerül sor. A személyes azonosítás helyszíne a Microsec Zrt.
ügyfélszolgálati irodája (Graphisoft Park: 1033 Ángel Sanz Briz út 13.,
Microsec fölszinti iroda, külső átadó ablak. Igény esetén helyszíni
kiszállást is biztosítanak, ennek díjazását szükséges előre egyeztetni a
<sales@microsec.hu> email címen). A személyes találkozást követően
elkészítik tanúsítványát, és a megadott értesítési e-mail címre elküldik
Önnek. A tanúsítványokat először ugyanarra a számítógépre kell
telepíteni, amelyiken az igénylőlapot kitöltöttük. A tanúsítványt később
[másik gépre is
átviheti](https://srv.e-szigno.hu/index.php?lap=telepitesi_utmutato_xp_szoftveres).
Az igénylőlap kitöltésekor felmerülő problémák esetén a MICROSEC-es
kollégák a 06 1 505 4444-es telefonszámon állnak rendelkezésre.

A tanúsítvány rendelkezésre állása esetén az IFSZ kollégai elvégzik a
telepítést és a konfigurációt. A dokumentumok elektronikus aláírását egy
szolgáltatás fogja elvégezni, amit az IFSZ Kft. az Önök SAP szerverére
telepít. (Másik szerverre is telepíthető, az a lényeg, hogy elérje az
SAP adatbázist és az eBiz addon generálási útvonalát.) Telepítés után a
szolgáltatás egy adott porton keresztül fogja fogadni az eBiz addon
kéréseit, ezért fontos, hogy nyitva legyen ez a port a kliensek
irányából induló kérések számára. Az EBIZSRV paraméterben kell megadni a
szolgáltatás url-jét, ami a következőképpen fog kinézni:
[http://ip-cím:port/](http://ip-cím:port/) Amennyiben ez a paraméter
nincs megadva, akkor elektronikus aláírás nélkül küldi el a
bizonylatokat az eBiz addon.

A szolgáltatás telepítéséhez szükségünk lesz:

-   A bélyegző tanúsítványra. Ebből egy pfx fájlt kell generálni az itt
    olvasható útmutató szerint:
    <https://help.e-szigno.hu/knowledgebase.php?article=42> . Ezt,
    illetve a generáláshoz használt jelszót is adja meg az IFSZ-nek.

-   Az időbélyeg szolgáltatáshoz kapcsolódó felhasználónévre és
    jelszóra.

-   A regisztrációs licenc lapon megadott regisztrációs kulcsra, ami
    ilyesmi formátumú lesz: 1aaaaaaa-a123-a123-a123-1aaaaaaaaaaa

Ha a telepítés és beállítás megtörtént, akkor a nyomtatási képek pdf-e
alapján a szolgáltatás készíteni fog egy \_signed.pdf-re végződő nevű
fájlt is, ami már tartalmazza az elektronikus aláírást, és az eBiz
addon ezt fogja elküldeni az email mellékleteként. Ezeknek a PDF
dokumentumoknak az elektronikus aláírását látni fogjuk a generált PDF
dokumentum megnyitásakor:

![](media/image42.png){width="2.9166666666666665in"
height="0.5486111111111112in"}

## Biztonság, ogosultságok {#jogosultsag}

  -------------------- -----------------------------------------------------------------------------------------------------------------------------------------
  **Szerepkör**        **Tartalom**
  F_EOA                A „Kimenő levélküldés / Postafiókok" menüponthoz való jogosultság.
  F_EOB                A „Kimenő levélküldés / E-mail sablonok" menüponthoz való jogosultság.
  F_EOH                A „Kimenő levélküldés / Küldési bizonylat" menüponthoz való jogosultság.
  F_EOHLIS             A „Kimenő levélküldés / Küldési bizonylat lista" menüponthoz való jogosultság.
  F_SZLKIV             A „Kimenő levélküldés / Bizonylatok listája" menüponthoz való jogosultság.
  EBIZADDRMOD          eBiz levélküldésnél címzettet lehet-e módosítani. (lásd: „Email szövegének, tárgyának módosítása" fejezet)
  EBIZPRINTLAYOUTMOD   eBiz levélküldésnél a nyomtatási kép formátumát lehet-e módosítani. (lásd „Nyomtatási képek kiválasztása" fejezet)
  EBIZTEMPLMOD         Email sablon által megadott tárgy és szövegtörzs módosítható-e kiküldés előtt? (lásd: „Email szövegének, tárgyának módosítása" fejezet)
  -------------------- -----------------------------------------------------------------------------------------------------------------------------------------

## Alkalmazás felhasználói felülete {#felulet}

## Funkciók {#funkciok}

## Beállítások, paraméterek {#parameterek}

## Adatbázis objektumok {#dbobj}

## Alkalmazás objektumok {#alkobj}

## Érintett területek {#erintett}

## Ismert problémák {#problemak}

## Telepítés {#telepites}

## Egyéb információk {#egyeb}

## Projekt résztvevői {#resztvevo}

## Kapcsolódó dokumentumok {#kapcsdok}

## Verziótörténet {#verzio}


