﻿### Átadási (Implementációs) dokumentum

### SAP üzletág

#

# Projekt:

# IFSZ eBiz modul - Postafiókok

## Ügyfél: -

## Verziószám: v20

#

### Fejezetek

[Üzleti igény](#uzleti_igeny)  
[Megoldás összefoglalása](#megoldas)  
[Biztonság, jogosultságok](#jogosultsag)  
[Alkalmazás felhasználói felülete](#felulet)  
[Funkciók](#funkciok)  
[Beállítások, paraméterek](#parameterek)  
[Adatbázis objektumok](#dbobj)  
[Alkalmazás objektumok](#alkobj)  
[Érintett területek](#erintett)  
[Ismert problémák](#problemak)  
[Telepítés](#telepites)  
[Egyéb információk](#egyeb)  
[Projekt résztvevői](#resztvevo)  
[Kapcsolódó dokumentumok](#kapcsdok)  
[Verziótörténet](#verzio)  

#########

### Üzleti igény {#uzleti_igeny}

Jelen modulfejlesztés azon célból valósult meg, hogy az SAP Business One
rendszerből (továbbiakban SAPB1) akár tömegesen lehessen kiküldeni
emailben bizonylatokat.

A jogosult felhasználó egy formon leszűri, hogy milyen típusú
dokumentumokat akar kiküldeni. A leszűrt dokumentumokból kijelöli a
valóban küldendő bizonylatokat, ezt követően egy gombnyomásra
legenerálja és elküldi azokat a partnernek. A küldési dokumentum
bizonylat mentésre kerül, ezáltal lekérdezhető, hogy melyik bizonylat
mikor és milyen címre lett elküldve.

Az eBIZ modul csak Crystal Reportos nyomtatási képeket tud kiküldeni

Jelen dokumentum az IFSZ eBIZ modul felhasználói szintű leírását
tartalmazza.

### Megoldás összefoglalása {#megoldas}

*Elérési útvonal: Kimenő levélküldés/Postafiókok*

Ezen a törzsadat-formon tároljuk a szükséges postafiókok elérési
adatait.

A levélküldéshez be kell állítani legalább egy kimenő postafiókot,
amelyről kiküldi a rendszer az emaileket. Akár felhasználónkénti vagy
csoportonkénti kimenő postafiókokat is meg lehet adni.

![](media/image3.png){width="5.2858595800524935in"
height="3.547825896762905in"}

A jelszó nyomógombot megnyomva lehet megadni az adott postafiók
jelszavát.

![](media/image4.png){width="3.2291666666666665in"
height="2.173611111111111in"}

##### Kitöltési útmutató

  --------------------- ------------------- --------------------------------------------------------------------------------------------------
  **Mező**              **Kitöltési mód**   **Tartalom**
  Megnevezés            Kötelező            A postafiók törzsadat neve, a felhasználóknál ez alapján lehet hozzárendelni az SMTP postafiókot
  SMTP szerver          Kötelező            A levelező szerver címe
  SMTP port             Opcionális          A levelező szerver portja
  SMTP felhasználónév   Kötelező            SMTP szerver felhasználónév
  SSL?                  Kötelező            Amennyiben nem ssl kapcsolódás történik, akkor „Nem"-re állítsuk.
  Jelszó                Kötelező            Az SMTP felhasználó jelszava. Kódolva tároljuk.
  --------------------- ------------------- --------------------------------------------------------------------------------------------------

#### Postafiókok felhasználóhoz rendelése

*Elérési útvonal: Adminisztráció/Definíciók/Általános/Felhasználók*

A felhasználó törzsadatoknál a Kimenő postafiók felhasználói mezőben
lehet az előzőleg felvett postafiókot a felhasználókhoz rendelni. Így
felhasználónként beállítható kinél, milyen kimenő postafiókot fogunk
használni.

A program az email küldőjének azt az email-címet állítja, be, amelyik a
küldést végző felhasználóhoz az E-mail mezőben be van állítva. (Ez az
eBiz modul alapvető működése, de ha az adott cég ettől eltérő
email-címet akar használni, akkor arra is lehetőség van.)

![](media/image5.png){width="5.381944444444445in"
height="3.513888888888889in"}

## Biztonság, ogosultságok {#jogosultsag}

  -------------------- -----------------------------------------------------------------------------------------------------------------------------------------
  **Szerepkör**        **Tartalom**
  F_EOA                A „Kimenő levélküldés / Postafiókok" menüponthoz való jogosultság.
  F_EOB                A „Kimenő levélküldés / E-mail sablonok" menüponthoz való jogosultság.
  F_EOH                A „Kimenő levélküldés / Küldési bizonylat" menüponthoz való jogosultság.
  F_EOHLIS             A „Kimenő levélküldés / Küldési bizonylat lista" menüponthoz való jogosultság.
  F_SZLKIV             A „Kimenő levélküldés / Bizonylatok listája" menüponthoz való jogosultság.
  EBIZADDRMOD          eBiz levélküldésnél címzettet lehet-e módosítani. (lásd: „Email szövegének, tárgyának módosítása" fejezet)
  EBIZPRINTLAYOUTMOD   eBiz levélküldésnél a nyomtatási kép formátumát lehet-e módosítani. (lásd „Nyomtatási képek kiválasztása" fejezet)
  EBIZTEMPLMOD         Email sablon által megadott tárgy és szövegtörzs módosítható-e kiküldés előtt? (lásd: „Email szövegének, tárgyának módosítása" fejezet)
  -------------------- -----------------------------------------------------------------------------------------------------------------------------------------

## Alkalmazás felhasználói felülete {#felulet}

## Funkciók {#funkciok}

## Beállítások, paraméterek {#parameterek}

## Adatbázis objektumok {#dbobj}

## Alkalmazás objektumok {#alkobj}

## Érintett területek {#erintett}

## Ismert problémák {#problemak}

## Telepítés {#telepites}

## Egyéb információk {#egyeb}

## Projekt résztvevői {#resztvevo}

## Kapcsolódó dokumentumok {#kapcsdok}

## Verziótörténet {#verzio}


