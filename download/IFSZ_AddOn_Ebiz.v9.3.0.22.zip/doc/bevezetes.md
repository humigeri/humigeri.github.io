﻿Jelen modulfejlesztés azon célból valósult meg, hogy az SAP Business One
rendszerből (továbbiakban SAPB1) akár tömegesen lehessen kiküldeni
emailben bizonylatokat.

A jogosult felhasználó egy formon leszűri, hogy milyen típusú
dokumentumokat akar kiküldeni. A leszűrt dokumentumokból kijelöli a
valóban küldendő bizonylatokat, ezt követően egy gombnyomásra
legenerálja és elküldi azokat a partnernek. A küldési dokumentum
bizonylat mentésre kerül, ezáltal lekérdezhető, hogy melyik bizonylat
mikor és milyen címre lett elküldve.

Az eBIZ modul csak Crystal Reportos nyomtatási képeket tud kiküldeni

Jelen dokumentum az IFSZ eBIZ modul felhasználói szintű leírását
tartalmazza.

