﻿$ver = "v20"

#Felhasználói doksi
$f =      "## Bevezetés`r`n`r`n"
$f = $f + (Get-Content -path bevezetes.md -Raw)

$f = $f + (Get-Content -path fhodok_pre_parameterek.md -Raw)
$f = $f + (Get-Content -path parameterek.md -Raw)

$f = $f + "### Jogosultságok`r`n`r`n"
$f = $f + (Get-Content -path jogosultsagok.md -Raw)

$f = $f + "### Bizonylatszám kategóriák`r`n`r`n"
$f = $f + (Get-Content -path bizkat.md -Raw)

$f = $f + "### Postafiók beállítások`r`n`r`n"
$f = $f + (Get-Content -path postafiok.md -Raw)

$f = $f + "### E-mail sablonok`r`n`r`n"
$f = $f + (Get-Content -path sablonok.md -Raw)

$f = $f + "### Küldési bizonylat`r`n`r`n"
$f = $f + (Get-Content -path kuldbiz.md -Raw)

$f = $f + "### Lekérdezések`r`n`r`n"
$f = $f + (Get-Content -path lekerdezesek.md -Raw)

$f = $f + "### Csatolmányok`r`n`r`n"
$f = $f + (Get-Content -path csatol.md -Raw)

$f = $f + "### Tanúsítványok igénylése`r`n`r`n"
$f = $f + (Get-Content -path tanusitvany.md -Raw)

$f = $f + "### Archiválás`r`n`r`n"
$f = $f + (Get-Content -path archivalas.md -Raw)


Set-Content -Encoding UTF8 -Path fhodok.md $f
Write-Output "fhodok.md created"


#Implementációs sablon - Postafiókok
$f =      (Get-Content -path impl_sablon.md -Raw)
$f = $f -replace "xxdoksi nevexx", "Postafiókok"
$f = $f -replace "xxverzióxx", $ver


$f = $f + "### Üzleti igény {#uzleti_igeny}`r`n`r`n"
$f = $f + (Get-Content -path bevezetes.md -Raw)

$f = $f + "### Megoldás összefoglalása {#megoldas}`r`n`r`n"
$f = $f + (Get-Content -path postafiok.md -Raw)

$f = $f + "## Biztonság, ogosultságok {#jogosultsag}`r`n`r`n"
$f = $f + (Get-Content -path jogosultsagok.md -Raw)

$f = $f + "## Alkalmazás felhasználói felülete {#felulet}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Funkciók {#funkciok}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Beállítások, paraméterek {#parameterek}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Adatbázis objektumok {#dbobj}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Alkalmazás objektumok {#alkobj}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Érintett területek {#erintett}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Ismert problémák {#problemak}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Telepítés {#telepites}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Egyéb információk {#egyeb}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Projekt résztvevői {#resztvevo}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Kapcsolódó dokumentumok {#kapcsdok}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Verziótörténet {#verzio}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

Set-Content -Encoding UTF8 -Path impl_postafiok.md $f
Write-Output "impl_postafiok.md created"


#Implementációs sablon - Email sablonok
$f =      (Get-Content -path impl_sablon.md -Raw)
$f = $f -replace "xxdoksi nevexx", "Email sablonok"
$f = $f -replace "xxverzióxx", $ver

$f = $f + "### Üzleti igény {#uzleti_igeny}`r`n`r`n"
$f = $f + (Get-Content -path bevezetes.md -Raw)

$f = $f + "### Megoldás összefoglalása {#megoldas}`r`n`r`n"
$f = $f + (Get-Content -path sablonok.md -Raw)

$f = $f + "## Biztonság, ogosultságok {#jogosultsag}`r`n`r`n"
$f = $f + (Get-Content -path jogosultsagok.md -Raw)

$f = $f + "## Alkalmazás felhasználói felülete {#felulet}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Funkciók {#funkciok}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Beállítások, paraméterek {#parameterek}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Adatbázis objektumok {#dbobj}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Alkalmazás objektumok {#alkobj}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Érintett területek {#erintett}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Ismert problémák {#problemak}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Telepítés {#telepites}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Egyéb információk {#egyeb}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Projekt résztvevői {#resztvevo}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Kapcsolódó dokumentumok {#kapcsdok}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Verziótörténet {#verzio}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

Set-Content -Encoding UTF8 -Path impl_sablonok.md $f
Write-Output "impl_sablonok.md created"


#Implementációs sablon - Küldési bizonylat
$f =      (Get-Content -path impl_sablon.md -Raw)
$f = $f -replace "xxdoksi nevexx", "Küldési bizonylat"
$f = $f -replace "xxverzióxx", $ver

$f = $f + "### Üzleti igény {#uzleti_igeny}`r`n`r`n"
$f = $f + (Get-Content -path bevezetes.md -Raw)

$f = $f + "### Megoldás összefoglalása {#megoldas}`r`n`r`n"
$f = $f + (Get-Content -path kuldbiz.md -Raw)

$f = $f + "## Biztonság, ogosultságok {#jogosultsag}`r`n`r`n"
$f = $f + (Get-Content -path jogosultsagok.md -Raw)

$f = $f + "## Alkalmazás felhasználói felülete {#felulet}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Funkciók {#funkciok}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Beállítások, paraméterek {#parameterek}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Adatbázis objektumok {#dbobj}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Alkalmazás objektumok {#alkobj}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Érintett területek {#erintett}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Ismert problémák {#problemak}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Telepítés {#telepites}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Egyéb információk {#egyeb}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Projekt résztvevői {#resztvevo}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Kapcsolódó dokumentumok {#kapcsdok}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Verziótörténet {#verzio}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

Set-Content -Encoding UTF8 -Path impl_kuldbiz.md $f
Write-Output "impl_kuldbiz.md created"


#Implementációs sablon - Lekérdezések
$f =      (Get-Content -path impl_sablon.md -Raw)
$f = $f -replace "xxdoksi nevexx", "Lekérdezések"
$f = $f -replace "xxverzióxx", $ver

$f = $f + "### Üzleti igény {#uzleti_igeny}`r`n`r`n"
$f = $f + (Get-Content -path bevezetes.md -Raw)

$f = $f + "### Megoldás összefoglalása {#megoldas}`r`n`r`n"
$f = $f + (Get-Content -path lekerdezesek.md -Raw)

$f = $f + "## Biztonság, ogosultságok {#jogosultsag}`r`n`r`n"
$f = $f + (Get-Content -path jogosultsagok.md -Raw)

$f = $f + "## Alkalmazás felhasználói felülete {#felulet}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Funkciók {#funkciok}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Beállítások, paraméterek {#parameterek}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Adatbázis objektumok {#dbobj}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Alkalmazás objektumok {#alkobj}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Érintett területek {#erintett}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Ismert problémák {#problemak}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Telepítés {#telepites}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Egyéb információk {#egyeb}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Projekt résztvevői {#resztvevo}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Kapcsolódó dokumentumok {#kapcsdok}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Verziótörténet {#verzio}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

Set-Content -Encoding UTF8 -Path impl_lekerdezesek.md $f
Write-Output "impl_lekerdezesek.md created"


#Implementációs sablon - Csatolmányok
$f =      (Get-Content -path impl_sablon.md -Raw)
$f = $f -replace "xxdoksi nevexx", "Csatolmányok"
$f = $f -replace "xxverzióxx", $ver

$f = $f + "### Üzleti igény {#uzleti_igeny}`r`n`r`n"
$f = $f + (Get-Content -path bevezetes.md -Raw)

$f = $f + "### Megoldás összefoglalása {#megoldas}`r`n`r`n"
$f = $f + (Get-Content -path csatol.md -Raw)

$f = $f + "## Biztonság, ogosultságok {#jogosultsag}`r`n`r`n"
$f = $f + (Get-Content -path jogosultsagok.md -Raw)

$f = $f + "## Alkalmazás felhasználói felülete {#felulet}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Funkciók {#funkciok}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Beállítások, paraméterek {#parameterek}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Adatbázis objektumok {#dbobj}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Alkalmazás objektumok {#alkobj}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Érintett területek {#erintett}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Ismert problémák {#problemak}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Telepítés {#telepites}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Egyéb információk {#egyeb}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Projekt résztvevői {#resztvevo}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Kapcsolódó dokumentumok {#kapcsdok}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Verziótörténet {#verzio}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

Set-Content -Encoding UTF8 -Path impl_csatol.md $f
Write-Output "impl_csatol.md created"


#Implementációs sablon - Tanúsítványok
$f =      (Get-Content -path impl_sablon.md -Raw)
$f = $f -replace "xxdoksi nevexx", "Tanúsítvány igénylése"
$f = $f -replace "xxverzióxx", $ver

$f = $f + "### Üzleti igény {#uzleti_igeny}`r`n`r`n"
$f = $f + (Get-Content -path bevezetes.md -Raw)

$f = $f + "### Megoldás összefoglalása {#megoldas}`r`n`r`n"
$f = $f + (Get-Content -path tanusitvany.md -Raw)

$f = $f + "## Biztonság, ogosultságok {#jogosultsag}`r`n`r`n"
$f = $f + (Get-Content -path jogosultsagok.md -Raw)

$f = $f + "## Alkalmazás felhasználói felülete {#felulet}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Funkciók {#funkciok}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Beállítások, paraméterek {#parameterek}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Adatbázis objektumok {#dbobj}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Alkalmazás objektumok {#alkobj}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Érintett területek {#erintett}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Ismert problémák {#problemak}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Telepítés {#telepites}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Egyéb információk {#egyeb}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Projekt résztvevői {#resztvevo}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Kapcsolódó dokumentumok {#kapcsdok}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Verziótörténet {#verzio}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

Set-Content -Encoding UTF8 -Path impl_tanusitvany.md $f
Write-Output "impl_tanusitvany.md created"


#Implementációs sablon - Archiválás
$f =      (Get-Content -path impl_sablon.md -Raw)
$f = $f -replace "xxdoksi nevexx", "Archiválás"
$f = $f -replace "xxverzióxx", $ver

$f = $f + "### Üzleti igény {#uzleti_igeny}`r`n`r`n"
$f = $f + (Get-Content -path bevezetes.md -Raw)

$f = $f + "### Megoldás összefoglalása {#megoldas}`r`n`r`n"
$f = $f + (Get-Content -path archivalas.md -Raw)

$f = $f + "## Biztonság, ogosultságok {#jogosultsag}`r`n`r`n"
$f = $f + (Get-Content -path jogosultsagok.md -Raw)

$f = $f + "## Alkalmazás felhasználói felülete {#felulet}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Funkciók {#funkciok}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Beállítások, paraméterek {#parameterek}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Adatbázis objektumok {#dbobj}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Alkalmazás objektumok {#alkobj}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Érintett területek {#erintett}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Ismert problémák {#problemak}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Telepítés {#telepites}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Egyéb információk {#egyeb}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Projekt résztvevői {#resztvevo}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Kapcsolódó dokumentumok {#kapcsdok}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

$f = $f + "## Verziótörténet {#verzio}`r`n`r`n"
#$f = $f + (Get-Content -path .md -Raw)

Set-Content -Encoding UTF8 -Path impl_archivalas.md $f
Write-Output "impl_archivalas.md created"




Read-Host -Prompt "Vége"
