﻿### Átadási (Implementációs) dokumentum

### SAP üzletág

#

# Projekt:

# IFSZ eBiz modul - Lekérdezések

## Ügyfél: -

## Verziószám: v20

#

### Fejezetek

[Üzleti igény](#uzleti_igeny)  
[Megoldás összefoglalása](#megoldas)  
[Biztonság, jogosultságok](#jogosultsag)  
[Alkalmazás felhasználói felülete](#felulet)  
[Funkciók](#funkciok)  
[Beállítások, paraméterek](#parameterek)  
[Adatbázis objektumok](#dbobj)  
[Alkalmazás objektumok](#alkobj)  
[Érintett területek](#erintett)  
[Ismert problémák](#problemak)  
[Telepítés](#telepites)  
[Egyéb információk](#egyeb)  
[Projekt résztvevői](#resztvevo)  
[Kapcsolódó dokumentumok](#kapcsdok)  
[Verziótörténet](#verzio)  

#########

### Üzleti igény {#uzleti_igeny}

Jelen modulfejlesztés azon célból valósult meg, hogy az SAP Business One
rendszerből (továbbiakban SAPB1) akár tömegesen lehessen kiküldeni
emailben bizonylatokat.

A jogosult felhasználó egy formon leszűri, hogy milyen típusú
dokumentumokat akar kiküldeni. A leszűrt dokumentumokból kijelöli a
valóban küldendő bizonylatokat, ezt követően egy gombnyomásra
legenerálja és elküldi azokat a partnernek. A küldési dokumentum
bizonylat mentésre kerül, ezáltal lekérdezhető, hogy melyik bizonylat
mikor és milyen címre lett elküldve.

Az eBIZ modul csak Crystal Reportos nyomtatási képeket tud kiküldeni

Jelen dokumentum az IFSZ eBIZ modul felhasználói szintű leírását
tartalmazza.

### Megoldás összefoglalása {#megoldas}

#### Bizonylatok listája

*Elérési útvonal: Kimenő levélküldés/Bizonylatok listája*

Ezen a képernyőn lehet a felső blokkban lévő szűrőparamétereket megadva
lekeresni a korábbi küldésekben szereplő bizonylatokat. A dátumszűrési
intervallum megadása kötelező.

A ![](media/image22.png){width="0.4097222222222222in" height="0.3125in"}
nyomógombra kattintva plusz, akár az adott cégnél egyedi szűrőfeltételek
adhatók meg.

![](media/image23.png){width="5.409722222222222in"
height="4.520833333333333in"}

A szűrőfeltételek megadása után a képernyőn láthatóak az adott bizonylat
adatai, pl. a bizonylatszám mezőben egy adott számlaszámot beírva
megtekeinthető, hogy ki lett-e küldve az adott számla emailben.

![](media/image11.png){width="5.568450349956255in"
height="2.504666447944007in"}

Amennyiben a Küldési státusz oszlopban az szerepel, hogy Kiküldve, akkor
a sárga nyílra kattintva meg tudjuk nézni az adott küldés adatait a
Küldési bizonylatok listája képernyőn.

![](media/image24.png){width="5.416666666666667in"
height="3.048611111111111in"}

Ezen a képernyőn lehetőségünk van a Bizonylatszám mezőre lefúrva
megnézni, hogy az adott küldési bizonylaton milyen tételek szerepeltek,
illetve az Útvonal mezőben lévő fájlra lefúrva pedig az adott bizonylat
pdf képét tudjuk megtekinteni.

#### Küldési bizonylat lista

*Elérési útvonal: Kimenő levélküldés/Küldési bizonylatok lista*

Ezen a képernyőn lehet megtekintei az összes eddigi küldési bizonylat
főbb adatait: felhasználó, küldés időpontja, státusza, mappája.

![](media/image25.png){width="5.465277777777778in"
height="3.7708333333333335in"}

## Biztonság, ogosultságok {#jogosultsag}

  -------------------- -----------------------------------------------------------------------------------------------------------------------------------------
  **Szerepkör**        **Tartalom**
  F_EOA                A „Kimenő levélküldés / Postafiókok" menüponthoz való jogosultság.
  F_EOB                A „Kimenő levélküldés / E-mail sablonok" menüponthoz való jogosultság.
  F_EOH                A „Kimenő levélküldés / Küldési bizonylat" menüponthoz való jogosultság.
  F_EOHLIS             A „Kimenő levélküldés / Küldési bizonylat lista" menüponthoz való jogosultság.
  F_SZLKIV             A „Kimenő levélküldés / Bizonylatok listája" menüponthoz való jogosultság.
  EBIZADDRMOD          eBiz levélküldésnél címzettet lehet-e módosítani. (lásd: „Email szövegének, tárgyának módosítása" fejezet)
  EBIZPRINTLAYOUTMOD   eBiz levélküldésnél a nyomtatási kép formátumát lehet-e módosítani. (lásd „Nyomtatási képek kiválasztása" fejezet)
  EBIZTEMPLMOD         Email sablon által megadott tárgy és szövegtörzs módosítható-e kiküldés előtt? (lásd: „Email szövegének, tárgyának módosítása" fejezet)
  -------------------- -----------------------------------------------------------------------------------------------------------------------------------------

## Alkalmazás felhasználói felülete {#felulet}

## Funkciók {#funkciok}

## Beállítások, paraméterek {#parameterek}

## Adatbázis objektumok {#dbobj}

## Alkalmazás objektumok {#alkobj}

## Érintett területek {#erintett}

## Ismert problémák {#problemak}

## Telepítés {#telepites}

## Egyéb információk {#egyeb}

## Projekt résztvevői {#resztvevo}

## Kapcsolódó dokumentumok {#kapcsdok}

## Verziótörténet {#verzio}


