﻿A \@IFSZ_PARAMETERS felhasználói táblában találhatjuk az eBiz modulban
használt paramétereket.

  -------------------- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  **Paraméter**        **Tartalom**
  EBIZADDRMOD          eBiz levélküldésnél címzettet lehet-e módosítani. (lásd: „Email szövegének, tárgyának módosítása" fejezet)
  EBIZATC              Csatoljuk-e a pdf-hez a számlához csatolt dolgokat? (lásd: „Generálás és küldés" fejezet)
  EBIZARCH             Archiv adatbázis neve
  EBIZARCHCHK          A napoknak a számát kell megadnunk, ahány naponként ismételten össze akarjuk hasonlítani az adatbázisba mentett fájlt a fájlrendszerbe mentettel
  EBIZARCHFRQ          Adjuk meg, hogy milyen gyakran (hány percenként) ellenőrizze az eBiz szolgáltatás, hogy lejárt-e már egy-egy fájl utolsó ellenőrzése úta „EBIZARCHCHK" nap.
  EBIZBCC              Az eBiz-zel elküldött levelek \"Titkos másolat\" mezőjébe ez kerül. (lásd: „E-mail sablonok" fejezet)
  EBIZCC               Az eBiz-zel elküldött levelek \"Másolat\" mezőjébe ez kerül. (lásd: „E-mail sablonok" fejezet)
  EBIZDSN              Küldjünk-e megérkezésről visszaigazolási kérelmet az email-lel? (I=Igen) (lásd: „E-mail sablonok" fejezet)
  EBIZFILENAME         eBiz generált pdf fájl nevének formátuma. (lásd: „Generálás és küldés" fejezet)
  EBIZINST             Ha értéke Y, vagy I, akkor történhet meg a felhasználói táblák, mezők telepítése. Erre persze csak akkor van szükség, ha ezek még nincsenek, vagy nincsenek teljes egészében feltelepítve.
  EBIZJOGMOD           Milyen módszerű jogosultságkezelés legyen. (ADDON, SBO) Gyakoribb az „ADDON", ekkor az \@IFSZ_USER_ROLES felhasználói táblában találjuk az addon jogait. „SBO" esetén pedig kiegészítő jogosultságként rögzítettük azokat.
  EBIZPATH             Kimenő nyomtatási képek fájl generálási helye. (lásd „Nyomtatási képek generálásának útvonala" fejezet)
  EBIZPATH_DOMAIN      Az eBiz útvonal eléréséhez használt domain. (lásd „Nyomtatási képek generálásának útvonala" fejezet)
  EBIZPATH_PASSWORD    Az eBiz útvonal eléréséhez használt jelszó. (lásd „Nyomtatási képek generálásának útvonala" fejezet)
  EBIZPATH_USER        Az eBiz útvonal eléréséhez használt felhasználónév. (lásd „Nyomtatási képek generálásának útvonala" fejezet)
  EBIZPRINTLAYOUTMOD   eBiz levélküldésnél a nyomtatási kép formátumát lehet-e módosítani. (lásd „Nyomtatási képek kiválasztása" fejezet)
  EBIZRRR              Küldjünk-e olvasási visszaigazolási kérelmet az email-lel? (I=Igen) (lásd: „E-mail sablonok" fejezet)
  EBIZSRV              Hitelesítést végző szolgáltatás címe. Pl.: <http://localhost:9111/> (lásd: „Tanúsítványok igénylése" fejezet)
  EBIZTEMPLMOD         Email sablon által megadott tárgy és szövegtörzs módosítható-e kiküldés előtt? (lásd: „Email szövegének, tárgyának módosítása" fejezet)
  EBIZXMLPATH          Kimenő nyomtatási képek online számla xml folder. (lásd: „Online számla XML csatolása" fejezet)
  -------------------- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

