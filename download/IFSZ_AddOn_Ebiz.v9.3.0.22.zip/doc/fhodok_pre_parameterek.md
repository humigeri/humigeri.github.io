﻿## Az IFSZ eBIZ modul üzleti funkciói

### Menüpontok

A SAPB1 addon külön addonként került telepítésre, az AddOn-kezelőből
indítható, akár automatikus indításúra is ütemezhető.

*Elérési útvonal: Adminisztráció/Addonok/AddOn-kezelő*

![](media/image2.png){width="5.347222222222222in"
height="3.3958333333333335in"}

#### Funkciók

A modul a következő menüpontokből áll:

**Kimenő levélküldés**

-   Postafiókok

-   Email-sablonok

-   Küldési bizonylat

-   Küldési bizonylat lista

-   Bizonylatok listája

A modulban a szokásos IFSZ AddOn-os módszerekkel lehet új sort felvenni,
törölni, keresni, értéklistát kérni.

### Paraméterek

