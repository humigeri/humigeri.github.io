﻿#### Bizonylatok eBiz típusa

Az eBiz modullal együtt kiegészítjük a bizonylat fejet és az üzleti
partner törzset is egy új felhasználói mezővel, ez az eBiz típus.
(U_EBIZ_TIPUS) Ez a mező 4 értéket vehet fel:

-   Papír alapú

-   Papír alapú PDF

-   Elektronikus -- nem hitelesített PDF

-   Elektronikus -- hitelesített PDF

![](media/image8.png){width="5.438579396325459in"
height="1.843477690288714in"}

Az beállítható az üzleti partnerre, ami aztán a bizonylat létrehozásakor
automatikusan öröklődik a létrehozott bizonylatra is. Amennyiben igény
van rá, egyéb szabályokat, ellenőrzéseket is be tudunk vezetni az eBiz
Típusra, annak bizonylatokon történő módosíthatóságára.

A „Papír alapú" jelenti azt, hogy ezt a bizonylatot hagyományos módon
akarjuk elküldeni az ügyfélnek. Nincs persze szigorú megkötés erre,
elküldhetjük az eBiz modullal is ezeket a bizonylatokat, viszont
alapértelmezetten meg sem jelennek a kiválasztó listában, csak akkor, ha
külön bepipáljuk ezt a jelölőnégyzetet is. Ha eBiz modulban küldjük,
akkor digitális aláírás készítése nélkül fog elmenni a levél.

A „Papír alapú -- PDF" esetén is hagyományos módon történik a számla
kézbesítése, viszont e mellett az eBiz modulban is küldünk emailt. Éppen
ezért alapértelmezetten listázzuk ezeket a bizonylatokat is, elküldéskor
azonban digitális aláírás nem kerül a PDF dokumentumra.

„Elektronikus -- nem hitelesített PDF" hasonló az előző típushoz.
Ilyenkor azonban nem küldünk hagyományos papír alapú számlát, csak az
eBiz modulból küldünk. Digitális aláírás ekkor sem kerül a PDF-re.

„Elektronikus -- hitelesített PDF": Itt sem küldjük hagyományos papír
alapon a számlát, de az eBiz modulból küldött PDF-re már digitális
aláírás kerül. Ez az egyetlen típus, amit aláírunk, ezért fontos, hogy a
küldendő bizonylaton az eBiz típus erre az értékre legyen állítva.

#### Nyomtatási képek generálásának útvonala

IFSZ paraméterekben az EBIZPATH paraméterben lehet megadni a küldendő
nyomtatási képek fájl-generálási helyét.

Ez akár lehet a SAPB1 attachment-hez beállított mappáján belül egy
almappa is (Így biztosított, hogy oda már van a felhasználóknak írás
joguk).

Ezen a mappán belül a program létrehoz minden küldési bizonylatnak egy
külön könyvtárat. A könyvtár neve tartalmazza a küldési bizonylatszámát,
a létrehozó felhasználó nevét és a küldési bizonylat létrehozásának
pontos időpontját. (pl.: \#00024_manager_20200427144416)

Ezáltak a paraméterekben megadott útvonalbeli mappán belül strukturáltan
helyezekednek el a küldési bizonylatokhoz tartazó almappák, amelyek
tartalmazzák az adott e-mail küldéshez tartozó bizonylatok nyomtatási
képét.

Alapban a programot futtató felhasználónak írási és olvasási joga is
kell, hogy legyen ehhez az útvonalhoz. Ez azonban biztonsági aggályokat
vethet fel. Éppen ezért lehetőség adtunk arra, hogy a program ne a
felhasználó nevében írjon, olvasson erről az útvonalról, hanem egy
központilag megadott fiókot használva. Ezt a központi felhasználónevet
az EBIZPATH_USER paraméterben lehet megadni, illetve az EBIZPATH_DOMAIN
paraméterbe a domain-t lehet írni. A felhasználóhoz tartozó jelszót az
EBIZPATH_PASSWORD paraméterbe kell beírni. Az első használat során a
program az EBIZPATH_PASSWORD értékét titkosítja, és visszaírja a
titkosított jelszót és egy „CRYPT:"előtagot. Ezt a titkosított jelszót a
program később is vissza tudja fejteni.

A megadott kapcsolódási adatokat használja a program, amikor a pdf fájlt
elkészíti, és azt elmenti a megadott útvonalra. Akkor is ezt használja,
ha a lefúró nyíllal megtekintjük a pdf fájlt. Ezért a felhasználónak nem
szükséges semmilyen jogot adni az útvonalhoz.

A „Küldési bizonylat" form fejében az útvonalra is le lehet fúrni, ami
egy intéző ablakban megnyitja az EBIZPATH útvonalat. Ez az egyetlen
dolog, amit nem engedünk megtenni abban az esetben, ha a futtató
felhasználónak nincs olvasási joga a mappához.

#### Küldési bizonylat

*Elérési útvonal:Kimenő levélküldés/Küldési bizonylat*

Ebben a menüpontban tudjuk kiválasztani a küldendő bizonylatokat (pl.
számlák) és elküldeni az emaileket. Minden email küldésről egy küldési
bizonylatot hoz létre a program.

A küldési bizonylat tartalmazza, hogy ki, mikor, mit küldött ki
email-en.

![](media/image9.png){width="5.375in" height="2.8472222222222223in"}

A képernyőn induláskor rögtön megjelenik a felhasználó kódja szürkén és
megkezd a program az adott felhasználó számára egy új küldési
bizonylatot. Ha már korábban megnyitotta küldési bizonylat képernyőt, és
van egy rögzítés alatti állapotú bizonylat, akkor azt nyitja meg a
program.

A küldési bizonylat fejrészében csak a Megjegyzés mező írható, az összes
többi mezőt a program tölti automatikusan.

A küldés időpontja akkor kerül kitöltésre, ha a küldési bizonylaton
szereplő összes e-mail kiküldésre került.

A Bizonylatszám mező azonnal, automatikusan töltődik. Ennek
előfeltétele, hogy az IFSZ AddOn Bizonylatszám hozzárendelésekben legyen
beállítva számozás a küldési bizonylatoknak. (Adminisztráció/IFSZ
keretrendszer menüpontban). A Bizonylatszám-kategóriánál a 'Küldési
bizonylatokat' kell választani. (Megjegyzés: ezt akár évente
újraindulóra is be lehet állítani.)

![](media/image10.png){width="5.395833333333333in"
height="2.451388888888889in"}

A küldési bizonylat létrehozásakor az Útvonal mezőbe belekerül az
EBIZPATH paraméterben megadott útvonalnak megfelelő mappa. Ezen a mappán
belül a program létrehoz minden küldési bizonylatnak egy külön
könyvtárat. Ebbe az almappába kerül legenerálásra az adott küldési
bizonylatban szereplő bizonylatok Crystal Reportos nyomtatási képe pdf
formátumban. Az Útvonal mező manuálisan nem módosítható. Az Útvonal mező
előtt lévő sárganyílra való lefúráskor meg is nyitja a program az adott
mappát a fájlkezelőben.

Státusz csak mentéskor mentődik; első értéke Rögzített. A küldési
bizonylatnak az alábbi státuszai lehetnek:

-   Rögzített: A küldési bizonylat 'Rögzített' státuszú, amíg nincs
    elküldve

-   Elküldve: A küldési bizonylatot elküldtük a címzett(ek)nek

-   Visszavonva: A küldési bizonylat a 'Visszavonás' nyomógomb
    megnyomása után visszavonás státuszba kerül. A 'Rögzített' státuszú
    bizonylatot lehet visszavonni.

A küldési bizonylathoz tételeket a Tételek hozzáadás nyomógombbal lehet
hozzárendelni.

#### Tételek hozzáadás

Tételek hozzáadása nyomógombra feljön a Bizonylat lista ablak, amelyben
ki lehet választani a küldendő bizonylatokat

![](media/image11.png){width="5.568450349956255in"
height="2.504666447944007in"}

A felhasználó a tételek feltöltését a Bizonylat lista képernyőn lévő
szűrésekkel valósítja meg.

Mire tudunk szűrni?:

-   Könyvelési dátumra vagy Létrehozási dátumra: dátum intervallumra
    lehet szűrni. Kötelező.

-   Partnerkód, Partnernév: Mind vagy egy partner kiválasztható
    (vevő-szállító)

-   Nyomtatva: Összes vagy Igen/Nem. Volt-e már nyomtatva az adott
    bizonylat.

-   Bizonylat típus: Összes vagy egy konkrét bizonylattípus.

    -   Szállítói megrendelés

    -   Vevői ajánlat

    -   Vevői rendelés

    -   Szállítólevél

    -   Kimenő számla

    -   Kimenő előlegszámla

    -   Kimenő jóváíró számla

    -   Kimenő helyesbítő számla

    -   Kimenő helyesbítő számla visszavonása

-   Létrehozó: A létrehozó felhasználó, értéklistából választható.

-   eBiz típus: Négy jelölőnégyzetről van szó, amelyik nincs bepiálva,
    azon típusú bizonylatok nem jelennek meg. Alapból „Papír alapú"
    nincs bepipálva. A „Papír alapú PDF", „Elektronikus -- nem
    hitelesített PDF" és „Elektronikus -- hitelesített PDF" lehetőségek
    be vannak pipálva.

-   Egyéb szűrések: A „..." nyomógombra kattintva egy külön ablak jön
    fel, amiben egyéb szűrési lehetőségek jelenhetnek meg. Itt van
    lehetőség konkrét bizonylatszámra szűrni, illetve a küldési státusz
    értékére is. Illetve ide kerülhet a többi, adott cégre jellemző
    egyedi szűrési feltétel.

Dátum szűrést kötelező megadni, a további szűréseknél csak ekkor
jelennek meg értékek. Amennyiben a dátum intervallum mindkét vége üres,
akkor a képernyőn nem jelenik meg semmilyen bizonylat. Tehát a szűrések
közül ezt kell először kitölteni.

A szűrési feltételeknek megfelelő bizonylatok jelennek meg a Bizonylat
lista képernyő alsó, táblázatos részében. Itt láthatóak a bizonylatok
legfőbb adatai: bizonylatszám, partner, bizonylattípus, létrehozás és a
könyvelés dátuma, bruttó összesen, a létrehozó felhasználó. Ezeken kívül
látható, hogy volt-e már nyomtatva a bizonylat és a küldési státusz.
Amennyiben a Küldési státusz mezőben a Elküldve érték szerepel, akkor az
adott bizonylat már szerepel egy korábbi küldési bizonylatban és a sárga
nyíllal lefúrva feljön a Küldési bizonylatok listája. Itt meg lehet
tekinteni a korábbi küldés adatait.

![](media/image12.png){width="5.368055555555555in" height="3.6875in"}

A Bizonylat lista képernyőn a leszűrt bizonylatok előtt chekbox-szal
tudjuk jelölni mely tételek kerüljenek beemelésre.

A leszűrt eredményhalmaz előtt mindig egyből ki van jelölve az összes
bizonylat; feltételezve, hogy a felhasználó pontosan le tudja szűrni
kinek, mit akar kiküldeni. Ezt persze lehet még ellenőrizni, és kivenni
a pipát azok elől, amelyeket mégsem akarunk elküldeni.

Egy küldési bizonylatra többféle bizonylattípushoz tartozó bizonylatot
ki lehet választani.

A Bizonylat lista ablakon OK-t nyomva, visszkerülünk a Küldési bizonylat
képernyőre, ahova a program beemelte az összes kiválasztott bizonylatot.
Még ekkor is lehetőségünk van arra, hogy kitöröljük a felesleges
bizonylatokat. Vagy az adott bizonylatot kijelölve először a Delete
gombot megnyomva a billentyűzeten, majd az Aktualizálást a képernyön.
Vagy az Összes tétel törlése gombot megnyomva a képernyőn.

Ezt követően a Küldési bizonylat képernyőn meg tudjuk nézni és
kiválasztani a nyomtatási formátumokat, illetve meg tudjuk adni az
e-mail címzettjét.

#### Nyomtatási képek kiválasztása

Miután beemelte a program az elküldendő bizonylatokat, kiválasztja az
SAPB1-beli alapértelmezésnek megfelelő nyomtatási formátumot
(felhasználó-partner). A Nyomt. formátum mezőben látszik a kiválasztott
nyomtatási kép, amelyet a felhasználó módosíthat, de csak Crystal
Report-os nyomtatási képet engedünk kiválasztani.

Az a lehetőség, hogy az alapértelmezett nyomtatási képet módosíthatja a
felhasználó, jogosultsági beállításhoz van kötve. Ha a
„EBIZPRINTLAYOUTMOD" nevű paraméter (\@IFSZ_PARAMETERS táblában) nincs
megadva, vagy I-re van állítva, akkor biztosan van lehetőség módosítani
a nyomtatási formátumot. Ha „N" az értéke, akkor viszont nem módosítható
az alapértelmezett formátum. Kivétel azok a felhasználók, aki
superuserek, vagy jogosultságot kapott az ugyanilyen nevű
„EBIZPRINTLAYOUTMOD" szerepkörhöz.

Az eBIZ modul csak Crystal Reportos nyomtatási képeket tud kiküldeni.
(OLE DB adatforrás legyen megadva a Crysatl Report-ban.)

Amennyiben a Nyomt. kép mező üresen jön fel, ez azt jelenti,hogy a
program az adott bizonylattípushoz nem talált alapértelmezett Crystal
Report-os nyomtatási képet, így ezt a bizonylatot nem fogja tudni
kiküldeni.

![](media/image13.png){width="3.8402777777777777in"
height="3.0972222222222223in"}

#### Email szövegének, tárgyának módosítása

Amennyiben a paraméterek között engedélyezve van a e-mail tárgy és
szövege a küldési bizonylaton is módosítható (EBIZTEMPLMOD). A küldési
bizonylaton már nem jelenik meg egy nagyobb szerkesztő mező, ezért azt
javasoljuk, hogy a szükséges módosításokat inkább az a-mail sablonok
beállításainál tegyék meg.

Amennyiben a paraméter nem engedélyezi ezeknek a mezőknek a módosítását,
akkor ezek a mezők szürkén jelennek meg. A nyomtatási formátumhoz
hasonlóan „EBIZTMPLMOD" szerepkör is létezik, ezért aki superuser, vagy
külön megkapta ezt a jogosultságot, azok az „EBIZTMPLMOD" paramétern „N"
értéke esetén is fogják tudni módostani a tárgyat és a szöveget.

#### Címzettek nyomógomb

A címzettek gombot megnyomva lehet megadni, hogy kinek küldjük el az
e-mailt.

A címzetteket beteszi a program a Küldési bizonylat tételrészének az
E-mail mezőjébe. Az adott ÜP-hez rendelt tárgyalópartnerek közül azoknak
az e-mail címét teszi oda, akiknél az E-biz címzett név ki van töltve. A
levélben ezt a nevet használja a program megszólításként. Amennyiben
több tárgyalópartnernél meg van adva az E-biz név, akkor az összes ilyen
tárgyalópartnert beteszi címzettként a program.

![](media/image14.png){width="5.597222222222222in"
height="3.6597222222222223in"}

Emellett a Címzettek nyomógombot megnyomva további tetszőleges e-mail
címekre küldhetjük még el a levelet, vagy akár törölhetünk is az
címzettek közül.

![](media/image15.png){width="3.9097222222222223in"
height="2.6180555555555554in"}

Az előző két objektumhoz hasonlóan a címzettek módosítására is
kialakítható jogosultsági rendszer. A paraméter és a szerepkör neve
„EBIZADDRMOD". „N" értéke esetén nem módosíthatók a címzettek, kivéve
annak, aki superuser, vagy külön meg lett adva neki ez a jogosultság.

#### Generálás és küldés

Ha a felhasználó már véglegesítette a bizonylatot akkor jöhet a „Csak
generálás" és a „Generálás és Küldés" nyomógomb megnyomása.

A „Generálás és Küldés" gombra való kattintáskor a következő üzenetet
kapjuk:

![](media/image16.png){width="2.6458333333333335in"
height="1.3333333333333333in"}

Igenlő válasz esetén a „Generálás és Küldés"funkcióval egyszerre készíti
el a progrm az adott bizonylat nyomtatási képét (pdf fájl), azt ellátja
a szükséges elektronikus aláírással (amennyiben ez a funkció be van
állítva), és küldi el a pdf-et tartalmazó e-mailt.

Először ellenőrizi a program, hogy a felhasználóhoz megadott email
authentikáció működik-e (fogunk-e tudni levelet küldeni). Tehát be van-e
állítva egy megfeleő postafiók. Ha nem érjük el a fiókot, akkor erről
tájékoztatja a felhasználót, aki nem tud továbblépni.

![](media/image17.png){width="4.159722222222222in"
height="1.4097222222222223in"}

Ha megvan az elérés a postafiókhoz, akkor bizonylat soronként egy
tranzakcióban a következő végzi el a program:

-   legenerálja és elmenti a pdf-eket (a küldési bizonylat fejben
    látható útvonalra),

-   az EBIZATC paraméter „I" értéke azt jelzi, hogy a csatolmányokat is
    küldeni kívánjuk, akkor a pdf-be beágyazza a számla csatolmányait.

-   amennyiben be van állítva, hogy a pdf elektronikus aláírással legyen
    ellátva (EBIZSRV paraméterben meg van adva az aláíró szolgáltatás
    elérhetősége), valamint az adott bizonylat eBiz típusa „H --
    Elektronikus hitelesített PDF", akkor elkészül a pdf elektronikus
    aláírással ellátott változata.

-   elkészíti az email-t és kiküldi a címzetteknek

-   beírja be a kiküldött fájl nevét a sorokba, kitölti a Fájl mezőt

-   módosítja be a küldési-bizonylat tételeibe a státuszt: Elküldve-re.

-   a bizonylat 'Nyomtatott' lesz és növeli a példányszámot

Ha sikerült az összes sort feldolgozni és elküldeni, akkor mindegyik sor
státusza 'Elküldve' lesz, ezután a küldési bizonylat fej szinten is
'Elküldve' státuszú lesz.

A legenerált nyomtatási képek fájlneve a bizonylatszámot, majd a
generálás időbélyegét fogja tartalmazni, végül a .pdf kiterjesztést. Ezt
lehetőség van felülbírálni az EBIZFILENAME paraméter beállításával. A
fájl neve akkor az lesz, ami itt paraméterként meg van adva, de

-   ha \<docnum\>-ot tartalmaz, azt lecseréljük a bizonylatszámra,

-   a \<timestamp\>-et az aktuális időbélyegre

-   a \<cardcode\>-ot a partner kódjára

A „Generálás és Küldés" többféle okból meghiúsulhat:

-   Nincs megfelelő Crystal Reportos nyomtatási kép:

![](media/image18.png){width="3.0625in" height="1.4444444444444444in"}

-   A bizonylathoz nincs egy címzett sem megadva:

![](media/image19.png){width="3.673611111111111in"
height="1.4513888888888888in"}

Amennyiben a folytatás mellett döntünk, a helyes bizonylatokat elküldi a
rendszer és a végén kapunk egy üzenetet a helyes és sikertelen e-mail
küldésekről.

![](media/image20.png){width="3.8958333333333335in" height="1.6875in"}

A sikeresen elküldött bizonylatok státusza Elküldve lesz és a Küldési
időpontot mezőt is kitölti a rendszer. A sikertelen bizonylatok státusza
Rögzített marad. Ekkor magának a küldési bizonylatnak sem változik a
státusza, ez is Rögzített marad. Ebben az esetben vagy javítjuk a hibát
(pl. adunk meg címzettet), vagy kitöröljük a bizonylatot a küldési
bizonylatról.

![](media/image21.png){width="5.416666666666667in"
height="2.8541666666666665in"}

#### Csak generálás

Ekkor csak kigeneráljuk a tételben lévő bizonylatok pdf-jeit a
létrehozott mappába megtekintés céljából, hogy jó nyomtatási képet
rendeltünk-e a bizonylathoz. Ez a pdf nem tartalmazza sem az esetleges
csatolmányokat, sem az elektronikus aláírást.

##### Küldési bizonylat fejrész kitöltési útmutató

+------------------+-------------------+-----------------------------+
| **Mező**         | **Kitöltési mód** | **Tartalom**                |
+------------------+-------------------+-----------------------------+
| Felhasználó      | Automatikus       | A küldési bizonylatot       |
|                  |                   | megnyitó felhasználó kódja  |
+------------------+-------------------+-----------------------------+
| Küldés időpontja | Automatikus       | Az utolsó e-mail            |
|                  |                   | kiküldésének időpontja.     |
+------------------+-------------------+-----------------------------+
| Bizonylatszám    | Automatikus       | A bizonylatszámozást        |
|                  |                   | előzetesen be kell állítani |
|                  |                   | az IFSZ addon               |
|                  |                   | Bizonylatszámozás részében  |
+------------------+-------------------+-----------------------------+
| Státusz          | Automatikus       | Lehetséges értékei:         |
|                  |                   |                             |
|                  |                   | -Rögzített                  |
|                  |                   |                             |
|                  |                   | -Elküldve                   |
|                  |                   |                             |
|                  |                   | -Visszavonva                |
+------------------+-------------------+-----------------------------+
| Megjegyzés       | Opcionális        | Tetszőleges megjegyzés      |
+------------------+-------------------+-----------------------------+
| Útvonal          | Automatikus       | A generálandó fájlok        |
|                  |                   | elérési útvonalán belül az  |
|                  |                   | adott küldési bizonylat     |
|                  |                   | mappája                     |
+------------------+-------------------+-----------------------------+

##### Küldési bizonylat tételrész kitöltési útmutató

  -------------------- ------------------------------ -----------------------------------------------------------------------------------------------------------------
  **Mező**             **Kitöltési mód**              **Tartalom**
  Sor                  Automatikus, nem módosítható   Sorszám
  Biz.típus            Automatikus, nem módosítható   Bizonylat típus
  Bizonylatszám        Automatikus, nem módosítható   Bizonylatszám
  ÜP.kód               Automatikus, nem módosítható   Partnerkód
  ÜP.neve              Automatikus, nem módosítható   Partnernév
  Nyomt.formátum       Automatikus, módosítható       Crystal Report-os nyomtatási formátum. Automatikusan a SAPB1 alapértelmezés szerinti, de módosítható
  E-mail               Automatikus                    Alapértelmezetten az ÜP-hez rendelt tárgyalópartnerek e-mail címe, ahol az E-biz címzett név mező ki van töltve
  Fájl                 Automatikus                    A generálás után itt lehet megtekinteni az adott bizonylat nyomtatási képét pdf-ben
  Email tárgya         Automatikus                    Paraméter vezérli, hogy módosítható-e. A hozzárendelt e-mail sablon tárgya
  Email szövegtörzse   Automatikus                    Paraméter vezérli, hogy módosítható-e. A hozzárendelt e-mail sablon tárgya
  Státusz              Automatikus                    Lehetséges értékei: Rögzítve, Elküldve.
  Küld.időpont         Automatikus                    Az e-mail küldésének pontos időpontja
  -------------------- ------------------------------ -----------------------------------------------------------------------------------------------------------------

##### Bizonylat lista képernyő kitöltési útmutató

  ----------------------------------------- ------------------- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  **Mező**                                  **Kitöltési mód**   **Tartalom**
  Könyvelési dátum vagy Létrehozási dátum   Kötelező            Szűrő paraméter. Vagy könyvelési dátum vagy létrehozási dátum választható. Dátumintervallumot kell megadni. Ha mindkét intervallum üres, nem jelennik meg egyetlen bizonylat sem.
  Partnerkód, partnernév                    Opcionális          Szűrő paraméter. Értéklistából választható
  Nyomtatva                                 Opcionális          Szűrő paraméter. Lehetséges értékei: Összes, Igen, Nem.
  Bizonylat típus                           Opcionális          Szűrő paraméter. Értéklistából választható
  Létrehozó                                 Opcionális          Szűrő paraméter. Értéklistából választható
  Kiválasztó checkbox                       Kötelező            A leszűrt tételek kiválasztására szolgál. Alapértelmezetten az össze ki van jelölve. Az össze kijelölést a fejlécre való kattintással lehet kivenni.
  Bizonylatszám                             Automatikus         Bizonylatszám
  ÜP-kód                                    Automatikus         ÜP-kód
  ÜP-név                                    Automatikus         ÜP-név
  Biz.típus                                 Automatikus         Bizonylat típus
  Létr. dátuma                              Automatikus         Létrehozás dátuma
  Könyv.dátum                               Automatikus         Könyvelési dtum
  Bruttó összesen                           Automatikus         Bruttó összesen
  Létrehozó                                 Automatikus         Létrehozó felhasználó
  Nyomtatva                                 Automatikus         Volt-e már nyomtatva a bizonylat. Lehetséges értékei: Igen/Nem.
  Küldés státusz                            Automatikus         Szerepel-e már küldési bizonylaton az adott bizonylat. Ha üres, akkor nem. Elküldve érték esetén igen. Ekkor a Küldési bizonylatok listájára lehet lefúrni.
  ----------------------------------------- ------------------- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

**Küldési bizonylat nyomógombok**

  ---------------------- -------------------------------------------------------------
  **Nyomógomb**          **Tartalom**
  Tételek hozzásadás     Bizonylatok kiválasztására szolgál
  Összes tétel törlése   A kiválasztott összes bizonylat törlésére szolgál
  Visszavonás            A küldési bizonylatot lehet vele visszavonni
  Címzettek              Az e-mail címzettjeit lehet ezzel megadni
  Generálás és küldés    A bizonylat nyomtatási képek generálása és az email küldése
  Csak generálás         Csak a nyomtatási képek generálása, e-mail küldés nélkül.
  Aktualizáls/OK         A módosítások elmentése.
  Mégsem                 Képernyőről való kilépés.
  ---------------------- -------------------------------------------------------------

