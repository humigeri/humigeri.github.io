﻿### Csatolmányok

#### Bizonylat csatolmányok küldése

A bizonylatok küldése során szükség lehet különböző csatolmányok
(szállítólevél, teljesítési igazolás, megrendelés, stb.) az adott
bizonylattal való egyidejű elküldésére.

A mellékletek csatolása a küldendő bizonylatok középső részének
„Mellékletek" fülén tallózott és csatolt fájlok adott bizonylattal való
küldését jelenti.

A „Tallózás" gombra kattintva ki tudjuk választani az egyes
csatolmányokat könyvtárunkból, a tallózott fájl neve fog az eBiz
Add-onnal történő küldés során a küldött bizonylat mellékletének
fájlneveként megjelenni. Fontos, hogy a küldési bizonylat elkészítése
előtt a küldendő mellékleteket tallózzuk be az adott bizonylatokhoz, ha
azt korábban a bizonylat elkészítésekor nem tettük meg.

![](media/image26.png){width="5.404861111111111in"
height="1.0472222222222223in"}

A A Mellékletek fülön csatolt dokumentumok eBiz küldését paraméterben
kell engedélyezni: amennyiben az IFSZ paraméterekben az EBIZATC nevű
paraméter értéke „I", engedélyezett a csatolmányok küldése, „N" esetén a
Mellékletek fülön csatolt fájlok nem kerülnek elküldésre.

A csatolmányok a küldött PDF formátumú bizonylatba beágyazott PDF
fájlként kerülnek továbbításra, melyek listája PDF olvasó alkalmazás
segítségével a Csatolmányok ikonra kattintva jeleníthető meg. A
beágyazott csatolmányokról bővebb tájékoztatás a következő URL-en érhető
el:
https://helpx.adobe.com/hu/acrobat/using/links-attachments-pdfs.html\#open_save_or_delete_an_attachment

![](media/image27.png){width="3.9722222222222223in"
height="2.3402777777777777in"}

Érdemes a bizonylatokat fogadó partnerek figyelmét felhívni arra, hogy a
küldött bizonylatok beágyazott mellékleteket tartalmazhatnak. Erre
lehetséges megoldás az e-mail sablonok szövegtörzsében megfogalmazott
figyelmeztetés. (Az e-mail sablonok készítéséről bővebben: *E-mail
sablonok* fejezet)

A nyomtatási képek az EBIZPATH paraméterben megadott útvonalra történő
generálásakor a nyomtatási képek szintén a beágyazott mellékletekkel
együtt kerülnek mentésre, így később az egyes bizonylatokhoz csatolt
dokumentumok bármikor megtekinthetők a PDF fájlok beágyazott
csatolmányaiként.

#### Online számla XML csatolása

Speciális lehetőség, hogy akár a NAV online számla rendszerébe elküldött
xml dokumentumot is becsatolhatjuk a PDF-be.

Ez úgy működik, hogy egyrészt az online számla szolgáltatás az elküldött
xml-t egy külön mappába másolja. Ez a külön mappa az EBIZXMLPATH
paraméterben megadandó. Ezt az útvonalat az online számla szolgáltatás
el kell, hogy tudja érni a saját jogosultságaival.

Az eBiz modul oldalon pedig a kimenő számla kiküldésénél a program
megkeresi ebben a mappában a megadott számlához tartozó xml-t. Ezt pedig
ugyanolyan módon csatolja be a PDF-be, ahogy a számla csatolmányait.

