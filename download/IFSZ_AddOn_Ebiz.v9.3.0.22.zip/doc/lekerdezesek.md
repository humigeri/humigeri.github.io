﻿#### Bizonylatok listája

*Elérési útvonal: Kimenő levélküldés/Bizonylatok listája*

Ezen a képernyőn lehet a felső blokkban lévő szűrőparamétereket megadva
lekeresni a korábbi küldésekben szereplő bizonylatokat. A dátumszűrési
intervallum megadása kötelező.

A ![](media/image22.png){width="0.4097222222222222in" height="0.3125in"}
nyomógombra kattintva plusz, akár az adott cégnél egyedi szűrőfeltételek
adhatók meg.

![](media/image23.png){width="5.409722222222222in"
height="4.520833333333333in"}

A szűrőfeltételek megadása után a képernyőn láthatóak az adott bizonylat
adatai, pl. a bizonylatszám mezőben egy adott számlaszámot beírva
megtekeinthető, hogy ki lett-e küldve az adott számla emailben.

![](media/image11.png){width="5.568450349956255in"
height="2.504666447944007in"}

Amennyiben a Küldési státusz oszlopban az szerepel, hogy Kiküldve, akkor
a sárga nyílra kattintva meg tudjuk nézni az adott küldés adatait a
Küldési bizonylatok listája képernyőn.

![](media/image24.png){width="5.416666666666667in"
height="3.048611111111111in"}

Ezen a képernyőn lehetőségünk van a Bizonylatszám mezőre lefúrva
megnézni, hogy az adott küldési bizonylaton milyen tételek szerepeltek,
illetve az Útvonal mezőben lévő fájlra lefúrva pedig az adott bizonylat
pdf képét tudjuk megtekinteni.

#### Küldési bizonylat lista

*Elérési útvonal: Kimenő levélküldés/Küldési bizonylatok lista*

Ezen a képernyőn lehet megtekintei az összes eddigi küldési bizonylat
főbb adatait: felhasználó, küldés időpontja, státusza, mappája.

![](media/image25.png){width="5.465277777777778in"
height="3.7708333333333335in"}

