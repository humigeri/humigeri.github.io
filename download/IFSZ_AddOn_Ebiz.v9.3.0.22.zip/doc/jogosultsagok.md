﻿  -------------------- -----------------------------------------------------------------------------------------------------------------------------------------
  **Szerepkör**        **Tartalom**
  F_EOA                A „Kimenő levélküldés / Postafiókok" menüponthoz való jogosultság.
  F_EOB                A „Kimenő levélküldés / E-mail sablonok" menüponthoz való jogosultság.
  F_EOH                A „Kimenő levélküldés / Küldési bizonylat" menüponthoz való jogosultság.
  F_EOHLIS             A „Kimenő levélküldés / Küldési bizonylat lista" menüponthoz való jogosultság.
  F_SZLKIV             A „Kimenő levélküldés / Bizonylatok listája" menüponthoz való jogosultság.
  EBIZADDRMOD          eBiz levélküldésnél címzettet lehet-e módosítani. (lásd: „Email szövegének, tárgyának módosítása" fejezet)
  EBIZPRINTLAYOUTMOD   eBiz levélküldésnél a nyomtatási kép formátumát lehet-e módosítani. (lásd „Nyomtatási képek kiválasztása" fejezet)
  EBIZTEMPLMOD         Email sablon által megadott tárgy és szövegtörzs módosítható-e kiküldés előtt? (lásd: „Email szövegének, tárgyának módosítása" fejezet)
  -------------------- -----------------------------------------------------------------------------------------------------------------------------------------

