﻿### Átadási (Implementációs) dokumentum

### SAP üzletág

#

# Projekt:

# IFSZ eBiz modul - Email sablonok

## Ügyfél: -

## Verziószám: v20

#

### Fejezetek

[Üzleti igény](#uzleti_igeny)  
[Megoldás összefoglalása](#megoldas)  
[Biztonság, jogosultságok](#jogosultsag)  
[Alkalmazás felhasználói felülete](#felulet)  
[Funkciók](#funkciok)  
[Beállítások, paraméterek](#parameterek)  
[Adatbázis objektumok](#dbobj)  
[Alkalmazás objektumok](#alkobj)  
[Érintett területek](#erintett)  
[Ismert problémák](#problemak)  
[Telepítés](#telepites)  
[Egyéb információk](#egyeb)  
[Projekt résztvevői](#resztvevo)  
[Kapcsolódó dokumentumok](#kapcsdok)  
[Verziótörténet](#verzio)  

#########

### Üzleti igény {#uzleti_igeny}

Jelen modulfejlesztés azon célból valósult meg, hogy az SAP Business One
rendszerből (továbbiakban SAPB1) akár tömegesen lehessen kiküldeni
emailben bizonylatokat.

A jogosult felhasználó egy formon leszűri, hogy milyen típusú
dokumentumokat akar kiküldeni. A leszűrt dokumentumokból kijelöli a
valóban küldendő bizonylatokat, ezt követően egy gombnyomásra
legenerálja és elküldi azokat a partnernek. A küldési dokumentum
bizonylat mentésre kerül, ezáltal lekérdezhető, hogy melyik bizonylat
mikor és milyen címre lett elküldve.

Az eBIZ modul csak Crystal Reportos nyomtatási képeket tud kiküldeni

Jelen dokumentum az IFSZ eBIZ modul felhasználói szintű leírását
tartalmazza.

### Megoldás összefoglalása {#megoldas}

*Elérési útvonal:Kimenő levélküldés/E-mail sablonok*

Az egyes bizonylattípusokhoz létre kell hozni egy email sablont, amely
tartalmazza az e-mail tárgyát, szövegét.

Amennyiben kiküldésre kerül pl. kimenő számla és jóváírás bizonylat is,
akkor két külön e-mail sablont kell felvenni.

Egy bizonylattípushoz akár több e-mail sablont is létre lehet hozni.

Az e-mail sablonokhoz nyelv is rendelhető. Amennyiben azt szeretnénk,
hogy nyelvenként eltérő szövegezésű levelek kerüljenek kiküldésre, akkor
külön sablont kell felvenni, megadva a kívánt nyelvet.

A képernyő alsó régiójában akár konkrét parnerekhez is hozzárendelhetjük
a sablonokat.

![](media/image6.png){width="5.361111111111111in"
height="2.9722222222222223in"}

E-mail sablonok használata a bizonylatküldés során:

1.  Ellenőrzi a program, hogy talál-e az adott bizonylat partneréhez és
    az adott bizonylattípushoz e-mail sablont. Amennyiben talál konkrét
    partnerhez rendelt megfelelő típusú sablont, akkor azt fogja
    alkalmazni.

2.  Ha nincs ilyen beállítva, akkor megnézi, hogy az adott bizonylatnál
    a Logisztika fülön a Nyelv mezőben mi van beállítva. (Ez a nyelv
    megöröklődik az ÜP-törzsbeli nyelvből). Ha talál a megfelelő
    nyelvhez és bizonylattípushoz sablont, akkor azt fogja alkalmazni.
    Ha több ilyen sor is van, akkor az alapértelmezettnek bejelölt lesz
    a küldésnél használva.

3.  Ha nem talál a program az előző pontnak megfelelő beállítást, akkor
    megnézi, hogy az adott bizonylattípushoz (nyelv és partner nélkül)
    van-e beállítva e-mail sablon. Amennyiben több is van, akkor az
    alapértelmezettként megjelöltet használja majd a küldési
    bizonylaton.

Alapértelmezett sablont lehet beállítani bizonylattípusonként, illetve
azon belül nyelvenként. Mindkét esetben csak egy e-mail sablon lehet
alapértelmezett. Egyébként hibaüzenetet küld a program.

![](media/image7.png){width="2.7777777777777777in"
height="1.1597222222222223in"}

Amennyiben egy tévesen létrehozott sablont törölni szeretnénk, akkor azt
adott sort kijelölve és a Delete gombot megnyomva tudjuk ezt megtenni.
Ezt követően az Aktualizálást is meg kell nyomni. Amennyiben volt
partner megadva a sablonban, akkor először azt a hozzárendelést kell
törölni.

A képernyő jobb alsó sarkában kiemelésre kerültek a sablon kód, e-mail
tárgya és e-mail szövegtörzse. Ezekben a mezőkben látható a felső
régióban kijelölt sablonok fő adatai, és akár szerkeszthetjük is itt
őket. Amennyiben beleírunk valamit, akkor az rögtön belekerül a fenti
sorba is. Tehát a szerkesztés mindkét helyen történhet.

A HTML mezőt Igenre állítva lehetőségünk van formázott levelet küldeni.
Ekkor a szövegtörzse mezőben HTML kódot kell megadni. Az addon nem
tartalmaz HTML szerkesztőt. Az előzetesen összeállított HTML kódot kell
idemásolni, ha ezt kívánjuk használni.

Amennyiben a ez a mező Nem-re van állítva, akkor egyszerű szöveges,
formázás nélküli levelet tudunk küldeni.

Az e-mail tárgya, szövegtörzse mezőben a következőket megadva a program
behelyettesíti az adott bizonylat adatait:

\#docnum esetén a bizonylatszám,

\#partner esetén a partner neve,

\#partnerkod esetén a partner kódja,

\#konyvdatum esetén a könyvelési dátum,

\#fizhatido esetén a fizetési határidő,

\#cegnev esetén a SAPB1 Cégadatoknál beállított cég neve,

\#fhonev esetén a küldési bizonylatot készítő felhasználó neve jelenik
meg.

##### Kitöltési útmutató

  --------------------- ------------------- -------------------------------------------------------------------------------------------------------------------
  **Mező**              **Kitöltési mód**   **Tartalom**
  Sablon kód            Kötelező            Az adott sablon kódja
  Bizonylattípus        Kötelező            Ki kell választani, hgy melyik bizonylattípushoz rögzítünk em-mail sablont.
  E-mail tárgya         Kötelező            Az e-mail tárgyában szereplő szöveg
  E-mail szövegtörzse   Kötelező            Az e-mail szövegtörzse vagy egyszerű szöveges formátumban, vagy HTML-ként
  HTML?                 Kötelező            Lehetséges értékei: Igen/Nem. HTML-ként vagy egyszerű szöveges fájlként kezeljük az e-mail szövegtörzsét
  Nyelv                 Opcionális          A sablon milyen nyelvű bizonylatoknál legyen értelmezve
  Alapértelmezett?      Kötelező            Lehetséges értékei: Igen/Nem. Alapértelmezett-e a sablon, bizonylatípus, illetve bizonylattípus és nyelv szinten.
  ÜP-kód                Opcionális          Egy sablont hozzá lehet rendelni partnerekhez az ÜP-kódot kiválasztva.
  ÜP neve               Opcionális          A kiválasztott partner neve.
  --------------------- ------------------- -------------------------------------------------------------------------------------------------------------------

Az e-mailek küldése során lehetőségünk van visszaigazolást kérni az
e-mailek megérkezéséről. Ezt az IFSZ paraméterekben található EBIZDSN
paraméter „I" értékével adhatjuk meg. Amennyiben nem kérünk
visszaigazolást a megérkezésről, a paraméter értéke „N" legyen.

Ha az e-mailek elolvasásáról is szeretnénk visszajelzést kapni a
fogadótól, azt az EBIZRRR paraméter „I" értékével definiálhatjuk, „N"
érték esetén az olvasásról nem kérünk visszaigazolást.

Az EBIZCC paraméter értékét ha megadjuk, akkor minden egyes elküldött
levél az itt megadott email címre (címekre) is el fog menni.Az EBIZBCC
ugyanígy működik, de ez a titkos másolatra vonatkozik.

## Biztonság, ogosultságok {#jogosultsag}

  -------------------- -----------------------------------------------------------------------------------------------------------------------------------------
  **Szerepkör**        **Tartalom**
  F_EOA                A „Kimenő levélküldés / Postafiókok" menüponthoz való jogosultság.
  F_EOB                A „Kimenő levélküldés / E-mail sablonok" menüponthoz való jogosultság.
  F_EOH                A „Kimenő levélküldés / Küldési bizonylat" menüponthoz való jogosultság.
  F_EOHLIS             A „Kimenő levélküldés / Küldési bizonylat lista" menüponthoz való jogosultság.
  F_SZLKIV             A „Kimenő levélküldés / Bizonylatok listája" menüponthoz való jogosultság.
  EBIZADDRMOD          eBiz levélküldésnél címzettet lehet-e módosítani. (lásd: „Email szövegének, tárgyának módosítása" fejezet)
  EBIZPRINTLAYOUTMOD   eBiz levélküldésnél a nyomtatási kép formátumát lehet-e módosítani. (lásd „Nyomtatási képek kiválasztása" fejezet)
  EBIZTEMPLMOD         Email sablon által megadott tárgy és szövegtörzs módosítható-e kiküldés előtt? (lásd: „Email szövegének, tárgyának módosítása" fejezet)
  -------------------- -----------------------------------------------------------------------------------------------------------------------------------------

## Alkalmazás felhasználói felülete {#felulet}

## Funkciók {#funkciok}

## Beállítások, paraméterek {#parameterek}

## Adatbázis objektumok {#dbobj}

## Alkalmazás objektumok {#alkobj}

## Érintett területek {#erintett}

## Ismert problémák {#problemak}

## Telepítés {#telepites}

## Egyéb információk {#egyeb}

## Projekt résztvevői {#resztvevo}

## Kapcsolódó dokumentumok {#kapcsdok}

## Verziótörténet {#verzio}


