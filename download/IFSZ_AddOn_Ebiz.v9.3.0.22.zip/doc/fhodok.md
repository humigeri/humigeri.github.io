﻿## Bevezetés

Jelen modulfejlesztés azon célból valósult meg, hogy az SAP Business One
rendszerből (továbbiakban SAPB1) akár tömegesen lehessen kiküldeni
emailben bizonylatokat.

A jogosult felhasználó egy formon leszűri, hogy milyen típusú
dokumentumokat akar kiküldeni. A leszűrt dokumentumokból kijelöli a
valóban küldendő bizonylatokat, ezt követően egy gombnyomásra
legenerálja és elküldi azokat a partnernek. A küldési dokumentum
bizonylat mentésre kerül, ezáltal lekérdezhető, hogy melyik bizonylat
mikor és milyen címre lett elküldve.

Az eBIZ modul csak Crystal Reportos nyomtatási képeket tud kiküldeni

Jelen dokumentum az IFSZ eBIZ modul felhasználói szintű leírását
tartalmazza.

## Az IFSZ eBIZ modul üzleti funkciói

### Menüpontok

A SAPB1 addon külön addonként került telepítésre, az AddOn-kezelőből
indítható, akár automatikus indításúra is ütemezhető.

*Elérési útvonal: Adminisztráció/Addonok/AddOn-kezelő*

![](media/image2.png){width="5.347222222222222in"
height="3.3958333333333335in"}

#### Funkciók

A modul a következő menüpontokből áll:

**Kimenő levélküldés**

-   Postafiókok

-   Email-sablonok

-   Küldési bizonylat

-   Küldési bizonylat lista

-   Bizonylatok listája

A modulban a szokásos IFSZ AddOn-os módszerekkel lehet új sort felvenni,
törölni, keresni, értéklistát kérni.

### Paraméterek

A \@IFSZ_PARAMETERS felhasználói táblában találhatjuk az eBiz modulban
használt paramétereket.

  -------------------- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  **Paraméter**        **Tartalom**
  EBIZADDRMOD          eBiz levélküldésnél címzettet lehet-e módosítani. (lásd: „Email szövegének, tárgyának módosítása" fejezet)
  EBIZATC              Csatoljuk-e a pdf-hez a számlához csatolt dolgokat? (lásd: „Generálás és küldés" fejezet)
  EBIZARCH             Archiv adatbázis neve
  EBIZARCHCHK          A napoknak a számát kell megadnunk, ahány naponként ismételten össze akarjuk hasonlítani az adatbázisba mentett fájlt a fájlrendszerbe mentettel
  EBIZARCHFRQ          Adjuk meg, hogy milyen gyakran (hány percenként) ellenőrizze az eBiz szolgáltatás, hogy lejárt-e már egy-egy fájl utolsó ellenőrzése úta „EBIZARCHCHK" nap.
  EBIZBCC              Az eBiz-zel elküldött levelek \"Titkos másolat\" mezőjébe ez kerül. (lásd: „E-mail sablonok" fejezet)
  EBIZCC               Az eBiz-zel elküldött levelek \"Másolat\" mezőjébe ez kerül. (lásd: „E-mail sablonok" fejezet)
  EBIZDSN              Küldjünk-e megérkezésről visszaigazolási kérelmet az email-lel? (I=Igen) (lásd: „E-mail sablonok" fejezet)
  EBIZFILENAME         eBiz generált pdf fájl nevének formátuma. (lásd: „Generálás és küldés" fejezet)
  EBIZINST             Ha értéke Y, vagy I, akkor történhet meg a felhasználói táblák, mezők telepítése. Erre persze csak akkor van szükség, ha ezek még nincsenek, vagy nincsenek teljes egészében feltelepítve.
  EBIZJOGMOD           Milyen módszerű jogosultságkezelés legyen. (ADDON, SBO) Gyakoribb az „ADDON", ekkor az \@IFSZ_USER_ROLES felhasználói táblában találjuk az addon jogait. „SBO" esetén pedig kiegészítő jogosultságként rögzítettük azokat.
  EBIZPATH             Kimenő nyomtatási képek fájl generálási helye. (lásd „Nyomtatási képek generálásának útvonala" fejezet)
  EBIZPATH_DOMAIN      Az eBiz útvonal eléréséhez használt domain. (lásd „Nyomtatási képek generálásának útvonala" fejezet)
  EBIZPATH_PASSWORD    Az eBiz útvonal eléréséhez használt jelszó. (lásd „Nyomtatási képek generálásának útvonala" fejezet)
  EBIZPATH_USER        Az eBiz útvonal eléréséhez használt felhasználónév. (lásd „Nyomtatási képek generálásának útvonala" fejezet)
  EBIZPRINTLAYOUTMOD   eBiz levélküldésnél a nyomtatási kép formátumát lehet-e módosítani. (lásd „Nyomtatási képek kiválasztása" fejezet)
  EBIZRRR              Küldjünk-e olvasási visszaigazolási kérelmet az email-lel? (I=Igen) (lásd: „E-mail sablonok" fejezet)
  EBIZSRV              Hitelesítést végző szolgáltatás címe. Pl.: <http://localhost:9111/> (lásd: „Tanúsítványok igénylése" fejezet)
  EBIZTEMPLMOD         Email sablon által megadott tárgy és szövegtörzs módosítható-e kiküldés előtt? (lásd: „Email szövegének, tárgyának módosítása" fejezet)
  EBIZXMLPATH          Kimenő nyomtatási képek online számla xml folder. (lásd: „Online számla XML csatolása" fejezet)
  -------------------- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

### Jogosultságok

  -------------------- -----------------------------------------------------------------------------------------------------------------------------------------
  **Szerepkör**        **Tartalom**
  F_EOA                A „Kimenő levélküldés / Postafiókok" menüponthoz való jogosultság.
  F_EOB                A „Kimenő levélküldés / E-mail sablonok" menüponthoz való jogosultság.
  F_EOH                A „Kimenő levélküldés / Küldési bizonylat" menüponthoz való jogosultság.
  F_EOHLIS             A „Kimenő levélküldés / Küldési bizonylat lista" menüponthoz való jogosultság.
  F_SZLKIV             A „Kimenő levélküldés / Bizonylatok listája" menüponthoz való jogosultság.
  EBIZADDRMOD          eBiz levélküldésnél címzettet lehet-e módosítani. (lásd: „Email szövegének, tárgyának módosítása" fejezet)
  EBIZPRINTLAYOUTMOD   eBiz levélküldésnél a nyomtatási kép formátumát lehet-e módosítani. (lásd „Nyomtatási képek kiválasztása" fejezet)
  EBIZTEMPLMOD         Email sablon által megadott tárgy és szövegtörzs módosítható-e kiküldés előtt? (lásd: „Email szövegének, tárgyának módosítása" fejezet)
  -------------------- -----------------------------------------------------------------------------------------------------------------------------------------

### Bizonylatszám kategóriák

  ------------------------------- -------------------------------------------------------------------------------------------------------
  **Bizonylatszám kategória**     **Tartalom**
  EMAILOUT -- Küldési bizonylat   Ebből fog osztani bizonylatszámot a küldési bizonylat dokumentum. (lásd: „Küldési bizonylat" fejezet)
  ------------------------------- -------------------------------------------------------------------------------------------------------

### Postafiók beállítások

*Elérési útvonal: Kimenő levélküldés/Postafiókok*

Ezen a törzsadat-formon tároljuk a szükséges postafiókok elérési
adatait.

A levélküldéshez be kell állítani legalább egy kimenő postafiókot,
amelyről kiküldi a rendszer az emaileket. Akár felhasználónkénti vagy
csoportonkénti kimenő postafiókokat is meg lehet adni.

![](media/image3.png){width="5.2858595800524935in"
height="3.547825896762905in"}

A jelszó nyomógombot megnyomva lehet megadni az adott postafiók
jelszavát.

![](media/image4.png){width="3.2291666666666665in"
height="2.173611111111111in"}

##### Kitöltési útmutató

  --------------------- ------------------- --------------------------------------------------------------------------------------------------
  **Mező**              **Kitöltési mód**   **Tartalom**
  Megnevezés            Kötelező            A postafiók törzsadat neve, a felhasználóknál ez alapján lehet hozzárendelni az SMTP postafiókot
  SMTP szerver          Kötelező            A levelező szerver címe
  SMTP port             Opcionális          A levelező szerver portja
  SMTP felhasználónév   Kötelező            SMTP szerver felhasználónév
  SSL?                  Kötelező            Amennyiben nem ssl kapcsolódás történik, akkor „Nem"-re állítsuk.
  Jelszó                Kötelező            Az SMTP felhasználó jelszava. Kódolva tároljuk.
  --------------------- ------------------- --------------------------------------------------------------------------------------------------

#### Postafiókok felhasználóhoz rendelése

*Elérési útvonal: Adminisztráció/Definíciók/Általános/Felhasználók*

A felhasználó törzsadatoknál a Kimenő postafiók felhasználói mezőben
lehet az előzőleg felvett postafiókot a felhasználókhoz rendelni. Így
felhasználónként beállítható kinél, milyen kimenő postafiókot fogunk
használni.

A program az email küldőjének azt az email-címet állítja, be, amelyik a
küldést végző felhasználóhoz az E-mail mezőben be van állítva. (Ez az
eBiz modul alapvető működése, de ha az adott cég ettől eltérő
email-címet akar használni, akkor arra is lehetőség van.)

![](media/image5.png){width="5.381944444444445in"
height="3.513888888888889in"}

### E-mail sablonok

*Elérési útvonal:Kimenő levélküldés/E-mail sablonok*

Az egyes bizonylattípusokhoz létre kell hozni egy email sablont, amely
tartalmazza az e-mail tárgyát, szövegét.

Amennyiben kiküldésre kerül pl. kimenő számla és jóváírás bizonylat is,
akkor két külön e-mail sablont kell felvenni.

Egy bizonylattípushoz akár több e-mail sablont is létre lehet hozni.

Az e-mail sablonokhoz nyelv is rendelhető. Amennyiben azt szeretnénk,
hogy nyelvenként eltérő szövegezésű levelek kerüljenek kiküldésre, akkor
külön sablont kell felvenni, megadva a kívánt nyelvet.

A képernyő alsó régiójában akár konkrét parnerekhez is hozzárendelhetjük
a sablonokat.

![](media/image6.png){width="5.361111111111111in"
height="2.9722222222222223in"}

E-mail sablonok használata a bizonylatküldés során:

1.  Ellenőrzi a program, hogy talál-e az adott bizonylat partneréhez és
    az adott bizonylattípushoz e-mail sablont. Amennyiben talál konkrét
    partnerhez rendelt megfelelő típusú sablont, akkor azt fogja
    alkalmazni.

2.  Ha nincs ilyen beállítva, akkor megnézi, hogy az adott bizonylatnál
    a Logisztika fülön a Nyelv mezőben mi van beállítva. (Ez a nyelv
    megöröklődik az ÜP-törzsbeli nyelvből). Ha talál a megfelelő
    nyelvhez és bizonylattípushoz sablont, akkor azt fogja alkalmazni.
    Ha több ilyen sor is van, akkor az alapértelmezettnek bejelölt lesz
    a küldésnél használva.

3.  Ha nem talál a program az előző pontnak megfelelő beállítást, akkor
    megnézi, hogy az adott bizonylattípushoz (nyelv és partner nélkül)
    van-e beállítva e-mail sablon. Amennyiben több is van, akkor az
    alapértelmezettként megjelöltet használja majd a küldési
    bizonylaton.

Alapértelmezett sablont lehet beállítani bizonylattípusonként, illetve
azon belül nyelvenként. Mindkét esetben csak egy e-mail sablon lehet
alapértelmezett. Egyébként hibaüzenetet küld a program.

![](media/image7.png){width="2.7777777777777777in"
height="1.1597222222222223in"}

Amennyiben egy tévesen létrehozott sablont törölni szeretnénk, akkor azt
adott sort kijelölve és a Delete gombot megnyomva tudjuk ezt megtenni.
Ezt követően az Aktualizálást is meg kell nyomni. Amennyiben volt
partner megadva a sablonban, akkor először azt a hozzárendelést kell
törölni.

A képernyő jobb alsó sarkában kiemelésre kerültek a sablon kód, e-mail
tárgya és e-mail szövegtörzse. Ezekben a mezőkben látható a felső
régióban kijelölt sablonok fő adatai, és akár szerkeszthetjük is itt
őket. Amennyiben beleírunk valamit, akkor az rögtön belekerül a fenti
sorba is. Tehát a szerkesztés mindkét helyen történhet.

A HTML mezőt Igenre állítva lehetőségünk van formázott levelet küldeni.
Ekkor a szövegtörzse mezőben HTML kódot kell megadni. Az addon nem
tartalmaz HTML szerkesztőt. Az előzetesen összeállított HTML kódot kell
idemásolni, ha ezt kívánjuk használni.

Amennyiben a ez a mező Nem-re van állítva, akkor egyszerű szöveges,
formázás nélküli levelet tudunk küldeni.

Az e-mail tárgya, szövegtörzse mezőben a következőket megadva a program
behelyettesíti az adott bizonylat adatait:

\#docnum esetén a bizonylatszám,

\#partner esetén a partner neve,

\#partnerkod esetén a partner kódja,

\#konyvdatum esetén a könyvelési dátum,

\#fizhatido esetén a fizetési határidő,

\#cegnev esetén a SAPB1 Cégadatoknál beállított cég neve,

\#fhonev esetén a küldési bizonylatot készítő felhasználó neve jelenik
meg.

##### Kitöltési útmutató

  --------------------- ------------------- -------------------------------------------------------------------------------------------------------------------
  **Mező**              **Kitöltési mód**   **Tartalom**
  Sablon kód            Kötelező            Az adott sablon kódja
  Bizonylattípus        Kötelező            Ki kell választani, hgy melyik bizonylattípushoz rögzítünk em-mail sablont.
  E-mail tárgya         Kötelező            Az e-mail tárgyában szereplő szöveg
  E-mail szövegtörzse   Kötelező            Az e-mail szövegtörzse vagy egyszerű szöveges formátumban, vagy HTML-ként
  HTML?                 Kötelező            Lehetséges értékei: Igen/Nem. HTML-ként vagy egyszerű szöveges fájlként kezeljük az e-mail szövegtörzsét
  Nyelv                 Opcionális          A sablon milyen nyelvű bizonylatoknál legyen értelmezve
  Alapértelmezett?      Kötelező            Lehetséges értékei: Igen/Nem. Alapértelmezett-e a sablon, bizonylatípus, illetve bizonylattípus és nyelv szinten.
  ÜP-kód                Opcionális          Egy sablont hozzá lehet rendelni partnerekhez az ÜP-kódot kiválasztva.
  ÜP neve               Opcionális          A kiválasztott partner neve.
  --------------------- ------------------- -------------------------------------------------------------------------------------------------------------------

Az e-mailek küldése során lehetőségünk van visszaigazolást kérni az
e-mailek megérkezéséről. Ezt az IFSZ paraméterekben található EBIZDSN
paraméter „I" értékével adhatjuk meg. Amennyiben nem kérünk
visszaigazolást a megérkezésről, a paraméter értéke „N" legyen.

Ha az e-mailek elolvasásáról is szeretnénk visszajelzést kapni a
fogadótól, azt az EBIZRRR paraméter „I" értékével definiálhatjuk, „N"
érték esetén az olvasásról nem kérünk visszaigazolást.

Az EBIZCC paraméter értékét ha megadjuk, akkor minden egyes elküldött
levél az itt megadott email címre (címekre) is el fog menni.Az EBIZBCC
ugyanígy működik, de ez a titkos másolatra vonatkozik.

### Küldési bizonylat

#### Bizonylatok eBiz típusa

Az eBiz modullal együtt kiegészítjük a bizonylat fejet és az üzleti
partner törzset is egy új felhasználói mezővel, ez az eBiz típus.
(U_EBIZ_TIPUS) Ez a mező 4 értéket vehet fel:

-   Papír alapú

-   Papír alapú PDF

-   Elektronikus -- nem hitelesített PDF

-   Elektronikus -- hitelesített PDF

![](media/image8.png){width="5.438579396325459in"
height="1.843477690288714in"}

Az beállítható az üzleti partnerre, ami aztán a bizonylat létrehozásakor
automatikusan öröklődik a létrehozott bizonylatra is. Amennyiben igény
van rá, egyéb szabályokat, ellenőrzéseket is be tudunk vezetni az eBiz
Típusra, annak bizonylatokon történő módosíthatóságára.

A „Papír alapú" jelenti azt, hogy ezt a bizonylatot hagyományos módon
akarjuk elküldeni az ügyfélnek. Nincs persze szigorú megkötés erre,
elküldhetjük az eBiz modullal is ezeket a bizonylatokat, viszont
alapértelmezetten meg sem jelennek a kiválasztó listában, csak akkor, ha
külön bepipáljuk ezt a jelölőnégyzetet is. Ha eBiz modulban küldjük,
akkor digitális aláírás készítése nélkül fog elmenni a levél.

A „Papír alapú -- PDF" esetén is hagyományos módon történik a számla
kézbesítése, viszont e mellett az eBiz modulban is küldünk emailt. Éppen
ezért alapértelmezetten listázzuk ezeket a bizonylatokat is, elküldéskor
azonban digitális aláírás nem kerül a PDF dokumentumra.

„Elektronikus -- nem hitelesített PDF" hasonló az előző típushoz.
Ilyenkor azonban nem küldünk hagyományos papír alapú számlát, csak az
eBiz modulból küldünk. Digitális aláírás ekkor sem kerül a PDF-re.

„Elektronikus -- hitelesített PDF": Itt sem küldjük hagyományos papír
alapon a számlát, de az eBiz modulból küldött PDF-re már digitális
aláírás kerül. Ez az egyetlen típus, amit aláírunk, ezért fontos, hogy a
küldendő bizonylaton az eBiz típus erre az értékre legyen állítva.

#### Nyomtatási képek generálásának útvonala

IFSZ paraméterekben az EBIZPATH paraméterben lehet megadni a küldendő
nyomtatási képek fájl-generálási helyét.

Ez akár lehet a SAPB1 attachment-hez beállított mappáján belül egy
almappa is (Így biztosított, hogy oda már van a felhasználóknak írás
joguk).

Ezen a mappán belül a program létrehoz minden küldési bizonylatnak egy
külön könyvtárat. A könyvtár neve tartalmazza a küldési bizonylatszámát,
a létrehozó felhasználó nevét és a küldési bizonylat létrehozásának
pontos időpontját. (pl.: \#00024_manager_20200427144416)

Ezáltak a paraméterekben megadott útvonalbeli mappán belül strukturáltan
helyezekednek el a küldési bizonylatokhoz tartazó almappák, amelyek
tartalmazzák az adott e-mail küldéshez tartozó bizonylatok nyomtatási
képét.

Alapban a programot futtató felhasználónak írási és olvasási joga is
kell, hogy legyen ehhez az útvonalhoz. Ez azonban biztonsági aggályokat
vethet fel. Éppen ezért lehetőség adtunk arra, hogy a program ne a
felhasználó nevében írjon, olvasson erről az útvonalról, hanem egy
központilag megadott fiókot használva. Ezt a központi felhasználónevet
az EBIZPATH_USER paraméterben lehet megadni, illetve az EBIZPATH_DOMAIN
paraméterbe a domain-t lehet írni. A felhasználóhoz tartozó jelszót az
EBIZPATH_PASSWORD paraméterbe kell beírni. Az első használat során a
program az EBIZPATH_PASSWORD értékét titkosítja, és visszaírja a
titkosított jelszót és egy „CRYPT:"előtagot. Ezt a titkosított jelszót a
program később is vissza tudja fejteni.

A megadott kapcsolódási adatokat használja a program, amikor a pdf fájlt
elkészíti, és azt elmenti a megadott útvonalra. Akkor is ezt használja,
ha a lefúró nyíllal megtekintjük a pdf fájlt. Ezért a felhasználónak nem
szükséges semmilyen jogot adni az útvonalhoz.

A „Küldési bizonylat" form fejében az útvonalra is le lehet fúrni, ami
egy intéző ablakban megnyitja az EBIZPATH útvonalat. Ez az egyetlen
dolog, amit nem engedünk megtenni abban az esetben, ha a futtató
felhasználónak nincs olvasási joga a mappához.

#### Küldési bizonylat

*Elérési útvonal:Kimenő levélküldés/Küldési bizonylat*

Ebben a menüpontban tudjuk kiválasztani a küldendő bizonylatokat (pl.
számlák) és elküldeni az emaileket. Minden email küldésről egy küldési
bizonylatot hoz létre a program.

A küldési bizonylat tartalmazza, hogy ki, mikor, mit küldött ki
email-en.

![](media/image9.png){width="5.375in" height="2.8472222222222223in"}

A képernyőn induláskor rögtön megjelenik a felhasználó kódja szürkén és
megkezd a program az adott felhasználó számára egy új küldési
bizonylatot. Ha már korábban megnyitotta küldési bizonylat képernyőt, és
van egy rögzítés alatti állapotú bizonylat, akkor azt nyitja meg a
program.

A küldési bizonylat fejrészében csak a Megjegyzés mező írható, az összes
többi mezőt a program tölti automatikusan.

A küldés időpontja akkor kerül kitöltésre, ha a küldési bizonylaton
szereplő összes e-mail kiküldésre került.

A Bizonylatszám mező azonnal, automatikusan töltődik. Ennek
előfeltétele, hogy az IFSZ AddOn Bizonylatszám hozzárendelésekben legyen
beállítva számozás a küldési bizonylatoknak. (Adminisztráció/IFSZ
keretrendszer menüpontban). A Bizonylatszám-kategóriánál a 'Küldési
bizonylatokat' kell választani. (Megjegyzés: ezt akár évente
újraindulóra is be lehet állítani.)

![](media/image10.png){width="5.395833333333333in"
height="2.451388888888889in"}

A küldési bizonylat létrehozásakor az Útvonal mezőbe belekerül az
EBIZPATH paraméterben megadott útvonalnak megfelelő mappa. Ezen a mappán
belül a program létrehoz minden küldési bizonylatnak egy külön
könyvtárat. Ebbe az almappába kerül legenerálásra az adott küldési
bizonylatban szereplő bizonylatok Crystal Reportos nyomtatási képe pdf
formátumban. Az Útvonal mező manuálisan nem módosítható. Az Útvonal mező
előtt lévő sárganyílra való lefúráskor meg is nyitja a program az adott
mappát a fájlkezelőben.

Státusz csak mentéskor mentődik; első értéke Rögzített. A küldési
bizonylatnak az alábbi státuszai lehetnek:

-   Rögzített: A küldési bizonylat 'Rögzített' státuszú, amíg nincs
    elküldve

-   Elküldve: A küldési bizonylatot elküldtük a címzett(ek)nek

-   Visszavonva: A küldési bizonylat a 'Visszavonás' nyomógomb
    megnyomása után visszavonás státuszba kerül. A 'Rögzített' státuszú
    bizonylatot lehet visszavonni.

A küldési bizonylathoz tételeket a Tételek hozzáadás nyomógombbal lehet
hozzárendelni.

#### Tételek hozzáadás

Tételek hozzáadása nyomógombra feljön a Bizonylat lista ablak, amelyben
ki lehet választani a küldendő bizonylatokat

![](media/image11.png){width="5.568450349956255in"
height="2.504666447944007in"}

A felhasználó a tételek feltöltését a Bizonylat lista képernyőn lévő
szűrésekkel valósítja meg.

Mire tudunk szűrni?:

-   Könyvelési dátumra vagy Létrehozási dátumra: dátum intervallumra
    lehet szűrni. Kötelező.

-   Partnerkód, Partnernév: Mind vagy egy partner kiválasztható
    (vevő-szállító)

-   Nyomtatva: Összes vagy Igen/Nem. Volt-e már nyomtatva az adott
    bizonylat.

-   Bizonylat típus: Összes vagy egy konkrét bizonylattípus.

    -   Szállítói megrendelés

    -   Vevői ajánlat

    -   Vevői rendelés

    -   Szállítólevél

    -   Kimenő számla

    -   Kimenő előlegszámla

    -   Kimenő jóváíró számla

    -   Kimenő helyesbítő számla

    -   Kimenő helyesbítő számla visszavonása

-   Létrehozó: A létrehozó felhasználó, értéklistából választható.

-   eBiz típus: Négy jelölőnégyzetről van szó, amelyik nincs bepiálva,
    azon típusú bizonylatok nem jelennek meg. Alapból „Papír alapú"
    nincs bepipálva. A „Papír alapú PDF", „Elektronikus -- nem
    hitelesített PDF" és „Elektronikus -- hitelesített PDF" lehetőségek
    be vannak pipálva.

-   Egyéb szűrések: A „..." nyomógombra kattintva egy külön ablak jön
    fel, amiben egyéb szűrési lehetőségek jelenhetnek meg. Itt van
    lehetőség konkrét bizonylatszámra szűrni, illetve a küldési státusz
    értékére is. Illetve ide kerülhet a többi, adott cégre jellemző
    egyedi szűrési feltétel.

Dátum szűrést kötelező megadni, a további szűréseknél csak ekkor
jelennek meg értékek. Amennyiben a dátum intervallum mindkét vége üres,
akkor a képernyőn nem jelenik meg semmilyen bizonylat. Tehát a szűrések
közül ezt kell először kitölteni.

A szűrési feltételeknek megfelelő bizonylatok jelennek meg a Bizonylat
lista képernyő alsó, táblázatos részében. Itt láthatóak a bizonylatok
legfőbb adatai: bizonylatszám, partner, bizonylattípus, létrehozás és a
könyvelés dátuma, bruttó összesen, a létrehozó felhasználó. Ezeken kívül
látható, hogy volt-e már nyomtatva a bizonylat és a küldési státusz.
Amennyiben a Küldési státusz mezőben a Elküldve érték szerepel, akkor az
adott bizonylat már szerepel egy korábbi küldési bizonylatban és a sárga
nyíllal lefúrva feljön a Küldési bizonylatok listája. Itt meg lehet
tekinteni a korábbi küldés adatait.

![](media/image12.png){width="5.368055555555555in" height="3.6875in"}

A Bizonylat lista képernyőn a leszűrt bizonylatok előtt chekbox-szal
tudjuk jelölni mely tételek kerüljenek beemelésre.

A leszűrt eredményhalmaz előtt mindig egyből ki van jelölve az összes
bizonylat; feltételezve, hogy a felhasználó pontosan le tudja szűrni
kinek, mit akar kiküldeni. Ezt persze lehet még ellenőrizni, és kivenni
a pipát azok elől, amelyeket mégsem akarunk elküldeni.

Egy küldési bizonylatra többféle bizonylattípushoz tartozó bizonylatot
ki lehet választani.

A Bizonylat lista ablakon OK-t nyomva, visszkerülünk a Küldési bizonylat
képernyőre, ahova a program beemelte az összes kiválasztott bizonylatot.
Még ekkor is lehetőségünk van arra, hogy kitöröljük a felesleges
bizonylatokat. Vagy az adott bizonylatot kijelölve először a Delete
gombot megnyomva a billentyűzeten, majd az Aktualizálást a képernyön.
Vagy az Összes tétel törlése gombot megnyomva a képernyőn.

Ezt követően a Küldési bizonylat képernyőn meg tudjuk nézni és
kiválasztani a nyomtatási formátumokat, illetve meg tudjuk adni az
e-mail címzettjét.

#### Nyomtatási képek kiválasztása

Miután beemelte a program az elküldendő bizonylatokat, kiválasztja az
SAPB1-beli alapértelmezésnek megfelelő nyomtatási formátumot
(felhasználó-partner). A Nyomt. formátum mezőben látszik a kiválasztott
nyomtatási kép, amelyet a felhasználó módosíthat, de csak Crystal
Report-os nyomtatási képet engedünk kiválasztani.

Az a lehetőség, hogy az alapértelmezett nyomtatási képet módosíthatja a
felhasználó, jogosultsági beállításhoz van kötve. Ha a
„EBIZPRINTLAYOUTMOD" nevű paraméter (\@IFSZ_PARAMETERS táblában) nincs
megadva, vagy I-re van állítva, akkor biztosan van lehetőség módosítani
a nyomtatási formátumot. Ha „N" az értéke, akkor viszont nem módosítható
az alapértelmezett formátum. Kivétel azok a felhasználók, aki
superuserek, vagy jogosultságot kapott az ugyanilyen nevű
„EBIZPRINTLAYOUTMOD" szerepkörhöz.

Az eBIZ modul csak Crystal Reportos nyomtatási képeket tud kiküldeni.
(OLE DB adatforrás legyen megadva a Crysatl Report-ban.)

Amennyiben a Nyomt. kép mező üresen jön fel, ez azt jelenti,hogy a
program az adott bizonylattípushoz nem talált alapértelmezett Crystal
Report-os nyomtatási képet, így ezt a bizonylatot nem fogja tudni
kiküldeni.

![](media/image13.png){width="3.8402777777777777in"
height="3.0972222222222223in"}

#### Email szövegének, tárgyának módosítása

Amennyiben a paraméterek között engedélyezve van a e-mail tárgy és
szövege a küldési bizonylaton is módosítható (EBIZTEMPLMOD). A küldési
bizonylaton már nem jelenik meg egy nagyobb szerkesztő mező, ezért azt
javasoljuk, hogy a szükséges módosításokat inkább az a-mail sablonok
beállításainál tegyék meg.

Amennyiben a paraméter nem engedélyezi ezeknek a mezőknek a módosítását,
akkor ezek a mezők szürkén jelennek meg. A nyomtatási formátumhoz
hasonlóan „EBIZTMPLMOD" szerepkör is létezik, ezért aki superuser, vagy
külön megkapta ezt a jogosultságot, azok az „EBIZTMPLMOD" paramétern „N"
értéke esetén is fogják tudni módostani a tárgyat és a szöveget.

#### Címzettek nyomógomb

A címzettek gombot megnyomva lehet megadni, hogy kinek küldjük el az
e-mailt.

A címzetteket beteszi a program a Küldési bizonylat tételrészének az
E-mail mezőjébe. Az adott ÜP-hez rendelt tárgyalópartnerek közül azoknak
az e-mail címét teszi oda, akiknél az E-biz címzett név ki van töltve. A
levélben ezt a nevet használja a program megszólításként. Amennyiben
több tárgyalópartnernél meg van adva az E-biz név, akkor az összes ilyen
tárgyalópartnert beteszi címzettként a program.

![](media/image14.png){width="5.597222222222222in"
height="3.6597222222222223in"}

Emellett a Címzettek nyomógombot megnyomva további tetszőleges e-mail
címekre küldhetjük még el a levelet, vagy akár törölhetünk is az
címzettek közül.

![](media/image15.png){width="3.9097222222222223in"
height="2.6180555555555554in"}

Az előző két objektumhoz hasonlóan a címzettek módosítására is
kialakítható jogosultsági rendszer. A paraméter és a szerepkör neve
„EBIZADDRMOD". „N" értéke esetén nem módosíthatók a címzettek, kivéve
annak, aki superuser, vagy külön meg lett adva neki ez a jogosultság.

#### Generálás és küldés

Ha a felhasználó már véglegesítette a bizonylatot akkor jöhet a „Csak
generálás" és a „Generálás és Küldés" nyomógomb megnyomása.

A „Generálás és Küldés" gombra való kattintáskor a következő üzenetet
kapjuk:

![](media/image16.png){width="2.6458333333333335in"
height="1.3333333333333333in"}

Igenlő válasz esetén a „Generálás és Küldés"funkcióval egyszerre készíti
el a progrm az adott bizonylat nyomtatási képét (pdf fájl), azt ellátja
a szükséges elektronikus aláírással (amennyiben ez a funkció be van
állítva), és küldi el a pdf-et tartalmazó e-mailt.

Először ellenőrizi a program, hogy a felhasználóhoz megadott email
authentikáció működik-e (fogunk-e tudni levelet küldeni). Tehát be van-e
állítva egy megfeleő postafiók. Ha nem érjük el a fiókot, akkor erről
tájékoztatja a felhasználót, aki nem tud továbblépni.

![](media/image17.png){width="4.159722222222222in"
height="1.4097222222222223in"}

Ha megvan az elérés a postafiókhoz, akkor bizonylat soronként egy
tranzakcióban a következő végzi el a program:

-   legenerálja és elmenti a pdf-eket (a küldési bizonylat fejben
    látható útvonalra),

-   az EBIZATC paraméter „I" értéke azt jelzi, hogy a csatolmányokat is
    küldeni kívánjuk, akkor a pdf-be beágyazza a számla csatolmányait.

-   amennyiben be van állítva, hogy a pdf elektronikus aláírással legyen
    ellátva (EBIZSRV paraméterben meg van adva az aláíró szolgáltatás
    elérhetősége), valamint az adott bizonylat eBiz típusa „H --
    Elektronikus hitelesített PDF", akkor elkészül a pdf elektronikus
    aláírással ellátott változata.

-   elkészíti az email-t és kiküldi a címzetteknek

-   beírja be a kiküldött fájl nevét a sorokba, kitölti a Fájl mezőt

-   módosítja be a küldési-bizonylat tételeibe a státuszt: Elküldve-re.

-   a bizonylat 'Nyomtatott' lesz és növeli a példányszámot

Ha sikerült az összes sort feldolgozni és elküldeni, akkor mindegyik sor
státusza 'Elküldve' lesz, ezután a küldési bizonylat fej szinten is
'Elküldve' státuszú lesz.

A legenerált nyomtatási képek fájlneve a bizonylatszámot, majd a
generálás időbélyegét fogja tartalmazni, végül a .pdf kiterjesztést. Ezt
lehetőség van felülbírálni az EBIZFILENAME paraméter beállításával. A
fájl neve akkor az lesz, ami itt paraméterként meg van adva, de

-   ha \<docnum\>-ot tartalmaz, azt lecseréljük a bizonylatszámra,

-   a \<timestamp\>-et az aktuális időbélyegre

-   a \<cardcode\>-ot a partner kódjára

A „Generálás és Küldés" többféle okból meghiúsulhat:

-   Nincs megfelelő Crystal Reportos nyomtatási kép:

![](media/image18.png){width="3.0625in" height="1.4444444444444444in"}

-   A bizonylathoz nincs egy címzett sem megadva:

![](media/image19.png){width="3.673611111111111in"
height="1.4513888888888888in"}

Amennyiben a folytatás mellett döntünk, a helyes bizonylatokat elküldi a
rendszer és a végén kapunk egy üzenetet a helyes és sikertelen e-mail
küldésekről.

![](media/image20.png){width="3.8958333333333335in" height="1.6875in"}

A sikeresen elküldött bizonylatok státusza Elküldve lesz és a Küldési
időpontot mezőt is kitölti a rendszer. A sikertelen bizonylatok státusza
Rögzített marad. Ekkor magának a küldési bizonylatnak sem változik a
státusza, ez is Rögzített marad. Ebben az esetben vagy javítjuk a hibát
(pl. adunk meg címzettet), vagy kitöröljük a bizonylatot a küldési
bizonylatról.

![](media/image21.png){width="5.416666666666667in"
height="2.8541666666666665in"}

#### Csak generálás

Ekkor csak kigeneráljuk a tételben lévő bizonylatok pdf-jeit a
létrehozott mappába megtekintés céljából, hogy jó nyomtatási képet
rendeltünk-e a bizonylathoz. Ez a pdf nem tartalmazza sem az esetleges
csatolmányokat, sem az elektronikus aláírást.

##### Küldési bizonylat fejrész kitöltési útmutató

+------------------+-------------------+-----------------------------+
| **Mező**         | **Kitöltési mód** | **Tartalom**                |
+------------------+-------------------+-----------------------------+
| Felhasználó      | Automatikus       | A küldési bizonylatot       |
|                  |                   | megnyitó felhasználó kódja  |
+------------------+-------------------+-----------------------------+
| Küldés időpontja | Automatikus       | Az utolsó e-mail            |
|                  |                   | kiküldésének időpontja.     |
+------------------+-------------------+-----------------------------+
| Bizonylatszám    | Automatikus       | A bizonylatszámozást        |
|                  |                   | előzetesen be kell állítani |
|                  |                   | az IFSZ addon               |
|                  |                   | Bizonylatszámozás részében  |
+------------------+-------------------+-----------------------------+
| Státusz          | Automatikus       | Lehetséges értékei:         |
|                  |                   |                             |
|                  |                   | -Rögzített                  |
|                  |                   |                             |
|                  |                   | -Elküldve                   |
|                  |                   |                             |
|                  |                   | -Visszavonva                |
+------------------+-------------------+-----------------------------+
| Megjegyzés       | Opcionális        | Tetszőleges megjegyzés      |
+------------------+-------------------+-----------------------------+
| Útvonal          | Automatikus       | A generálandó fájlok        |
|                  |                   | elérési útvonalán belül az  |
|                  |                   | adott küldési bizonylat     |
|                  |                   | mappája                     |
+------------------+-------------------+-----------------------------+

##### Küldési bizonylat tételrész kitöltési útmutató

  -------------------- ------------------------------ -----------------------------------------------------------------------------------------------------------------
  **Mező**             **Kitöltési mód**              **Tartalom**
  Sor                  Automatikus, nem módosítható   Sorszám
  Biz.típus            Automatikus, nem módosítható   Bizonylat típus
  Bizonylatszám        Automatikus, nem módosítható   Bizonylatszám
  ÜP.kód               Automatikus, nem módosítható   Partnerkód
  ÜP.neve              Automatikus, nem módosítható   Partnernév
  Nyomt.formátum       Automatikus, módosítható       Crystal Report-os nyomtatási formátum. Automatikusan a SAPB1 alapértelmezés szerinti, de módosítható
  E-mail               Automatikus                    Alapértelmezetten az ÜP-hez rendelt tárgyalópartnerek e-mail címe, ahol az E-biz címzett név mező ki van töltve
  Fájl                 Automatikus                    A generálás után itt lehet megtekinteni az adott bizonylat nyomtatási képét pdf-ben
  Email tárgya         Automatikus                    Paraméter vezérli, hogy módosítható-e. A hozzárendelt e-mail sablon tárgya
  Email szövegtörzse   Automatikus                    Paraméter vezérli, hogy módosítható-e. A hozzárendelt e-mail sablon tárgya
  Státusz              Automatikus                    Lehetséges értékei: Rögzítve, Elküldve.
  Küld.időpont         Automatikus                    Az e-mail küldésének pontos időpontja
  -------------------- ------------------------------ -----------------------------------------------------------------------------------------------------------------

##### Bizonylat lista képernyő kitöltési útmutató

  ----------------------------------------- ------------------- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  **Mező**                                  **Kitöltési mód**   **Tartalom**
  Könyvelési dátum vagy Létrehozási dátum   Kötelező            Szűrő paraméter. Vagy könyvelési dátum vagy létrehozási dátum választható. Dátumintervallumot kell megadni. Ha mindkét intervallum üres, nem jelennik meg egyetlen bizonylat sem.
  Partnerkód, partnernév                    Opcionális          Szűrő paraméter. Értéklistából választható
  Nyomtatva                                 Opcionális          Szűrő paraméter. Lehetséges értékei: Összes, Igen, Nem.
  Bizonylat típus                           Opcionális          Szűrő paraméter. Értéklistából választható
  Létrehozó                                 Opcionális          Szűrő paraméter. Értéklistából választható
  Kiválasztó checkbox                       Kötelező            A leszűrt tételek kiválasztására szolgál. Alapértelmezetten az össze ki van jelölve. Az össze kijelölést a fejlécre való kattintással lehet kivenni.
  Bizonylatszám                             Automatikus         Bizonylatszám
  ÜP-kód                                    Automatikus         ÜP-kód
  ÜP-név                                    Automatikus         ÜP-név
  Biz.típus                                 Automatikus         Bizonylat típus
  Létr. dátuma                              Automatikus         Létrehozás dátuma
  Könyv.dátum                               Automatikus         Könyvelési dtum
  Bruttó összesen                           Automatikus         Bruttó összesen
  Létrehozó                                 Automatikus         Létrehozó felhasználó
  Nyomtatva                                 Automatikus         Volt-e már nyomtatva a bizonylat. Lehetséges értékei: Igen/Nem.
  Küldés státusz                            Automatikus         Szerepel-e már küldési bizonylaton az adott bizonylat. Ha üres, akkor nem. Elküldve érték esetén igen. Ekkor a Küldési bizonylatok listájára lehet lefúrni.
  ----------------------------------------- ------------------- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

**Küldési bizonylat nyomógombok**

  ---------------------- -------------------------------------------------------------
  **Nyomógomb**          **Tartalom**
  Tételek hozzásadás     Bizonylatok kiválasztására szolgál
  Összes tétel törlése   A kiválasztott összes bizonylat törlésére szolgál
  Visszavonás            A küldési bizonylatot lehet vele visszavonni
  Címzettek              Az e-mail címzettjeit lehet ezzel megadni
  Generálás és küldés    A bizonylat nyomtatási képek generálása és az email küldése
  Csak generálás         Csak a nyomtatási képek generálása, e-mail küldés nélkül.
  Aktualizáls/OK         A módosítások elmentése.
  Mégsem                 Képernyőről való kilépés.
  ---------------------- -------------------------------------------------------------

### Lekérdezések

#### Bizonylatok listája

*Elérési útvonal: Kimenő levélküldés/Bizonylatok listája*

Ezen a képernyőn lehet a felső blokkban lévő szűrőparamétereket megadva
lekeresni a korábbi küldésekben szereplő bizonylatokat. A dátumszűrési
intervallum megadása kötelező.

A ![](media/image22.png){width="0.4097222222222222in" height="0.3125in"}
nyomógombra kattintva plusz, akár az adott cégnél egyedi szűrőfeltételek
adhatók meg.

![](media/image23.png){width="5.409722222222222in"
height="4.520833333333333in"}

A szűrőfeltételek megadása után a képernyőn láthatóak az adott bizonylat
adatai, pl. a bizonylatszám mezőben egy adott számlaszámot beírva
megtekeinthető, hogy ki lett-e küldve az adott számla emailben.

![](media/image11.png){width="5.568450349956255in"
height="2.504666447944007in"}

Amennyiben a Küldési státusz oszlopban az szerepel, hogy Kiküldve, akkor
a sárga nyílra kattintva meg tudjuk nézni az adott küldés adatait a
Küldési bizonylatok listája képernyőn.

![](media/image24.png){width="5.416666666666667in"
height="3.048611111111111in"}

Ezen a képernyőn lehetőségünk van a Bizonylatszám mezőre lefúrva
megnézni, hogy az adott küldési bizonylaton milyen tételek szerepeltek,
illetve az Útvonal mezőben lévő fájlra lefúrva pedig az adott bizonylat
pdf képét tudjuk megtekinteni.

#### Küldési bizonylat lista

*Elérési útvonal: Kimenő levélküldés/Küldési bizonylatok lista*

Ezen a képernyőn lehet megtekintei az összes eddigi küldési bizonylat
főbb adatait: felhasználó, küldés időpontja, státusza, mappája.

![](media/image25.png){width="5.465277777777778in"
height="3.7708333333333335in"}

### Csatolmányok

### Csatolmányok

#### Bizonylat csatolmányok küldése

A bizonylatok küldése során szükség lehet különböző csatolmányok
(szállítólevél, teljesítési igazolás, megrendelés, stb.) az adott
bizonylattal való egyidejű elküldésére.

A mellékletek csatolása a küldendő bizonylatok középső részének
„Mellékletek" fülén tallózott és csatolt fájlok adott bizonylattal való
küldését jelenti.

A „Tallózás" gombra kattintva ki tudjuk választani az egyes
csatolmányokat könyvtárunkból, a tallózott fájl neve fog az eBiz
Add-onnal történő küldés során a küldött bizonylat mellékletének
fájlneveként megjelenni. Fontos, hogy a küldési bizonylat elkészítése
előtt a küldendő mellékleteket tallózzuk be az adott bizonylatokhoz, ha
azt korábban a bizonylat elkészítésekor nem tettük meg.

![](media/image26.png){width="5.404861111111111in"
height="1.0472222222222223in"}

A A Mellékletek fülön csatolt dokumentumok eBiz küldését paraméterben
kell engedélyezni: amennyiben az IFSZ paraméterekben az EBIZATC nevű
paraméter értéke „I", engedélyezett a csatolmányok küldése, „N" esetén a
Mellékletek fülön csatolt fájlok nem kerülnek elküldésre.

A csatolmányok a küldött PDF formátumú bizonylatba beágyazott PDF
fájlként kerülnek továbbításra, melyek listája PDF olvasó alkalmazás
segítségével a Csatolmányok ikonra kattintva jeleníthető meg. A
beágyazott csatolmányokról bővebb tájékoztatás a következő URL-en érhető
el:
https://helpx.adobe.com/hu/acrobat/using/links-attachments-pdfs.html\#open_save_or_delete_an_attachment

![](media/image27.png){width="3.9722222222222223in"
height="2.3402777777777777in"}

Érdemes a bizonylatokat fogadó partnerek figyelmét felhívni arra, hogy a
küldött bizonylatok beágyazott mellékleteket tartalmazhatnak. Erre
lehetséges megoldás az e-mail sablonok szövegtörzsében megfogalmazott
figyelmeztetés. (Az e-mail sablonok készítéséről bővebben: *E-mail
sablonok* fejezet)

A nyomtatási képek az EBIZPATH paraméterben megadott útvonalra történő
generálásakor a nyomtatási képek szintén a beágyazott mellékletekkel
együtt kerülnek mentésre, így később az egyes bizonylatokhoz csatolt
dokumentumok bármikor megtekinthetők a PDF fájlok beágyazott
csatolmányaiként.

#### Online számla XML csatolása

Speciális lehetőség, hogy akár a NAV online számla rendszerébe elküldött
xml dokumentumot is becsatolhatjuk a PDF-be.

Ez úgy működik, hogy egyrészt az online számla szolgáltatás az elküldött
xml-t egy külön mappába másolja. Ez a külön mappa az EBIZXMLPATH
paraméterben megadandó. Ezt az útvonalat az online számla szolgáltatás
el kell, hogy tudja érni a saját jogosultságaival.

Az eBiz modul oldalon pedig a kimenő számla kiküldésénél a program
megkeresi ebben a mappában a megadott számlához tartozó xml-t. Ezt pedig
ugyanolyan módon csatolja be a PDF-be, ahogy a számla csatolmányait.

### Tanúsítványok igénylése

### Tanúsítványok igénylése

Az elektronikus aláírás bizosításához két tanúsítvány megszerzésére
van szükség:

-   Szervezeti bélyegző tanúsítványra

-   Időbélyeg tanúsítvány csomagra (tranzakciós) az egyes
    dokumentumokhoz

Ezeket jelenleg a Microsec Zrt. tanúsító szervezet tanúsítványaival
biztosíthatjuk (e-Szignó).

**A szervezeti bélyegző tanúsítvány igénylési folyamata a következő:**

Link:
<https://srv.e-szigno.hu/index.php?lap=szoftveres_automata_igenyles>

Ezt a linket az alapértelmezett böngésző azonnal megnyitja. (Itt még
mindegy, hogy milyen böngészőt indítunk.) Meg kell adnunk egy e-mail
címet, melyet azonnal tudunk olvasni, valamint ez az email cím fog
bekerülni a tanúsítványba is. Legyen most ez az e-mail cím a
<penzugy@ifsz.hu>.

![](media/image28.png){width="4.854166666666667in"
height="2.4791666666666665in"}

A link megnyitásakor a szervezeti bélyegző igénylésének éves díja is
azonnal látható.

Ezután a megadott címre érkezik egy email, melyben lesz egy link, amire
rákattintva folytatni lehet az igénylést. Erre a linkre rákattintva már
nem mindegy, melyik böngészőből folytatjuk az igénylést: Internet
Explorer-be, vagy 58-as verziótól régebbi Mozilla FireFox böngészőbe
kell a kapott linket másolnunk és megnyitnunk. Ha ezt követjük, akkor a
böngésző megcsinálja a párosító kulcs generálását, egyébként külön
kódoló algoritmusokat kell alkalmaznunk.

![](media/image29.png){width="5.097222222222222in"
height="2.7708333333333335in"}

Az igénylőnél azt a személyt kell megadnunk, aki az igénylésnél el fog
járni (számára meghatalmazást kell kiállítani, melyről formanyomtatvány
fog érkezni a MICROSEC-től).

A kitöltés menete a következőképpen folytatódik:

![](media/image30.png){width="5.284722222222222in"
height="4.256944444444445in"}

![](media/image31.png){width="4.972222222222222in"
height="4.111111111111111in"}

![](media/image32.png){width="4.965277777777778in"
height="4.069444444444445in"}

Ha rossz böngészőben vagyunk, akkor a Kulcsgenerálás módja blokknál
kapunk egy piros üzenetet. Ezt rögtön az adatrögzítés legelején le lehet
ellenőrizni, ha legörgetünk a lentebb látható pontig:

![](media/image33.png){width="5.138888888888889in"
height="4.208333333333333in"}

A megjegyzésbe írjuk be: *„Minősített időbélyegzés szolgáltatást is
fogunk igényelni IFSZ eBIZ modulhoz; kérjük ennek megfelelő dokumentum
csomagot küldeni."*

Így az Ügyfélszolgálat a Szolgáltatási szerződés időbélyeg tanúsítvány
csomagra vonatkozó mellékletét is elküldi emailben.

Ezután fogadjuk el a nyilatkozatokat:

![](media/image34.png){width="5.263888888888889in"
height="4.319444444444445in"}

![](media/image35.png){width="4.973611111111111in"
height="3.752083333333333in"}

![](media/image36.png){width="5.166666666666667in"
height="3.1041666666666665in"}

![](media/image37.png){width="4.875in" height="3.2291666666666665in"}

![](media/image38.png){width="4.840277777777778in" height="3.125in"}

![](media/image39.png){width="4.979166666666667in"
height="3.2708333333333335in"}

![](media/image40.png){width="4.590277777777778in"
height="2.7291666666666665in"}

A sikeres megrendelést követően az alábbi üzenet fogjuk kapni az
igénylés első lépése során megadott e-mail címre:

![](media/image41.png){width="5.506944444444445in"
height="2.3680555555555554in"}

A kapott dokumentumokat ki kell tölteni, aláírni, majd személyes
azonosításra kerül sor. Ehhez lépjen kapcsolatba a Microsec
[Ügyfélszolgálattal](https://srv.e-szigno.hu/index.php?lap=ugyfelszolgalat),
és egyeztesse kollégákkal, hogy az Ön személyes azonosítására mikor
kerül sor. A személyes azonosítás helyszíne a Microsec Zrt.
ügyfélszolgálati irodája (Graphisoft Park: 1033 Ángel Sanz Briz út 13.,
Microsec fölszinti iroda, külső átadó ablak. Igény esetén helyszíni
kiszállást is biztosítanak, ennek díjazását szükséges előre egyeztetni a
<sales@microsec.hu> email címen). A személyes találkozást követően
elkészítik tanúsítványát, és a megadott értesítési e-mail címre elküldik
Önnek. A tanúsítványokat először ugyanarra a számítógépre kell
telepíteni, amelyiken az igénylőlapot kitöltöttük. A tanúsítványt később
[másik gépre is
átviheti](https://srv.e-szigno.hu/index.php?lap=telepitesi_utmutato_xp_szoftveres).
Az igénylőlap kitöltésekor felmerülő problémák esetén a MICROSEC-es
kollégák a 06 1 505 4444-es telefonszámon állnak rendelkezésre.

A tanúsítvány rendelkezésre állása esetén az IFSZ kollégai elvégzik a
telepítést és a konfigurációt. A dokumentumok elektronikus aláírását egy
szolgáltatás fogja elvégezni, amit az IFSZ Kft. az Önök SAP szerverére
telepít. (Másik szerverre is telepíthető, az a lényeg, hogy elérje az
SAP adatbázist és az eBiz addon generálási útvonalát.) Telepítés után a
szolgáltatás egy adott porton keresztül fogja fogadni az eBiz addon
kéréseit, ezért fontos, hogy nyitva legyen ez a port a kliensek
irányából induló kérések számára. Az EBIZSRV paraméterben kell megadni a
szolgáltatás url-jét, ami a következőképpen fog kinézni:
[http://ip-cím:port/](http://ip-cím:port/) Amennyiben ez a paraméter
nincs megadva, akkor elektronikus aláírás nélkül küldi el a
bizonylatokat az eBiz addon.

A szolgáltatás telepítéséhez szükségünk lesz:

-   A bélyegző tanúsítványra. Ebből egy pfx fájlt kell generálni az itt
    olvasható útmutató szerint:
    <https://help.e-szigno.hu/knowledgebase.php?article=42> . Ezt,
    illetve a generáláshoz használt jelszót is adja meg az IFSZ-nek.

-   Az időbélyeg szolgáltatáshoz kapcsolódó felhasználónévre és
    jelszóra.

-   A regisztrációs licenc lapon megadott regisztrációs kulcsra, ami
    ilyesmi formátumú lesz: 1aaaaaaa-a123-a123-a123-1aaaaaaaaaaa

Ha a telepítés és beállítás megtörtént, akkor a nyomtatási képek pdf-e
alapján a szolgáltatás készíteni fog egy \_signed.pdf-re végződő nevű
fájlt is, ami már tartalmazza az elektronikus aláírást, és az eBiz
addon ezt fogja elküldeni az email mellékleteként. Ezeknek a PDF
dokumentumoknak az elektronikus aláírását látni fogjuk a generált PDF
dokumentum megnyitásakor:

![](media/image42.png){width="2.9166666666666665in"
height="0.5486111111111112in"}

### Archiválás

### Archiválás

Lehetőség van egy külön adatbázis példányba archiválni az elkészített
számlákat. A pdf fájlok ugyan a fájlrendszerben is jelen vannak, de
magasabb szintű biztonságot nyújt, ha ezeket ezzel párhuzamosan egy
másik helyre is -- esetünkben az adatbázisba -- elmentünk.

További biztonságot nyújt az, hogy az eBiz szolgáltatás rendszeres
időközönként összehasonlítja a fájlrendszerben és az adatbázisban tárolt
fájlokat. Amennyiben bármelyik hiányzik, vagy eltérnek egymástól, akkor
figyelmeztetést tud adni erről az eseményről.

A külön adatbázisnak a nevét az EBIZARCH paraméterben kell megadni.
Amennyiben ez üres, akkor nem történik adatbázis archiválás.

Az eBiz szolgáltatás abban az esetben ellenőrzi ezeket a fájlokat, ha az
EBIZARCHCHK paraméter meg van adva, és szabályos egész szám szerepel
benne. Minden fájlról ismert, hogy mikor történt meg az utolsó
ellenőrzése. Rendszeresen (EBIZARCHFRQ-ban megadott percenként --
alapértelmezetten 10) ellenőrzi a program, hogy azóta van-e olyan
számla, aminél már lejárt a megadott napok száma. Ha van, akkor ezeket a
fájlokat összehasonlítja a fájlrendszerben található pdf-fel. Ha az
hiányzik, vagy tartalmában eltér (egy MD5 ellenőrző összeget számol a
program mindkét fájlra, és ennek eltérését vizsgálja), akkor ezt az
eltérést bejegyzi.

Az eltéréseket külön felhasználói lekérdezésben lehet megtekinteni.

Az EBIZARCHCHK paraméterben nem csak szabályos egész szám szerepelhet,
hanem az egész szám után egy betű is, ami

-   D, vagy N esetén napot jelent. (elhagyása esetén is napként
    értelmezzük a megadott számot.

-   H, vagy Ó esetén órát.

-   M, vagy P esetén percet.

Az óra és percek használatának inkább csak teszt környezetben lehet
szerepe. Éles környezetben nem célszerű ilyen gyakran ellenőrizni a
fájlokat.

#### Hibakódok

Ha valamilyen eltérés keletkezik az archiv adatbázisban tárolt és a fájlrenszerben
lévő dokumentum között, akkor a következő hibakód jelenik meg:

| Hibakód | Hiba leírása |
|:--------|:-------------|
| 1 | A fájlrendszerben nem található a fájl |
| 2 | Eltér az archiv adatbázisban, és a fájlrendszerben lévő fájl |
| 4 | Nincs meg az eredeti adatbázisban a küldési bizonylat sor. Ez az előző kettővel is variálódhat |
| 5 | A 4-es és az 1-es hibakód is fennáll egyszerre |
| 6 | A 4-es és a 2-es hibakód is fennáll egyszerre |


