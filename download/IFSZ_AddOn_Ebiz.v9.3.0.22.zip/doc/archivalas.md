﻿### Archiválás

Lehetőség van egy külön adatbázis példányba archiválni az elkészített
számlákat. A pdf fájlok ugyan a fájlrendszerben is jelen vannak, de
magasabb szintű biztonságot nyújt, ha ezeket ezzel párhuzamosan egy
másik helyre is -- esetünkben az adatbázisba -- elmentünk.

További biztonságot nyújt az, hogy az eBiz szolgáltatás rendszeres
időközönként összehasonlítja a fájlrendszerben és az adatbázisban tárolt
fájlokat. Amennyiben bármelyik hiányzik, vagy eltérnek egymástól, akkor
figyelmeztetést tud adni erről az eseményről.

A külön adatbázisnak a nevét az EBIZARCH paraméterben kell megadni.
Amennyiben ez üres, akkor nem történik adatbázis archiválás.

Az eBiz szolgáltatás abban az esetben ellenőrzi ezeket a fájlokat, ha az
EBIZARCHCHK paraméter meg van adva, és szabályos egész szám szerepel
benne. Minden fájlról ismert, hogy mikor történt meg az utolsó
ellenőrzése. Rendszeresen (EBIZARCHFRQ-ban megadott percenként --
alapértelmezetten 10) ellenőrzi a program, hogy azóta van-e olyan
számla, aminél már lejárt a megadott napok száma. Ha van, akkor ezeket a
fájlokat összehasonlítja a fájlrendszerben található pdf-fel. Ha az
hiányzik, vagy tartalmában eltér (egy MD5 ellenőrző összeget számol a
program mindkét fájlra, és ennek eltérését vizsgálja), akkor ezt az
eltérést bejegyzi.

Az eltéréseket külön felhasználói lekérdezésben lehet megtekinteni.

Az EBIZARCHCHK paraméterben nem csak szabályos egész szám szerepelhet,
hanem az egész szám után egy betű is, ami

-   D, vagy N esetén napot jelent. (elhagyása esetén is napként
    értelmezzük a megadott számot.

-   H, vagy Ó esetén órát.

-   M, vagy P esetén percet.

Az óra és percek használatának inkább csak teszt környezetben lehet
szerepe. Éles környezetben nem célszerű ilyen gyakran ellenőrizni a
fájlokat.

#### Hibakódok

Ha valamilyen eltérés keletkezik az archiv adatbázisban tárolt és a fájlrenszerben
lévő dokumentum között, akkor a következő hibakód jelenik meg:

| Hibakód | Hiba leírása |
|:--------|:-------------|
| 1 | A fájlrendszerben nem található a fájl |
| 2 | Eltér az archiv adatbázisban, és a fájlrendszerben lévő fájl |
| 4 | Nincs meg az eredeti adatbázisban a küldési bizonylat sor. Ez az előző kettővel is variálódhat |
| 5 | A 4-es és az 1-es hibakód is fennáll egyszerre |
| 6 | A 4-es és a 2-es hibakód is fennáll egyszerre |

