﻿Imports System.ComponentModel
Imports System.Configuration.Install

Public Class ProjectInstaller

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add initialization code after the call to InitializeComponent

    End Sub

    Protected Overrides Sub OnBeforeInstall(savedState As IDictionary)
        Dim l_nev As String = IFSZ_Globals.GetIniValue("SBO", "company")
        If String.IsNullOrEmpty(l_nev) Then
            l_nev = IFSZ_Connect.m_database
        End If
        ServiceInstaller1.ServiceName = ServiceInstaller1.ServiceName + "_" + l_nev
        ServiceInstaller1.DisplayName = ServiceInstaller1.DisplayName + " (" + l_nev + ")"
        MyBase.OnBeforeInstall(savedState)
    End Sub

    Protected Overrides Sub OnBeforeUninstall(savedState As IDictionary)
        Dim l_nev As String = IFSZ_Globals.GetIniValue("SBO", "company")
        If String.IsNullOrEmpty(l_nev) Then
            l_nev = IFSZ_Connect.m_database
        End If
        ServiceInstaller1.ServiceName = ServiceInstaller1.ServiceName + "_" + l_nev
        ServiceInstaller1.DisplayName = ServiceInstaller1.DisplayName + " (" + l_nev + ")"
        MyBase.OnBeforeUninstall(savedState)
    End Sub

End Class
