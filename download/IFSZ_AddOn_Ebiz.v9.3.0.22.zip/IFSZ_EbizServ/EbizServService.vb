﻿Imports System.ServiceProcess

Public Class EbizServService

    'Public m_running = False
    'Public m_interval As Integer = 0
    'Public m_lastrun As DateTime = New DateTime(1990, 1, 1)

    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

    End Sub

    Protected Overrides Sub OnStart(args() As String)
        InitInterface()
    End Sub

    Protected Overrides Sub OnStop()
        Module1.m_running = False
    End Sub

    Protected Overrides Sub OnPause()
        Module1.m_paused = True
    End Sub

    Protected Overrides Sub OnContinue()
        Module1.m_paused = False
    End Sub

End Class
