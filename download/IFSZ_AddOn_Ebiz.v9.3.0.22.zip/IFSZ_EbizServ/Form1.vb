﻿Imports Microsoft.Owin.Hosting
Imports System
Imports System.Net.Http

Public Class Form1

    Private m_baseaddress As String
    Private m_running As Boolean = False

    Private Sub Form1_Resize(sender As Object, e As EventArgs) Handles MyBase.Resize
        If Me.WindowState = FormWindowState.Minimized Then
            NotifyIcon1.Visible = True
            NotifyIcon1.Icon = SystemIcons.Application
            NotifyIcon1.BalloonTipIcon = ToolTipIcon.Info
            NotifyIcon1.BalloonTipText = "Az IFSZ Logicort WEB API a háttérben fut tovább"
            NotifyIcon1.ShowBalloonTip(5000)
            Me.Hide()
            ShowInTaskbar = False
        End If
    End Sub

    Private Sub NotifyIcon1_DoubleClick(sender As Object, e As EventArgs) Handles NotifyIcon1.DoubleClick
        Me.Show()
        ShowInTaskbar = True
        Me.WindowState = FormWindowState.Normal
        NotifyIcon1.Visible = False
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Me.WindowState = FormWindowState.Minimized
    End Sub

    ''' <summary>
    ''' Ez a szál kezeli a bejövő REST API hívásokat
    ''' </summary>
    Private Sub WebAppThread()
        Using WebApp.Start(Of Startup)(url:=m_baseaddress)
            While m_running
                System.Threading.Thread.Sleep(1000)
            End While
        End Using
    End Sub

    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Me.m_running = False
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub
End Class
