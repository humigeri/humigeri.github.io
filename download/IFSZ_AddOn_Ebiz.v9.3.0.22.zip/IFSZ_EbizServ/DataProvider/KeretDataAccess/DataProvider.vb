Imports SystemImports System.CollectionsImports System.TextImports System.IOImports System.DataImports Microsoft.VisualBasicImports Microsoft.VisualBasic.InteractionPublic Class DataProvider    Public Shared m_tipus As Integer = 0
    Public Shared Property m_ConnectionString() As String
        Get
            If DataProvider.m_tipus = 0 Then
                Return MSDataProvider.m_ConnectionString
            Else
                Return HANADataProvider.m_ConnectionString
            End If        End Get
        Set(ByVal value As String)
            If DataProvider.m_tipus = 0 Then
                MSDataProvider.m_ConnectionString = value
            Else
                HANADataProvider.m_ConnectionString = value
            End If        End Set
    End Property

    Public Shared Function ExecuteScalar(ByVal sqlQuery As String) As Integer        If DataProvider.m_tipus = 0 Then
            Return MSDataProvider.ExecuteScalar(sqlQuery)        Else
            Return HANADataProvider.ExecuteScalar(sqlQuery)        End If    End Function

    Public Shared Function ExecuteNonQuery(ByVal sqlQuery As String, ByRef p_messege As String, Optional ByVal p_hiba As Boolean = False) As Integer        If DataProvider.m_tipus = 0 Then
            Return MSDataProvider.ExecuteNonQuery(sqlQuery, p_messege, p_hiba)        Else
            Return HANADataProvider.ExecuteNonQuery(sqlQuery, p_messege, p_hiba)        End If    End Function

    Public Shared Function GetDataRecord(ByVal sqlQuery As String) As DataRowCollection        If DataProvider.m_tipus = 0 Then
            Return MSDataProvider.GetDataRecord(sqlQuery)        Else
            Return HANADataProvider.GetDataRecord(sqlQuery)        End If    End Function

    Public Shared Function EExecuteNonQuery(ByVal sqlQuery As String, Optional ByVal p_CommandTimeOut As Integer = -1) As Integer        If DataProvider.m_tipus = 0 Then
            Return MSDataProvider.EExecuteNonQuery(sqlQuery, p_CommandTimeOut)        Else
            Return HANADataProvider.EExecuteNonQuery(sqlQuery, p_CommandTimeOut)        End If    End Function

    Public Shared Function ExecuteScalarString(ByVal sqlQuery As String) As String        If DataProvider.m_tipus = 0 Then
            Return MSDataProvider.ExecuteScalarString(sqlQuery)        Else
            Return HANADataProvider.ExecuteScalarString(sqlQuery)        End If    End Function

    Public Shared Function EGetDataTable(ByVal sqlQuery As String, Optional ByVal p_CommandTimeOut As Integer = -1) As DataTable        If DataProvider.m_tipus = 0 Then
            Return MSDataProvider.EGetDataTable(sqlQuery, p_CommandTimeOut)        Else
            Return HANADataProvider.EGetDataTable(sqlQuery, p_CommandTimeOut)        End If    End Function    Public Shared Function GetSysDate() As DateTime
        If DataProvider.m_tipus = 0 Then
            Return MSDataProvider.GetSysDate()        Else
            Return HANADataProvider.GetSysDate()        End If    End Function
End Class