Imports System
Imports System.Collections
Imports System.Text
Imports System.Data
Imports System.Data.SqlClient

Public Class MSConnectionProvider

    Public m_Connection As SqlConnection
    Public m_Transaction As SqlTransaction
    Public Shared m_sdkuser As String = "sdkuser"
    Public Shared m_sdkpwd As String = "ifszsdk"

    Sub New()
        m_Connection = New SqlConnection(DataProvider.m_ConnectionString)
        m_Connection.Open()
        m_Transaction = m_Connection.BeginTransaction()
    End Sub

    Sub New(ByVal p_beginTransaction As Boolean)
        m_Connection = New SqlConnection(DataProvider.m_ConnectionString)
        m_Connection.Open()
        If p_beginTransaction Then
            m_Transaction = m_Connection.BeginTransaction()
        End If
    End Sub

    Public Sub Commit(Optional ByVal p_beginTransaction As Boolean = True)
        m_Transaction.Commit()
        If p_beginTransaction Then
            m_Connection.Close()
            m_Connection.Dispose()
        End If
    End Sub

    Sub New(ByVal p_beginTransaction As Boolean, ByVal l_connectionstring As String)
        m_Connection = New SqlConnection(l_connectionstring)
        m_Connection.Open()
        If p_beginTransaction Then
            m_Transaction = m_Connection.BeginTransaction()
        End If
    End Sub

    Public Sub Colse()
        m_Connection.Close()
        m_Connection.Dispose()
    End Sub

    Public Sub BeginTransaction()
        m_Transaction = m_Connection.BeginTransaction()
    End Sub
    Public Sub Rollback(Optional ByVal p_beginTransaction As Boolean = True)
        m_Transaction.Rollback()
        If IFSZ_Globals.m_Hiba_Naploz_e And (Not IFSZ_Globals.m_Utolso_Hiba Is Nothing) Then
            Dim l_message As String
            m_Transaction = m_Connection.BeginTransaction()
            DataProvider.ExecuteNonQuery(IFSZ_Globals.m_Utolso_Hiba, l_message)
            IFSZ_Globals.m_Utolso_Hiba = Nothing
            m_Transaction.Commit()
        End If
        If p_beginTransaction Then
            m_Connection.Close()
            m_Connection.Dispose()
        End If
    End Sub

    Public Shared Function CreateConnectionString(ByVal p_servername As String, ByVal p_companydb As String) As String
        Return "Persist Security Info=False;Integrated Security=False;" & _
                                        "database=" & p_companydb & ";server=" & p_servername & ";User ID = " + MSConnectionProvider.m_sdkuser + ";Password=" + MSConnectionProvider.m_sdkpwd + ";Connect Timeout=30"
    End Function

End Class