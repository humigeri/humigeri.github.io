Imports System
Imports System.Collections
Imports System.Text
Imports System.Data
Imports System.Data.Odbc

Public Class HANAConnectionProvider

    Public m_Connection As OdbcConnection
    'Public m_Connection_sql As SqlConnection
    Public m_Transaction As OdbcTransaction
    'Public m_Transaction_sql As SqlTransaction
    'Public m_Transaction_sql As SqlTransaction
    'Public m_Connection_sql As SqlConnection
    Public Shared m_sdkuser As String = "IFSZSDK"
    'Public Shared m_sdkuser As String = "IFSZ"
    Public Shared m_sdkpwd As String = "CVBdfgERT456"
    'Public Shared m_sdkpwd As String = "fghUIO987"

    Sub New()
        m_Connection = New OdbcConnection(DataProvider.m_ConnectionString)
        m_Connection.Open()
        m_Transaction = m_Connection.BeginTransaction()
    End Sub

    Sub New(ByVal p_beginTransaction As Boolean)
        m_Connection = New OdbcConnection(DataProvider.m_ConnectionString)
        m_Connection.Open()
        If p_beginTransaction Then
            m_Transaction = m_Connection.BeginTransaction()
        End If
    End Sub

    Public Sub Commit(Optional ByVal p_beginTransaction As Boolean = True)
        m_Transaction.Commit()
        If p_beginTransaction Then
            m_Connection.Close()
            m_Connection.Dispose()
        End If
    End Sub

    Sub New(ByVal p_beginTransaction As Boolean, ByVal l_connectionstring As String)
        m_Connection = New OdbcConnection(l_connectionstring)
        m_Connection.Open()
        If p_beginTransaction Then
            m_Transaction = m_Connection.BeginTransaction()
        End If
    End Sub

    Public Sub Colse()
        m_Connection.Close()
        m_Connection.Dispose()
    End Sub

    Public Sub BeginTransaction()
        m_Transaction = m_Connection.BeginTransaction()
    End Sub
    Public Sub Rollback(Optional ByVal p_beginTransaction As Boolean = True)
        m_Transaction.Rollback()
        If IFSZ_Globals.m_Hiba_Naploz_e And (Not IFSZ_Globals.m_Utolso_Hiba Is Nothing) Then
            Dim l_message As String
            m_Transaction = m_Connection.BeginTransaction()
            DataProvider.ExecuteNonQuery(IFSZ_Globals.m_Utolso_Hiba, l_message)
            IFSZ_Globals.m_Utolso_Hiba = Nothing
            m_Transaction.Commit()
        End If
        If p_beginTransaction Then
            m_Connection.Close()
            m_Connection.Dispose()
        End If
    End Sub

    Public Shared Function CreateConnectionString(ByVal p_servername As String, ByVal p_companydb As String, ByVal p_user As String, ByVal p_password As String) As String
        Dim strConnectionString As String
        If IntPtr.Size = 8 Then
            'Do 64-bit stuff
            strConnectionString = String.Concat(strConnectionString, "Driver={HDBODBC};")
        Else
            'Do 32-bit
            strConnectionString = String.Concat(strConnectionString, "Driver={HDBODBC32};")
        End If
        strConnectionString = String.Concat(strConnectionString, "ServerNode=", p_servername, ";")
        strConnectionString = String.Concat(strConnectionString, "database=", p_companydb, ";")
        strConnectionString = String.Concat(strConnectionString, "UID=" + p_user + ";")
        strConnectionString = String.Concat(strConnectionString, "PWD=" + p_password + ";")
        Return strConnectionString
    End Function

End Class