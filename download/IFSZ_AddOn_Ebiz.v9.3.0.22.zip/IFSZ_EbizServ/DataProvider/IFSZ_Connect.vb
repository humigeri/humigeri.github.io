Imports Microsoft.VisualBasic
Imports System
Imports System.Text

Public Class IFSZ_Connect

    Private Shared lm_webapiport As String = Nothing
    Private Shared lm_database As String = Nothing
    Private Shared lm_host As String = Nothing
    Private Shared lm_username As String = Nothing
    Private Shared lm_password As String = Nothing
    Private Shared lm_loglevel As Integer = -1
    Private Shared lm_esignolog As String = Nothing
    Private Shared lm_curllog As Integer = -1
    Private Shared lm_serverregxml As String = Nothing
    Private Shared lm_pfx As String = Nothing
    Private Shared lm_pfxpwd As String = Nothing
    Private Shared lm_lognapoktorol As Integer = -1
    Private Shared lm_timestampurl As String = Nothing
    Private Shared lm_basicauthhost As String = Nothing
    Private Shared lm_basicauthuser As String = Nothing
    Private Shared lm_basicauthpwd As String = Nothing

    'Public Shared m_eles_e As Boolean = True
    Public Shared m_napok_regi As Integer = 30

    Public Shared ReadOnly Property m_webapiport() As String
        Get
            If IFSZ_Connect.lm_webapiport Is Nothing Then
                IFSZ_Connect.lm_webapiport = IFSZ_Globals.GetIniValue("SBO", "webapiport")
                If String.IsNullOrEmpty(IFSZ_Connect.lm_webapiport) Then
                    Throw New Exception("Nincs megadva a port")
                End If
            End If
            Return IFSZ_Connect.lm_webapiport
        End Get
    End Property

    Public Shared ReadOnly Property m_database() As String
        Get
            If IFSZ_Connect.lm_database Is Nothing Then
                IFSZ_Connect.lm_database = IFSZ_Globals.GetIniValue("SBO", "DATABASE")
                If String.IsNullOrEmpty(IFSZ_Connect.lm_database) Then
                    Throw New Exception("Nem siker�lt meghat�rozni az adatb�zist")
                End If
            End If
            Return IFSZ_Connect.lm_database
        End Get
    End Property

    Public Shared ReadOnly Property m_host() As String
        Get
            If IFSZ_Connect.lm_host Is Nothing Then
                IFSZ_Connect.lm_host = IFSZ_Globals.GetIniValue("SBO", "HOST")
                If String.IsNullOrEmpty(IFSZ_Connect.lm_host) Then
                    Throw New Exception("Nem siker�lt meghat�rozni az adatb�zis szervert")
                End If
            End If
            Return IFSZ_Connect.lm_host
        End Get
    End Property

    Public Shared ReadOnly Property m_username() As String
        Get
            If IFSZ_Connect.lm_username Is Nothing Then
                IFSZ_Connect.lm_username = IFSZ_Globals.GetIniValue("SBO", "USERNAME")
                If String.IsNullOrEmpty(IFSZ_Connect.lm_username) Then
                    IFSZ_Connect.lm_username = "sdkuser"
                End If
            End If
            Return IFSZ_Connect.lm_username
        End Get
    End Property

    Public Shared ReadOnly Property m_password() As String
        Get
            If IFSZ_Connect.lm_password Is Nothing Then
                IFSZ_Connect.lm_password = IFSZ_Globals.GetIniValue("SBO", "PASSWORD")
                If String.IsNullOrEmpty(IFSZ_Connect.lm_password) Then
                    IFSZ_Connect.lm_password = "ifszsdk"
                Else
                    IFSZ_Connect.lm_password = getPassword(IFSZ_Connect.lm_password)
                End If
            End If
            Return IFSZ_Connect.lm_password
        End Get
    End Property

    Public Shared ReadOnly Property m_loglevel() As String
        Get
            If IFSZ_Connect.lm_loglevel = -1 Then
                Dim l_temp As String
                l_temp = IFSZ_Globals.GetIniValue("SBO", "loglevel")
                If String.IsNullOrEmpty(l_temp) Then
                    IFSZ_Connect.lm_loglevel = 5
                Else
                    If Not Integer.TryParse(l_temp, IFSZ_Connect.lm_loglevel) Then
                        IFSZ_Connect.lm_loglevel = 5
                    End If
                    If IFSZ_Connect.lm_loglevel < 1 OrElse IFSZ_Connect.lm_loglevel > 5 Then
                        IFSZ_Connect.lm_loglevel = 5
                    End If
                End If
            End If
            Return IFSZ_Connect.lm_loglevel
        End Get
    End Property

    Public Shared ReadOnly Property m_curllog() As String
        Get
            If IFSZ_Connect.lm_curllog = -1 Then
                Dim l_temp As String
                l_temp = IFSZ_Globals.GetIniValue("SBO", "curllog")
                If String.IsNullOrEmpty(l_temp) Then
                    IFSZ_Connect.lm_curllog = 0
                Else
                    If Not Integer.TryParse(l_temp, IFSZ_Connect.lm_curllog) Then
                        IFSZ_Connect.lm_curllog = 0
                    End If
                    If IFSZ_Connect.lm_curllog < 0 OrElse IFSZ_Connect.lm_curllog > 1 Then
                        IFSZ_Connect.lm_curllog = 0
                    End If
                End If
            End If
            Return IFSZ_Connect.lm_curllog
        End Get
    End Property

    Public Shared ReadOnly Property m_lognapoktorol() As String
        Get
            If IFSZ_Connect.lm_lognapoktorol = -1 Then
                Dim l_temp As String
                l_temp = IFSZ_Globals.GetIniValue("SBO", "lognapoktorol")
                If String.IsNullOrEmpty(l_temp) Then
                    IFSZ_Connect.lm_lognapoktorol = 30
                Else
                    If Not Integer.TryParse(l_temp, IFSZ_Connect.lm_lognapoktorol) Then
                        IFSZ_Connect.lm_lognapoktorol = 30
                    End If
                    If IFSZ_Connect.lm_lognapoktorol < 0 Then
                        IFSZ_Connect.lm_lognapoktorol = 30
                    End If
                End If
            End If
            Return IFSZ_Connect.lm_lognapoktorol
        End Get
    End Property

    Public Shared ReadOnly Property m_esignolog() As String
        Get
            If IFSZ_Connect.lm_esignolog Is Nothing Then
                IFSZ_Connect.lm_esignolog = IFSZ_Globals.GetIniValue("SBO", "esignolog")
                If String.IsNullOrEmpty(IFSZ_Connect.lm_esignolog) Then
                    IFSZ_Connect.lm_esignolog = ""
                End If
            End If
            Return IFSZ_Connect.lm_esignolog
        End Get
    End Property

    Public Shared ReadOnly Property m_serverregxml() As String
        Get
            If IFSZ_Connect.lm_serverregxml Is Nothing Then
                IFSZ_Connect.lm_serverregxml = IFSZ_Globals.GetIniValue("SBO", "serverregxml")
                If String.IsNullOrEmpty(IFSZ_Connect.lm_serverregxml) Then
                    IFSZ_Connect.lm_serverregxml = "server_reg.xml"
                End If
            End If
            Return IFSZ_Connect.lm_serverregxml
        End Get
    End Property

    Public Shared ReadOnly Property m_pfx() As String
        Get
            If IFSZ_Connect.lm_pfx Is Nothing Then
                IFSZ_Connect.lm_pfx = IFSZ_Globals.GetIniValue("SBO", "pfx")
                If String.IsNullOrEmpty(IFSZ_Connect.lm_pfx) Then
                    IFSZ_Connect.lm_pfx = "peterke.pfx"
                End If
            End If
            Return IFSZ_Connect.lm_pfx
        End Get
    End Property

    Public Shared ReadOnly Property m_pfxpwd() As String
        Get
            If IFSZ_Connect.lm_pfxpwd Is Nothing Then
                IFSZ_Connect.lm_pfxpwd = IFSZ_Globals.GetIniValue("SBO", "pfxpwd")
                If String.IsNullOrEmpty(IFSZ_Connect.lm_pfxpwd) Then
                    IFSZ_Connect.lm_pfxpwd = "12345"
                Else
                    IFSZ_Connect.lm_pfxpwd = getPassword(IFSZ_Connect.lm_pfxpwd)
                End If
            End If
            Return IFSZ_Connect.lm_pfxpwd
        End Get
    End Property

    Public Shared ReadOnly Property m_timestampurl() As String
        Get
            If IFSZ_Connect.lm_timestampurl Is Nothing Then
                IFSZ_Connect.lm_timestampurl = IFSZ_Globals.GetIniValue("SBO", "timestampurl")
                If String.IsNullOrEmpty(IFSZ_Connect.lm_timestampurl) Then
                    IFSZ_Connect.lm_timestampurl = "https://bteszt.e-szigno.hu/tsa"
                End If
            End If
            Return IFSZ_Connect.lm_timestampurl
        End Get
    End Property

    Public Shared ReadOnly Property m_basicauthhost() As String
        Get
            If IFSZ_Connect.lm_basicauthhost Is Nothing Then
                IFSZ_Connect.lm_basicauthhost = IFSZ_Globals.GetIniValue("SBO", "basicauthhost")
                If String.IsNullOrEmpty(IFSZ_Connect.lm_basicauthhost) Then
                    IFSZ_Connect.lm_basicauthhost = "bteszt.e-szigno.hu"
                End If
            End If
            Return IFSZ_Connect.lm_basicauthhost
        End Get
    End Property

    Public Shared ReadOnly Property m_basicauthuser() As String
        Get
            If IFSZ_Connect.lm_basicauthuser Is Nothing Then
                IFSZ_Connect.lm_basicauthuser = IFSZ_Globals.GetIniValue("SBO", "basicauthuser")
                If String.IsNullOrEmpty(IFSZ_Connect.lm_basicauthuser) Then
                    IFSZ_Connect.lm_basicauthuser = "teszt"
                End If
            End If
            Return IFSZ_Connect.lm_basicauthuser
        End Get
    End Property

    Public Shared ReadOnly Property m_basicauthpwd() As String
        Get
            If IFSZ_Connect.lm_basicauthpwd Is Nothing Then
                IFSZ_Connect.lm_basicauthpwd = IFSZ_Globals.GetIniValue("SBO", "basicauthpwd")
                If String.IsNullOrEmpty(IFSZ_Connect.lm_basicauthpwd) Then
                    IFSZ_Connect.lm_basicauthpwd = "teszt"
                Else
                    IFSZ_Connect.lm_basicauthpwd = getPassword(IFSZ_Connect.lm_basicauthpwd)
                End If
            End If
            Return IFSZ_Connect.lm_basicauthpwd
        End Get
    End Property

    Public Shared m_lasthiba As String = ""

    Public Shared Function ConnectDB() As Boolean

        'Return True 'Lehet, hogy nincs �rtelme ennek a functionnak
        Try

            If IFSZ_Connect.m_host.EndsWith(":30015") Then
                DataProvider.m_tipus = 1
                DataProvider.m_ConnectionString = HANAConnectionProvider.CreateConnectionString(IFSZ_Connect.m_host, IFSZ_Connect.m_database, IFSZ_Connect.m_username, IFSZ_Connect.m_password)
            Else
                DataProvider.m_tipus = 0
                DataProvider.m_ConnectionString = "Persist Security Info=False" +
                                              ";database=" + IFSZ_Connect.m_database +
                                              ";server=" + IFSZ_Connect.m_host +
                                              ";User ID=" + IFSZ_Connect.m_username +
                                              ";Password=" + IFSZ_Connect.m_password +
                                              ";Connect Timeout=10000"
            End If

            IFSZ_Globals.AppendLog("ConnectDb " + DataProvider.m_ConnectionString, 1)
            Return True

            'Dim conn As New System.Data.SqlClient.SqlConnection(DataProvider.m_ConnectionString)
            'conn.Open()
            'If conn.State = System.Data.ConnectionState.Open Then
            '    Return True
            'Else
            '    AppendLog("Nem siker�lt csatlakozni az adatb�zishoz")
            '    Return False
            'End If

        Catch ex As Exception
            IFSZ_Globals.AppendLog("Nem siker�lt csatlakozni az adatb�zishoz: " + ex.ToString())
        End Try

        Return False

    End Function

    Public Shared Function getPassword(ByVal p_kod As String) As String
        Return IFSZ_Connect.visszakodol(p_kod)
    End Function

    Public Shared Function visszakodol(ByVal p_kod As String) As String
        Dim ByteConverter As Encoding = Encoding.Unicode
        Dim i As Integer
        Dim l_encrypted_kulcs() As Byte
        Dim l_decrypted_kulcs() As Byte
        Dim l_moduleName, l_Module, l_azonosito, l_tipus As String
        Dim l_kulcs As String

        l_encrypted_kulcs = IFSZ_Security.GetEncryptedByte(p_kod)
        Dim key As New System.Security.Cryptography.DESCryptoServiceProvider()
        Dim plaintext As String = IFSZ_Security.DESDecrypt(l_encrypted_kulcs, key)
        Return plaintext
    End Function

    Public Shared Function bekodol(ByVal p_kod As String) As String
        Dim ByteConverter As Encoding = Encoding.Unicode
        Dim dataToEncrypt As Byte() = ByteConverter.GetBytes(p_kod)
        Dim l_kulcs As String
        Dim key As New System.Security.Cryptography.DESCryptoServiceProvider()
        Dim buffer As Byte() = IFSZ_Security.DESEncrypt(p_kod, key)
        l_kulcs = ByteConverter.GetString(buffer)

        Dim l_string As String
        Dim j As Integer
        For j = 1 To buffer.Length
            If l_string <> "" Then
                l_string = l_string & "&" & buffer(j - 1).ToString
            Else
                l_string = l_string & buffer(j - 1).ToString
            End If
        Next

        ' Decrypt the byte array back to a string.
        Dim plaintext As String = IFSZ_Security.DESDecrypt(buffer, key)
        Return l_string
    End Function

End Class
