﻿Public Class ProcessedReturnValue
    Public eol_id As Integer
    Public token As Integer
    Public started As DateTime
    Public feldolgozva As Boolean
    Public hiba As String
End Class
