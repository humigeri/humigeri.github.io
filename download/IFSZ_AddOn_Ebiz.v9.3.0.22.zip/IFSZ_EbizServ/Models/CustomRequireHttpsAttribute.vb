﻿Imports System
Imports System.Net
Imports System.Net.Http
Imports System.Text
Imports System.Web.Http.Controllers
Imports System.Web.Http.Filters

Namespace WebAPIEnableHTTPS.Models
    Public Class CustomRequireHttpsAttribute
        Inherits AuthorizationFilterAttribute

        Public Overrides Sub OnAuthorization(ByVal actionContext As HttpActionContext)
            If actionContext.Request.RequestUri.Scheme <> Uri.UriSchemeHttps Then
                actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.Found)
                actionContext.Response.Content = New StringContent("<p>Use https instead of http</p>", Encoding.UTF8, "text/html")
                Dim uriBuilder As UriBuilder = New UriBuilder(actionContext.Request.RequestUri)
                uriBuilder.Scheme = Uri.UriSchemeHttps
                uriBuilder.Port = IFSZ_Connect.m_webapiport
                actionContext.Response.Headers.Location = uriBuilder.Uri
            Else
                MyBase.OnAuthorization(actionContext)
            End If
        End Sub
    End Class
End Namespace
