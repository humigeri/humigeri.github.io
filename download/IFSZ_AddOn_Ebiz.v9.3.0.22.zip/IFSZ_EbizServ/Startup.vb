﻿Imports Owin
Imports System.Web.Http
Imports IFSZ_EbizServ.WebAPIEnableHTTPS.Models

Public Class Startup
    Public Sub Configuration(ByVal appBuilder As IAppBuilder)
        Dim config As HttpConfiguration = New HttpConfiguration()
        'config.Filters.Add(New CustomRequireHttpsAttribute())
        config.MapHttpAttributeRoutes()
        config.Routes.MapHttpRoute(
            name:="DefaultApi",
            routeTemplate:="{controller}/{id}",
            defaults:=New With {.id = RouteParameter.Optional}
        )
        'config.Filters.Add(New AuthorizeAttribute())
        appBuilder.UseWebApi(config)
    End Sub
End Class
