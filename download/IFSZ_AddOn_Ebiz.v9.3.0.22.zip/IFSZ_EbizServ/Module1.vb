﻿Imports Microsoft.Owin.Hosting
Imports System.ServiceProcess
Imports System.Configuration.Install
Module Module1    Public m_restart_DIAPI_failure As Boolean = True    Private m_baseaddress As String
    Public m_running As Boolean = False
    Public m_paused As Boolean = False

    Public c_encoding As Integer = 65001
    Public c_iskola_qgnum As Integer = 1
    Public c_SQL_TimeZoneID As String = "Central Europe Standard Time"

    Public mm_IFSZ_Globals As IFSZ_Globals

    Public mm_folyamat As String = "EBIZSERV"
    Public mm_folyamat_azon As String = "-"

    Public mm_mailuser As String
    Public mm_mailpw As String
    Public mm_mailhost As String
    Public mm_mailport As String
    Public mm_mailSSL As String

    Public mm_exe_utvonal As String = ""
    Public mm_eszignwork_utvonal As String = ""
    Public mm_log_utvonal As String = ""

    Sub Main(ByVal args() As String)

        'Dim xyy As String = IFSZ_Connect.visszakodol("124&117&58&33&247&66&27&69&46&109&130&198&227&182&29&236&8&149&249&53&68&42&232&31")

        If args.Length = 1 Then
            If args(0) = "/install" Then
                Using inst As New AssemblyInstaller(GetType(Module1).Assembly, args)
                    Dim state As New Hashtable()
                    inst.UseNewContext = True
                    Try
                        inst.Install(state)
                        inst.Commit(state)
                    Catch ex As Exception
                        Try
                            inst.Rollback(state)
                        Catch ex2 As Exception
                            Dim x As Integer = 1
                        End Try
                        Environment.Exit(-100)
                    End Try
                End Using
                Environment.Exit(0)
            ElseIf args(0) = "/uninstall" Then
                Using inst As New AssemblyInstaller(GetType(Module1).Assembly, args)
                    Dim state As New Hashtable()
                    inst.UseNewContext = True
                    Try
                        inst.Uninstall(state)
                    Catch ex As Exception
                        Try
                            inst.Rollback(state)
                        Catch ex2 As Exception
                            Dim x As Integer = 1
                        End Try
                        Environment.Exit(-100)
                    End Try
                End Using
                Environment.Exit(0)
            End If
        ElseIf args.Length = 2 Then
            If args(0) = "/pwd" Then
                System.Console.WriteLine(IFSZ_Connect.bekodol(args(1)).Replace("&", "&amp;"))
            End If
            Environment.Exit(0)
        ElseIf args.Length = 4 Then
            If args(0) = "/csat" Then
                Console.WriteLine("Csatolmány")
                If IFSZ_Connect.ConnectDB() Then
                    Console.WriteLine("Csatlakozva")
                    mm_exe_utvonal = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location)
                    mm_eszignwork_utvonal = mm_exe_utvonal + "\eszignowork"
                    mm_log_utvonal = mm_exe_utvonal + "\log"

                    If Not System.IO.Directory.Exists(mm_eszignwork_utvonal) Then
                        System.IO.Directory.CreateDirectory(mm_eszignwork_utvonal)
                    End If
                    If Not System.IO.Directory.Exists(mm_log_utvonal) Then
                        System.IO.Directory.CreateDirectory(mm_log_utvonal)
                    End If

                    Idozites.CsatolProba(args(1), args(2), args(3))
                End If
            End If
            Environment.Exit(0)
        End If

        If Environment.UserInteractive Then
            'MsgBox("que?")
            Console.WriteLine("Szolgáltatás inicializálása")
            InitInterface()
            If Module1.m_running Then
                Console.WriteLine("A szolgáltatás console ablakban elindult. Nyomjon entert a befejezéshez")
                Dim l_thread As New System.Threading.Thread(AddressOf ConsoleStop)
                l_thread.SetApartmentState(Threading.ApartmentState.STA)
                l_thread.Start()
            End If
        Else
            Dim l_servtorun As ServiceBase() = {New EbizServService()}
            ServiceBase.Run(l_servtorun)
        End If

    End Sub    Public Sub InitInterface()
        Try
            m_baseaddress = "http://*:" + IFSZ_Connect.m_webapiport + "/"
            m_running = True

            mm_exe_utvonal = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location)
            mm_eszignwork_utvonal = mm_exe_utvonal + "\eszignowork"
            mm_log_utvonal = mm_exe_utvonal + "\log"

            If Not System.IO.Directory.Exists(mm_eszignwork_utvonal) Then
                System.IO.Directory.CreateDirectory(mm_eszignwork_utvonal)
            End If
            If Not System.IO.Directory.Exists(mm_log_utvonal) Then
                System.IO.Directory.CreateDirectory(mm_log_utvonal)
            End If

            'Dim x As String = IFSZ_Connect.bekodol("ifsz").Replace("&", "&amp;")

            IFSZ_Globals.AppendLog("IFSZ_EbizServ elindult - " + m_baseaddress)

            If IFSZ_EbizServ.My.Settings.restart_DIAPI_failure = 1 Then
                Module1.m_restart_DIAPI_failure = True
                IFSZ_Globals.AppendLog("Szolgáltatás restart DIAPI hiba esetén")
            End If

            Dim l_thread As New System.Threading.Thread(AddressOf WebAppThread)
            l_thread.SetApartmentState(Threading.ApartmentState.STA)
            l_thread.Start()
            IFSZ_Globals.AppendLog("WebAppThred elindítva", 1)

            Dim l_thread2 As New System.Threading.Thread(AddressOf TimerProcessThread)
            l_thread2.SetApartmentState(Threading.ApartmentState.STA)
            l_thread2.Start()
            IFSZ_Globals.AppendLog("SendProcessThread elindítva", 1)

        Catch ex As Exception
            'Nincs mit tenni
            IFSZ_Globals.AppendLog("(9999) " + ex.Message)
        End Try
    End Sub    Private Sub WebAppThread()
        Using WebApp.Start(Of Startup)(url:=m_baseaddress)
            While m_running
                System.Threading.Thread.Sleep(1000)
            End While
        End Using
    End Sub

    ''' <summary>
    ''' Ez a szál végzi az ütemezett feldolgozásokat
    ''' </summary>
    Private Sub TimerProcessThread()
        Dim l_vanmunka As Boolean = False
        While m_running
            If Not Module1.m_paused Then
                l_vanmunka = Idozites.ProcessJob()
            Else
                l_vanmunka = False
            End If
            If Not l_vanmunka Then System.Threading.Thread.Sleep(250)  'Ha üres a queue (False-t kaptunk vissza), akkor pihenünk egy kicsit, ha nem, akkor felesleges pihenni
        End While
    End Sub

    Private Sub ConsoleStop()
        Console.ReadLine()
        Module1.m_running = False
        Console.WriteLine("A szolgáltatás pillanatokon belül leáll...")
    End Sub


    <System.Runtime.InteropServices.DllImport("user32.dll",
    EntryPoint:="ShowWindow",
    CallingConvention:=Runtime.InteropServices.CallingConvention.StdCall,
    CharSet:=Runtime.InteropServices.CharSet.Unicode, SetLastError:=True)>
    Public Function ShowWindow(ByVal handle As IntPtr,
    ByVal nCmd As Int32) As Boolean
        ' Leave function empty
    End Function    <System.Runtime.InteropServices.DllImport("user32.dll",
    EntryPoint:="FindWindow",
    CallingConvention:=Runtime.InteropServices.CallingConvention.StdCall,
    CharSet:=Runtime.InteropServices.CharSet.Unicode, SetLastError:=True)>
    Public Function FindWindow(ByVal WindowClass As String,
                                     ByVal WindowName As String) As IntPtr
        ' Leave function empty
    End FunctionEnd Module