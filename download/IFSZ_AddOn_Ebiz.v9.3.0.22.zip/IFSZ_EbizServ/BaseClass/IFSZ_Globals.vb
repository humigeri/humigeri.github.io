﻿Imports System.Reflection
Imports System.Globalization
Imports System.Threading
Imports System.IO
Imports System.Resources
Imports System.Diagnostics
Imports System.Data
Imports System
Imports System.Collections
Imports System.Web.Http
Imports System.Net.Http

'Imports IniFile

Public Class IFSZ_Globals

    Public Shared m_ResourceManager As ResourceManager

    Public Shared m_Connection As Object
    Public Shared m_Connection1 As Object

    Public Shared m_connLockObject As New Object
    Public Shared m_dbconnLockObject As New Object
    Public Shared m_logLockObject As New Object
    Public Shared MicraInitialised As New Object
    Public Shared PositionBufferEvent As New Object

    Public Shared DefaultCellBackColor As System.Drawing.Color = System.Drawing.Color.FromArgb(CType(CType(253, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(243, Byte), Integer))
    Public Shared m_Hiba_Naploz_e As Boolean = False
    Public Shared m_Utolso_Hiba As String
    Public Shared m_ParentAddOn As Object 'SBOAddOn
    Public Shared m_MDIParent As Object 'IFSZ_MDIParent
    Public Shared m_ParentType As String = ""
    Public Shared m_CultInfo As System.Globalization.CultureInfo
    Public Shared m_RandomClass As Random
    Public Shared p_Key As Byte() = {80, 82, 84, 86, 88, 90, 92, 94}
    Public Shared p_IV As Byte() = {168, 74, 196, 13, 29, 206, 159, 120}

    Public Shared NyugtaFormFut As Boolean = False
    Public Shared USER As String
    Public Shared USERNAME As String

    Sub New(Optional ByRef p_Parent As Object = Nothing)


    End Sub

    Public Shared Property LocRM() As ResourceManager
        Get
            IFSZ_Globals.SetLanguage()
            Return m_ResourceManager
        End Get
        Set(ByVal Value As ResourceManager)
            m_ResourceManager = Value
        End Set
    End Property

    Public Shared Sub SetLanguage()
        If IFSZ_Globals.m_ParentType = "SBOAddOn" Or IFSZ_Globals.m_ParentType = "IFSZ_Addon" Then
            Select Case m_ParentAddOn.SboApplication.Language
                Case "3"
                    IFSZ_Globals.SetLanguage("En")
                Case "14"
                    IFSZ_Globals.SetLanguage("Hu")
                Case ""
                    IFSZ_Globals.SetLanguage("Ge")
                Case Else
                    IFSZ_Globals.SetLanguage("En")
            End Select
        Else
            IFSZ_Globals.SetLanguage("Hu")
        End If
    End Sub

    Public Shared Sub SetLanguage(ByVal l_language As String)
        Select Case l_language
            Case "En"
                m_CultInfo = New CultureInfo("en-gb")
            Case "Hu"
                m_CultInfo = New CultureInfo("hu-hu")
            Case "Ge"
                m_CultInfo = New CultureInfo("ge-ge")
            Case "Sr"
                m_CultInfo = New CultureInfo("sr-sr")
            Case Else
                m_CultInfo = New CultureInfo("en-gb")
        End Select
        Thread.CurrentThread.CurrentCulture = m_CultInfo
        Thread.CurrentThread.CurrentUICulture = m_CultInfo
    End Sub


    Public Shared Function GetString(ByVal p_message As String, Optional ByVal p_par1 As String = "", Optional ByVal p_par2 As String = "", Optional ByVal p_par3 As String = "", Optional ByVal p_par4 As String = "") As String
        Dim l_message As String
        'IFSZ_Globals.SetLanguage()
        Dim ci As System.Globalization.CultureInfo
        ci = System.Threading.Thread.CurrentThread.CurrentCulture
        'l_message = IFSZ_Globals.LocRM.GetString(p_message, ci)
        l_message = LocRM.GetString(p_message.ToUpper, m_CultInfo)

        If l_message Is Nothing Then
            l_message = p_message
        End If
        If Not p_par1 Is Nothing And p_par1 <> "" Then
            l_message = l_message.Replace("<p1>", p_par1)
        End If
        If Not p_par2 Is Nothing And p_par2 <> "" Then
            l_message = l_message.Replace("<p2>", p_par2)
        End If
        If Not p_par3 Is Nothing And p_par3 <> "" Then
            l_message = l_message.Replace("<p3>", p_par3)
        End If
        If Not p_par4 Is Nothing And p_par4 <> "" Then
            l_message = l_message.Replace("<p4>", p_par4)
        End If
        Return l_message
    End Function

    Public Shared Function get_next_seq(
        ByVal Domain As String
    ) As String
        Dim str_code As String
        Dim int_next_seq As Integer
        Dim str_next_seq As String
        Dim l_message As String
        Dim l_result As Integer

        If Domain Is Nothing Or Domain = "" Then
            str_code = "DEFAULT"
        Else
            str_code = Domain
        End If

        Try
            int_next_seq = DataProvider.ExecuteScalar("Select u_next from [@ifsz_sequences] with(updlock) where code = '" & str_code & "'")
            l_result = DataProvider.ExecuteNonQuery("update [@ifsz_sequences] set u_next = " & int_next_seq & "+1 where code = '" & str_code & "'", l_message)
            str_next_seq = int_next_seq
            Return str_next_seq.PadLeft(8, "0")
        Catch
            Return -1
        Finally
        End Try
    End Function 'get_next_seq

    Public Shared Function DoubleToString(ByVal p_ertek As Double, Optional ByVal p_decimal_separator As String = ".") As String
        Dim nfi As Globalization.NumberFormatInfo = New Globalization.NumberFormatInfo
        nfi.NumberDecimalSeparator = p_decimal_separator
        nfi.PercentGroupSeparator = ""

        Return p_ertek.ToString(nfi)

    End Function

    Public Shared Function StringToDouble(ByVal p_ertek As String) As Double

        If p_ertek Is Nothing Or p_ertek = "" Then
            Return 0
        End If

        Dim lTemp As String = p_ertek.Replace("0", "").Replace("1", "").Replace("2", "").Replace("3", "").Replace("4", "").Replace("5", "").Replace("6", "").Replace("7", "").Replace("8", "").Replace("9", "").Replace(" ", "")

        If lTemp Is Nothing Or lTemp = "" Or lTemp = "," Then
            Return CDbl(p_ertek)
        ElseIf lTemp = "-" Or lTemp = "-," Then
            If p_ertek.StartsWith("-") Then
                Return CDbl(p_ertek)
            Else
                Return 0
            End If
        ElseIf lTemp = "." Then
            Return CDbl(p_ertek.Replace(".", ","))
        ElseIf lTemp = "-." Then
            If p_ertek.StartsWith("-") Then
                Return CDbl(p_ertek.Replace(".", ","))
            Else
                Return 0
            End If
        Else
            Return 0
        End If

    End Function

    ' Form mezőjében lévő szöveget értelmezi, mint szám. Paraméterként megadandó még az adott mezőn értelmezett formázó sztring
    ' És a double érték. Ha kell, akkor a sztring paramétert is visszaformázza a megfelelő formátumba, és a függvény visszatérési értéke true vagy false lesz, hogy sikerült-e, vagy sem
    Public Shared Function FormStringToDouble(ByRef p_ertek As String, ByRef p_double_ertek As Double, Optional ByVal p_format As String = "") As Boolean
        Dim nfi As System.Globalization.NumberFormatInfo = System.Threading.Thread.CurrentThread.CurrentCulture.NumberFormat

        If p_ertek Is Nothing Or p_ertek = "" Then
            Return True
        End If

        'Normál konverzió
        Try
            p_double_ertek = Double.Parse(p_ertek, nfi)
            If p_format <> "" Then
                p_ertek = p_double_ertek.ToString(p_format, nfi)
            Else
                p_ertek = p_double_ertek.ToString(nfi)
            End If
            Return True
        Catch
        End Try

        'Ha nem jött össze, akkor megpróbáljuk úgy értelmezni, hogy talán pontot írt a felhasználó tizedeselválasztóként
        If nfi.NumberDecimalSeparator <> "." Then
            p_ertek.Replace(".", nfi.NumberDecimalSeparator)
            Try
                p_double_ertek = Double.Parse(p_ertek, nfi)
                If p_format <> "" Then
                    p_ertek = p_double_ertek.ToString(p_format, nfi)
                Else
                    p_ertek = p_double_ertek.ToString(nfi)
                End If
                Return True
            Catch
            End Try
        End If

        Return False

        'If p_ertek.Replace(nfi.NativeDigits(0), "").Replace(nfi.NativeDigits(1), "").Replace(nfi.NativeDigits(2), "").Replace(nfi.NativeDigits(3), "").Replace(nfi.NativeDigits(4), "").Replace(nfi.NativeDigits(5), "").Replace(nfi.NativeDigits(6), "").Replace(nfi.NativeDigits(7), "").Replace(nfi.NativeDigits(8), "").Replace(nfi.NativeDigits(9), "").Replace(nfi.NegativeSign, "").Replace(nfi.NegativeInfinitySymbol, "").Replace(nfi.NumberDecimalSeparator, "").Replace(nfi.NumberGroupSeparator, "").Replace(nfi.PositiveInfinitySymbol, "").Replace(nfi.PositiveSign, "").Replace(" ", "") <> "" _
        'Then
        '    Return False
        'End If

    End Function

    ' Form mezőjében lévő szöveget értelmezi, mint dátum (idő nélkül). Paraméterként megadandó még az adott mezőn értelmezett formázó sztring
    ' És a datetime érték. Ha kell, akkor a sztring paramétert is visszaformázza a megfelelő formátumba, és a függvény visszatérési értéke true vagy false lesz, hogy sikerült-e, vagy sem
    Public Shared Function FormStringToDate(ByRef p_ertek As String, ByRef p_date_ertek As DateTime, Optional ByVal p_format As String = "") As Boolean
        Dim dfi As System.Globalization.DateTimeFormatInfo = System.Threading.Thread.CurrentThread.CurrentCulture.DateTimeFormat

        If p_ertek Is Nothing Or p_ertek = "" Then
            Return True
        End If

        'Első körben megpróbáljuk értelmezni
        Try
            If p_format <> "" Then
                p_date_ertek = DateTime.ParseExact(p_ertek, p_format, dfi)
            Else
                p_date_ertek = DateTime.Parse(p_ertek, dfi)
            End If
            p_date_ertek = p_date_ertek.Subtract(p_date_ertek.TimeOfDay)
            If p_format <> "" Then
                p_ertek = p_date_ertek.ToString(p_format, dfi)
            Else
                p_ertek = p_date_ertek.ToString("d", dfi)
            End If
            Return True
        Catch
        End Try

        'Ha nem sikerült, megpróbáljuk a StringToDateVal csodálatosan összeeszkábált függvényecskét felhasználni formázásra
        Try
            p_date_ertek = StringToDateVal(p_ertek)
            p_date_ertek = p_date_ertek.Subtract(p_date_ertek.TimeOfDay)
            If p_format <> "" Then
                p_ertek = p_date_ertek.ToString(p_format, dfi)
            Else
                p_ertek = p_date_ertek.ToString("d", dfi)
            End If
            Return True
        Catch
        End Try

        'Ez a függvény a legrosszabb esetben is visszaadja a now-t, tehát ide nem jut el a program, de mégis maradjon ez itt
        Return False

    End Function

    ' Form mezőjében lévő szöveget értelmezi, mint dátum (idővel). Paraméterként megadandó még az adott mezőn értelmezett formázó sztring
    ' És a datetime érték. Ha kell, akkor a sztring paramétert is visszaformázza a megfelelő formátumba, és a függvény visszatérési értéke true vagy false lesz, hogy sikerült-e, vagy sem
    Public Shared Function FormStringToDateTime(ByRef p_ertek As String, ByRef p_date_ertek As DateTime, Optional ByVal p_format As String = "") As Boolean
        Dim dfi As System.Globalization.DateTimeFormatInfo = System.Threading.Thread.CurrentThread.CurrentCulture.DateTimeFormat

        If p_ertek Is Nothing Or p_ertek = "" Then
            Return True
        End If

        'Első körben megpróbáljuk értelmezni
        Try
            If p_format <> "" Then
                p_date_ertek = DateTime.ParseExact(p_ertek, p_format, dfi)
                p_ertek = p_date_ertek.ToString(p_format, dfi)
            Else
                p_date_ertek = DateTime.Parse(p_ertek, dfi)
                p_ertek = p_date_ertek.ToString("g", dfi)
            End If
            Return True
        Catch
        End Try

        'Ha nem sikerült, megpróbáljuk a StringToDateVal csodálatosan összeeszkábált függvényecskét felhasználni formázásra
        Try
            p_date_ertek = StringToDateVal(p_ertek)
            If p_format <> "" Then
                p_ertek = p_date_ertek.ToString(p_format, dfi)
            Else
                p_ertek = p_date_ertek.ToString("g", dfi)
            End If
            Return True
        Catch
        End Try

        'Ez a függvény a legrosszabb esetben is visszaadja a now-t, tehát ide nem jut el a program, de mégis maradjon ez itt
        Return False

    End Function

    ' A FormStringToDouble-nek a fordítottja kellene, hogy legyen
    ' Külön vigyázni kell a Nothing értékkel, mert ez a függvény nem tud Nothing eredménnyel visszatérni
    Public Shared Function DoubleToFormString(ByVal p_ertek As Double, Optional ByVal p_format As String = "") As String
        Dim nfi As System.Globalization.NumberFormatInfo = System.Threading.Thread.CurrentThread.CurrentCulture.NumberFormat

        'Normál konverzió
        Try
            If p_format <> "" Then
                Return p_ertek.ToString(p_format)
            Else
                Return p_ertek.ToString
            End If
        Catch
        End Try

        Return Nothing

    End Function

    ' FormStringToDate fordítottja
    Public Shared Function DateToFormString(ByRef p_ertek As DateTime, Optional ByVal p_format As String = "") As String
        Dim dfi As System.Globalization.DateTimeFormatInfo = System.Threading.Thread.CurrentThread.CurrentCulture.DateTimeFormat

        'Első körben megpróbáljuk értelmezni
        Try
            If p_format <> "" Then
                Return p_ertek.ToString(p_format, dfi)
            Else
                Return p_ertek.ToString("d", dfi)
            End If
        Catch
        End Try

        Return Nothing

    End Function

    ' FormStringToDateTime fordítottja
    Public Shared Function DateTimeToFormString(ByRef p_ertek As DateTime, Optional ByVal p_format As String = "") As String
        Dim dfi As System.Globalization.DateTimeFormatInfo = System.Threading.Thread.CurrentThread.CurrentCulture.DateTimeFormat

        'Első körben megpróbáljuk értelmezni
        Try
            If p_format <> "" Then
                Return p_ertek.ToString(p_format, dfi)
            Else
                Return p_ertek.ToString("g", dfi)
            End If
        Catch
        End Try

        Return Nothing

    End Function

    'Internal függvények, az entitásban használjuk, mivel ott a különböző típusú értékek stringként vannak reprezentálva. A formátum egységes
    Public Shared Function GetInternalStringToDateTime(ByVal p_ertek As String) As DateTime
        Dim dfi As System.Globalization.DateTimeFormatInfo = System.Threading.Thread.CurrentThread.CurrentCulture.DateTimeFormat
        If p_ertek Is Nothing Then
            Return Nothing
        ElseIf p_ertek = "" Then
            Return Nothing
        End If
        Return DateTime.ParseExact(p_ertek, "yyyyMMddHHmmss", dfi)
    End Function

    Public Shared Function GetInternalStringToDate(ByVal p_ertek As String) As DateTime
        Dim dfi As System.Globalization.DateTimeFormatInfo = System.Threading.Thread.CurrentThread.CurrentCulture.DateTimeFormat
        Return DateTime.ParseExact(p_ertek, "yyyyMMdd", dfi)
    End Function

    Public Shared Function GetInternalDateTimeToString(ByVal p_ertek As DateTime) As String
        If p_ertek.Year = 1 Then
            Return ""
        End If
        Return p_ertek.ToString("yyyyMMddHHmmss")
    End Function

    Public Shared Function GetInternalDateToString(ByVal p_ertek As Date) As String
        Return p_ertek.ToString("yyyyMMdd")
    End Function

    Public Shared Function GetInternalStringToDouble(ByVal p_ertek As String) As Double
        Dim nfi As New System.Globalization.NumberFormatInfo()
        nfi.NumberGroupSeparator = ""
        nfi.NumberDecimalSeparator = "."
        If p_ertek Is Nothing Then
            Return Nothing
        End If
        Return Double.Parse(p_ertek, nfi)
    End Function

    Public Shared Function GetStringToDouble(ByVal p_ertek As String, ByVal p_decimal_separator As String) As Double
        Dim nfi As New System.Globalization.NumberFormatInfo()
        nfi.NumberGroupSeparator = ""
        nfi.NumberDecimalSeparator = p_decimal_separator
        If p_ertek Is Nothing Then
            Return Nothing
        End If
        Return Double.Parse(p_ertek, nfi)
    End Function


    Public Shared Function GetInternalDoubleToString(ByVal p_ertek As Double) As String
        Dim nfi As New System.Globalization.NumberFormatInfo()
        nfi.NumberGroupSeparator = ""
        nfi.NumberDecimalSeparator = "."
        If p_ertek = 0 Then
            Return "0"
        Else
            Return p_ertek.ToString("####################.########", nfi)
        End If
    End Function


    Public Shared Function StringToDouble(ByVal p_ertek As String, ByVal p_digit As Integer) As Double

        If p_ertek Is Nothing Or p_ertek = "" Then
            Return 0
        End If

        Dim lTemp As String = p_ertek.Replace("0", "").Replace("1", "").Replace("2", "").Replace("3", "").Replace("4", "").Replace("5", "").Replace("6", "").Replace("7", "").Replace("8", "").Replace("9", "").Replace(" ", "").Replace("-", "")

        If lTemp Is Nothing Or lTemp = "" Or lTemp = "," Then
            Return Math.Round(CType(p_ertek, Double), p_digit)
        ElseIf lTemp = "." Then
            Return Math.Round(CType(p_ertek.Replace(".", ","), Double), p_digit)
        Else
            Return 0
        End If

    End Function

    Public Shared Function DateTimeToString(ByVal p_ertek As DateTime) As String
        Return p_ertek.ToString("yyyyMMdd")
    End Function

    Public Shared Function StringToDateTime(ByVal p_ertek As String) As DateTime
        Dim dfi As Globalization.DateTimeFormatInfo = New Globalization.DateTimeFormatInfo()
        Try
            Return DateTime.ParseExact(p_ertek.Replace(".", "").Replace("/", "").Replace(" ", ""), "yyyyMMdd", dfi)
        Catch ex As Exception
            Return DateTime.Now
        End Try
    End Function

    'Public Shared Function GetMyProc() As Process
    '    Dim MyProcs() As Process

    '    MyProcs = Process.GetProcessesByName("IFSZ_AddOnBase")
    '    If MyProcs.Length <> 0 Then
    '        For i As Integer = 0 To MyProcs.Length - 1
    '            Return MyProcs(i)
    '        Next
    '    End If

    '    MyProcs = Process.GetProcessesByName("IFSZ_Cash")
    '    If MyProcs.Length <> 0 Then
    '        For i As Integer = 0 To MyProcs.Length - 1
    '            Return MyProcs(i)
    '        Next
    '    End If

    '    MyProcs = Process.GetProcessesByName("IFSZ_AddOnBase.vshost")
    '    If MyProcs.Length <> 0 Then
    '        For i As Integer = 0 To MyProcs.Length - 1
    '            Return MyProcs(i)
    '        Next
    '    End If

    '    MyProcs = Process.GetProcessesByName("IFSZ_Kassza.vshost")
    '    If MyProcs.Length <> 0 Then
    '        For i As Integer = 0 To MyProcs.Length - 1
    '            Return MyProcs(i)
    '        Next
    '    End If

    '    MyProcs = Process.GetProcessesByName(My.Settings.Item("ProcessName"))
    '    If MyProcs.Length <> 0 Then
    '        For i As Integer = 0 To MyProcs.Length - 1
    '            Return MyProcs(i)
    '        Next
    '    End If

    '    MyProcs = Process.GetProcessesByName(My.Settings.Item("ProcessName") + ".vshost")
    '    If MyProcs.Length <> 0 Then
    '        For i As Integer = 0 To MyProcs.Length - 1
    '            Return MyProcs(i)
    '        Next
    '    End If

    '    Return Nothing

    'End Function


    Public Shared Function StringToDateVal(ByVal p_ertek As String) As DateTime
        Dim dfi As Globalization.DateTimeFormatInfo = New Globalization.DateTimeFormatInfo()
        Dim l_ertek As String = p_ertek.Replace(".", "").Replace("/", "").Replace(" ", "")
        Dim l_nap, l_honap, l_ev As String
        Dim l_poz As Int16
        'Ha nem megfelel? karaktereket tartalmaz a sztring, akkor a now-t adjuk vissza
        If p_ertek.Replace(".", "").Replace("/", "").Replace(" ", "").Replace("0", "").Replace("1", "").Replace("2", "").Replace("3", "").Replace("4", "").Replace("5", "").Replace("6", "").Replace("7", "").Replace("8", "").Replace("9", "") <> "" Then
            Return DateTime.Now()
        End If
        l_ev = DateTime.Now().ToString("yyyyMMdd").Substring(0, 4)
        l_honap = DateTime.Now().ToString("yyyyMMdd").Substring(4, 2)
        l_nap = DateTime.Now().ToString("yyyyMMdd").Substring(6, 2)
        l_poz = p_ertek.Length - 1
        If Char.IsDigit(p_ertek.Chars(l_poz)) Then
            l_nap = p_ertek.Chars(l_poz).ToString
            l_poz = l_poz - 1
        Else
            Return DateTime.Now()
        End If
        If l_poz >= 0 Then
            If Char.IsDigit(p_ertek.Chars(l_poz)) Then
                l_nap = p_ertek.Chars(l_poz).ToString + l_nap
                l_poz = l_poz - 1
            Else
                l_poz = l_poz - 1
            End If
        End If
        If l_poz >= 0 Then
            If Char.IsDigit(p_ertek.Chars(l_poz)) Then
                l_honap = p_ertek.Chars(l_poz).ToString
                l_poz = l_poz - 1
            Else
                Return DateTime.Now()
            End If
        End If
        If l_poz >= 0 Then
            If Char.IsDigit(p_ertek.Chars(l_poz)) Then
                l_honap = p_ertek.Chars(l_poz).ToString + l_honap
                l_poz = l_poz - 1
            Else
                l_poz = l_poz - 1
            End If
        End If
        If l_poz >= 0 Then
            l_ev = p_ertek.Substring(0, l_poz + 1)
            If l_ev.Contains(".") Or l_ev.Contains("/") Or l_ev.Contains(" ") Then
                Return DateTime.Now()
            End If
            If l_ev.Length() = 1 Then
                l_ev = DateTime.Now().ToString("yyyyMMdd").Substring(0, 2) + "0" + l_ev
            ElseIf l_ev.Length() = 2 Then
                l_ev = DateTime.Now().ToString("yyyyMMdd").Substring(0, 2) + l_ev
            End If
        End If
        l_ertek = l_ev.PadLeft(4, "0") + l_honap.PadLeft(2, "0") + l_nap.PadLeft(2, "0")
        Return DateTime.ParseExact(l_ertek, "yyyyMMdd", dfi)
    End Function

    'Stringet konvertál datetime-ra a megadott formátum szerint
    'Nem játsza végig azt, amit a FormStringToDateTime, hogy mindenféle userbeírást megpróbál értelmezni. Csak a normális formátum szerinti dátumot értelmezi
    Public Shared Function StringToDateTime(ByRef p_ertek As String, ByRef p_date_ertek As DateTime, Optional ByVal p_format As String = "") As Boolean
        Dim dfi As System.Globalization.DateTimeFormatInfo = System.Threading.Thread.CurrentThread.CurrentCulture.DateTimeFormat

        If p_ertek Is Nothing Or p_ertek = "" Then
            Return True
        End If

        Try
            If p_format <> "" Then
                p_date_ertek = DateTime.ParseExact(p_ertek, p_format, dfi)
                p_ertek = p_date_ertek.ToString(p_format, dfi)
            Else
                p_date_ertek = DateTime.Parse(p_ertek, dfi)
                p_ertek = p_date_ertek.ToString("g", dfi)
            End If
            Return True
        Catch
        End Try

        Return False

    End Function

    Public Shared Function GetParameter(ByVal p_parname As String) As String
        Dim l_ertek As String
        'System.Windows.Forms.MessageBox.Show("teszt")
        l_ertek = DataProvider.ExecuteScalarString("select ""U_Value"" from ""@IFSZ_PARAMETERS"" where ""Name"" = N'" + p_parname + "'")
        If Not l_ertek Is Nothing Then
            Return l_ertek
        Else
            Return ""
        End If
        'Return DataProvider.ExecuteScalarString("select u_value from [@ifsz_parameters] where code = N'" + p_parname + "'")
    End Function

    Public Shared Sub SetParameter(ByVal pnr_kod As String, ByVal pValue As String)
        'Dim oRecordSet As SAPbobsCOM.Recordset
        'Dim p_select As String
        'Try
        '    oRecordSet = m_ParentAddOn.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

        '    p_select = "select u_value from [@ifsz_parameters] where code = '" & pnr_kod & "'"
        '    oRecordSet.DoQuery(p_select)
        '    oRecordSet.MoveLast()
        '    oRecordSet.MoveFirst()
        '    If oRecordSet.RecordCount <> 1 Then
        '        oRecordSet.DoQuery("insert into [@ifsz_parameters] (code, name, u_value, u_comment) values ('" & pnr_kod & "', '" & pnr_kod & "', '" & pValue & "', 'Automatikusan beszúrva')")
        '        Exit Sub
        '    End If

        '    If oRecordSet.RecordCount = 1 Then
        '        oRecordSet.DoQuery("update [@ifsz_parameters] set u_value = '" & pValue & "' where code = '" & pnr_kod & "'")
        '    End If
        'Catch ex As Exception
        '    Exit Sub
        'Finally
        '    If (Not oRecordSet Is Nothing) Then
        '        System.Runtime.InteropServices.Marshal.ReleaseComObject(oRecordSet)
        '        oRecordSet = Nothing
        '    End If
        'End Try
    End Sub

    Public Shared Function GetMDIParameter(ByVal p_parname As String) As String
        'System.Windows.Forms.MessageBox.Show("teszt2")
        Return DataProvider.ExecuteScalarString("select ertek from [@ifsz_parameterek] where kod = N'" + p_parname + "'")
    End Function

    Public Shared Function GetServerDate() As DateTime

        Return DataProvider.GetSysDate().Date

    End Function

    Public Shared Function GetSqlDoubleToString(ByVal p_ertek As Double) As String
        Dim nfi As New System.Globalization.NumberFormatInfo()
        nfi.NumberGroupSeparator = ""
        nfi.NumberDecimalSeparator = "."
        If p_ertek = 0 Then
            Return "0"
        Else
            Return p_ertek.ToString(nfi)
        End If
    End Function

    Public Shared Function GetSqlDateTimeToString(ByVal p_ertek As Date) As String

        Return "convert(datetime, '" + CType(p_ertek, DateTime).ToString("yyyy-MM-dd HH:mm:ss") + "', 120)"

    End Function

    Public Shared Function GetUserName() As String
        If IFSZ_Globals.m_ParentType = "SBOAddOn" Or IFSZ_Globals.m_ParentType = "IFSZ_Addon" Then
            Return IFSZ_Globals.m_ParentAddOn.SboCompany.UserName
        Else
            Return IFSZ_Globals.m_MDIParent.UserName
        End If
    End Function

    Public Shared Function GetUserID() As Integer
        If IFSZ_Globals.m_ParentType = "SBOAddOn" Or IFSZ_Globals.m_ParentType = "IFSZ_Addon" Then
            Return IFSZ_Globals.m_ParentAddOn.SboCompany.UserSignature
        Else
            Return IFSZ_Globals.m_MDIParent.UserID
        End If
    End Function

    Public Shared Function IsCurrentUserManager() As Boolean
        Dim l_sql As String
        Dim l_rows As DataRowCollection
        l_sql = "select rol.id,rol.name,rol.manager from ifsz_users usr left join ifsz_user_roles url on usr.id = url.user_id left join ifsz_roles rol on rol.id = url.role_id where usr.login_nev = '" & IFSZ_Globals.USER.ToString & "' and rol.isvalid = 'I' and rol.manager = 'I'"
        l_rows = DataProvider.GetDataRecord(l_sql)
        If l_rows.Count > 0 Then
            Return True
        Else
            Return False
        End If

    End Function


    Public Shared Function GetServerDateTime() As DateTime
        Return DataProvider.GetSysDate()
    End Function

    Public Shared Function SQLStringPrepare(ByVal p_string As String) As String
        If p_string Is Nothing Or p_string = "" Then
            Return p_string
        Else
            Return p_string.Replace("'", "''")
        End If
    End Function

    Public Shared Function GetObjectAsString(ByVal p_ertek As Object, Optional ByVal p_nullertek As String = Nothing) As String
        If p_ertek Is Nothing Then
            Return p_nullertek
        End If
        Select Case p_ertek.GetType().Name
            Case "String"
                Return p_ertek
            Case "Double"
                Return IFSZ_Globals.GetInternalDoubleToString(p_ertek)
            Case "Decimal"
                Return IFSZ_Globals.GetInternalDoubleToString(p_ertek)
            Case "Integer"
                Return IFSZ_Globals.GetInternalDoubleToString(p_ertek)
            Case "Int16"
                Return IFSZ_Globals.GetInternalDoubleToString(p_ertek)
            Case "Int32"
                Return IFSZ_Globals.GetInternalDoubleToString(p_ertek)
            Case "Int64"
                Return IFSZ_Globals.GetInternalDoubleToString(p_ertek)
            Case "Date"
                Return IFSZ_Globals.GetInternalDateTimeToString(p_ertek)
            Case "DateTime"
                Return IFSZ_Globals.GetInternalDateTimeToString(p_ertek)
            Case "DBNull"
                Return p_nullertek
            Case Else
                Return p_ertek.ToString
        End Select
    End Function

    Public Shared Function NVL(ByVal p_ertek As String, ByVal p_nullertek As String) As String
        If p_ertek Is Nothing Or p_ertek = "" Then
            Return p_nullertek
        Else
            Return p_ertek
        End If
    End Function

    Public Shared Function GetSBOProc(ByVal p_ParentAddOn As Object) As Process
        Dim l_eredeti_title As String
        Dim l_uj_title As String
        Dim MyProcs() As Process

        'If IFSZ_Globals.m_ParentType <> "SBOAddOn" And IFSZ_Globals.m_ParentType <> "IFSZ_Addon" Then
        '    Return Nothing
        'End If

        'l_eredeti_title = IFSZ_Globals.m_ParentAddOn.SboApplication.Desktop.Title
        'l_uj_title = "SBO under " + IFSZ_Globals.m_ParentAddOn.SboCompany.UserName + IFSZ_Globals.m_RandomClass.Next(0, 999999).ToString
        'IFSZ_Globals.m_ParentAddOn.SboApplication.Desktop.Title = l_uj_title

        'MyProcs = Process.GetProcessesByName("SAP Business One")
        MyProcs = Process.GetProcesses

        If MyProcs.Length <> 0 Then
            For i As Integer = 0 To MyProcs.Length - 1
                If MyProcs(i).MainWindowTitle = l_uj_title Then
                    IFSZ_Globals.m_ParentAddOn.SboApplication.Desktop.Title = l_eredeti_title
                    Return MyProcs(i)
                End If
            Next
        End If

        'p_ParentAddOn.SboApplication.Desktop.Title = l_eredeti_title

        Return Nothing

    End Function

    Public Shared Function GetSBOProc() As Process
        Dim l_eredeti_title As String
        Dim l_uj_title As String
        Dim MyProcs() As Process


        'MyProcs = Process.GetProcessesByName("SAP Business One")
        MyProcs = Process.GetProcesses

        If MyProcs.Length <> 0 Then
            For i As Integer = 0 To MyProcs.Length - 1
                If MyProcs(i).ProcessName = "IFSZ_Kassza.vshost" Then
                    'IFSZ_Globals.m_ParentAddOn.SboApplication.Desktop.Title = l_eredeti_title
                    Return MyProcs(i)
                End If
            Next
        End If

        'p_ParentAddOn.SboApplication.Desktop.Title = l_eredeti_title

        Return Nothing

    End Function

    Public Shared Function SQLConstantPrepare(ByVal p_string As String) As String
        If p_string Is Nothing Then
            Return "null"
        End If
        If p_string = "" Then
            'Return p_string
            Return "null"
        Else
            Return "N'" + p_string.Replace("'", "''") + "'"
        End If
    End Function

    Public Shared Function SQLConstantPrepare(ByVal p_number As Integer) As String
        If p_number = 0 Then
            Return "0"
        End If
        Return p_number.ToString("#####################").Trim
    End Function

    Public Shared Function SQLConstantPrepare(ByVal p_number As Double) As String
        If p_number = 0 Then
            Return "0"
        End If
        Return p_number.ToString("#####################.######").Trim.Replace(",", ".")
    End Function

    Public Shared Function SQLConstantPrepare(ByVal p_date As DateTime) As String
        If p_date = NullDate() Then
            Return "null"
        Else
            'Return "convert(datetime, '" + p_date.ToString("yyyy-MM-dd HH:mm:ss") + "', 120)"
            Return "{ts'" + p_date.ToString("yyyy-MM-dd HH:mm:ss") + "'}"
        End If
    End Function

    Public Shared Function SQLConstantPrepare(ByVal p_val As DBNull) As String
        Return "null"
    End Function

    Public Shared Function PGSQLConstantPrepare(ByVal p_string As String) As String
        If p_string Is Nothing Then
            Return "null"
        End If
        If p_string = "" Then
            'Return p_string
            Return "null"
        Else
            Return "'" + p_string.Replace("'", "''") + "'"
        End If
    End Function

    Public Shared Function PGSQLConstantPrepare(ByVal p_number As Integer) As String
        If p_number = 0 Then
            Return "0"
        End If
        Return p_number.ToString("#####################").Trim
    End Function

    Public Shared Function PGSQLConstantPrepare(ByVal p_number As Double) As String
        If p_number = 0 Then
            Return "0"
        End If
        Return p_number.ToString("#####################.######").Trim.Replace(",", ".")
    End Function

    Public Shared Function PGSQLConstantPrepare(ByVal p_date As DateTime) As String
        If p_date = NullDate() Then
            Return "null"
        Else
            Return "to_date('" + p_date.ToString("yyyyMMddHHmmss") + "', 'YYYYMMDDHH24MISS')"
        End If
    End Function

    Public Shared Function DataViewConstantPrepare(ByVal p_string As String) As String
        If p_string Is Nothing Then
            Return "null"
        End If
        If p_string = "" Then
            'Return p_string
            Return "null"
        Else
            Return "'" + p_string.Replace("'", "''") + "'"
        End If
    End Function

    Public Shared Function DataViewConstantPrepare(ByVal p_number As Integer) As String
        If p_number = 0 Then
            Return "0"
        End If
        Return p_number.ToString("#####################").Trim
    End Function

    Public Shared Function DataViewConstantPrepare(ByVal p_number As Double) As String
        If p_number = 0 Then
            Return "0"
        End If
        Return p_number.ToString("#####################.######").Trim.Replace(",", ".")
    End Function

    Public Shared Function DataViewConstantPrepare(ByVal p_date As DateTime) As String
        If p_date = NullDate() Then
            Return "null"
        Else
            Return "convert(datetime, '" + p_date.ToString("yyyy-MM-dd HH:mm:ss") + "', 120)"
        End If
    End Function

    Public Shared Function NullDate() As DateTime
        Dim dfi As System.Globalization.DateTimeFormatInfo = System.Threading.Thread.CurrentThread.CurrentCulture.DateTimeFormat
        Return DateTime.ParseExact("9999-12-31 23:47:47", "yyyy-MM-dd HH:mm:ss", dfi)
    End Function

    Public Shared Function ConvertFile2ByteArray(ByVal fileName As String) As Byte()

        Dim fileStream As FileStream = New FileStream(fileName, FileMode.OpenOrCreate, FileAccess.Read)
        Dim len As Long
        len = fileStream.Length
        Dim fileAsByte As Byte()
        ReDim fileAsByte(len)
        fileStream.Read(fileAsByte, 0, fileAsByte.Length)
        Dim memoryStream As MemoryStream = New MemoryStream(fileAsByte)
        Return memoryStream.ToArray()

    End Function

    Public Shared Function GetFileLength(ByVal fileName As String) As Long
        Dim fileStream As FileStream = New FileStream(fileName, FileMode.OpenOrCreate, FileAccess.Read)
        Dim len As Long
        len = fileStream.Length
        Return len

    End Function

    Public Shared Sub WriteFileFromByteArray(ByVal fileName As String, ByVal content As Byte())
        Dim fs As FileStream = New FileStream(fileName, FileMode.Create)
        fs.Write(content, 0, System.Convert.ToInt64(content.Length))
        fs.Seek(0, SeekOrigin.Begin)
        fs.Close()
    End Sub
    'di & "\\" & 

    Public Shared Sub WriteFileFromByteArray(ByVal fileName As String, ByVal content As Byte(), ByVal di As DirectoryInfo)
        Dim fs As FileStream = New FileStream(di.FullName & "\" & fileName, FileMode.Create)
        fs.Write(content, 0, System.Convert.ToInt64(content.Length))
        fs.Seek(0, SeekOrigin.Begin)
        fs.Close()
    End Sub

    Public Shared Function IsNull(ByVal p_val As Object) As Boolean
        Return (p_val.GetType().Name = "DBNull")
    End Function


    Public Shared Function GetIniValue(ByVal p_section As String, ByVal p_key As String) As String

        Dim l_setting As String
        Try
            l_setting = My.MySettings.Default.Item(p_key).ToString()
        Catch ex As Exception
            Return Nothing
        End Try
        Return l_setting

        Return Nothing
    End Function

    Public Shared Sub ReleaseObject(ByRef p_obj As Object)        If Not p_obj Is Nothing Then            System.Runtime.InteropServices.Marshal.ReleaseComObject(p_obj)            p_obj = Nothing            GC.Collect()        End If    End Sub    Public Shared Function GetDocNumString(ByVal pDNCode As String, ByVal pNum As Long, ByVal pDate As Date)
        Dim l_Method As String
        Dim l_DNCode As String
        Dim l_expression As String
        Dim l_rows As DataRowCollection
        Dim p_message As String

        Try


            l_rows = DataProvider.GetDataRecord("select u_method, u_dncateg from [@ifsz_docnum_assigns] where u_dncateg = '" + pDNCode + "' and u_datefrom <= '" + pDate.ToString("s") + "' and u_dateto >= '" + pDate.ToString("s") + "'")

            If l_rows.Count = 1 Then
                l_Method = l_rows.Item(0).Item(0).ToString

                l_DNCode = l_rows.Item(0).Item(1).ToString

                Return GetDocNumString(l_DNCode, l_Method, pNum, pDate)
            Else
                Return ""
            End If

        Catch
            Return ""
        Finally

        End Try

    End Function


    Public Shared Function GetDocNumString(ByVal PDNCode As String, ByVal PMethod As String, ByVal PNum As Long, ByVal PDate As Date)
        Dim Method As String
        Dim l_DNCode As String
        Dim l_expression As String
        Dim l_rows As DataRowCollection
        Dim p_message As String

        Try

            Method = PMethod

            l_DNCode = PDNCode

            Method = Method.Replace("{next}", PNum).Replace("{date}", PDate.ToString("yyyy.MM.dd")).Replace("{dnc_code}", l_DNCode)
            Method = Method.Replace("{NEXT}", PNum).Replace("{DATE}", PDate.ToString("yyyy.MM.dd")).Replace("{DNC_CODE}", l_DNCode)

            l_expression = "select "

            l_expression = l_expression & Method & " from [@ifsz_docnum_assigns]"

            Return DataProvider.GetDataRecord(l_expression).Item(0).Item(0)
        Catch
            Return ""
        Finally

        End Try

    End Function

    Public Shared Function GetNextBizSzam(
        ByVal pDNCode As String, ByVal pUpdate As Boolean
    ) As String        Dim l_next As Integer        Dim l_date As DateTime = IFSZ_Globals.GetServerDate()        l_next = GetNextBizSzam_engine(pDNCode, l_date, pUpdate)        If l_next = -1 Then            Return ""        End If        Return GetDocNumString(pDNCode, l_next, l_date)    End Function    Private Shared Function GetNextBizSzam_engine(
        ByVal pDNCode As String,
        ByVal pDate As DateTime,
        ByVal pUpdate As Boolean
    ) As Integer        Dim RetVal As Long        Dim l_code As String        Dim l_command As String        Dim l_date As DateTime        Dim l_rows As DataRowCollection        Dim p_message As String        l_date = pDate
        'l_command = "select u_next, code from [@ifsz_docnum_assigns] with(updlock) where U_DNCateg = '" & pDNCode & "' and '" & pDate.ToString("yyyyMMdd") & "' between convert(varchar, u_datefrom, 112) and convert(varchar, u_dateto, 112)"
        If pUpdate Then            l_command = "select u_next, code from [@ifsz_docnum_assigns] with(updlock) where U_DNCateg = '" & pDNCode & "' and '" & l_date.ToString("yyyyMMdd") & "' between convert(varchar, u_datefrom, 112) and convert(varchar, u_dateto, 112)"        Else            l_command = "select u_next, code from [@ifsz_docnum_assigns] where U_DNCateg = '" & pDNCode & "' and '" & l_date.ToString("yyyyMMdd") & "' between convert(varchar, u_datefrom, 112) and convert(varchar, u_dateto, 112)"        End If        l_rows = DataProvider.GetDataRecord(l_command)        If l_rows.Count = 0 Then
            'Nem létezõ Bizonylatszám kategória ("<1>"), vagy nincs érvényes hozzárendelés a megadott idõpontban ("<2>")
            Return -1        End If        If l_rows.Count > 1 Then
            'Több érvényes hozzárendelés is létezik a megadott idõpontban ("<1>") a bizonylatszám kategóriához ("<2>")
            Return -1        End If        RetVal = Val(l_rows.Item(0).Item(0)) + 1        l_code = l_rows.Item(0).Item(1)        If pUpdate Then            DataProvider.EExecuteNonQuery("update [@ifsz_docnum_assigns] set u_next = u_next + 1 where code = '" & l_code & "'", p_message)        End If        Return RetVal    End Function


#Region "MDI"

#End Region


    Public Shared Sub AppendLog(ByVal p_hiba As String, Optional ByVal p_loglevel As Integer = 5)
        SyncLock IFSZ_Globals.m_logLockObject
            Try
                If p_loglevel < 5 AndAlso p_loglevel < IFSZ_Connect.m_loglevel Then
                    Exit Sub
                End If

                MSDataProvider.hiba_kiir(DateTime.Now().ToString("HH:mm:ss") + " " + Thread.CurrentThread.ManagedThreadId.ToString() + " " + p_hiba + Environment.NewLine, mm_log_utvonal + "\" + DateTime.Now().ToString("yyyyMMdd") + "_" + mm_folyamat + ".log", True)
            Catch ex As Exception
                Dim x As Integer = 1  'Nem tudok ilyenkor mit tenni
            End Try
        End SyncLock

    End Sub

    Public Shared Function GetDateJSON(ByVal p_sdate As String, ByVal p_metodus As String) As DateTime
        Dim l_date As DateTime
        If String.IsNullOrEmpty(p_sdate) Then
            Return IFSZ_Globals.NullDate()
        End If
        Try
            l_date = DateTime.ParseExact(p_sdate.Replace("-", ".").TrimEnd(".".ToCharArray()), "yyyy.MM.dd", System.Globalization.CultureInfo.InvariantCulture)
        Catch ex As Exception
            IFSZ_Globals.RESTAPIError(Net.HttpStatusCode.BadRequest, "Hibás dátumformátum: " + p_sdate, p_metodus)
        End Try
        Return l_date
    End Function

    Public Shared Function GetDateTime8601JSON(ByVal p_sdate As String, ByVal p_metodus As String) As DateTime
        Dim l_date As DateTime
        Dim l_dateo As DateTimeOffset
        If String.IsNullOrEmpty(p_sdate) Then
            Return IFSZ_Globals.NullDate()
        End If
        Try
            l_dateo = DateTimeOffset.ParseExact(p_sdate, New String() {"s", "u", "yyyy-MM-ddTHH:mm:sszzz", "yyyy-MM-ddTHH:mm:ss.fffzzz"}, System.Globalization.CultureInfo.InvariantCulture, DateTimeStyles.None)
            'l_date = l_dateo.UtcDateTime
            'l_date = TimeZoneInfo.ConvertTime(l_date, TimeZoneInfo.FindSystemTimeZoneById(c_SQL_TimeZoneID))
            'inkább ne konvertálgassunk időzónák között
            l_date = l_dateo.Date
        Catch ex As Exception
            IFSZ_Globals.RESTAPIError(Net.HttpStatusCode.BadRequest, "Hibás dátumidő formátum: " + p_sdate, p_metodus)
        End Try
        Return l_date
    End Function

    Public Shared Sub RESTAPIError(ByVal p_statuscode As Net.HttpStatusCode, ByVal p_message As String, ByVal p_metodus As String)
        Dim p_http_msg As New HttpResponseMessage(p_statuscode)
        p_http_msg.Content = New StringContent(p_message)
        IFSZ_Globals.AppendLog("<<POST>>: " + p_metodus + " FAIL: " + p_message, 1)
        Throw New HttpResponseException(p_http_msg)
    End Sub

    Public Enum enForditIrany
        SBOWeb
        WebSBO
    End Enum

    Public Enum enKodTipus
        OrderStatus
        ShipType
        PaymentType
        PaymentStatus
        VatGroup
    End Enum

    Public Shared Function KodForditSBOWeb(ByVal p_tipus As IFSZ_Globals.enKodTipus, ByVal p_sboazon As String) As String
        Return IFSZ_Globals.KodFordit(enForditIrany.SBOWeb, p_tipus, p_sboazon)
    End Function

    Public Shared Function KodForditWebSBO(ByVal p_tipus As IFSZ_Globals.enKodTipus, ByVal p_webazon As String, Optional ByVal p_portal As String = "", Optional ByVal p_afastatus As String = "") As String
        Return IFSZ_Globals.KodFordit(enForditIrany.WebSBO, p_tipus, p_webazon, p_portal, p_afastatus)
    End Function

    Private Shared Function KodFordit(ByVal p_irany As enForditIrany, ByVal p_tipus As IFSZ_Globals.enKodTipus, ByVal p_azon As String, Optional ByVal p_portal As String = "", Optional ByVal p_afastatus As String = "") As String
        Select Case p_tipus
            Case enKodTipus.OrderStatus
                Return p_azon

            Case enKodTipus.ShipType
                If p_irany = enForditIrany.WebSBO Then
                    Select Case p_azon
                        Case "HSZ", "PONT", "ATVET"
                            Return p_azon
                        Case Else
                            IFSZ_Globals.RESTAPIError(Net.HttpStatusCode.BadRequest, "Hibás ShipType", "Order")
                    End Select
                Else
                    Select Case p_azon
                        Case "HSZ", "PONT", "ATVET"
                            Return p_azon
                        Case Else
                            Return ""
                    End Select
                End If

            Case enKodTipus.PaymentType
                If p_irany = enForditIrany.WebSBO Then
                    Select Case p_azon
                        Case "KP"
                            Return "1"
                        Case "BK"
                            Return "2"
                        Case "UV"
                            Return "3"
                        Case "EU"
                            Return "4"
                        Case Else
                            IFSZ_Globals.RESTAPIError(Net.HttpStatusCode.BadRequest, "Hibás PaymentType", "Order")
                    End Select
                Else
                    Select Case p_azon
                        Case "1"
                            Return "KP"
                        Case "2"
                            Return "BK"
                        Case "3"
                            Return "UV"
                        Case "4"
                            Return "EU"
                        Case Else
                            Return ""
                    End Select
                End If

            Case enKodTipus.PaymentStatus
                If p_irany = enForditIrany.WebSBO Then
                    Select Case p_azon.ToLower()
                        Case "successful"
                            Return "Y"
                        Case "initiated", ""
                            Return "I"
                        Case "pending"
                            Return "F"
                        Case Else
                            Return "N"
                            'IFSZ_Globals.RESTAPIError(Net.HttpStatusCode.BadRequest, "Hibás PaymentStatus", "Order")
                    End Select
                Else
                    Select Case p_azon
                        Case "Y"
                            Return "successful"
                        Case "F"
                            Return "pending"
                        Case "I"
                            Return "initiated"
                        Case Else
                            Return "unsuccessful"
                    End Select
                End If

            Case enKodTipus.VatGroup
                If p_irany = enForditIrany.WebSBO Then
                    If p_afastatus = "Y" Then
                        Select Case p_portal
                            Case "HU"
                                Select Case p_azon
                                    Case "27", "27,0", "27.0"
                                        Return "K27"
                                    Case Else
                                        IFSZ_Globals.RESTAPIError(Net.HttpStatusCode.BadRequest, "Hibás ÁFA százalék: " + p_azon, "Order")
                                End Select
                            Case "RO"
                                Select Case p_azon
                                    Case "27", "27,0", "27.0"
                                        Return "K19RO"
                                    Case "19", "19,0", "19.0"
                                        Return "K19RO"
                                    Case Else
                                        IFSZ_Globals.RESTAPIError(Net.HttpStatusCode.BadRequest, "Hibás ÁFA százalék: " + p_azon, "Order")
                                End Select
                        End Select
                    Else
                        Return "KEUA"
                    End If
                Else
                    'Nincs ilyen irányból használva
                End If
        End Select
        Return ""
    End Function

    Public Shared Function GetMD5HashFile(ByVal p_filename As String) As String

        Using hasher As System.Security.Cryptography.MD5 = System.Security.Cryptography.MD5.Create()

            ' Convert to byte array and get hash
            Dim dbytes As Byte() =
                 hasher.ComputeHash(System.IO.File.ReadAllBytes(p_filename))

            Return Convert.ToBase64String(dbytes)

        End Using

    End Function

End Class
