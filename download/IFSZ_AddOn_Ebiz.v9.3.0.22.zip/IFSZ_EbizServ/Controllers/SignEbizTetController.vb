﻿Imports System.Net
Imports System.Web.Http

Namespace Controllers
    Public Class SignEbizTetController
        Inherits ApiController

        ' GET: api/Orders/5
        Public Function GetValue() As String

            Return ""

        End Function

        ' POST: api/Orders
        Public Function PostValue(<FromBody()> ByVal p_eol_id As Integer) As Integer
            IFSZ_Globals.AppendLog("<<POST>>: SignEbizTet", 1)

            If Module1.m_paused Then
                IFSZ_Globals.RESTAPIError(HttpStatusCode.ServiceUnavailable, "A szolgáltatás szüneteltetve van", "SignEbizTet")
            End If

            Dim l_token As Integer = -1

            SyncLock Idozites.m_process_queue_lockobj  'Erre lehet, hogy nem is lenne szükség, mert ConcurrentQueue-t használunk, de jobb az elővigyázatosság
                Try
                    'Vigyázunk, ha esetleg már túl sok elem lenne a queue-ban
                    If Idozites.m_toprocess_queue.Count > 50 Then
                        IFSZ_Globals.RESTAPIError(HttpStatusCode.InternalServerError, p_eol_id.ToString() + ": A feldolgozási sor betelt", "SignEbizTet")
                    End If
                    'Először megnézzük, van-e már a tömbben ilyen id
                    If Idozites.m_toprocess_queue.Contains(p_eol_id) OrElse Idozites.m_processed_array.ContainsKey(p_eol_id) Then
                        IFSZ_Globals.RESTAPIError(HttpStatusCode.BadRequest, p_eol_id.ToString() + ": Ennek a tételnek a feldolgozása már a feldolgozási sorban van", "SignEbizTet")
                    End If
                    Idozites.m_toprocess_queue.Enqueue(p_eol_id)
                    l_token = GetToken()
                    Dim l_processed As New ProcessedReturnValue()
                    Idozites.m_array_link(l_token) = p_eol_id
                    l_processed.eol_id = p_eol_id
                    l_processed.token = l_token
                    l_processed.hiba = Nothing
                    l_processed.feldolgozva = False
                    l_processed.started = DateTime.Now
                    Idozites.m_processed_array(p_eol_id) = l_processed

                    IFSZ_Globals.AppendLog("Sorba betéve: " + p_eol_id.ToString() + " queue méret: " + Idozites.m_toprocess_queue.Count.ToString(), 1)

                Catch exh As System.Web.Http.HttpResponseException
                    Throw
                Catch ex As Exception
                    IFSZ_Globals.RESTAPIError(HttpStatusCode.InternalServerError, "Hiba a feldolgozási sorba helyezés során: " + ex.Message(), "SignEbizTet")
                End Try
            End SyncLock

            Return l_token

        End Function

        ' PUT: api/Orders/5
        Public Sub PutValue(ByVal id As Integer, <FromBody()> ByVal value As String)

        End Sub

        ' DELETE: api/Orders/5
        Public Sub DeleteValue(ByVal id As Integer)

        End Sub

        Private Function GetToken() As Integer
            Dim l_val As Integer
            Dim l_rnd As New Random
            Do
                l_val = l_rnd.Next()
                If Not Idozites.m_array_link.ContainsKey(l_val) Then
                    Exit Do
                End If
            Loop
            Return l_val
        End Function

    End Class
End Namespace