﻿Imports System.Net
Imports System.Web.Http

Namespace Controllers
    Public Class CheckSignController
        Inherits ApiController

        ' GET: api/Orders/5
        Public Function GetValue() As String

            Return ""

        End Function

        ' POST: api/Orders
        Public Function PostValue(<FromBody()> ByVal p_token As Integer) As Integer
            IFSZ_Globals.AppendLog("<<POST>>: CheckSign", 1)

            If Module1.m_paused Then
                IFSZ_Globals.RESTAPIError(HttpStatusCode.ServiceUnavailable, "A szolgáltatás szüneteltetve van", "CheckSign")
            End If

            Dim l_eol_id As Integer = -1

            SyncLock Idozites.m_process_queue_lockobj  'Erre lehet, hogy nem is lenne szükség, mert ConcurrentQueue-t használunk, de jobb az elővigyázatosság
                Try
                    'Először megnézzük, van-e már a tömbben ilyen id
                    If Not Idozites.m_array_link.ContainsKey(p_token) Then
                        IFSZ_Globals.RESTAPIError(HttpStatusCode.BadRequest, p_token.ToString() + ": Ez a tétel (már) nincs a feldolgozási sorban", "CheckSign")
                    End If
                    l_eol_id = Idozites.m_array_link(p_token)
                    Dim l_processed As ProcessedReturnValue
                    Dim l_hiba As String
                    l_processed = Idozites.m_processed_array(l_eol_id)
                    If l_processed.feldolgozva Then
                        l_hiba = l_processed.hiba
                        If Not Idozites.m_processed_array.TryRemove(l_eol_id, l_processed) Then
                            IFSZ_Globals.RESTAPIError(HttpStatusCode.InternalServerError, "m_processed_array remove hiba", "CheckSign")
                        Else
                            If Not Idozites.m_array_link.TryRemove(p_token, l_eol_id) Then
                                IFSZ_Globals.RESTAPIError(HttpStatusCode.InternalServerError, "m_array_link remove hiba", "CheckSign")
                            Else
                                If String.IsNullOrEmpty(l_hiba) Then
                                    Return 1
                                Else
                                    IFSZ_Globals.RESTAPIError(HttpStatusCode.InternalServerError, l_hiba, "CheckSign")
                                End If
                            End If
                        End If
                    Else
                        Return 0
                    End If

                Catch exh As System.Web.Http.HttpResponseException
                    Throw
                Catch ex As Exception
                    IFSZ_Globals.RESTAPIError(HttpStatusCode.InternalServerError, "Hiba a feldolgozási sorba helyezés során: " + ex.Message(), "CheckSign")
                End Try
            End SyncLock

            Return l_eol_id

        End Function

        ' PUT: api/Orders/5
        Public Sub PutValue(ByVal id As Integer, <FromBody()> ByVal value As String)

        End Sub

        ' DELETE: api/Orders/5
        Public Sub DeleteValue(ByVal id As Integer)

        End Sub

        Private Function GetToken() As Integer
            Dim l_val As Integer
            Dim l_rnd As New Random
            Do
                l_val = l_rnd.Next()
                If Not Idozites.m_array_link.ContainsKey(l_val) Then
                    Exit Do
                End If
            Loop
            Return l_val
        End Function

    End Class
End Namespace