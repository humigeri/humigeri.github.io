﻿Imports System.Net
Imports System.Collections.Concurrent
Imports Microsec.XSign4Net
Imports Microsec.XSign4Net.PDF
Imports System.Security

Public Class Idozites

    Public Shared m_process_queue_lockobj As New Object  'A feldolgozási sor kezelésére használom. Hogy egyszerre csak egy férjen hozzá. A következő három tömbszerűségből akármelyikkel is dolgozom, ezt a lockot kiadom

    Public Shared m_toprocess_queue As New ConcurrentQueue(Of Integer)  'Ez a feldolgozási sort tartalmazza. Az eol_id-k kerülnek bele, amit fel kell dolgozni. Sorban fogjuk feldolgozni egymás után az egyes kéréseket, ahogy a queue-ba bekerülnek
    Public Shared m_processed_array As New ConcurrentDictionary(Of Integer, ProcessedReturnValue)  'Ez az eredményt fogja tartalmazni. key: eol_id, value: Egy ProcessedReturnValue objektum, ami tartalmazza az eol_id-hez tartozó tokent, azt, hogy lefutott-e már a feldolgozása, ha igen, akkor van-e hiba
    Public Shared m_array_link As New ConcurrentDictionary(Of Integer, Integer)  'Összekapcsolja az eol_id-kat (key) a token-ekkel (value). Token: Amikor behívnak a SignBizTetControllerbe, akkor csak egy eol_id-t adnak át. Válaszként generálunk egy random tokent, ezt kapják vissza. A kliensnek ezek után a CheckSign-t kell hívogatnia a megkapott tokennel, és válaszként visszaadjuk neki, hogy lefutott-e már, vagy nem.

    Private Shared m_last_tisztitas As DateTime = New DateTime(1900, 1, 1)
    Private Shared m_last_archivcheck As DateTime = New DateTime(1900, 1, 1)
    Private Shared m_archivcheck_freq As Integer = 0

    Public Shared Function ProcessJob() As Boolean
        'IFSZ_Globals.AppendLog("ProcessJob indul", 1)

        Dim l_feldolgoz As Integer

        SyncLock Idozites.m_process_queue_lockobj  'Erre lehet, hogy nem is lenne szükség, mert ConcurrentQueue-t használunk, de jobb az elővigyázatosság
            Try
                'Kivesszük a következő elemet a sorból
                If Not Idozites.m_toprocess_queue.TryDequeue(l_feldolgoz) Then
                    Idozites.Tisztitas()
                    Return False
                End If
            Catch ex As Exception
                IFSZ_Globals.AppendLog("ProcessJob/1 lekezeletlen hiba: " + ex.Message())
            End Try
        End SyncLock

        Try
            'Az l_feldolgozban van az id, amit fel kell dolgoznunk
            If IFSZ_Connect.ConnectDB() Then

                Idozites.Alair(l_feldolgoz)

            End If
        Catch ex As Exception
            IFSZ_Globals.AppendLog("ProcessJob/2 lekezeletlen hiba: " + ex.Message())
        End Try

        Idozites.Tisztitas()

        Return True

    End Function

    Private Shared Sub Alair(ByVal p_eol_id As Integer)
        Dim m_impersonator As AliasAccount
        Dim m_impersonated As Boolean = False
        Dim l_fs_domain, l_fs_username, l_fs_passwordStr, l_xmlpath, l_xmlpath_root As String

        l_xmlpath = IFSZ_Globals.GetParameter("EBIZXMLPATH")
        If Not String.IsNullOrEmpty(l_xmlpath) Then
            l_xmlpath_root = l_xmlpath.TrimEnd("\")
        End If

        l_fs_domain = IFSZ_Globals.GetParameter("EBIZPATH_DOMAIN")
        l_fs_username = IFSZ_Globals.GetParameter("EBIZPATH_USER")
        l_fs_passwordStr = IFSZ_Globals.GetParameter("EBIZPATH_PASSWORD")
        If Not String.IsNullOrEmpty(l_fs_username) AndAlso Not String.IsNullOrEmpty(l_fs_passwordStr) Then
            If l_fs_passwordStr.StartsWith("CRYPT:") Then
                l_fs_passwordStr = l_fs_passwordStr.Substring(6)
                If l_fs_passwordStr <> "" Then
                    l_fs_passwordStr = IFSZ_Connect.visszakodol(l_fs_passwordStr)
                End If
            Else
                Dim l_vissza As String = IFSZ_Connect.bekodol(l_fs_passwordStr)
                DataProvider.EExecuteNonQuery("update ""@IFSZ_PARAMETERS"" set ""U_Value"" = " + IFSZ_Globals.SQLConstantPrepare("CRYPT:" + l_vissza) + " where ""Name"" = " + IFSZ_Globals.SQLConstantPrepare("EBIZPATH_PASSWORD"))
            End If
            m_impersonator = New AliasAccount(l_fs_username, l_fs_passwordStr, l_fs_domain)
            m_impersonated = True
        End If

        Using xsign As XSignSession = New XSignSession()

            Dim l_pdf_path, l_pdf_signed_path, l_pdf_atc_path, l_fajl, l_atcpar, l_ebiztip, l_tabnev, l_docentry As String
            Dim l_rc As DataRowCollection
            Dim l_atctab As DataTable = Nothing
            Dim l_eoltab As DataTable
            Dim l_nav As Boolean = False

            Try

                If m_impersonated Then
                    m_impersonator.BeginImpersonation()
                End If

                IFSZ_Globals.AppendLog("Aláírás indul: " + p_eol_id.ToString() + " queue méret: " + Idozites.m_toprocess_queue.Count.ToString(), 1)

                'Mivel szemetel a console-ra logokat, ezért inkább átirányítom - de nem hatja meg
                System.Console.SetOut(System.IO.TextWriter.Null)

                l_atcpar = DataProvider.ExecuteScalarString("select min(""U_Value"") from ""@IFSZ_PARAMETERS"" where ""Name"" = N'EBIZATC'")
                If String.IsNullOrEmpty(l_atcpar) Then
                    l_atcpar = "N"
                Else
                    If l_atcpar.ToUpper() = "I" Then
                        l_atcpar = "I"
                    Else
                        l_atcpar = "N"
                    End If
                End If

                'l_rc = DataProvider.EGetDataRecord("select eol.U_FILE, df.""AtcEntry"" from ""@IFSZ_EMAILOUTLINE"" eol left join IFSZ_DFEJ df on eol.U_DOCTYPE = df.""ObjType"" and eol.U_DOCENTRY = df.""DocEntry"" where eol.""Code"" = " + IFSZ_Globals.SQLConstantPrepare(p_eol_id.ToString()))
                l_eoltab = DataProvider.EGetDataTable("select tp.RTYPPRE, eol.DOCENTRY, eol.""FILE"", eol.EBIZTIP, df.U_NAVO_STATUS from IFSZ_EMAILOUTLINE eol join IFSZ_EDOC_TYPES_V tp on eol.DOCTYPE = tp.CODE JOIN IFSZ_DFEJ df on eol.doctype = df.""ObjType"" and eol.docentry = df.""DocEntry"" where eol.id = " + IFSZ_Globals.SQLConstantPrepare(p_eol_id.ToString()))
                If l_eoltab Is Nothing OrElse l_eoltab.Rows.Count = 0 Then
                    Throw New Exception("Nem található a bejegyzés")
                End If
                l_pdf_path = l_eoltab.Rows(0)("FILE").ToString()
                l_ebiztip = l_eoltab.Rows(0)("EBIZTIP").ToString()
                l_tabnev = "O" + l_eoltab.Rows(0)("RTYPPRE").ToString()
                l_docentry = l_eoltab.Rows(0)("DOCENTRY").ToString()
                l_nav = (Not String.IsNullOrEmpty(l_xmlpath) AndAlso Not IsDBNull(l_eoltab.Rows(0)("U_NAVO_STATUS")))
                If l_atcpar = "I" OrElse l_nav Then
                    l_atctab = DataProvider.EGetDataTable("select * from IFSZ_EBIZ_ATC_V where ""Code"" = " + p_eol_id.ToString() + " order by ""Line""")
                    If l_nav Then
                        l_xmlpath = l_xmlpath_root + "\" + l_tabnev + "\" + l_docentry + ".xml"
                        If Not System.IO.File.Exists(l_xmlpath) Then
                            l_xmlpath = l_xmlpath_root + "\" + l_tabnev + "\" + IFSZ_Connect.m_database + "_" + l_docentry + ".xml"
                            IFSZ_Globals.AppendLog("XML: " + l_xmlpath)
                            If Not System.IO.File.Exists(l_xmlpath) Then
                                Throw New Exception("Az Ebiz modul nem tudja csatolni a NAV xml-t")
                            End If
                        End If
                        Dim l_row As DataRow
                        l_row = l_atctab.NewRow()
                        l_row("trgtPath") = System.IO.Path.GetDirectoryName(l_xmlpath)
                        l_row("FileName") = System.IO.Path.GetFileNameWithoutExtension(l_xmlpath)
                        l_row("FileExt") = System.IO.Path.GetExtension(l_xmlpath).Replace(".", "")
                        l_atctab.Rows.Add(l_row)
                        l_atctab.AcceptChanges()
                        l_atcpar = "I"
                    End If
                End If
                If String.IsNullOrEmpty(l_pdf_path) Then
                    Throw New Exception("Ismeretlen küldési bizonylat tétel, vagy még nem történt meg a pdf generálása")
                Else
                    If l_atcpar = "N" OrElse l_atctab Is Nothing OrElse l_atctab.Rows.Count = 0 Then
                        l_pdf_atc_path = l_pdf_path
                    Else
                        l_pdf_atc_path = System.IO.Path.GetDirectoryName(l_pdf_path) + "\" + System.IO.Path.GetFileNameWithoutExtension(l_pdf_path) + "_atc.pdf"
                    End If
                    l_pdf_signed_path = System.IO.Path.GetDirectoryName(l_pdf_path) + "\" + System.IO.Path.GetFileNameWithoutExtension(l_pdf_path) + "_signed.pdf"
                    If System.IO.File.Exists(l_pdf_signed_path) Then
                        Throw New Exception("Már megtörtént az aláírt pdf elkészítése")
                    End If
                    If Not System.IO.File.Exists(l_pdf_path) Then
                        Throw New Exception("Nem található a fájl: " + l_pdf_path)
                    End If
                End If
                'Log inicializálás:
                If IFSZ_Connect.m_loglevel < 5 AndAlso Not String.IsNullOrEmpty(IFSZ_Connect.m_esignolog) Then
                    xsign.SetLogFilePath(mm_log_utvonal + "\" + DateTime.Now().ToString("yyyyMMdd") + "_" + IFSZ_Connect.m_esignolog)
                End If

                'XSign Init
                xsign.Initialize(mm_exe_utvonal + "\eszignowork", mm_exe_utvonal + "\" + IFSZ_Connect.m_serverregxml, String.Empty)

                'Dialógus ablakok ne legyenek
                xsign.SetWorkSilent(WorkMode.XS_FORCE_SILENT)
                If IFSZ_Connect.m_loglevel < 5 AndAlso Not String.IsNullOrEmpty(IFSZ_Connect.m_esignolog) Then
                    xsign.SetCURLDebug((IFSZ_Connect.m_curllog = 1))
                Else
                    xsign.SetCURLDebug(False)
                End If

                'Csatolás
                If Not System.IO.File.Exists(l_pdf_atc_path) Then
                    If l_atctab Is Nothing OrElse l_atctab.Rows.Count = 0 Then
                        Throw New Exception("Nem található a fájl (atc) " + l_pdf_atc_path)
                    End If
                    Using pdf As PdfDocument = xsign.OpenPdfDocument(l_pdf_path)
                        Dim l_ind As Integer = 1
                        For Each l_row As DataRow In l_atctab.Rows
                            l_fajl = l_row("trgtPath").ToString() + "\" + l_row("FileName").ToString()
                            If l_row("FileExt").ToString() <> "" Then
                                l_fajl += "." + l_row("FileExt").ToString()
                            End If
                            IFSZ_Globals.AppendLog(l_fajl + " fájl csatolása a " + l_pdf_path + "-hez (" + l_row("FileName").ToString() + ")", 1)
                            If System.IO.File.Exists(l_fajl) Then
                                pdf.AddAttachment(l_fajl, l_ind.ToString() + ": " + l_row("FileName").ToString())
                            Else
                                'IFSZ_Globals.AppendLog(l_fajl + " nem létezik, ezért nem csatolható a " + l_pdf_path + "-hez")
                                Throw New Exception(l_fajl + " nem létezik, ezért nem csatolható a " + l_pdf_path + "-hez")
                            End If
                            l_ind += 1
                        Next
                        'Save it
                        pdf.Save(l_pdf_atc_path)
                    End Using
                End If

                If l_ebiztip = "H" Then 'Csak megadott típus esetén aláírunk
                    'Aláíró tanúsítvány beállítása
                    Dim l_pwd As New SecureString()
                    For i As Integer = 0 To IFSZ_Connect.m_pfxpwd.Length - 1
                        l_pwd.AppendChar(IFSZ_Connect.m_pfxpwd.Substring(i, 1))
                    Next
                    xsign.SetSigningCertificateFile(mm_exe_utvonal + "\" + IFSZ_Connect.m_pfx, l_pwd)

                    'Set XAdES-T and newest XAdES version
                    xsign.SetAdESType(XSignAdesType.XS_ADES_T)
                    xsign.SetXAdESVersion(XAdESVersion.XS_XADES_VERSION_EN_1_0_0)

                    'Set the revocation checking mode to OCSP
                    xsign.SetRevocationCheckingMode(RevocationCheckingMode.XS_REV_CHECK_OCSP)

                    'Set the timestamp service URL.
                    If Not String.IsNullOrEmpty(IFSZ_Connect.m_timestampurl) Then
                        IFSZ_Globals.AppendLog("." + IFSZ_Connect.m_timestampurl + "." + IFSZ_Connect.m_basicauthhost + "." + IFSZ_Connect.m_basicauthuser + "." + IFSZ_Connect.m_basicauthpwd + ".", 1)
                        xsign.SetTimeStampURLs(New String() {IFSZ_Connect.m_timestampurl})

                        'Set basic authentication data
                        xsign.SetBasicAuthList(New HostBasicAuthData() {New HostBasicAuthData(
                            IFSZ_Connect.m_basicauthhost,
                            IFSZ_Connect.m_basicauthuser,
                            IFSZ_Connect.m_basicauthpwd
                        )})

                    Else
                        IFSZ_Globals.AppendLog("Nincs időbélyeg", 1)

                    End If

                    'Create a New pdf
                    Using pdf As PdfDocument = xsign.OpenPdfDocument(l_pdf_atc_path)
                        'Sign it
                        Dim sig As PdfSignature = pdf.Sign()

                        'Save it
                        pdf.Save(l_pdf_signed_path)
                    End Using
                End If

                'Close log file
                xsign.CloseLogFilePath()

                Dim l_proc As ProcessedReturnValue = Idozites.m_processed_array(p_eol_id)
                l_proc.feldolgozva = True
                l_proc.hiba = Nothing
                Idozites.m_processed_array(p_eol_id) = l_proc

                IFSZ_Globals.AppendLog("Aláírás vége: " + p_eol_id.ToString(), 1)

            Catch ex As Exception
                Dim l_proc As ProcessedReturnValue = Idozites.m_processed_array(p_eol_id)
                l_proc.hiba = ex.Message + "(id: " + p_eol_id.ToString() + ")"
                l_proc.feldolgozva = True
                Idozites.m_processed_array(p_eol_id) = l_proc
                IFSZ_Globals.AppendLog("Aláírás hiba: " + l_proc.hiba, 1)
            Finally
                If m_impersonated Then
                    m_impersonator.EndImpersonation()
                End If
                'Visszaállítjuk az outputot - Lehet, hogy felesleges. Mehetne ez is egy fájlba.
                Dim l_stand As New System.IO.StreamWriter(Console.OpenStandardOutput())
                l_stand.AutoFlush = True
                Console.SetOut(l_stand)
            End Try

        End Using

    End Sub

    ''' <summary>
    ''' Ez az eljárás felszabadítja a sorból az esetlegesen bennmaradt folyamatokat
    ''' </summary>
    Private Shared Sub Tisztitas()
        Try
            Dim l_idopont As DateTime = DateTime.Now()
            Dim l_eol_id, l_token As Integer
            Dim l_temp As ProcessedReturnValue
            Dim l_feleje As String
            Dim l_szam As Integer
            Dim l_torol_dat As String
            Dim l_napvissza As Decimal

            If l_idopont.Subtract(Idozites.m_last_archivcheck).TotalMinutes > m_archivcheck_freq Then
                Idozites.m_last_archivcheck = l_idopont
                If IFSZ_Connect.ConnectDB() Then

                    Dim l_archiv As String = DataProvider.ExecuteScalarString("select ""U_Value"" from ""@IFSZ_PARAMETERS"" where ""Name"" = 'EBIZARCH' ")
                    Dim l_temppar As String = DataProvider.ExecuteScalarString("select ""U_Value"" from ""@IFSZ_PARAMETERS"" where ""Name"" = 'EBIZARCHFRQ' ")
                    If String.IsNullOrEmpty(l_temppar) OrElse Not Integer.TryParse(l_temppar, m_archivcheck_freq) Then
                        m_archivcheck_freq = 10
                    End If
                    If Not String.IsNullOrEmpty(l_archiv) Then
                        l_temppar = DataProvider.ExecuteScalarString("select ""U_Value"" from ""@IFSZ_PARAMETERS"" where ""Name"" = 'EBIZARCHCHK' ")
                        If String.IsNullOrEmpty(l_temppar) Then
                            l_napvissza = 0
                        Else
                            If Not (l_temppar.ToUpper().EndsWith("N") OrElse l_temppar.ToUpper().EndsWith("D") OrElse l_temppar.ToUpper().EndsWith("H") OrElse l_temppar.ToUpper().EndsWith("Ó") OrElse l_temppar.ToUpper().EndsWith("P") OrElse l_temppar.ToUpper().EndsWith("M")) Then
                                l_temppar += "D"
                            End If
                            If Not Integer.TryParse(l_temppar.Substring(0, l_temppar.Length - 1), l_napvissza) Then
                                l_napvissza = 0
                            End If
                            Select Case l_temppar.ToUpper().Substring(l_temppar.Length - 1)
                                Case "D", "N"
                                    l_napvissza = l_napvissza  'Ha D-re, vagy N-re végződik, akkor napban adta meg
                                Case "H", "Ó"
                                    l_napvissza = l_napvissza / 24  'H, Ó: Órákban adta meg
                                Case "M", "P"
                                    l_napvissza = l_napvissza / 24 / 60 'M, P: percekben adta meg
                            End Select
                        End If
                        If l_napvissza > 0 Then

                            Dim m_impersonator As AliasAccount
                            Dim m_impersonated As Boolean = False
                            Dim l_fs_domain, l_fs_username, l_fs_passwordStr As String

                            l_fs_domain = IFSZ_Globals.GetParameter("EBIZPATH_DOMAIN")
                            l_fs_username = IFSZ_Globals.GetParameter("EBIZPATH_USER")
                            l_fs_passwordStr = IFSZ_Globals.GetParameter("EBIZPATH_PASSWORD")
                            If Not String.IsNullOrEmpty(l_fs_username) AndAlso Not String.IsNullOrEmpty(l_fs_passwordStr) Then
                                If l_fs_passwordStr.StartsWith("CRYPT:") Then
                                    l_fs_passwordStr = l_fs_passwordStr.Substring(6)
                                    If l_fs_passwordStr <> "" Then
                                        l_fs_passwordStr = IFSZ_Connect.visszakodol(l_fs_passwordStr)
                                    End If
                                Else
                                    Dim l_vissza As String = IFSZ_Connect.bekodol(l_fs_passwordStr)
                                    DataProvider.EExecuteNonQuery("update ""@IFSZ_PARAMETERS"" set ""U_Value"" = " + IFSZ_Globals.SQLConstantPrepare("CRYPT:" + l_vissza) + " where ""Name"" = " + IFSZ_Globals.SQLConstantPrepare("EBIZPATH_PASSWORD"))
                                End If
                                m_impersonator = New AliasAccount(l_fs_username, l_fs_passwordStr, l_fs_domain)
                                m_impersonated = True
                            End If

                            Try
                                If m_impersonated Then
                                    m_impersonator.BeginImpersonation()
                                End If

                                Dim l_elltab As DataTable
                                Dim l_md5 As String
                                Dim l_checkresult As Integer

                                If DataProvider.m_tipus = 0 Then
                                    l_elltab = DataProvider.EGetDataTable("select top 100 * from " + l_archiv + ".dbo.IFSZ_EMAILOUTLINE where DB = " + IFSZ_Globals.SQLConstantPrepare(IFSZ_Connect.m_database) + " and checktime < getdate()-" + IFSZ_Globals.SQLConstantPrepare(l_napvissza))
                                Else
                                    l_elltab = DataProvider.EGetDataTable("select top 100 * from " + l_archiv + ".IFSZ_EMAILOUTLINE where DB = " + IFSZ_Globals.SQLConstantPrepare(IFSZ_Connect.m_database) + " and checktime < add_seconds(current_timestamp, -" + IFSZ_Globals.SQLConstantPrepare(Math.Round(l_napvissza * 3600 * 24, 0)) + ") ")
                                End If
                                If l_elltab IsNot Nothing AndAlso l_elltab.Rows.Count > 0 Then
                                    IFSZ_Globals.AppendLog("Archív ellenőrzés indul: " + l_elltab.Rows.Count.ToString(), 1)
                                    For Each l_row As DataRow In l_elltab.Rows
                                        Try
                                            If System.IO.File.Exists(l_row("FILE_PATH").ToString()) Then
                                                l_checkresult = 0
                                                l_md5 = IFSZ_Globals.GetMD5HashFile(l_row("FILE_PATH").ToString())
                                                If l_md5 <> l_row("MD5_SIGNED").ToString() Then
                                                    l_checkresult += 2
                                                End If
                                            Else
                                                'Nem található a file
                                                l_checkresult = 1
                                            End If
                                            If DataProvider.ExecuteScalar("select count(9) from ""@IFSZ_EMAILOUTLINE"" where ""Code"" = " + l_row("ID").ToString()) = 0 Then
                                                'Nincs meg az eredeti bejegyzés
                                                l_checkresult += 4
                                            End If
                                            If DataProvider.m_tipus = 0 Then
                                                DataProvider.EExecuteNonQuery("update " + l_archiv + ".dbo.IFSZ_EMAILOUTLINE set checkresult = " + l_checkresult.ToString() + ", checktime = getdate() where DB = " + IFSZ_Globals.SQLConstantPrepare(IFSZ_Connect.m_database) + " and id = " + l_row("ID").ToString())
                                            Else
                                                DataProvider.EExecuteNonQuery("select top 100 * from " + l_archiv + ".IFSZ_EMAILOUTLINE set checkresult = " + l_checkresult.ToString() + ", checktime = getdate() where DB = " + IFSZ_Globals.SQLConstantPrepare(IFSZ_Connect.m_database) + " and id = " + l_row("ID").ToString())
                                            End If
                                        Catch ex As Exception
                                            IFSZ_Globals.AppendLog("Archív ellenőrzés hiba: " + l_row("ID").ToString() + ": " + ex.Message(), 1)
                                        End Try
                                    Next
                                End If

                            Catch ex As Exception
                                IFSZ_Globals.AppendLog("Archív ellenőrzés hiba: " + ex.Message(), 1)
                            Finally
                                If m_impersonated Then
                                    m_impersonator.EndImpersonation()
                                End If
                            End Try
                        End If

                    End If

                End If

            End If

            If l_idopont.Subtract(Idozites.m_last_tisztitas).TotalMinutes > 2 Then

                IFSZ_Globals.AppendLog("Tisztítás indul", 1)

                Idozites.m_last_tisztitas = l_idopont
                Dim l_todelete As New List(Of Integer)

                l_torol_dat = l_idopont.Date().AddDays(-1 * IFSZ_Connect.m_lognapoktorol).ToString("yyyyMMdd")

                Dim di As System.IO.DirectoryInfo
                Dim l_fi As System.IO.FileInfo()
                Dim l_count As Integer = 0

                'logfájlok törlése:
                di = New System.IO.DirectoryInfo(mm_log_utvonal)
                If di IsNot Nothing Then
                    l_fi = di.GetFiles()
                    l_count = l_fi.Count
                End If

                If l_count > 0 Then
                    For Each file As System.IO.FileInfo In l_fi
                        l_feleje = ""
                        If file.Name.Length > 9 AndAlso file.Name.Substring(8, 1) = "_" AndAlso Integer.TryParse(file.Name.Substring(0, 8), l_szam) Then
                            l_feleje = file.Name.Substring(0, 8)
                        End If
                        If l_feleje <> "" AndAlso l_feleje <= l_torol_dat Then
                            Try
                                file.Delete()
                                IFSZ_Globals.AppendLog(file.Name + " log fájl törölve")
                            Catch ex As Exception
                                IFSZ_Globals.AppendLog(file.Name + " log fájl törlése nem sikerült " + ex.Message())
                            End Try
                        End If
                    Next
                End If

                'eszignowork tisztítása
                l_count = 0
                If System.IO.Directory.Exists(mm_exe_utvonal + "\eszignowork") Then
                    di = New System.IO.DirectoryInfo(mm_exe_utvonal + "\eszignowork")
                    If di IsNot Nothing Then
                        l_fi = di.GetFiles()
                        l_count = l_fi.Count
                    End If
                End If

                If l_count = 0 Then
                    IFSZ_Globals.AppendLog("Nincs törlendő munkafájl", 1)
                Else
                    IFSZ_Globals.AppendLog(l_count.ToString() + " db munkafájl törlése", 1)
                    For Each file As System.IO.FileInfo In l_fi
                        Try
                            file.Delete()
                        Catch ex As Exception
                            IFSZ_Globals.AppendLog(file.Name + " törlése nem sikerült " + ex.Message())
                        End Try
                    Next
                    IFSZ_Globals.AppendLog(l_count.ToString() + " db munkafájl törölve", 1)
                End If

                l_idopont = l_idopont.Subtract(TimeSpan.FromMinutes(5))  '-5 perc

                SyncLock Idozites.m_process_queue_lockobj

                    'Először is a sor elején lévő feladatokat ellenőrizzük
                    While Idozites.m_toprocess_queue.Count > 0 AndAlso Idozites.m_toprocess_queue.TryPeek(l_eol_id)
                        IFSZ_Globals.AppendLog("Tisztítás: Queue peek-je: " + l_eol_id.ToString(), 1)
                        If Not Idozites.m_processed_array.ContainsKey(l_eol_id) Then
                            IFSZ_Globals.AppendLog("Tisztítás: Processedarray not contains " + l_eol_id.ToString(), 1)
                            'Ilyennek nem is kellene lennie, kellene, hogy legyen hozzá tartozó processed_array. De ha mégsem, akkor vegyük ki a sorból is, meg az array_linkből is
                            If Not Idozites.m_toprocess_queue.TryDequeue(l_eol_id) Then
                                IFSZ_Globals.AppendLog("Tisztítás: TryDequeue nem sikerült " + l_eol_id.ToString(), 1)
                                Exit While
                            End If
                            IFSZ_Globals.AppendLog("Tisztítás: TryDequeue megtörtént " + l_eol_id.ToString(), 1)
                            l_token = -1
                            For Each l_kv As KeyValuePair(Of Integer, Integer) In Idozites.m_array_link
                                If l_kv.Value = l_eol_id Then
                                    l_token = l_kv.Key
                                    Exit For
                                End If
                            Next
                            If l_token <> -1 Then
                                IFSZ_Globals.AppendLog("Tisztítás: array_link remove " + l_token.ToString(), 1)
                                Idozites.m_array_link.TryRemove(l_token, l_eol_id)
                            End If
                            IFSZ_Globals.AppendLog("Tisztítás: Processedarray not contains vége " + l_eol_id.ToString(), 1)

                        Else
                            IFSZ_Globals.AppendLog("Tisztítás: Processedarray tartalmazza: " + l_eol_id.ToString(), 1)
                            If Idozites.m_processed_array(l_eol_id).started < l_idopont Then
                                IFSZ_Globals.AppendLog("Tisztítás: Lejárt: " + l_eol_id.ToString(), 1)
                                'Ha már régóta a sorban van, akkor vegyük ki mindhárom tömbből
                                l_token = Idozites.m_processed_array(l_eol_id).token
                                If Not Idozites.m_toprocess_queue.TryDequeue(l_eol_id) Then
                                    IFSZ_Globals.AppendLog("Tisztítás: TryDequeue nem sikerült " + l_eol_id.ToString(), 1)
                                    Exit While
                                End If
                                Idozites.m_processed_array.TryRemove(l_eol_id, l_temp)
                                Idozites.m_array_link.TryRemove(l_token, l_eol_id)
                            Else
                                'Ha a legkorábbi feldolgozandó nem járt még le, akkor felesleges a többit vizsgálni
                                IFSZ_Globals.AppendLog("Tisztítás: Még nem járt le: " + l_eol_id.ToString(), 1)
                                Exit While
                            End If
                            IFSZ_Globals.AppendLog("Tisztítás: Processedarray tartalmazza vége " + l_eol_id.ToString(), 1)

                        End If
                        IFSZ_Globals.AppendLog("Tisztítás: Queue peek-je vége " + l_eol_id.ToString(), 1)
                    End While

                    'Utána meg azokat próbáljuk kigyomlálni, amihez nem tartozik queue bejegyzés, és lejárt (a kliens nem érdeklődött az eredményről)
                    For Each l_proc As KeyValuePair(Of Integer, ProcessedReturnValue) In Idozites.m_processed_array
                        If Not Idozites.m_toprocess_queue.Contains(l_proc.Key) Then
                            If l_idopont > l_proc.Value.started Then
                                l_todelete.Add(l_proc.Key)
                            End If
                        End If
                    Next
                    For Each l_tempi As Integer In l_todelete
                        IFSZ_Globals.AppendLog("Tisztítás: Nem tartozik queue, lejárt, töröljük " + l_tempi.ToString(), 1)
                        l_temp = Idozites.m_processed_array(l_tempi)
                        Idozites.m_array_link.TryRemove(l_temp.token, l_tempi)
                        Idozites.m_processed_array.TryRemove(l_tempi, l_temp)
                    Next

                    'Végül azt is, ha az array_link árván maradt volna
                    l_todelete.Clear()
                    For Each l_link As KeyValuePair(Of Integer, Integer) In Idozites.m_array_link
                        If Not Idozites.m_processed_array.ContainsKey(l_link.Value) Then
                            l_todelete.Add(l_link.Key)
                        End If
                    Next
                    For Each l_tempi As Integer In l_todelete
                        IFSZ_Globals.AppendLog("Tisztítás: árva array_link, töröljük " + l_tempi.ToString(), 1)
                        Idozites.m_array_link.TryRemove(l_tempi, l_eol_id)
                    Next

                End SyncLock

                IFSZ_Globals.AppendLog("Tisztítás vége", 1)

            End If
        Catch ex As Exception
            IFSZ_Globals.AppendLog("Tisztítás hiba: " + ex.Message)
        End Try
    End Sub

    Public Shared Sub CsatolProba(ByVal p_alappdf As String, ByVal p_csatolmany As String, ByVal p_impers As String)
        Dim m_impersonator As AliasAccount
        Dim m_impersonated As Boolean = False
        Dim l_fs_domain, l_fs_username, l_fs_passwordStr, l_xmlpath, l_xmlpath_root As String

        If p_impers.ToUpper() = "N" Then
            m_impersonated = False

        Else

            l_fs_domain = IFSZ_Globals.GetParameter("EBIZPATH_DOMAIN")
            l_fs_username = IFSZ_Globals.GetParameter("EBIZPATH_USER")
            l_fs_passwordStr = IFSZ_Globals.GetParameter("EBIZPATH_PASSWORD")
            If Not String.IsNullOrEmpty(l_fs_username) AndAlso Not String.IsNullOrEmpty(l_fs_passwordStr) Then
                If l_fs_passwordStr.StartsWith("CRYPT:") Then
                    l_fs_passwordStr = l_fs_passwordStr.Substring(6)
                    If l_fs_passwordStr <> "" Then
                        l_fs_passwordStr = IFSZ_Connect.visszakodol(l_fs_passwordStr)
                    End If
                Else
                    Dim l_vissza As String = IFSZ_Connect.bekodol(l_fs_passwordStr)
                    DataProvider.EExecuteNonQuery("update ""@IFSZ_PARAMETERS"" set ""U_Value"" = " + IFSZ_Globals.SQLConstantPrepare("CRYPT:" + l_vissza) + " where ""Name"" = " + IFSZ_Globals.SQLConstantPrepare("EBIZPATH_PASSWORD"))
                End If
                m_impersonator = New AliasAccount(l_fs_username, l_fs_passwordStr, l_fs_domain)
                m_impersonated = True
            End If

        End If

        Using xsign As XSignSession = New XSignSession()

            Dim l_pdf_path, l_pdf_signed_path, l_pdf_atc_path, l_fajl, l_atcpar, l_ebiztip, l_tabnev, l_docentry As String
            Dim l_rc As DataRowCollection
            Dim l_atctab As DataTable = Nothing
            Dim l_eoltab As DataTable
            Dim l_nav As Boolean = False

            Try

                Console.WriteLine("kezd")

                If m_impersonated Then
                    m_impersonator.BeginImpersonation()
                End If

                Console.WriteLine("impersonation over")
                l_atcpar = "I"

                'l_rc = DataProvider.EGetDataRecord("select eol.U_FILE, df.""AtcEntry"" from ""@IFSZ_EMAILOUTLINE"" eol left join IFSZ_DFEJ df on eol.U_DOCTYPE = df.""ObjType"" and eol.U_DOCENTRY = df.""DocEntry"" where eol.""Code"" = " + IFSZ_Globals.SQLConstantPrepare(p_eol_id.ToString()))
                l_pdf_path = p_alappdf
                l_ebiztip = "P"
                If String.IsNullOrEmpty(l_pdf_path) Then
                    Throw New Exception("Ismeretlen küldési bizonylat tétel, vagy még nem történt meg a pdf generálása")
                Else
                    l_pdf_atc_path = System.IO.Path.GetDirectoryName(l_pdf_path) + "\" + System.IO.Path.GetFileNameWithoutExtension(l_pdf_path) + "_atc.pdf"
                    If Not System.IO.File.Exists(l_pdf_path) Then
                        Throw New Exception("Nem található a fájl: " + l_pdf_path)
                    End If
                End If
                'Log inicializálás:
                If IFSZ_Connect.m_loglevel < 5 AndAlso Not String.IsNullOrEmpty(IFSZ_Connect.m_esignolog) Then
                    xsign.SetLogFilePath(mm_log_utvonal + "\" + DateTime.Now().ToString("yyyyMMdd") + "_" + IFSZ_Connect.m_esignolog)
                End If

                Console.Write("1..")
                'XSign Init
                xsign.Initialize(mm_exe_utvonal + "\eszignowork", mm_exe_utvonal + "\" + IFSZ_Connect.m_serverregxml, String.Empty)

                Console.Write("2..")
                'Dialógus ablakok ne legyenek
                xsign.SetWorkSilent(WorkMode.XS_FORCE_SILENT)
                If IFSZ_Connect.m_loglevel < 5 AndAlso Not String.IsNullOrEmpty(IFSZ_Connect.m_esignolog) Then
                    xsign.SetCURLDebug((IFSZ_Connect.m_curllog = 1))
                Else
                    xsign.SetCURLDebug(False)
                End If
                Console.WriteLine("3..")

                Console.WriteLine("Csatol: " + l_pdf_atc_path)

                'Csatolás
                If Not System.IO.File.Exists(l_pdf_atc_path) Then
                    Console.WriteLine("Csatol mehet, nem létezik: " + l_pdf_atc_path)
                    Using pdf As PdfDocument = xsign.OpenPdfDocument(l_pdf_path)

                        l_fajl = p_csatolmany
                        IFSZ_Globals.AppendLog(l_fajl + " fájl csatolása a " + l_pdf_path + "-hez", 1)
                        Console.WriteLine(l_fajl + " fájl csatolása a " + l_pdf_path + "-hez")
                        If System.IO.File.Exists(l_fajl) Then
                            Console.WriteLine(l_fajl + " fájl readallbytes")
                            System.IO.File.ReadAllBytes(l_fajl)
                            Console.WriteLine(l_fajl + " fájl readallbytes sikeres")
                            pdf.AddAttachment(l_fajl, "1")
                        Else
                            'IFSZ_Globals.AppendLog(l_fajl + " nem létezik, ezért nem csatolható a " + l_pdf_path + "-hez")
                            Throw New Exception(l_fajl + " nem létezik, ezért nem csatolható a " + l_pdf_path + "-hez")
                        End If

                        Console.WriteLine("save")
                        'Save it
                        pdf.Save(l_pdf_atc_path)
                    End Using
                End If
                Console.WriteLine("vége")

                'Close log file
                xsign.CloseLogFilePath()

            Catch ex As Exception
                Console.WriteLine(ex.Message)
            Finally
                If m_impersonated Then
                    m_impersonator.EndImpersonation()
                End If
            End Try

        End Using

    End Sub

End Class
