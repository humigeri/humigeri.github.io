# IFSZ_AddOn_Ebiz

2022.11 IFSZ-től kapott forráskód. Ebbe a repository-ba került az ebizserv és az addon installere is.