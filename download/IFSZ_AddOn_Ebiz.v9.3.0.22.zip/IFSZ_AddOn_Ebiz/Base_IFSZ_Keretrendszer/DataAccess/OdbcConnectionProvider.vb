Imports SystemImports System.CollectionsImports System.TextImports System.Data'Imports System.Data.SqlClient'Imports System.Data.OracleClient'Imports ObjectDataBinding.PropertiesPublic Class OdbcConnectionProvider









#If VAN_MYSQL Then
    Public m_Connection As MySql.Data.MySqlClient.MySqlConnection    Public m_Transaction As MySql.Data.MySqlClient.MySqlTransaction

    Sub New()        m_Connection = New MySql.Data.MySqlClient.MySqlConnection(OdbcDataProvider.m_ConnectionString)        m_Connection.Open()        m_Transaction = m_Connection.BeginTransaction()    End Sub
#Else
    Public m_Connection As Object    Public m_Transaction As Object

    Sub New()    End Sub



#End If
    Public Sub Commit()        m_Transaction.Commit()        m_Connection.Close()        m_Connection.Dispose()    End Sub    Public Sub Rollback()        m_Transaction.Rollback()        m_Connection.Close()        m_Connection.Dispose()    End SubEnd Class