Imports SystemImports System.CollectionsImports System.TextImports System.Data

Class IFSZ_SBO_DAO

#Region "Variables"

#End Region


#Region "Saj�t k�dok"

    Public Shared Function Update_DLN1(ByVal p_docnum As String, ByRef p_message As String) As Integer
        Dim l_prefix As String = " "
        Dim sqlQuery As New StringBuilder("Update DLN1 Set ")
        Dim nfi As Globalization.NumberFormatInfo = New Globalization.NumberFormatInfo
        nfi.NumberDecimalSeparator = "."
        nfi.PercentGroupSeparator = ""

        If p_docnum.Length > 0 Then
            sqlQuery.Append(l_prefix + [String].Format("dln1.U_Szlszam = '{0}' ", p_docnum))
            sqlQuery.Append(l_prefix + [String].Format("+'/'+"))
            sqlQuery.Append(l_prefix + [String].Format("convert(varchar,LineNum+1,102) "))
        End If


        sqlQuery.Append([String].Format("from odln where dln1.docentry = odln.docentry and odln.DocNum = '{0}'", p_docnum))

        ' Execute query
        Return DataProvider.ExecuteNonQuery(sqlQuery.ToString(), p_message)
    End Function

    Friend Function Update_OCRD(ByVal p_record As DataRow, ByVal p_record_old As DataRowView, ByVal p_ertek As String, ByRef p_message As String) As Integer
        Dim l_prefix As String = " "
        Dim sqlQuery As New StringBuilder("Update " + QueryResource.AzonPrep("OCRD") + " Set ")
        Dim nfi As Globalization.NumberFormatInfo = New Globalization.NumberFormatInfo
        nfi.NumberDecimalSeparator = "."
        nfi.PercentGroupSeparator = ""

        If CType(p_record, DataRow).Table.Columns.IndexOf("MODOSITAS_DATUMA") >= 0 Then
            If Not p_record.IsNull("MODOSITAS_DATUMA") Then

                'sqlQuery.Append(l_prefix + [String].Format("MODOSITAS_DATUMA = '{0}' ", p_record.Item("MODOSITAS_DATUMA")))
                sqlQuery.Append(l_prefix + "U_UtModDat = convert(datetime, '" + CType(p_record.Item("MODOSITAS_DATUMA"), DateTime).ToString("yyyy-MM-dd HH:mm:ss") + "', 120)")
                l_prefix = ", "
            Else
                p_message = ""
                Return -1
            End If
        End If

        sqlQuery.Append([String].Format("Where CardCode = '{0}'", p_record.Item("CARDCODE")))

        ' Execute query
        Return DataProvider.ExecuteNonQuery(sqlQuery.ToString(), p_message)
    End Function

    Public Shared Function get_BejovoSzamlaDocEntryByNum(ByVal p_docnum As String) As String
        Dim l_query As String
        l_query = QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "sel_docentry_from_opch_by_docnum_order_pindicator", p_docnum)
        Return DataProvider.GetDataRecord(l_query.ToString()).Item(0).Item(0).ToString
    End Function

    Public Shared Function get_KimenoSzamlaDocEntryByNum(ByVal p_docnum As String) As String
        Dim l_query As String
        l_query = QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "sel_docentry_from_opch_by_docnum_order_pindicator", p_docnum)
        Return DataProvider.GetDataRecord(l_query.ToString()).Item(0).Item(0).ToString
    End Function

    Public Shared Function get_szamlaDocEntryByNum(ByVal p_docnum As String) As String
        Dim l_query As String
        l_query = QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "sel_docentry_from_szamlalov_by_docnum", p_docnum)
        Return DataProvider.GetDataRecord(l_query.ToString()).Item(0).Item(0).ToString
    End Function

    Public Shared Function get_ItemType(ByVal p_itemcode As String) As String
        Dim l_query As String
        Dim l_type1 As String
        Dim l_type2 As String
        Dim l_row As DataRow

        l_query = QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "sel_mannums_from_oitm_by_itemcode", p_itemcode)
        l_row = DataProvider.GetDataRecord(l_query.ToString()).Item(0)
        l_type1 = l_row.Item(0).ToString
        l_type2 = l_row.Item(1).ToString

        If l_type1 = "Y" Then
            Return "S"
        ElseIf l_type2 = "Y" Then
            Return "GY"
        Else
            Return "E"
        End If
    End Function

    Public Shared Function get_ItemExists(ByVal p_itemcode As String) As Boolean
        Dim l_query As String

        l_query = QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "sel_itemcode_from_oitm_by_itemcode", p_itemcode)
        If DataProvider.GetDataRecord(l_query.ToString()).Count = 1 Then
            Return True
        Else
            Return False
        End If
    End Function

    Public Shared Function get_BejovoSzamla_Storno(ByVal p_docnum As String) As Boolean
        Dim l_query As String
        Dim l_NCorrInv As String

        l_query = QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "sel_ncorrinv_from_opch_by_docentry", p_docnum)
        If DataProvider.GetDataRecord(l_query.ToString()).Count = 1 Then
            l_NCorrInv = DataProvider.GetDataRecord(l_query.ToString()).Item(0).Item(0).ToString
            If l_NCorrInv >= 1 Then
                Return True
            Else
                Return False
            End If
        Else
            Return False
        End If
    End Function

    Public Shared Function get_KimenoSzamla_Storno(ByVal p_docnum As String) As Boolean
        Dim l_query As String
        Dim l_NCorrInv As String

        l_query = QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "sel_ncorrinv_from_oinv_by_docentry", p_docnum)
        If DataProvider.GetDataRecord(l_query.ToString()).Count = 1 Then
            l_NCorrInv = DataProvider.GetDataRecord(l_query.ToString()).Item(0).Item(0).ToString
            If l_NCorrInv >= 1 Then
                Return True
            Else
                Return False
            End If
        Else
            Return False
        End If
    End Function

    Public Shared Function get_ItemMinValue(ByVal p_itemcode As String) As String
        Dim l_query As String
        Dim l_type1 As String
        Dim l_row As DataRow

        l_query = QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "sel_minlevel_from_oitm_by_itemcode", p_itemcode)
        l_row = DataProvider.GetDataRecord(l_query.ToString()).Item(0)
        l_type1 = l_row.Item(0).ToString

        Return l_type1
    End Function

    Public Shared Function get_ItemSysSerial(ByVal p_itemcode As String) As Integer
        Dim l_query As String
        Dim l_row As DataRow

        l_query = QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "sel_max_sysnumber_from_osrn_by_itemcode", p_itemcode)
        l_row = DataProvider.GetDataRecord(l_query.ToString()).Item(0)
        If l_row.Item(0).ToString = "" Then
            Return 1
        Else
            Return l_row.Item(0)
        End If
    End Function

    Public Shared Function get_ExistingItemSysSerial(ByVal p_itemcode As String, ByVal p_serialnum As String) As Integer
        Dim l_query As String
        Dim l_row As DataRow

        l_query = QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "sel_sysnumber_from_osrn_by_itemcode_distnumber", p_itemcode, p_serialnum)
        l_row = DataProvider.GetDataRecord(l_query.ToString()).Item(0)
        If l_row.Item(0).ToString = "" Then
            Return 1
        Else
            Return l_row.Item(0)
        End If
    End Function

    Public Shared Function get_Raktar(ByVal p_itemcode As String) As String
        Dim l_query As String
        Dim l_type1 As String
        Dim l_row As DataRow

        l_query = QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "sel_whscode_from_owhs_by_whscode", p_itemcode)
        l_row = DataProvider.GetDataRecord(l_query.ToString()).Item(0)
        l_type1 = l_row.Item(0).ToString

        Return l_type1
    End Function

    Public Shared Function get_CardCode(ByVal p_cardcode As String) As String
        Dim l_query As String
        Dim l_type1 As String
        Dim l_row As DataRow

        l_query = QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "sel_cardcode_from_ocrd_by_cardcode", p_cardcode)
        l_row = DataProvider.GetDataRecord(l_query.ToString()).Item(0)
        l_type1 = l_row.Item(0).ToString

        Return l_type1
    End Function

    Public Shared Function get_CardCodeType(ByVal p_cardcode As String) As String
        Dim l_query As String
        Dim l_type1 As String
        Dim l_row As DataRow

        l_query = QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "sel_cardtype_from_ocrd_by_cardcode", p_cardcode)
        l_row = DataProvider.GetDataRecord(l_query.ToString()).Item(0)
        l_type1 = l_row.Item(0).ToString

        Return l_type1
    End Function

    Public Shared Function get_AHLertek(ByVal p_batchnum As String, ByVal p_ItemCode As String) As Double
        Dim l_query As String
        Dim l_row As DataRow
        Dim l_rows As DataRowCollection

        l_query = QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "sel_ahlertek_by_batchnum_itemcode", p_batchnum, p_ItemCode)
        l_rows = DataProvider.GetDataRecord(l_query.ToString())
        If l_rows.Count = 0 Then
            Return 0
        End If
        l_row = l_rows.Item(0)
        Return l_row.Item(0)
    End Function

    Public Shared Function update_AjanlatManualNum(ByVal p_azonosito As String) As String
        Dim l_query As String
        Dim p_message As String

#If HANADB Then
        l_query = "update oqut set ""ManualNum"" = cast(""DocNum"" as nvarchar) || '/V00' where ""ManualNum"" = " & IFSZ_Globals.SqlConstantPrepare(p_azonosito)
#Else
        l_query = "update oqut set manualnum = convert(nvarchar,docnum) + '/V00' where manualnum = '" & p_azonosito & "'"
#End If

        DataProvider.ExecuteNonQuery(l_query, p_message)
        Return p_message
    End Function

    Public Shared Function get_Ajanlat_DocEntry(ByVal p_docnum As String) As String
        Dim l_query As String

        l_query = QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "sel_docentry_from_oqut_by_docnum", p_docnum)

        If DataProvider.GetDataRecord(l_query.ToString()).Count = 1 Then
            Return DataProvider.GetDataRecord(l_query.ToString()).Item(0).Item(0).ToString
        Else
            Return ""
        End If
    End Function

    Public Shared Function get_ManualNum_Ajanlat(ByVal p_docentry As String) As String
        Dim l_query As String

        l_query = QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "sel_manualnum_from_oqut_by_docentry", p_docentry)

        If DataProvider.GetDataRecord(l_query.ToString()).Count = 1 Then
            Return DataProvider.GetDataRecord(l_query.ToString()).Item(0).Item(0).ToString
        Else
            Return ""
        End If
    End Function

    Public Shared Function get_MaxVerzio_Ajanlat(ByVal p_docnum As String) As String
        Dim l_query As String

        l_query = QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "get_maxverzio_ajanlat", p_docnum)

        If DataProvider.GetDataRecord(l_query.ToString()).Count = 1 Then
            Return DataProvider.GetDataRecord(l_query.ToString()).Item(0).Item(0).ToString
        Else
            Return ""
        End If
    End Function

    Public Shared Function get_MaxDocEntry_Ajanlat(ByVal p_docnum As String, ByVal p_verzio As String) As String
        Dim l_query As String

        l_query = QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "get_maxdocentry_ajanlat", p_docnum & "/V" & p_verzio)

        If DataProvider.GetDataRecord(l_query.ToString()).Count = 1 Then
            Return DataProvider.GetDataRecord(l_query.ToString()).Item(0).Item(0).ToString
        Else
            Return ""
        End If
    End Function

    Public Shared Function get_MaxDocNum_Ajanlat(ByVal p_verzio As String) As String
        Dim l_query As String

        l_query = QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "get_maxdocnum_ajanlat", p_verzio)

        If DataProvider.GetDataRecord(l_query.ToString()).Count = 1 Then
            Return DataProvider.GetDataRecord(l_query.ToString()).Item(0).Item(0).ToString
        Else
            Return ""
        End If
    End Function

    Public Shared Function get_Un(ByVal p_itemcode As String, ByVal p_menny As Double) As DataRow
        Dim l_query As String
        l_query = QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "get_un", p_menny, p_itemcode)
        'l_query = "select a.sweight1 mennyiseg, b.unitdisply egyseg, a.U_UNszam unszam from oitm as a left join owgt as b ON a.swght1Unit = b.unitcode where itemcode = '" & p_itemcode & "'"
        If DataProvider.GetDataRecord(l_query.ToString()).Count = 1 Then
            Return DataProvider.GetDataRecord(l_query.ToString()).Item(0)
        End If
    End Function

    Public Shared Function get_UnSzam(ByVal p_itemcode As String) As String
        Dim l_query As String
        l_query = QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "get_unszam", p_itemcode)

        If DataProvider.GetDataRecord(l_query.ToString()).Count = 1 Then
            Return DataProvider.GetDataRecord(l_query.ToString()).Item(0).Item(0).ToString
        Else
            Return ""
        End If

    End Function

    Public Shared Function get_UserData(ByVal p_user As String) As DataRow
        Dim l_query As String

        l_query = QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "sel_all_from_ousr_by_user_code", p_user)

        Return DataProvider.GetDataRecord(l_query.ToString()).Item(0)
    End Function

    Public Shared Function Update_Elerheto_Mennyiseg(ByVal p_tipus As Integer, ByVal p_docentry As Integer, ByRef p_message As String) As Integer
        Dim l_sqlQuery, l_tabla As String
        Select Case p_tipus
            Case 10014
                l_tabla = "DLN1"
            Case 10012
                l_tabla = "INV1"
            Case 10016
                l_tabla = "RDR1"
            Case 10022
                l_tabla = "QUT1"
            Case Else
                Return 0
        End Select
#If HANADB Then
        l_sqlQuery = "Update " + l_tabla + " set ""U_elerheto"" = "
        l_sqlQuery = l_sqlQuery + "(SELECT SUM(T0.OnHand)-SUM(T0.IsCommited)+[dbo].IFSZ_ELOZETESSZLA_cikkfoglalasa(" + l_tabla + ".""ItemCode"") FROM OITW T0 WHERE T0.""ItemCode"" = " + l_tabla + ".""ItemCode"") "
        l_sqlQuery = l_sqlQuery + " where ""DocEntry"" = " + p_docentry.ToString
#Else
        l_sqlQuery = "Update " + l_tabla + " set u_elerheto = "
        l_sqlQuery = l_sqlQuery + "(SELECT SUM(T0.OnHand)-SUM(T0.IsCommited)+[dbo].IFSZ_ELOZETESSZLA_cikkfoglalasa(" + l_tabla + ".itemcode) FROM OITW T0 WHERE T0.ItemCode = " + l_tabla + ".itemcode) "
        l_sqlQuery = l_sqlQuery + " where docentry = " + p_docentry.ToString
#End If
        Return DataProvider.ExecuteNonQuery(l_sqlQuery, p_message)
    End Function

#End Region

End Class