Imports SystemImports System.CollectionsImports System.TextImports System.IOImports System.Data#If HANADB Then
Imports System.Data.Odbc#Else
Imports System.Data.SqlClient#End If
Imports Microsoft.VisualBasicImports Microsoft.VisualBasic.Interaction'Imports ObjectDataBinding.PropertiesPublic Class DataProvider    Public Shared m_ConnectionString As String = [String].Empty    Private Shared m_DBName_Def As String = "database"    Private Shared m_Connect_TimeOut_Def As String = "Connect Timeout"    Private Shared m_Connect_Password_Def As String = "Password"    Private Shared m_Connect_TrustedConn_Def As String = "Integrated Security"    Shared Sub New()        m_ConnectionString = SBOAddOn.m_conn_string        If Not String.IsNullOrEmpty(System.Configuration.ConfigurationSettings.AppSettings("password")) Then            DataProvider.SetPassword(System.Configuration.ConfigurationSettings.AppSettings("password"))            DataProvider.SetTrusted("False")        End If        If m_ConnectionString Is Nothing Then            m_ConnectionString = "Persist Security Info=False;" &
                                                    "database=SBODemo_HU;server=(local);User ID=sa;Password=proba;Connect Timeout=30"        End If        If IFSZ_Globals.OpenLOG = False AndAlso IFSZ_Globals.GetParameter("OpenLOG") = "N" Then
            IFSZ_Globals.OpenLOG = False
        Else
            IFSZ_Globals.SboUserName = IFSZ_Globals.m_ParentAddOn.SboCompany.UserName
            IFSZ_Globals.OpenLOG = True
        End If    End Sub    Public Shared Function GetDBName() As String        Dim l_split() As String        Dim l_temp2() As String        l_split = DataProvider.m_ConnectionString.Split(";")        For Each l_temp As String In l_split            l_temp2 = l_temp.Split("=")            If l_temp2.Length = 2 AndAlso l_temp2(0).Trim().ToLower() = DataProvider.m_DBName_Def.ToLower() Then                Return l_temp2(1).Trim            End If        Next        Return Nothing    End Function    Public Shared Function GetDBName(ByVal l_conn_str As String) As String        Dim l_split() As String        Dim l_temp2() As String        l_split = l_conn_str.Split(";")        For Each l_temp As String In l_split            l_temp2 = l_temp.Split("=")            If l_temp2.Length = 2 AndAlso l_temp2(0).Trim().ToLower() = DataProvider.m_DBName_Def.ToLower() Then                Return l_temp2(1).Trim            End If        Next        Return Nothing    End Function    Public Shared Function GetTimeOut() As Integer        Dim l_split() As String        Dim l_temp2() As String        Dim l_ret As Integer = 0        Try            l_split = DataProvider.m_ConnectionString.Split(";")            For Each l_temp As String In l_split                l_temp2 = l_temp.Split("=")                If l_temp2.Length = 2 AndAlso l_temp2(0).Trim().ToLower() = DataProvider.m_Connect_TimeOut_Def.ToLower() Then                    Return CInt(l_temp2(1).Trim)                End If            Next            Return 0        Catch        Finally            l_ret = 0        End Try        Return l_ret    End Function    Public Shared Sub SetTimeOut(ByVal p_ertek As Integer)        Dim l_split() As String        Dim l_temp2() As String        Dim l_connstring As String = ""        Try            l_split = DataProvider.m_ConnectionString.Split(";")            For Each l_temp As String In l_split                l_temp2 = l_temp.Split("=")                If l_temp2.Length = 2 AndAlso l_temp2(0).Trim().ToLower() = DataProvider.m_Connect_TimeOut_Def.ToLower() Then                    If l_connstring = "" Then                        l_connstring += DataProvider.m_Connect_TimeOut_Def + "=" + p_ertek.ToString()                    Else                        l_connstring += ";" + DataProvider.m_Connect_TimeOut_Def + "=" + p_ertek.ToString()                    End If                Else                    If Not String.IsNullOrEmpty(l_temp) Then                        If l_connstring = "" Then                            l_connstring += l_temp                        Else                            l_connstring += ";" + l_temp                        End If                    End If                End If            Next            DataProvider.m_ConnectionString = l_connstring        Catch        Finally            'Nem akarok hib�t kiv�ltani        End Try    End Sub    Public Shared Sub SetPassword(ByVal p_ertek As String)        Dim l_split() As String        Dim l_temp2() As String        Dim l_connstring As String = ""        Try            l_split = DataProvider.m_ConnectionString.Split(";")            For Each l_temp As String In l_split                l_temp2 = l_temp.Split("=")                If l_temp2.Length = 2 AndAlso l_temp2(0).Trim().ToLower() = DataProvider.m_Connect_Password_Def.ToLower() Then                    If l_connstring = "" Then                        l_connstring += DataProvider.m_Connect_Password_Def + "=" + p_ertek.ToString()                    Else                        l_connstring += ";" + DataProvider.m_Connect_Password_Def + "=" + p_ertek.ToString()                    End If                Else                    If Not String.IsNullOrEmpty(l_temp) Then                        If l_connstring = "" Then                            l_connstring += l_temp                        Else                            l_connstring += ";" + l_temp                        End If                    End If                End If            Next            DataProvider.m_ConnectionString = l_connstring        Catch        Finally            'Nem akarok hib�t kiv�ltani        End Try    End Sub    Public Shared Sub SetTrusted(ByVal p_ertek As String)        Dim l_split() As String        Dim l_temp2() As String        Dim l_connstring As String = ""        Try            l_split = DataProvider.m_ConnectionString.Split(";")            For Each l_temp As String In l_split                l_temp2 = l_temp.Split("=")                If l_temp2.Length = 2 AndAlso l_temp2(0).Trim().ToLower() = DataProvider.m_Connect_TrustedConn_Def.ToLower() Then                    If l_connstring = "" Then                        l_connstring += DataProvider.m_Connect_TrustedConn_Def + "=" + p_ertek.ToString()                    Else                        l_connstring += ";" + DataProvider.m_Connect_TrustedConn_Def + "=" + p_ertek.ToString()                    End If                Else                    If Not String.IsNullOrEmpty(l_temp) Then                        If l_connstring = "" Then                            l_connstring += l_temp                        Else                            l_connstring += ";" + l_temp                        End If                    End If                End If            Next            DataProvider.m_ConnectionString = l_connstring        Catch        Finally            'Nem akarok hib�t kiv�ltani        End Try    End Sub    Public Shared Function ExecuteNonQuery(ByVal sqlQuery As String, ByRef p_messege As String, Optional ByVal p_hiba As Boolean = False) As Integer
        ' Create and open a connection
        IFSZ_Globals.LastDML = sqlQuery

#If HANADB Then
        Dim connection As OdbcConnection
        'If IFSZ_Globals.m_Connection Is Nothing Then
        If IFSZ_Globals.m_Connection Is Nothing Then            connection = New OdbcConnection(m_ConnectionString)            connection.Open()        ElseIf IFSZ_Globals.m_Connection.m_Connection.ConnectionString = "" Then            connection = New OdbcConnection(m_ConnectionString)            connection.Open()        Else            connection = IFSZ_Globals.m_Connection.m_Connection        End If

        ' Create and configure a command
        Dim command As OdbcCommand = connection.CreateCommand()        If Not IFSZ_Globals.m_Connection Is Nothing Then            command.Transaction = IFSZ_Globals.m_Connection.m_Transaction        End If        command.CommandText = "SET SCHEMA " + DataProvider.GetDBName()        command.ExecuteNonQuery()

        If IFSZ_Globals.OpenLOG = True Then
            Try
                command.CommandText = "INSERT INTO IFSZ_SQL_LOG VALUES (right('" + sqlQuery.Replace("'", "''") + "',4000),'" & IFSZ_Globals.SboUserName & "',current_timestamp,'" & IFSZ_Globals.AktivForm & "'); "
                command.ExecuteNonQuery()

            Catch ex As Exception
                command.CommandText = ""
            End Try
        End If
        command.CommandText = sqlQuery.TrimEnd(";".ToCharArray)




































#Else
        Dim connection As SqlConnection        'If IFSZ_Globals.m_Connection Is Nothing Then        If IFSZ_Globals.m_Connection Is Nothing Then            connection = New SqlConnection(m_ConnectionString)            connection.Open()        ElseIf IFSZ_Globals.m_Connection.m_Connection.ConnectionString = "" Then            connection = New SqlConnection(m_ConnectionString)            connection.Open()        Else            connection = IFSZ_Globals.m_Connection.m_Connection        End If        ' Create and configure a command        Dim command As New SqlCommand(sqlQuery, connection)        If Not IFSZ_Globals.m_Connection Is Nothing Then            command.Transaction = IFSZ_Globals.m_Connection.m_Transaction        End If
#End If
        ' Execute the command
        Try            Dim numRowsAffected As Integer = command.ExecuteNonQuery
            ' Close and dispose
            command.Dispose()            If IFSZ_Globals.m_Connection Is Nothing Then                connection.Close()                connection.Dispose()            ElseIf IFSZ_Globals.m_Connection.m_Connection.ConnectionString = "" Then                connection.Close()                connection.Dispose()            End If

            ' Set return value
            Return numRowsAffected        Catch ex As System.Data.SqlClient.SqlException            If p_hiba Then
#If NOMSGBOX Then
#Else
                MsgBox(ex.ToString, MsgBoxStyle.OkCancel, "Hiba!")


#End If            End If            Select Case ex.Number                Case 2627                    p_messege = "Egyedi kulcs megs�rt�s!"                    Return -1                Case 242                    p_messege = "Hib�s d�tum form�tum!"                    Return -1                Case Else                    p_messege = ex.Message                    Return -1            End Select        End Try    End Function 'ExecuteNonQuery

    Public Shared Function ExecuteNonQuery(ByVal sqlQuery As String, ByRef p_messege As String, ByVal l_conn As String, Optional ByVal p_hiba As Boolean = False) As Integer
        ' Create and open a connection
        IFSZ_Globals.LastDML = sqlQuery

#If HANADB Then
        Dim connection As OdbcConnection
        'If IFSZ_Globals.m_Connection Is Nothing Then
        If IFSZ_Globals.m_Connection Is Nothing Then            connection = New OdbcConnection(l_conn)            connection.Open()        ElseIf IFSZ_Globals.m_Connection.m_Connection.ConnectionString = "" Then            connection = New OdbcConnection(l_conn)            connection.Open()        Else            connection = IFSZ_Globals.m_Connection.m_Connection        End If

        ' Create and configure a command
        Dim command As OdbcCommand = connection.CreateCommand()        If Not IFSZ_Globals.m_Connection Is Nothing Then            command.Transaction = IFSZ_Globals.m_Connection.m_Transaction        End If        command.CommandText = "SET SCHEMA " + DataProvider.GetDBName(l_conn)        command.ExecuteNonQuery()

        If IFSZ_Globals.OpenLOG = True Then
            Try
                command.CommandText = "INSERT INTO IFSZ_SQL_LOG VALUES (right('" + sqlQuery.Replace("'", "''") + "',4000),'" & IFSZ_Globals.SboUserName & "',current_timestamp,'" & IFSZ_Globals.AktivForm & "'); "
                command.ExecuteNonQuery()

            Catch ex As Exception
                command.CommandText = ""
            End Try
        End If
        command.CommandText = sqlQuery.TrimEnd(";".ToCharArray)




































#Else
        Dim connection As SqlConnection        'If IFSZ_Globals.m_Connection Is Nothing Then        If IFSZ_Globals.m_Connection Is Nothing Then            connection = New SqlConnection(m_ConnectionString)            connection.Open()        ElseIf IFSZ_Globals.m_Connection.m_Connection.ConnectionString = "" Then            connection = New SqlConnection(m_ConnectionString)            connection.Open()        Else            connection = IFSZ_Globals.m_Connection.m_Connection        End If        ' Create and configure a command        Dim command As New SqlCommand(sqlQuery, connection)        If Not IFSZ_Globals.m_Connection Is Nothing Then            command.Transaction = IFSZ_Globals.m_Connection.m_Transaction        End If
#End If
        ' Execute the command
        Try            Dim numRowsAffected As Integer = command.ExecuteNonQuery
            ' Close and dispose
            command.Dispose()            If IFSZ_Globals.m_Connection Is Nothing Then                connection.Close()                connection.Dispose()            ElseIf IFSZ_Globals.m_Connection.m_Connection.ConnectionString = "" Then                connection.Close()                connection.Dispose()            End If

            ' Set return value
            Return numRowsAffected        Catch ex As System.Data.SqlClient.SqlException            If p_hiba Then

#If NOMSGBOX Then
#Else
                MsgBox(ex.ToString, MsgBoxStyle.OkCancel, "Hiba!")




#End If            End If            Select Case ex.Number                Case 2627                    p_messege = "Egyedi kulcs megs�rt�s!"                    Return -1                Case 242                    p_messege = "Hib�s d�tum form�tum!"                    Return -1                Case Else                    p_messege = ex.Message                    Return -1            End Select        End Try    End Function 'ExecuteNonQuery


    Public Shared Function InsertUpdateFile(ByVal sqlQuery As String, ByVal filename As String, ByRef p_messege As String, Optional ByVal p_commit As Boolean = False, Optional ByVal p_hiba As Boolean = False) As Integer        ' Create and open a connection        Dim image As Byte()#If HANADB Then
        Dim connection As OdbcConnection        If IFSZ_Globals.m_Connection Is Nothing Then            connection = New OdbcConnection(m_ConnectionString)            connection.Open()        ElseIf IFSZ_Globals.m_Connection.m_Connection.ConnectionString = "" Then            connection = New OdbcConnection(m_ConnectionString)            connection.Open()        Else            connection = IFSZ_Globals.m_Connection.m_Connection        End If        ' Create and configure a command        Dim command As OdbcCommand = connection.CreateCommand()        If Not IFSZ_Globals.m_Connection Is Nothing Then            command.Transaction = IFSZ_Globals.m_Connection.m_Transaction        End If        command.CommandText = "SET SCHEMA " + DataProvider.GetDBName()        command.ExecuteNonQuery()        command.CommandText = sqlQuery.TrimEnd(";".ToCharArray)        Dim imageParameter As OdbcParameter = command.Parameters.Add("@file", SqlDbType.Binary)#Else
        Dim connection As SqlConnection        If IFSZ_Globals.m_Connection Is Nothing Then            connection = New SqlConnection(m_ConnectionString)            connection.Open()        ElseIf IFSZ_Globals.m_Connection.m_Connection.ConnectionString = "" Then            connection = New SqlConnection(m_ConnectionString)            connection.Open()        Else            connection = IFSZ_Globals.m_Connection.m_Connection        End If        ' Create and configure a command        Dim command As New SqlCommand(sqlQuery, connection)        Dim imageParameter As SqlParameter = command.Parameters.Add("@file", SqlDbType.Binary)        If Not IFSZ_Globals.m_Connection Is Nothing Then            command.Transaction = IFSZ_Globals.m_Connection.m_Transaction        End If#End If
        image = IFSZ_Globals.ConvertFile2ByteArray(filename)        imageParameter.Value = image        imageParameter.Size = image.Length        ' Execute the command        Try            Dim numRowsAffected As Integer = command.ExecuteNonQuery            ' Close and dispose            If p_commit Then                Try                    command.Transaction.Commit()                Catch ex As Exception                End Try            End If            command.Dispose()            If IFSZ_Globals.m_Connection Is Nothing Then                connection.Close()                connection.Dispose()            End If            ' Set return value            Return numRowsAffected        Catch ex As System.Data.SqlClient.SqlException            If p_hiba Then#If NOMSGBOX Then#Else
                MsgBox(ex.ToString, MsgBoxStyle.OkCancel, "Hiba!")#End If            End If            Select Case ex.Number                Case 2627                    p_messege = "Egyedi kulcs megs�rt�s!"                    Return -1                Case 242                    p_messege = "Hib�s d�tum form�tum!"                    Return -1                Case Else                    p_messege = ex.Message                    Return -1            End Select        End Try    End Function 'ExecuteNonQuery

#If HANADB Then
#Else


    Public Shared Function InsertUpdateVarbinary(ByVal sqlQuery As String, ByVal filename As String, ByRef p_messege As String, Optional ByVal p_commit As Boolean = False, Optional ByVal p_hiba As Boolean = False) As Integer
        ' Create and open a connection
        Dim image As Byte()

        Dim connection As SqlConnection        If IFSZ_Globals.m_Connection Is Nothing Then            connection = New SqlConnection(m_ConnectionString)            connection.Open()        ElseIf IFSZ_Globals.m_Connection.m_Connection.ConnectionString = "" Then            connection = New SqlConnection(m_ConnectionString)            connection.Open()        Else            connection = IFSZ_Globals.m_Connection.m_Connection        End If

        ' Create and configure a command
        Dim command As New SqlCommand(sqlQuery, connection)        Dim imageParameter As SqlParameter = command.Parameters.Add("@file", SqlDbType.VarBinary)        If Not IFSZ_Globals.m_Connection Is Nothing Then            command.Transaction = IFSZ_Globals.m_Connection.m_Transaction        End If

        image = IFSZ_Globals.ConvertFile2ByteArray(filename)        imageParameter.Value = image        imageParameter.Size = image.Length

        ' Execute the command
        Try            Dim numRowsAffected As Integer = command.ExecuteNonQuery
            ' Close and dispose
            If p_commit Then                Try                    command.Transaction.Commit()                Catch ex As Exception                End Try            End If            command.Dispose()            If IFSZ_Globals.m_Connection Is Nothing Then                connection.Close()                connection.Dispose()            End If

            ' Set return value
            Return numRowsAffected        Catch ex As System.Data.SqlClient.SqlException            If p_hiba Then

#If NOMSGBOX Then
#Else
                MsgBox(ex.ToString, MsgBoxStyle.OkCancel, "Hiba!")




#End If            End If            Select Case ex.Number                Case 2627                    p_messege = "Egyedi kulcs megs�rt�s!"                    Return -1                Case 242                    p_messege = "Hib�s d�tum form�tum!"                    Return -1                Case Else                    p_messege = ex.Message                    Return -1            End Select        End Try    End Function 'ExecuteNonQuery
#End If

    Public Shared Function ExecuteNonQueryRowCommit(ByVal sqlQuery As String, ByRef p_messege As String, ByVal l_connection As String, Optional ByVal p_hiba As Boolean = False) As Integer
        ' Create and open a connection
        IFSZ_Globals.LastDML = sqlQuery
#If HANADB Then
        Dim connection As OdbcConnection
        connection = New OdbcConnection(l_connection)
        connection.Open()

        ' Create and configure a command        Dim command As OdbcCommand = connection.CreateCommand()        command.Transaction = connection.BeginTransaction        command.CommandText = "SET SCHEMA " + DataProvider.GetDBName()        command.ExecuteNonQuery()        command.CommandText = sqlQuery.TrimEnd(";".ToCharArray)#Else
        Dim connection As SqlConnection
        connection = New SqlConnection(l_connection)
        connection.Open()

        ' Create and configure a command        Dim command As New SqlCommand(sqlQuery, connection)        command.Transaction = connection.BeginTransaction#End If
        ' Execute the command        Try            Dim numRowsAffected As Integer = command.ExecuteNonQuery            ' Close and dispose            command.Transaction.Commit()            command.Dispose()            connection.Close()            connection.Dispose()            ' Set return value            Return numRowsAffected        Catch ex As System.Data.SqlClient.SqlException            command.Transaction.Rollback()            If p_hiba Then#If NOMSGBOX Then#Else
                MsgBox(ex.ToString, MsgBoxStyle.OkCancel, "Hiba!")#End If            End If            Select Case ex.Number                Case 2627                    p_messege = "Egyedi kulcs megs�rt�s!"                    Return -1            End Select        End Try    End Function 'ExecuteNonQuery    '/ <summary>    '/ Execute a query that returns a scalar value    '/ </summary>    '/ <param name="sqlQuery">The SQL query to run against the database </param>    '/ <returns>The scalar value returned by the database.</returns>    Public Shared Function ExecuteScalar(ByVal sqlQuery As String) As Integer
        ' Create and open a connection
        IFSZ_Globals.LastDML = sqlQuery

#If HANADB Then
        Dim connection As OdbcConnection        If IFSZ_Globals.m_Connection Is Nothing Then            connection = New OdbcConnection(m_ConnectionString)            connection.Open()        ElseIf IFSZ_Globals.m_Connection.m_Connection.ConnectionString = "" Then            connection = New OdbcConnection(m_ConnectionString)            connection.Open()        Else            connection = IFSZ_Globals.m_Connection.m_Connection        End If        ' Create and configure a command        Dim command As OdbcCommand = connection.CreateCommand()        If Not IFSZ_Globals.m_Connection Is Nothing Then            command.Transaction = IFSZ_Globals.m_Connection.m_Transaction        End If        command.CommandText = "SET SCHEMA " + DataProvider.GetDBName()        command.ExecuteNonQuery()


        If IFSZ_Globals.OpenLOG = True Then
            Try
                command.CommandText = "INSERT INTO IFSZ_SQL_LOG VALUES (right('" + sqlQuery.Replace("'", "''") + "',4000),'" & IFSZ_Globals.SboUserName & "',current_timestamp,'" & IFSZ_Globals.AktivForm & "'); "
                command.ExecuteNonQuery()

            Catch ex As Exception
                command.CommandText = ""
            End Try
        End If        command.CommandText = sqlQuery.TrimEnd(";".ToCharArray)#Else
        Dim connection As SqlConnection        If IFSZ_Globals.m_Connection Is Nothing Then            connection = New SqlConnection(m_ConnectionString)            connection.Open()        ElseIf IFSZ_Globals.m_Connection.m_Connection.ConnectionString = "" Then            connection = New SqlConnection(m_ConnectionString)            connection.Open()        Else            connection = IFSZ_Globals.m_Connection.m_Connection        End If        ' Create and configure a command        Dim command As New SqlCommand(sqlQuery, connection)        If Not IFSZ_Globals.m_Connection Is Nothing Then            command.Transaction = IFSZ_Globals.m_Connection.m_Transaction        End If#End If
        ' Execute the command        Dim result As Integer = Convert.ToInt32(command.ExecuteScalar())        ' Close and dispose        command.Dispose()        If IFSZ_Globals.m_Connection Is Nothing Then            connection.Close()            connection.Dispose()        ElseIf IFSZ_Globals.m_Connection.m_Connection.ConnectionString = "" Then            connection.Close()            connection.Dispose()        End If        ' Set return value        Return result    End Function 'ExecuteScalar


    ''' <summary>
    ''' Az ExecuteScalar olyan v�ltozata, ami f�ggetlen�l az IFSZ_Globals.m_connection tartalm�t�l mindig �j
    ''' kapcsolatot nyit, �s azt haszn�lja
    ''' </summary>
    ''' <param name="sqlQuery"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Function ExecuteScalarAutonomTransaction(ByVal sqlQuery As String) As Integer
        ' Create and open a connection
#If HANADB Then
        Dim connection As OdbcConnection        Dim l_transaction As OdbcTransaction        Dim command As OdbcCommand        Dim l_elso As Boolean = True        Try

            connection = New OdbcConnection(m_ConnectionString)
            connection.Open()
            l_transaction = connection.BeginTransaction()

            ' Create and configure a command
            command = connection.CreateCommand()

            command.Transaction = l_transaction
            command.CommandText = "SET SCHEMA " + DataProvider.GetDBName()

            Dim l_sqlek() As String = DataProvider.SqlCommandSplit(sqlQuery)            For i As Integer = 0 To l_sqlek.Length - 1                If Not String.IsNullOrEmpty(l_sqlek(i).Trim()) Then
                    command.ExecuteNonQuery()
                    command.CommandText = l_sqlek(i)                End If            Next

            ' Execute the command
            Dim result As Integer = Convert.ToInt32(command.ExecuteScalar())

            l_transaction.Commit()

#Else
        Dim connection As SqlConnection
        Try

            connection = New SqlConnection(m_ConnectionString)
            connection.Open()
            ' Create and configure a command            Dim command As New SqlCommand(sqlQuery, connection)
            ' Execute the command
            Dim result As Integer = Convert.ToInt32(command.ExecuteScalar())

#End If

            ' Close and dispose
            command.Dispose()

            connection.Close()
            connection.Dispose()

            ' Set return value
            Return result

        Catch ex As Exception
#If HANADB Then
            If command IsNot Nothing Then
                command.Dispose()
            End If
            If l_transaction IsNot Nothing Then
                l_transaction.Rollback()
            End If
#End If
            If connection IsNot Nothing Then
                connection.Close()
                connection.Dispose()
            End If
            Return -1
        End Try
    End Function 'ExecuteScalarAutonomTransaction

    Public Shared Sub ExecuteScalarAutonomTransactionNewThread(ByVal sqlQuery As String)
        ' Create and open a connection
#If HANADB Then
        Dim connection As OdbcConnection        Dim l_transaction As OdbcTransaction        Dim command As OdbcCommand        Dim l_elso As Boolean = True        Try

            connection = New OdbcConnection(m_ConnectionString)
            connection.Open()
            l_transaction = connection.BeginTransaction()

            ' Create and configure a command
            command = connection.CreateCommand()

            command.Transaction = l_transaction
            command.CommandText = "SET SCHEMA " + DataProvider.GetDBName()

            Dim l_sqlek() As String = DataProvider.SqlCommandSplit(sqlQuery)            For i As Integer = 0 To l_sqlek.Length - 1                If Not String.IsNullOrEmpty(l_sqlek(i).Trim()) Then
                    command.ExecuteNonQuery()
                    command.CommandText = l_sqlek(i)                End If            Next

            ' Execute the command
            Dim result As Integer = Convert.ToInt32(command.ExecuteScalar())

            l_transaction.Commit()

#Else
        Dim connection As SqlConnection
        Try

            connection = New SqlConnection(m_ConnectionString)
            connection.Open()
            ' Create and configure a command            Dim command As New SqlCommand(sqlQuery, connection)
            ' Execute the command
            Dim result As Integer = Convert.ToInt32(command.ExecuteScalar())

#End If

            ' Close and dispose
            command.Dispose()

            connection.Close()
            connection.Dispose()

            ' Set return value


        Catch ex As Exception
#If HANADB Then
            If command IsNot Nothing Then
                command.Dispose()
            End If
            If l_transaction IsNot Nothing Then
                l_transaction.Rollback()
            End If
#End If
            If connection IsNot Nothing Then
                connection.Close()
                connection.Dispose()
            End If

        End Try
    End Sub 'Execute


    Public Delegate Sub p_ExecutePointer(ByVal l_sql As String)

    Public Shared Sub ExecuteInditas()

    End Sub

    Public Shared Sub ExecuteScalarAutonomTransaction(ByVal sqlQuery As String, ByVal l_new_thread As Boolean)

        If l_new_thread = False Then
            ExecuteScalarAutonomTransaction(sqlQuery)
        End If

        'Dim l_pointer As New p_ExecutePointer(AddressOf ExecuteScalarAutonomTransactionNewThread)

        Dim p_newThread = New Threading.Thread(AddressOf ExecuteScalarAutonomTransactionNewThread)
        CType(p_newThread, Threading.Thread).Start(sqlQuery)

    End Sub 'ExecuteScalarAutonomTransaction


    Public Shared Function GetDataSet(ByVal sqlQuery As String, Optional ByVal p_message As String = "") As DataSet
        ' Create dataset
        Dim dataSet As New DataSet        Dim l_str As String        IFSZ_Globals.LastDML = sqlQuery        l_str = m_ConnectionString
        'm_ConnectionString = "Persist Security Info=False;" & _
        '                                        "database=SBODemo_HU;server=(local);User ID=sa;Password=proba;Connect Timeout=30"
        'l_str = "Initial Catalog=SBODemo_HU;Data Source=(local);Integrated Security=SSPI;"
        'l_str = "Persist Security Info=False;Integrated Security=SSPI;database=SBODemo_HU;server=local;Connect Timeout=30"

        ' Populate dataset
        'Dim connection As New SqlConnection("Data Source=(Paris);Initial Catalog=SBODemo_HU;Integrated Security=False")
#If HANADB Then
        Dim connection As OdbcConnection        If IFSZ_Globals.m_Connection Is Nothing Then            connection = New OdbcConnection(l_str)        ElseIf IFSZ_Globals.m_Connection.m_Connection.ConnectionString = "" Then        Else            connection = IFSZ_Globals.m_Connection.m_Connection            If connection.ConnectionString = "" Then                connection = New OdbcConnection(l_str)            End If        End If        If connection Is Nothing Then            connection = New OdbcConnection(l_str)        End If


















#Else
        Dim connection As SqlConnection        'If IFSZ_Globals.m_Connection Is Nothing Then        If IFSZ_Globals.m_Connection Is Nothing Then            connection = New SqlConnection(l_str)            'IFSZ_Globals.m_Connection.m_Connection = connection        ElseIf IFSZ_Globals.m_Connection.m_Connection.ConnectionString = "" Then            'IFSZ_Globals.m_Connection = New ConnectionProvider()            'connection = IFSZ_Globals.m_Connection.m_Connection        Else            connection = IFSZ_Globals.m_Connection.m_Connection            If connection.ConnectionString = "" Then                connection = New SqlConnection(l_str)            End If        End If        If connection Is Nothing Then            connection = New SqlConnection(l_str)        End If
#End If
        Try


#If HANADB Then            Dim command As OdbcCommand = connection.CreateCommand()            If Not IFSZ_Globals.m_Connection Is Nothing Then                command.Transaction = IFSZ_Globals.m_Connection.m_Transaction            End If            command.CommandText = "SET SCHEMA " + DataProvider.GetDBName()            If connection.State <> ConnectionState.Open Then                connection.Open()            End If            command.ExecuteNonQuery()

            If IFSZ_Globals.OpenLOG = True Then
                Try
                    command.CommandText = "INSERT INTO IFSZ_SQL_LOG VALUES (right('" + sqlQuery.Replace("'", "''") + "',4000),'" & IFSZ_Globals.SboUserName & "',current_timestamp,'" & IFSZ_Globals.AktivForm & "'); "
                    command.ExecuteNonQuery()

                Catch ex As Exception
                    command.CommandText = ""
                End Try
            End If            Dim l_sqlek() As String = DataProvider.SqlCommandSplit(sqlQuery)            Dim l_tempds As DataSet            For i As Integer = 0 To l_sqlek.Length - 1                If Not String.IsNullOrEmpty(l_sqlek(i).Trim()) Then                    command.CommandText = l_sqlek(i)                    Dim dataAdapter As New OdbcDataAdapter(command)                    If i = 0 Then                        dataAdapter.Fill(dataSet)                        dataSet.Tables(0).TableName = i.ToString()                    Else                        l_tempds = New DataSet                        dataAdapter.Fill(l_tempds)                        l_tempds.Tables(0).TableName = i.ToString()                        dataSet.Merge(l_tempds)                    End If                End If            Next















#Else
            Dim command As SqlCommand = connection.CreateCommand()            If Not IFSZ_Globals.m_Connection Is Nothing Then                command.Transaction = IFSZ_Globals.m_Connection.m_Transaction            End If            command.CommandText = sqlQuery            Dim dataAdapter As New SqlDataAdapter(command)            dataAdapter.Fill(dataSet)
#End If        Catch ex As Exception
#If NOMSGBOX Then
#Else
            MsgBox(ex.ToString, MsgBoxStyle.OkCancel, "Hiba!")


#End If        Finally            If IFSZ_Globals.m_Connection Is Nothing Then                connection.Dispose()            ElseIf IFSZ_Globals.m_Connection.m_Connection.ConnectionString = "" Then
                'connection.Close()
                Try                    connection.Dispose()                Catch ex As Exception                End Try            End If        End Try

        ' return dataset
        Return dataSet    End Function 'GetDataSet

    Public Shared Function GetDataTable(ByVal sqlQuery As String, Optional ByVal p_CommandTimeOut As Integer = -1) As DataTable
        ' Create dataset
        Dim dataSet As New DataSet        Dim l_str As String        IFSZ_Globals.LastDML = sqlQuery        l_str = m_ConnectionString
#If HANADB Then        Dim connection As OdbcConnection
        'If IFSZ_Globals.m_Connection Is Nothing Then
        If IFSZ_Globals.m_Connection Is Nothing Then            connection = New OdbcConnection(l_str)        ElseIf IFSZ_Globals.m_Connection.m_Connection.ConnectionString = "" Then            connection = New OdbcConnection(l_str)        Else            connection = IFSZ_Globals.m_Connection.m_Connection            If connection.ConnectionString = "" Then                connection = New OdbcConnection(l_str)            End If        End If



























#Else
        Dim connection As SqlConnection        'If IFSZ_Globals.m_Connection Is Nothing Then        If IFSZ_Globals.m_Connection Is Nothing Then            connection = New SqlConnection(l_str)        ElseIf IFSZ_Globals.m_Connection.m_Connection.ConnectionString = "" Then            connection = New SqlConnection(l_str)        Else            connection = IFSZ_Globals.m_Connection.m_Connection            If connection.ConnectionString = "" Then                connection = New SqlConnection(l_str)            End If        End If
#End If        Try


#If HANADB Then            Dim command As OdbcCommand = connection.CreateCommand()            If Not IFSZ_Globals.m_Connection Is Nothing Then                command.Transaction = IFSZ_Globals.m_Connection.m_Transaction            End If            command.CommandText = "SET SCHEMA " + DataProvider.GetDBName()            If connection.State <> ConnectionState.Open Then                connection.Open()            End If            command.ExecuteNonQuery()

            If IFSZ_Globals.OpenLOG = True Then
                Try
                    'System.Threading.Thread.Sleep(1000)
                    Dim l_ret As Integer
                    Dim l_sql_log As String

                    l_sql_log = "INSERT INTO IFSZ_SQL_LOG VALUES (right('" + sqlQuery.Replace("'", "''") + "',4000),'" & IFSZ_Globals.SboUserName & "',current_timestamp,'" & IFSZ_Globals.AktivForm & "'); "
                    'DataProvider.ExecuteScalarAutonomTransaction(l_sql_log, True)
                    command.CommandText = l_sql_log
                    command.ExecuteNonQuery()
                    'l_sql_log = "select 2+5 from dummy"
                    'System.Threading.Thread.Sleep(2000)
                    'System.Threading.Thread.Sleep(2000)
                Catch ex As Exception
                    command.CommandText = ""
                End Try
            End If

            command.CommandText = sqlQuery.TrimEnd(";".ToCharArray)            If p_CommandTimeOut > -1 Then                command.CommandTimeout = p_CommandTimeOut            End If            Dim dataAdapter As New OdbcDataAdapter(command)



















#Else
            Dim command As SqlCommand = connection.CreateCommand()            If Not IFSZ_Globals.m_Connection Is Nothing Then                command.Transaction = IFSZ_Globals.m_Connection.m_Transaction            End If            command.CommandText = sqlQuery            If p_CommandTimeOut > -1 Then                command.CommandTimeout = p_CommandTimeOut            End If            Dim dataAdapter As New SqlDataAdapter(command)
#End If            dataAdapter.Fill(dataSet)

        Catch ex As Exception            l_str = ""        Finally            If IFSZ_Globals.m_Connection Is Nothing Then                connection.Dispose()            ElseIf IFSZ_Globals.m_Connection.m_Connection.ConnectionString = "" Then
                'connection.Close()
                connection.Dispose()            End If        End Try

        ' return dataset
        If dataSet Is Nothing OrElse dataSet.Tables.Count = 0 Then
            Return Nothing
        Else
            Return dataSet.Tables(0)
        End If
    End Function 'GetDataSet

    Public Shared Function GetDataRecord(ByVal sqlQuery As String) As DataRowCollection        ' Create dataset        Dim dataSet As New DataSet        Dim l_str As String

        'l_str = "Persist Security Info=False;" & _
        '                                "database=SBODemo_HU;server=(local);User ID=sa;Password=proba;Connect Timeout=30"

        IFSZ_Globals.LastDML = sqlQuery        l_str = m_ConnectionString#If HANADB Then        Dim connection As OdbcConnection        If IFSZ_Globals.m_Connection Is Nothing Then            connection = New OdbcConnection(l_str)        ElseIf IFSZ_Globals.m_Connection.m_Connection.ConnectionString = "" Then            'IFSZ_Globals.m_Connection = New ConnectionProvider()            'connection = IFSZ_Globals.m_Connection.m_Connection            connection = New OdbcConnection(l_str)        Else            connection = IFSZ_Globals.m_Connection.m_Connection            If connection.ConnectionString = "" Then                connection = New OdbcConnection(l_str)            End If        End If#Else
        Dim connection As SqlConnection        If IFSZ_Globals.m_Connection Is Nothing Then            connection = New SqlConnection(l_str)        ElseIf IFSZ_Globals.m_Connection.m_Connection.ConnectionString = "" Then            'IFSZ_Globals.m_Connection = New ConnectionProvider()            'connection = IFSZ_Globals.m_Connection.m_Connection            connection = New SqlConnection(l_str)        Else            connection = IFSZ_Globals.m_Connection.m_Connection            If connection.ConnectionString = "" Then                connection = New SqlConnection(l_str)            End If        End If#End If        Try#If HANADB Then            Dim command As OdbcCommand = connection.CreateCommand()            If Not IFSZ_Globals.m_Connection Is Nothing Then                command.Transaction = IFSZ_Globals.m_Connection.m_Transaction            End If            command.CommandText = "SET SCHEMA " + DataProvider.GetDBName()            If connection.State <> ConnectionState.Open Then                connection.Open()            End If            command.ExecuteNonQuery()

            If IFSZ_Globals.OpenLOG = True And 1 = 2 Then
                Try
                    command.CommandText = "INSERT INTO IFSZ_SQL_LOG VALUES (right('" + sqlQuery.Replace("'", "''") + "',4000),'" & IFSZ_Globals.SboUserName & "',current_timestamp,'" & IFSZ_Globals.AktivForm & "'); "
                    command.ExecuteNonQuery()

                Catch ex As Exception
                    command.CommandText = ""
                End Try
            End If            command.CommandText = sqlQuery.TrimEnd(";".ToCharArray)            Dim dataAdapter As New OdbcDataAdapter(command)#Else
            Dim command As SqlCommand = connection.CreateCommand()            If Not IFSZ_Globals.m_Connection Is Nothing Then                command.Transaction = IFSZ_Globals.m_Connection.m_Transaction            End If            command.CommandText = sqlQuery            Dim dataAdapter As New SqlDataAdapter(command)#End If            dataAdapter.Fill(dataSet)        Catch ex As Exception#If NOMSGBOX Then#Else
            MsgBox(ex.ToString, MsgBoxStyle.OkCancel, "Hiba!")#End If        Finally            If IFSZ_Globals.m_Connection Is Nothing Then                connection.Dispose()            ElseIf IFSZ_Globals.m_Connection.m_Connection.ConnectionString = "" Then                'connection.Close()                connection.Dispose()            End If        End Try

        ' return dataset
        If dataSet Is Nothing OrElse dataSet.Tables.Count = 0 Then
            Return Nothing
        Else
            Return dataSet.Tables(0).Rows
        End If    End Function 'GetDataSet

    Public Shared Function GetDataRecord(ByVal sqlQuery As String, ByVal l_connectString As String) As DataRowCollection
        ' Create dataset
        Dim dataSet As New DataSet        Dim l_str As String

        'l_str = "Persist Security Info=False;" & _
        '                                "database=SBODemo_HU;server=(local);User ID=sa;Password=proba;Connect Timeout=30"
        IFSZ_Globals.LastDML = sqlQuery        l_str = l_connectString


#If HANADB Then        Dim connection As OdbcConnection        connection = New OdbcConnection(l_str)        If connection.ConnectionString = "" Then            connection = New OdbcConnection(l_str)        End If















#Else
        Dim connection As SqlConnection        connection = New SqlConnection(l_str)        If connection.ConnectionString = "" Then            connection = New SqlConnection(l_str)        End If
#End If
        Try


#If HANADB Then            Dim command As OdbcCommand = connection.CreateCommand()            If Not IFSZ_Globals.m_Connection Is Nothing Then                command.Transaction = IFSZ_Globals.m_Connection.m_Transaction            End If            command.CommandText = "SET SCHEMA " + DataProvider.GetDBName(l_connectString)            If connection.State <> ConnectionState.Open Then                connection.Open()            End If            command.ExecuteNonQuery()

            If IFSZ_Globals.OpenLOG = True Then
                Try
                    command.CommandText = "INSERT INTO IFSZ_SQL_LOG VALUES (right('" + sqlQuery.Replace("'", "''") + "',4000),'" & IFSZ_Globals.SboUserName & "',current_timestamp,'" & IFSZ_Globals.AktivForm & "'); "
                    command.ExecuteNonQuery()

                Catch ex As Exception
                    command.CommandText = ""
                End Try
            End If            command.CommandText = sqlQuery.TrimEnd(";".ToCharArray)            Dim dataAdapter As New OdbcDataAdapter(command)













#Else
            Dim command As SqlCommand = connection.CreateCommand()            If Not IFSZ_Globals.m_Connection Is Nothing Then                command.Transaction = IFSZ_Globals.m_Connection.m_Transaction            End If            command.CommandText = sqlQuery            Dim dataAdapter As New SqlDataAdapter(command)
#End If            dataAdapter.Fill(dataSet)        Catch ex As Exception
#If NOMSGBOX Then
#Else
            MsgBox(ex.ToString, MsgBoxStyle.OkCancel, "Hiba!")


#End If        Finally            If IFSZ_Globals.m_Connection Is Nothing Then                connection.Dispose()            End If        End Try

        ' return dataset
        If dataSet Is Nothing OrElse dataSet.Tables.Count = 0 Then
            Return Nothing
        Else
            Return dataSet.Tables(0).Rows
        End If    End Function 'GetDataSet


    Public Shared Function ExecuteScalarString(ByVal sqlQuery As String) As String        ' Create and open a connection#If HANADB Then        Dim connection As OdbcConnection        If IFSZ_Globals.m_Connection Is Nothing Then            connection = New OdbcConnection(m_ConnectionString)            connection.Open()        ElseIf IFSZ_Globals.m_Connection.m_Connection.ConnectionString = "" Then            connection = New OdbcConnection(m_ConnectionString)            connection.Open()        Else            connection = IFSZ_Globals.m_Connection.m_Connection        End If        ' Create and configure a command        Dim command As OdbcCommand = connection.CreateCommand()        If Not IFSZ_Globals.m_Connection Is Nothing Then            command.Transaction = IFSZ_Globals.m_Connection.m_Transaction        End If        command.CommandText = "SET SCHEMA " + DataProvider.GetDBName()        command.ExecuteNonQuery()

        If IFSZ_Globals.OpenLOG = True Then
            Try
                command.CommandText = "INSERT INTO IFSZ_SQL_LOG VALUES (right('" + sqlQuery.Replace("'", "''") + "',4000),'" & IFSZ_Globals.SboUserName & "',current_timestamp,'" & IFSZ_Globals.AktivForm & "'); "
                command.ExecuteNonQuery()

            Catch ex As Exception
                command.CommandText = ""
            End Try
        End If



        command.CommandText = sqlQuery.TrimEnd(";".ToCharArray)#Else
        Dim connection As SqlConnection        If IFSZ_Globals.m_Connection Is Nothing Then            connection = New SqlConnection(m_ConnectionString)            connection.Open()        ElseIf IFSZ_Globals.m_Connection.m_Connection.ConnectionString = "" Then            'IFSZ_Globals.m_Connection = New ConnectionProvider()            'connection = IFSZ_Globals.m_Connection.m_Connection            connection = New SqlConnection(m_ConnectionString)            connection.Open()        Else            connection = IFSZ_Globals.m_Connection.m_Connection        End If        ' Create and configure a command        Dim command As New SqlCommand(sqlQuery, connection)        If Not IFSZ_Globals.m_Connection Is Nothing Then            Command.Transaction = IFSZ_Globals.m_Connection.m_Transaction        End If#End If        ' Execute the command        Dim result As Object = command.ExecuteScalar()        Dim l_res As String        If result Is Nothing Then            l_res = Nothing        Else            If result.GetType.Name = "String" Then                l_res = result            Else                l_res = Nothing            End If        End If        ' Close and dispose        command.Dispose()        If IFSZ_Globals.m_Connection Is Nothing Then            connection.Close()            connection.Dispose()        End If        ' Set return value        Return l_res    End Function 'ExecuteScalar    Public Shared Function GetSysDate() As DateTime#If HANADB Then        Return GetDataRecord("SELECT CURRENT_TIMESTAMP FROM DUMMY").Item(0).Item(0)#Else
        Return GetDataRecord("select getdate()").Item(0).Item(0)#End If    End Function    Public Shared Function GetSysDate(ByVal p_day As Integer) As DateTime        Dim l_sql As String        'l_sql = "select getdate() + " + p_day#If HANADB Then        Return GetDataRecord("SELECT ADD_DAYS( CURRENT_DATE, " + IFSZ_Globals.SqlConstantPrepare(p_day) + ") FROM DUMMY").Item(0).Item(0)#Else
        Return GetDataRecord("select getdate()+ " & p_day.ToString).Item(0).Item(0)#End If    End Function    Public Shared Function GetLastDate() As DateTime#If HANADB Then        Return New DateTime(DataProvider.GetSysDate.Year, 12, 31)#Else
        Return GetDataRecord("select year(getdate())+1").Item(0).Item(0).ToString + ".12.31"#End If    End Function    Public Shared Function GetMDIMenuModule(ByVal p_menuID As Integer) As String        Dim l_datarec As DataRowCollection = DataProvider.GetDataRecord(QueryResource.GetQuery("Base_IFSZ_AddOn_SBO", "sel_module_from_mdimenu_by_id", p_menuID.ToString))        If l_datarec.Count = 0 Then            Return Nothing        End If        If l_datarec.Item(0).Item(0).GetType().Name = "DBNull" Then            Return Nothing        End If        Return l_datarec.Item(0).Item(0)    End Function    'Kezdetleges verzi�, m�g nincs haszn�lva, j� lenne, ha nem minden param�ter karakteres lenne    Public Shared Sub ExecuteStoredProc( _        ByVal p_sp_name As String _      , Optional ByVal p_parname1 As String = Nothing _      , Optional ByVal p_parval1 As String = Nothing _      , Optional ByVal p_parname2 As String = Nothing _      , Optional ByVal p_parval2 As String = Nothing _      , Optional ByVal p_parname3 As String = Nothing _      , Optional ByVal p_parval3 As String = Nothing _      , Optional ByVal p_parname4 As String = Nothing _      , Optional ByVal p_parval4 As String = Nothing _      , Optional ByVal p_parname5 As String = Nothing _      , Optional ByVal p_parval5 As String = Nothing _      , Optional ByVal p_parname6 As String = Nothing _      , Optional ByVal p_parval6 As String = Nothing _      , Optional ByVal p_parname7 As String = Nothing _      , Optional ByVal p_parval7 As String = Nothing _      , Optional ByVal p_parname8 As String = Nothing _      , Optional ByVal p_parval8 As String = Nothing _      , Optional ByVal p_parname9 As String = Nothing _      , Optional ByVal p_parval9 As String = Nothing _    )        ' Create dataset        Dim dataSet As New DataSet        Dim l_str As String        l_str = m_ConnectionString#If HANADB Then        Dim connection As OdbcConnection        If IFSZ_Globals.m_Connection Is Nothing Then            connection = New OdbcConnection(l_str)        ElseIf IFSZ_Globals.m_Connection.m_Connection.ConnectionString = "" Then            connection = New OdbcConnection(l_str)        Else            connection = IFSZ_Globals.m_Connection.m_Connection            If connection.ConnectionString = "" Then                connection = New OdbcConnection(l_str)            End If        End If#Else
        Dim connection As SqlConnection        If IFSZ_Globals.m_Connection Is Nothing Then            connection = New SqlConnection(l_str)        ElseIf IFSZ_Globals.m_Connection.m_Connection.ConnectionString = "" Then            connection = New SqlConnection(l_str)        Else            connection = IFSZ_Globals.m_Connection.m_Connection            If connection.ConnectionString = "" Then                connection = New SqlConnection(l_str)            End If        End If#End If        Try#If HANADB Then            Dim command As OdbcCommand = connection.CreateCommand()            command.CommandText = "SET SCHEMA " + DataProvider.GetDBName()            If connection.State <> ConnectionState.Open Then                connection.Open()            End If            command.ExecuteNonQuery()            command.CommandText = p_sp_name#Else
            Dim command As SqlCommand = New SqlCommand(p_sp_name, connection)#End If            command.CommandType = CommandType.StoredProcedure            If Not String.IsNullOrEmpty(p_parname1) Then                command.Parameters.Add("@" + p_parname1, SqlDbType.VarChar, 255).Value = p_parval1            End If            If Not String.IsNullOrEmpty(p_parname2) Then                command.Parameters.Add("@" + p_parname2, SqlDbType.VarChar, 255).Value = p_parval2            End If            If Not String.IsNullOrEmpty(p_parname3) Then                command.Parameters.Add("@" + p_parname3, SqlDbType.VarChar, 255).Value = p_parval3            End If            If Not String.IsNullOrEmpty(p_parname4) Then                command.Parameters.Add("@" + p_parname4, SqlDbType.VarChar, 255).Value = p_parval4            End If            If Not String.IsNullOrEmpty(p_parname5) Then                command.Parameters.Add("@" + p_parname5, SqlDbType.VarChar, 255).Value = p_parval5            End If            If Not String.IsNullOrEmpty(p_parname6) Then                command.Parameters.Add("@" + p_parname6, SqlDbType.VarChar, 255).Value = p_parval6            End If            If Not String.IsNullOrEmpty(p_parname7) Then                command.Parameters.Add("@" + p_parname7, SqlDbType.VarChar, 255).Value = p_parval7            End If            If Not String.IsNullOrEmpty(p_parname8) Then                command.Parameters.Add("@" + p_parname8, SqlDbType.VarChar, 255).Value = p_parval8            End If            If Not String.IsNullOrEmpty(p_parname9) Then                command.Parameters.Add("@" + p_parname9, SqlDbType.VarChar, 255).Value = p_parval9            End If            ' Execute the command            Dim numRowsAffected As Integer = command.ExecuteNonQuery            command.Dispose()            If IFSZ_Globals.m_Connection Is Nothing Then                connection.Close()                connection.Dispose()            End If        Catch ex As Exception        End Try    End Sub    Public Shared Function ExecuteScalarDouble(ByVal sqlQuery As String) As Double        ' Create and open a connection#If HANADB Then        Dim connection As OdbcConnection        If IFSZ_Globals.m_Connection Is Nothing Then            connection = New OdbcConnection(m_ConnectionString)            connection.Open()        Else            connection = IFSZ_Globals.m_Connection.m_Connection        End If        ' Create and configure a command        Dim command As OdbcCommand = connection.CreateCommand()        If Not IFSZ_Globals.m_Connection Is Nothing Then            command.Transaction = IFSZ_Globals.m_Connection.m_Transaction        End If        command.CommandText = "SET SCHEMA " + DataProvider.GetDBName()        command.ExecuteNonQuery()        command.CommandText = sqlQuery.TrimEnd(";".ToCharArray)#Else
        Dim connection As SqlConnection        If IFSZ_Globals.m_Connection Is Nothing Then            connection = New SqlConnection(m_ConnectionString)            connection.Open()        Else            connection = IFSZ_Globals.m_Connection.m_Connection        End If        ' Create and configure a command        Dim command As New SqlCommand(sqlQuery, connection)        If Not IFSZ_Globals.m_Connection Is Nothing Then            command.Transaction = IFSZ_Globals.m_Connection.m_Transaction        End If#End If        ' Execute the command        Dim result As Object = command.ExecuteScalar()        Dim l_res As String        If result Is Nothing Then            l_res = 0        Else            If result.GetType.Name = "String" Or result.GetType.Name = "DBNull" Or result.GetType.Name = "Date" Or result.GetType.Name = "DateTime" Then                l_res = 0            Else                l_res = result            End If        End If        ' Close and dispose        command.Dispose()        If IFSZ_Globals.m_Connection Is Nothing Then            connection.Close()            connection.Dispose()        End If        ' Set return value        Return l_res    End Function 'ExecuteScalarDouble    Public Shared Function ExecuteScalarDateTime(ByVal sqlQuery As String) As DateTime        ' Create and open a connection#If HANADB Then        Dim connection As OdbcConnection        If IFSZ_Globals.m_Connection Is Nothing Then            connection = New OdbcConnection(m_ConnectionString)            connection.Open()        Else            connection = IFSZ_Globals.m_Connection.m_Connection        End If        ' Create and configure a command        Dim command As OdbcCommand = connection.CreateCommand()        If Not IFSZ_Globals.m_Connection Is Nothing Then            command.Transaction = IFSZ_Globals.m_Connection.m_Transaction        End If        command.CommandText = "SET SCHEMA " + DataProvider.GetDBName()        command.ExecuteNonQuery()        command.CommandText = sqlQuery.TrimEnd(";".ToCharArray)#Else
        Dim connection As SqlConnection        If IFSZ_Globals.m_Connection Is Nothing Then            connection = New SqlConnection(m_ConnectionString)            connection.Open()        Else            connection = IFSZ_Globals.m_Connection.m_Connection        End If        ' Create and configure a command        Dim command As New SqlCommand(sqlQuery, connection)        If Not IFSZ_Globals.m_Connection Is Nothing Then            command.Transaction = IFSZ_Globals.m_Connection.m_Transaction        End If#End If        ' Execute the command        Dim result As Object = command.ExecuteScalar()        Dim l_res As String        If result Is Nothing Then            l_res = IFSZ_Globals.NullDate()        Else            If result.GetType.Name = "Date" Or result.GetType.Name = "DateTime" Then                l_res = result            Else                l_res = IFSZ_Globals.NullDate()            End If        End If        ' Close and dispose        command.Dispose()        If IFSZ_Globals.m_Connection Is Nothing Then            connection.Close()            connection.Dispose()        End If        ' Set return value        Return l_res    End Function 'ExecuteScalarDateTime    Public Shared Function EExecuteNonQueryWithXml( _      ByVal sqlQuery As String, Optional ByVal p_CommandTimeOut As Integer = -1 _      , Optional ByVal p_xmlparname As String = Nothing _      , Optional ByVal p_xmlparval As String = Nothing _    ) As Integer#If HANADB Then        Return -1
#Else
        ' Create and open a connection        Dim connection As SqlConnection        If IFSZ_Globals.m_Connection Is Nothing Then            connection = New SqlConnection(m_ConnectionString)            connection.Open()        ElseIf IFSZ_Globals.m_Connection.m_Connection.ConnectionString = "" Then            connection = New SqlConnection(m_ConnectionString)            connection.Open()        Else            connection = IFSZ_Globals.m_Connection.m_Connection        End If        ' Create and configure a command        Dim command As New SqlCommand(sqlQuery, connection)        Try            If Not IFSZ_Globals.m_Connection Is Nothing Then                command.Transaction = IFSZ_Globals.m_Connection.m_Transaction            End If            If p_CommandTimeOut > -1 Then                command.CommandTimeout = p_CommandTimeOut            End If            If Not String.IsNullOrEmpty(p_xmlparname) Then                command.Parameters.Add("@" + p_xmlparname, SqlDbType.Xml).Value = New System.Xml.XmlTextReader(p_xmlparval, System.Xml.XmlNodeType.Document, Nothing)            End If            Dim numRowsAffected As Integer = command.ExecuteNonQuery            Return numRowsAffected        Catch            Throw        Finally            command.Dispose()            If IFSZ_Globals.m_Connection Is Nothing Then                connection.Close()                connection.Dispose()            ElseIf IFSZ_Globals.m_Connection.m_Connection.ConnectionString = "" Then                connection.Close()                connection.Dispose()            End If        End Try#End If    End Function    ''' <summary>    ''' Funkci�n�v visszakeres�se MDI-s alkalmaz�sok eset�n    ''' </summary>    ''' <param name="p_menuID"></param>    ''' <returns></returns>    ''' <remarks></remarks>    Public Shared Function GetMDIFcoName(ByVal p_menuID As Integer) As String        Dim l_datarec As DataRowCollection = DataProvider.GetDataRecord(QueryResource.GetQuery("Base_IFSZ_AddOn_SBO", "sel_fco_name_from_mdimenu_by_id", p_menuID.ToString))        If l_datarec.Count = 0 Then            Return Nothing        End If        If l_datarec.Item(0).Item(0).GetType().Name = "DBNull" Then            Return Nothing        End If        Return l_datarec.Item(0).Item(0)    End Function#Region "Exception-t kiv�lt� elj�r�sok"    '-------------------------------------------------------------------    'Exception-t kiv�lt� elj�r�sok    '-------------------------------------------------------------------    Public Shared Function EExecuteNonQuery(ByVal sqlQuery As String, Optional ByVal p_CommandTimeOut As Integer = -1) As Integer        ' Create and open a connection#If HANADB Then        Dim connection As OdbcConnection        If IFSZ_Globals.m_Connection Is Nothing Then            connection = New OdbcConnection(m_ConnectionString)            connection.Open()        ElseIf IFSZ_Globals.m_Connection.m_Connection.ConnectionString = "" Then            connection = New OdbcConnection(m_ConnectionString)            connection.Open()        Else            connection = IFSZ_Globals.m_Connection.m_Connection        End If        ' Create and configure a command        Dim command As OdbcCommand = connection.CreateCommand()        If Not IFSZ_Globals.m_Connection Is Nothing Then            command.Transaction = IFSZ_Globals.m_Connection.m_Transaction        End If        command.CommandText = "SET SCHEMA " + DataProvider.GetDBName()        command.ExecuteNonQuery()

        If IFSZ_Globals.OpenLOG = True Then
            Try
                command.CommandText = "INSERT INTO IFSZ_SQL_LOG VALUES (right('" + sqlQuery.Replace("'", "''") + "',4000),'" & IFSZ_Globals.SboUserName & "',current_timestamp,'" & IFSZ_Globals.AktivForm & "'); "
                command.ExecuteNonQuery()

            Catch ex As Exception
                command.CommandText = ""
            End Try
        End If        command.CommandText = sqlQuery.TrimEnd(";".ToCharArray)#Else
        Dim connection As SqlConnection        If IFSZ_Globals.m_Connection Is Nothing Then            connection = New SqlConnection(m_ConnectionString)            connection.Open()        ElseIf IFSZ_Globals.m_Connection.m_Connection.ConnectionString = "" Then            connection = New SqlConnection(m_ConnectionString)            connection.Open()        Else            connection = IFSZ_Globals.m_Connection.m_Connection        End If        ' Create and configure a command        Dim command As New SqlCommand(sqlQuery, connection)            If Not IFSZ_Globals.m_Connection Is Nothing Then                command.Transaction = IFSZ_Globals.m_Connection.m_Transaction            End If#End If        Try            If p_CommandTimeOut > -1 Then                command.CommandTimeout = p_CommandTimeOut            End If            Dim numRowsAffected As Integer = command.ExecuteNonQuery            Return numRowsAffected        Catch            Throw        Finally            command.Dispose()            If IFSZ_Globals.m_Connection Is Nothing Then                connection.Close()                connection.Dispose()            ElseIf IFSZ_Globals.m_Connection.m_Connection.ConnectionString = "" Then                connection.Close()                connection.Dispose()            End If        End Try    End Function 'EExecuteNonQuery    Public Shared Function EGetDataSet(ByVal sqlQuery As String, Optional ByVal p_CommandTimeOut As Integer = -1) As DataSet        ' Create dataset        Dim dataSet As New DataSet        Dim l_str As String        l_str = m_ConnectionString#If HANADB Then        Dim connection As OdbcConnection        If IFSZ_Globals.m_Connection Is Nothing Then            connection = New OdbcConnection(l_str)        ElseIf IFSZ_Globals.m_Connection.m_Connection.ConnectionString = "" Then            connection = New OdbcConnection(l_str)        Else            connection = IFSZ_Globals.m_Connection.m_Connection            If connection.ConnectionString = "" Then                connection = New OdbcConnection(l_str)            End If        End If        If connection Is Nothing Then            connection = New OdbcConnection(l_str)        End If        Dim command As OdbcCommand = connection.CreateCommand()        If Not IFSZ_Globals.m_Connection Is Nothing Then            command.Transaction = IFSZ_Globals.m_Connection.m_Transaction        End If        command.CommandText = "SET SCHEMA " + DataProvider.GetDBName()        If connection.State <> ConnectionState.Open Then            connection.Open()        End If        command.ExecuteNonQuery()

        If IFSZ_Globals.OpenLOG = True Then
            Try
                command.CommandText = "INSERT INTO IFSZ_SQL_LOG VALUES (right('" + sqlQuery.Replace("'", "''") + "',4000),'" & IFSZ_Globals.SboUserName & "',current_timestamp,'" & IFSZ_Globals.AktivForm & "'); "
                command.ExecuteNonQuery()

            Catch ex As Exception
                command.CommandText = ""
            End Try
        End If









#Else
        Dim connection As SqlConnection        If IFSZ_Globals.m_Connection Is Nothing Then            connection = New SqlConnection(l_str)        ElseIf IFSZ_Globals.m_Connection.m_Connection.ConnectionString = "" Then            connection = New SqlConnection(l_str)        Else            connection = IFSZ_Globals.m_Connection.m_Connection            If connection.ConnectionString = "" Then                connection = New SqlConnection(l_str)            End If        End If        If connection Is Nothing Then            connection = New SqlConnection(l_str)        End If        Dim command As SqlCommand = connection.CreateCommand()            If Not IFSZ_Globals.m_Connection Is Nothing Then                command.Transaction = IFSZ_Globals.m_Connection.m_Transaction            End If
#End If        Try





#If HANADB Then            Dim l_sqlek() As String = DataProvider.SqlCommandSplit(sqlQuery)
            Dim l_tempds As DataSet
            For i As Integer = 0 To l_sqlek.Length - 1
                If Not String.IsNullOrEmpty(l_sqlek(i).Trim()) Then
                    command.CommandText = l_sqlek(i)
                    If p_CommandTimeOut > -1 Then
                        command.CommandTimeout = p_CommandTimeOut
                    End If                    Dim dataAdapter As New OdbcDataAdapter(command)
                    If i = 0 Then
                        dataAdapter.Fill(dataSet)
                        dataSet.Tables(0).TableName = i.ToString()
                    Else
                        l_tempds = New DataSet
                        dataAdapter.Fill(l_tempds)
                        l_tempds.Tables(0).TableName = i.ToString()
                        dataSet.Merge(l_tempds)
                    End If
                End If
            Next



#Else
            command.CommandText = sqlQuery            If p_CommandTimeOut > -1 Then                command.CommandTimeout = p_CommandTimeOut            End If            Dim dataAdapter As New SqlDataAdapter(command)            dataAdapter.Fill(dataSet)
#End If        Catch            Throw        Finally            command.Dispose()            If IFSZ_Globals.m_Connection Is Nothing Then                connection.Dispose()            ElseIf IFSZ_Globals.m_Connection.m_Connection.ConnectionString = "" Then                Try                    connection.Dispose()                Catch                End Try            End If        End Try        ' return dataset        Return dataSet    End Function 'EGetDataSet    Public Shared Function EGetDataTable(ByVal sqlQuery As String, Optional ByVal p_CommandTimeOut As Integer = -1) As DataTable        Dim dataSet As New DataSet        dataSet = DataProvider.EGetDataSet(sqlQuery, p_CommandTimeOut)        Return dataSet.Tables(0)    End Function 'EGetDataTable    Public Shared Function EGetDataRecord(ByVal sqlQuery As String, Optional ByVal p_CommandTimeOut As Integer = -1) As DataRowCollection        Dim dataSet As New DataSet        dataSet = DataProvider.EGetDataSet(sqlQuery, p_CommandTimeOut)        Return dataSet.Tables(0).Rows    End Function 'EGetDataRecord#End Region    ''' <summary>
    ''' Ha egy sql-ben t�bb utas�t�s is van ;-kkel elv�lasztva, azokat sz�tdob�lja egy t�mbbe
    ''' </summary>
    ''' <param name="p_sql"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>    Public Shared Function SqlCommandSplit(ByVal p_sql As String) As String()        Dim l_res() As String

        If String.IsNullOrEmpty(p_sql) Then
            Return Nothing
        End If

        l_res = p_sql.Split(";".ToCharArray)

        'Az l_res-ben megvan sz�tszabdalva a ;-k ment�n az utas�t�s
        'Ha egy ilyen van, akkor azt visszaadjuk
        If l_res.Length = 1 Then
            Return l_res
        End If

        'Ha t�bb, akkor m�g el�fordulhat, hogy szerencs�tlen m�don egy ; egy sztring belsej�ben van. Ez�rt ezek nem val�di utas�t�s elv�laszt�k, vissza kell csin�lni �ket.
        'A karaktereken v�gigmegyek egyes�vel, �s figyelem az aposztr�fokat. A sz�veg v�g�re tudni fogom, hogy egy sztring meg lett-e nyitva aposztr�ffal.
        'De el�sz�r csak megn�zem, tartalmaz-e aposztr�fot, ha nem, akkor feleslegesen ne p�rgess�k v�gig a karaktereket.
        Dim l_akt_string, l_vizs_string As Integer
        Dim l_sztringben As Boolean = False
        l_akt_string = -1
        For l_vizs_string = 0 To l_res.Length - 1
            If l_sztringben Then
                l_res(l_akt_string) += ";" + l_res(l_vizs_string)
                l_res(l_vizs_string) = ""
            End If
            If Not l_sztringben Then
                l_akt_string += 1
            End If
            If l_res(l_vizs_string).Contains("'") Then
                For i As Integer = 0 To l_res(l_vizs_string).Length - 1
                    If l_res(l_vizs_string).Substring(i, 1) = "'" Then
                        If Not l_sztringben Then
                            l_sztringben = True
                        Else
                            l_sztringben = False
                        End If
                    End If
                Next
            End If
        Next

        ReDim Preserve l_res(l_akt_string)

        Return l_res

    End FunctionEnd Class