Imports System
Imports System.Collections
Imports System.Text
Imports System.Data
#If HANADB Then
Imports System.Data.Odbc#Else
Imports System.Data.SqlClient#End If
'Imports ObjectDataBinding.Properties

Public Class ConnectionProvider

#If HANADB Then
    Public m_Connection As OdbcConnection
    'Public m_Connection_sql As SqlConnection
    Public m_Transaction As OdbcTransaction
    'Public m_Transaction_sql As SqlTransaction
    'Public m_Transaction_sql As SqlTransaction
    'Public m_Connection_sql As SqlConnection
    Public Shared m_sdkuser As String = "IFSZSDK"
    'Public Shared m_sdkuser As String = "IFSZ"
    Public Shared m_sdkpwd As String = "CVBdfgERT456"
    'Public Shared m_sdkpwd As String = "fghUIO987"

    Sub New()
        m_Connection = New OdbcConnection(DataProvider.m_ConnectionString)
        m_Connection.Open()
        m_Transaction = m_Connection.BeginTransaction()
    End Sub

    Sub New(ByVal p_beginTransaction As Boolean)
        m_Connection = New OdbcConnection(DataProvider.m_ConnectionString)
        m_Connection.Open()
        If p_beginTransaction Then
            m_Transaction = m_Connection.BeginTransaction()
        End If
    End Sub

#Else
    Public m_Connection As SqlConnection
    Public m_Transaction As SqlTransaction
    Public Shared m_sdkuser As String = "sdkuser"
    Public Shared m_sdkpwd As String = "ifszsdk"

    Sub New()
        m_Connection = New SqlConnection(DataProvider.m_ConnectionString)
        m_Connection.Open()
        m_Transaction = m_Connection.BeginTransaction()
    End Sub

    Sub New(ByVal p_beginTransaction As Boolean)
        m_Connection = New SqlConnection(DataProvider.m_ConnectionString)
        m_Connection.Open()
        If p_beginTransaction Then
            m_Transaction = m_Connection.BeginTransaction()
        End If
    End Sub

#End If

    Public Sub Commit(Optional ByVal p_beginTransaction As Boolean = True)
        m_Transaction.Commit()
        If p_beginTransaction Then
            m_Connection.Close()
            m_Connection.Dispose()
        End If
    End Sub

    Sub New(ByVal p_beginTransaction As Boolean, ByVal l_connectionstring As String)
#If HANADB Then
        m_Connection = New OdbcConnection(l_connectionstring)
#Else
        m_Connection = New SqlConnection(l_connectionstring)
#End If
        m_Connection.Open()
        If p_beginTransaction Then
            m_Transaction = m_Connection.BeginTransaction()
        End If
    End Sub

    Public Sub Colse()
        m_Connection.Close()
        m_Connection.Dispose()
    End Sub

    Public Sub BeginTransaction()
        m_Transaction = m_Connection.BeginTransaction()
    End Sub
    Public Sub Rollback(Optional ByVal p_beginTransaction As Boolean = True)
        m_Transaction.Rollback()
        If IFSZ_Globals.m_Hiba_Naploz_e And (Not IFSZ_Globals.m_Utolso_Hiba Is Nothing) Then
            Dim l_message As String
            m_Transaction = m_Connection.BeginTransaction()
            DataProvider.ExecuteNonQuery(IFSZ_Globals.m_Utolso_Hiba, l_message)
            IFSZ_Globals.m_Utolso_Hiba = Nothing
            m_Transaction.Commit()
        End If
        If p_beginTransaction Then
            m_Connection.Close()
            m_Connection.Dispose()
        End If
    End Sub

    Public Shared Function CreateConnectionString(ByVal p_servername As String, ByVal p_companydb As String) As String



#If HANADB Then        Dim l_regex As New System.Text.RegularExpressions.Regex("^[^\@]*\@([^\:]*)\:30013$")
        If l_regex.IsMatch(p_servername) Then
            p_servername = l_regex.Replace(p_servername, "$1:30015")
        End If
        Dim strConnectionString As String        If IntPtr.Size = 8 Then
            'Do 64-bit stuff
            strConnectionString = String.Concat(strConnectionString, "Driver={HDBODBC};")
        Else
            'Do 32-bit
            strConnectionString = String.Concat(strConnectionString, "Driver={HDBODBC32};")
        End If
        strConnectionString = String.Concat(strConnectionString, "ServerNode=", p_servername, ";")
        strConnectionString = String.Concat(strConnectionString, "database=", p_companydb, ";")
        strConnectionString = String.Concat(strConnectionString, "UID=" + ConnectionProvider.m_sdkuser + ";")
        strConnectionString = String.Concat(strConnectionString, "PWD=" + ConnectionProvider.m_sdkpwd + ";")
        Return strConnectionString
#Else
        Return "Persist Security Info=False;Integrated Security=False;" & _
                                        "database=" & p_companydb & ";server=" & p_servername & ";User ID = " + ConnectionProvider.m_sdkuser + ";Password=" + ConnectionProvider.m_sdkpwd + ";Connect Timeout=30"
#End If
    End FunctionEnd Class