﻿Imports System.Net
Imports System.Net.Sockets
Imports System.Text
Imports System.Security.Cryptography.X509CertificatesImports System.Net.Mail
Imports System.Net.Security

Public Class SmtpHelper

    Public Shared m_mailto_for_test As String = ""

    Public Shared Function TestConnection(ByVal smtpServerAddress As String, ByVal port As Integer) As Boolean
        Dim hostEntry As IPHostEntry = Dns.GetHostEntry(smtpServerAddress)
        Dim endPoint As IPEndPoint = New IPEndPoint(hostEntry.AddressList(0), port)

        Using tcpSocket As Socket = New Socket(endPoint.AddressFamily, SocketType.Stream, ProtocolType.Tcp)
            tcpSocket.Connect(endPoint)

            If Not CheckResponse(tcpSocket, 220) Then
                Return False
            End If

            SendData(tcpSocket, String.Format("HELO {0}" & vbCrLf, Dns.GetHostName()))

            If Not CheckResponse(tcpSocket, 250) Then
                Return False
            End If

            Return True
        End Using
    End Function

    Private Shared Sub SendData(ByVal socket As Socket, ByVal data As String)
        Dim dataArray As Byte() = Encoding.ASCII.GetBytes(data)
        socket.Send(dataArray, 0, dataArray.Length, SocketFlags.None)
    End Sub

    Private Shared Function CheckResponse(ByVal socket As Socket, ByVal expectedCode As Integer) As Boolean
        While socket.Available = 0
            System.Threading.Thread.Sleep(100)
        End While

        Dim responseArray As Byte() = New Byte(1023) {}
        socket.Receive(responseArray, 0, socket.Available, SocketFlags.None)
        Dim responseData As String = Encoding.ASCII.GetString(responseArray)
        Dim responseCode As Integer = Convert.ToInt32(responseData.Substring(0, 3))

        If responseCode = expectedCode Then
            Return True
        End If

        Return False
    End Function

    Public Shared Function ValidateServerCertificate(ByVal sender As Object, ByVal certificate As System.Security.Cryptography.X509Certificates.X509Certificate, ByVal chain As System.Security.Cryptography.X509Certificates.X509Chain, ByVal sslPolicyErrors As System.Net.Security.SslPolicyErrors) As Boolean        Return True    End Function    Public Shared Sub SendMail(
        ByVal l_UserName As String _
      , ByVal l_Password As String _
      , ByVal p_host As String _
      , ByVal p_port As Integer _
      , ByVal p_enablessl As Boolean _
      , ByVal p_frommail As String _
      , ByVal p_to As String _
      , ByVal p_subject As String _
      , ByVal p_body As String _
      , Optional ByVal p_isbodyhtml As Boolean = False _
      , Optional ByVal p_fileattachment As String() = Nothing _
      , Optional ByVal p_attach_filename As String() = Nothing _
      , Optional ByVal l_MailCC As String = Nothing _
      , Optional ByVal l_MailBCC As String = Nothing _
      , Optional ByVal p_MailToList As MailAddressCollection = Nothing _
      , Optional ByVal p_MailCCList As MailAddressCollection = Nothing _
      , Optional ByVal p_MailBccList As MailAddressCollection = Nothing _
      , Optional ByVal p_from_displayname As String = Nothing _
      , Optional ByVal p_req_delivery_receipt As Boolean = False _
      , Optional ByVal p_req_read_receipt As Boolean = False
    )        Dim l_subject, l_body, l_from As String        Dim l_to As String        Dim melleklet As Attachment
        l_from = p_frommail        If String.IsNullOrEmpty(l_from) Then            Throw New Exception("Nincs megadva a levélküldő")        End If

        l_subject = p_subject        If Not String.IsNullOrEmpty(SmtpHelper.m_mailto_for_test) Then            If p_MailToList Is Nothing Then
                l_subject = "[" + p_to + "] " + l_subject
            Else
                Dim l_cimzettek As String = ""
                For Each l_mailto As MailAddress In p_MailToList
                    If l_cimzettek = "" Then
                        l_cimzettek = l_mailto.Address
                    Else
                        l_cimzettek += ";" + l_mailto.Address
                    End If
                Next
                l_subject = "[" + l_cimzettek + "] " + l_subject
            End If            l_to = SmtpHelper.m_mailto_for_test
        Else
            l_to = p_to
        End If
        l_body = p_body        If String.IsNullOrEmpty(l_subject) OrElse String.IsNullOrEmpty(l_body) Then            Throw New Exception("Meg kell adni a tárgyat és a levéltörzset is")        End If        Dim oMsg As New MailMessage        Dim myCredentials As New System.Net.NetworkCredential        myCredentials.UserName = l_UserName        myCredentials.Password = l_Password        oMsg.IsBodyHtml = p_isbodyhtml

        Dim mySmtpsvr As New SmtpClient()
        mySmtpsvr.Host = p_host
        mySmtpsvr.Port = p_port
        mySmtpsvr.EnableSsl = p_enablessl

        'If p_host = "smtp.mailtrap.io" Then
        '    myCredentials.Domain = p_host
        'End If

        mySmtpsvr.UseDefaultCredentials = False
        mySmtpsvr.Credentials = myCredentials

        ServicePointManager.ServerCertificateValidationCallback = New RemoteCertificateValidationCallback(AddressOf ValidateServerCertificate)        Try            Dim l_temp As String            Dim l_emailtomb, l_cimzett As String()            If String.IsNullOrEmpty(p_from_displayname) Then
                oMsg.From = New MailAddress(l_from)
            Else
                oMsg.From = New MailAddress(l_from, p_from_displayname)
            End If
            If p_req_read_receipt Then
                oMsg.Headers.Add("Disposition-Notification-To", l_from)
            End If
            If p_req_delivery_receipt Then
                oMsg.Headers.Add("Return-Receipt-To", l_from)
            End If
            oMsg.Subject = l_subject            oMsg.Body = l_body
            If p_MailToList Is Nothing Then
                l_emailtomb = l_to.Trim().Split(New String() {";"}, StringSplitOptions.RemoveEmptyEntries)
                If l_emailtomb IsNot Nothing Then
                    For Each l_temp In l_emailtomb
                        l_cimzett = l_temp.Trim().Split(New String() {"<"}, StringSplitOptions.RemoveEmptyEntries)
                        If l_cimzett.GetUpperBound(0) = 0 Then
                            oMsg.To.Add(New MailAddress(l_cimzett(0).Trim()))
                        Else
                            oMsg.To.Add(New MailAddress(l_cimzett(1).Trim().TrimEnd(">".ToCharArray()), l_cimzett(0).Trim()))
                        End If
                    Next
                End If
            Else
                For Each l_mailto As MailAddress In p_MailToList
                    oMsg.To.Add(l_mailto)
                Next
            End If

            If String.IsNullOrEmpty(SmtpHelper.m_mailto_for_test) Then
                If p_MailCCList IsNot Nothing Then
                    For Each l_mailto As MailAddress In p_MailCCList
                        oMsg.CC.Add(l_mailto)
                    Next
                ElseIf Not String.IsNullOrEmpty(l_MailCC) Then
                    l_emailtomb = l_MailCC.Trim().Split(New String() {";"}, StringSplitOptions.RemoveEmptyEntries)
                    If l_emailtomb IsNot Nothing Then
                        For Each l_temp In l_emailtomb
                            l_cimzett = l_temp.Trim().Split(New String() {"<"}, StringSplitOptions.RemoveEmptyEntries)
                            If l_cimzett.GetUpperBound(0) = 0 Then
                                oMsg.CC.Add(New MailAddress(l_cimzett(0).Trim()))
                            Else
                                oMsg.CC.Add(New MailAddress(l_cimzett(1).Trim().TrimEnd(">".ToCharArray()), l_cimzett(0).Trim()))
                            End If
                        Next
                    End If
                End If

                If p_MailBccList IsNot Nothing Then
                    For Each l_mailto As MailAddress In p_MailBccList
                        oMsg.Bcc.Add(l_mailto)
                    Next
                ElseIf Not String.IsNullOrEmpty(l_MailBCC) Then
                    l_emailtomb = l_MailBCC.Trim().Split(New String() {";"}, StringSplitOptions.RemoveEmptyEntries)
                    If l_emailtomb IsNot Nothing Then
                        For Each l_temp In l_emailtomb
                            l_cimzett = l_temp.Trim().Split(New String() {"<"}, StringSplitOptions.RemoveEmptyEntries)
                            If l_cimzett.GetUpperBound(0) = 0 Then
                                oMsg.Bcc.Add(New MailAddress(l_cimzett(0).Trim()))
                            Else
                                oMsg.Bcc.Add(New MailAddress(l_cimzett(1).Trim().TrimEnd(">".ToCharArray()), l_cimzett(0).Trim()))
                            End If
                        Next
                    End If
                End If
            End If

            If p_fileattachment IsNot Nothing AndAlso p_fileattachment.GetUpperBound(0) > -1 Then                For i As Integer = 0 To p_fileattachment.GetUpperBound(0)                    If Not String.IsNullOrEmpty(p_fileattachment(i)) Then                        melleklet = New Attachment(p_fileattachment(i))                        If p_attach_filename Is Nothing Then
                            melleklet.Name = System.IO.Path.GetFileName(p_fileattachment(i))
                        Else
                            melleklet.Name = p_attach_filename(i)                        End If                        oMsg.Attachments.Add(melleklet)                    End If
                Next            End If            mySmtpsvr.Send(oMsg)

            oMsg.Dispose()        Catch ex As Exception            Throw New Exception("Hiba az email küldése közben: " & Err.Number & Err.Description & ex.Message)        End Try    End SubEnd Class
