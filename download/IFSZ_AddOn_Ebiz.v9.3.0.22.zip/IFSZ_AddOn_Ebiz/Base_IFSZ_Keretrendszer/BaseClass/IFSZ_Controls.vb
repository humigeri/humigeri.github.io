Imports SystemImports System.DrawingImports System.CollectionsImports System.ComponentModelImports System.Windows.FormsPublic Class TextAndImageColumn    Inherits DataGridViewTextBoxColumn    Private imageValue As Image    Private imageSize As Size    Private p_LinkObject As Object    Private p_menuUID As String    Private p_formUID As String    Public Sub New()        Me.CellTemplate = New TextAndImageCell    End Sub    Public Overloads Overrides Function Clone() As Object        Dim c As TextAndImageColumn = CType(TryCast(MyBase.Clone, TextAndImageColumn), TextAndImageColumn)        c.imageValue = Me.imageValue        c.imageSize = Me.imageSize        Return c    End Function    Public Property Image() As Image        Get            Return Me.imageValue        End Get        Set(ByVal value As Image)            If Not Me.Image Is value Then                Me.imageValue = value                Me.imageSize = value.Size                If Not (Me.InheritedStyle Is Nothing) Then                    Dim inheritedPadding As Padding = Me.InheritedStyle.Padding                    Me.DefaultCellStyle.Padding = New Padding(imageSize.Width, inheritedPadding.Top, inheritedPadding.Right, inheritedPadding.Bottom)                End If            End If        End Set    End Property    Public Property LinkObject() As Object        Get            Return Me.p_LinkObject        End Get        Set(ByVal value As Object)            Me.p_LinkObject = value        End Set    End Property    Public Property MenuUID() As String        Get            Return Me.p_menuUID        End Get        Set(ByVal value As String)            If Not Me.p_menuUID Is value Then                Me.p_menuUID = value            End If        End Set    End Property    Public Property FormUID() As String        Get            Return Me.p_formUID        End Get        Set(ByVal value As String)            If Not Me.p_formUID Is value Then                Me.p_formUID = value            End If        End Set    End Property    Private ReadOnly Property TextAndImageCellTemplate() As TextAndImageCell        Get            Return CType(TryCast(Me.CellTemplate, TextAndImageCell), TextAndImageCell)        End Get    End Property    Friend ReadOnly Property ImageSize_() As Size        Get            Return imageSize        End Get    End PropertyEnd ClassPublic Class TextAndImageCell    Inherits DataGridViewTextBoxCell    Private imageValue As Image    Private imageSize As Size    Private p_LinkObject As Object    Private p_menuUID As String    Private p_formUID As String    Public Overloads Overrides Function Clone() As Object        Dim c As TextAndImageCell = CType(TryCast(MyBase.Clone, TextAndImageCell), TextAndImageCell)        c.imageValue = Me.imageValue        c.imageSize = Me.imageSize        Return c    End Function    Public Property Image() As Image        Get            If Me.OwningColumn Is Nothing OrElse Me.OwningTextAndImageColumn Is Nothing Then                Return imageValue            Else                If Not (Me.imageValue Is Nothing) Then                    Return Me.imageValue                Else                    Return Me.OwningTextAndImageColumn.Image                End If            End If        End Get        Set(ByVal value As Image)            If Not Me.Image Is value Then                Me.imageValue = value                Me.imageSize = value.Size                Dim inheritedPadding As Padding = Me.InheritedStyle.Padding                Me.Style.Padding = New Padding(imageSize.Width, inheritedPadding.Top + 5, inheritedPadding.Right, inheritedPadding.Bottom)            End If        End Set    End Property    Public Property LinkObject() As Object        Get            If Me.OwningColumn Is Nothing OrElse Me.OwningTextAndImageColumn Is Nothing Then                Return p_LinkObject            Else                If Not (Me.p_LinkObject Is Nothing) Then                    Return Me.p_LinkObject                Else                    Return Me.OwningTextAndImageColumn.LinkObject                End If            End If        End Get        Set(ByVal value As Object)            If Not Me.p_LinkObject Is value Then                Me.p_LinkObject = value            End If        End Set    End Property    Public Property MenuUID() As String        Get            If Me.OwningColumn Is Nothing OrElse Me.OwningTextAndImageColumn Is Nothing Then                Return Me.p_menuUID            Else                If Not (Me.p_menuUID Is Nothing) Then                    Return Me.p_menuUID                Else                    Return Me.OwningTextAndImageColumn.MenuUID                End If            End If        End Get        Set(ByVal value As String)            If Not Me.p_menuUID Is value Then                Me.p_menuUID = value            End If        End Set    End Property    Public Property FormUID() As String        Get            If Me.OwningColumn Is Nothing OrElse Me.OwningTextAndImageColumn Is Nothing Then                Return Me.p_formUID            Else                If Not (Me.p_formUID Is Nothing) Then                    Return Me.p_formUID                Else                    Return Me.OwningTextAndImageColumn.FormUID                End If            End If        End Get        Set(ByVal value As String)            If Not Me.p_formUID Is value Then                Me.p_formUID = value            End If        End Set    End Property    Protected Overloads Overrides Sub Paint(ByVal graphics As Graphics, ByVal clipBounds As Rectangle, ByVal cellBounds As Rectangle, ByVal rowIndex As Integer, ByVal cellState As DataGridViewElementStates, ByVal value As Object, ByVal formattedValue As Object, ByVal errorText As String, ByVal cellStyle As DataGridViewCellStyle, ByVal advancedBorderStyle As DataGridViewAdvancedBorderStyle, ByVal paintParts As DataGridViewPaintParts)        MyBase.Paint(graphics, clipBounds, cellBounds, rowIndex, cellState, value, formattedValue, errorText, cellStyle, advancedBorderStyle, paintParts)        If Not (Me.Image Is Nothing) Then            Dim container As System.Drawing.Drawing2D.GraphicsContainer = graphics.BeginContainer            graphics.SetClip(cellBounds)            graphics.DrawImageUnscaled(Me.Image, cellBounds.Location.X, cellBounds.Location.Y + 4)            graphics.EndContainer(container)        End If    End Sub    Private ReadOnly Property OwningTextAndImageColumn() As TextAndImageColumn        Get            Return CType(TryCast(Me.OwningColumn, TextAndImageColumn), TextAndImageColumn)        End Get    End PropertyEnd ClassPublic Class IFSZ_MessageBox
    Public Shared Function Show(ByVal p_text As String, ByVal p_labels() As String) As Integer
        ' Create a new input box dialog
        Dim frmMsgBox As New IFSZ_MessageBoxForm(p_text, p_labels)
        frmMsgBox.ShowDialog()
        Return frmMsgBox.ReturnValue
    End Function
End Class

''' <summary>
''' Summary description for IFSZ_MessageBoxForm
''' </summary>
Friend Class IFSZ_MessageBoxForm
    Inherits System.Windows.Forms.Form
    Private btn1 As System.Windows.Forms.Button
    Private btn2 As System.Windows.Forms.Button
    Private btn3 As System.Windows.Forms.Button
    Private btn4 As System.Windows.Forms.Button
    Private btn5 As System.Windows.Forms.Button
    Private btn6 As System.Windows.Forms.Button
    Private btn7 As System.Windows.Forms.Button
    Private btn8 As System.Windows.Forms.Button
    Private btn9 As System.Windows.Forms.Button
    Private btn10 As System.Windows.Forms.Button
    Private btn11 As System.Windows.Forms.Button
    Private btn12 As System.Windows.Forms.Button
    Private lblText As System.Windows.Forms.Label
    Private strReturnValue As Integer
    Private pntStartLocation As Point
    Private m_labels() As String
    Private m_text As String
    Public m_szelesseg As Integer = 400
    Public m_gombszelesseg As Integer = 84
    Public m_gombkoz As Integer = 6
    Public m_darab As Integer
    ''' <summary>
    ''' Required designer variable.
    ''' </summary>
    Private components As System.ComponentModel.Container = Nothing

    Public Sub New(ByVal p_text As String, ByVal p_labels() As String)
        Me.m_text = p_text
        Me.m_labels = p_labels
        If Me.m_labels Is Nothing Then
            Me.m_darab = 0
        Else
            Me.m_darab = Me.m_labels.GetUpperBound(0) + 1
        End If
        ' Required for Windows Form Designer support
        InitializeComponent()
        Me.strReturnValue = 0
    End Sub

    ''' <summary>
    ''' Clean up any resources being used.
    ''' </summary>
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If components IsNot Nothing Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

#Region "Windows Form Designer generated code"
    ''' <summary>
    ''' Required method for Designer support - do not modify
    ''' the contents of this method with the code editor.
    ''' </summary>
    Private Sub InitializeComponent()
        Me.btn1 = New System.Windows.Forms.Button()
        Me.lblText = New System.Windows.Forms.Label()
        Me.btn2 = New System.Windows.Forms.Button()
        Me.btn3 = New System.Windows.Forms.Button()
        Me.btn4 = New System.Windows.Forms.Button()
        Me.btn5 = New System.Windows.Forms.Button()
        Me.btn6 = New System.Windows.Forms.Button()
        Me.btn7 = New System.Windows.Forms.Button()
        Me.btn8 = New System.Windows.Forms.Button()
        Me.btn9 = New System.Windows.Forms.Button()
        Me.btn10 = New System.Windows.Forms.Button()
        Me.btn11 = New System.Windows.Forms.Button()
        Me.btn12 = New System.Windows.Forms.Button()

        Me.SuspendLayout()
        ' 
        ' btn1
        ' 
        Me.btn1.Location = New System.Drawing.Point(217, 86)
        Me.btn1.Name = "btn1"
        Me.btn1.Size = New System.Drawing.Size(Me.m_gombszelesseg, 27)
        Me.btn1.TabIndex = 0
        Me.btn1.Text = "OK"
        AddHandler Me.btn1.Click, AddressOf Me.btn1_Click
        ' 
        ' lblText
        ' 
        Me.lblText.Location = New System.Drawing.Point(9, 7)
        Me.lblText.Name = "lblText"
        Me.lblText.Size = New System.Drawing.Size(Me.m_szelesseg - 18, 64)
        Me.lblText.TabIndex = 2
        Me.lblText.Text = Me.m_text
        ' 
        ' btn2
        ' 
        Me.btn2.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btn2.Location = New System.Drawing.Point(307, 86)
        Me.btn2.Name = "btn2"
        Me.btn2.Size = New System.Drawing.Size(Me.m_gombszelesseg, 27)
        Me.btn2.TabIndex = 3
        Me.btn2.Text = "Cancel"
        AddHandler Me.btn2.Click, AddressOf Me.btn2_Click
        ' 
        ' btn3
        ' 
        Me.btn3.Location = New System.Drawing.Point(288, 8)
        Me.btn3.Name = "btn3"
        Me.btn3.Size = New System.Drawing.Size(Me.m_gombszelesseg, 27)
        Me.btn3.TabIndex = 4
        Me.btn3.Text = "3"
        Me.btn3.Visible = False
        AddHandler Me.btn3.Click, AddressOf Me.btn3_Click
        ' 
        ' btn4
        ' 
        Me.btn4.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btn4.Location = New System.Drawing.Point(288, 40)
        Me.btn4.Name = "btn2"
        Me.btn4.Size = New System.Drawing.Size(Me.m_gombszelesseg, 27)
        Me.btn4.TabIndex = 5
        Me.btn4.Text = "4"
        Me.btn4.Visible = False
        AddHandler Me.btn4.Click, AddressOf Me.btn4_Click

        Me.btn5.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btn5.Location = New System.Drawing.Point(288, 40)
        Me.btn5.Name = "btn5"
        Me.btn5.Size = New System.Drawing.Size(Me.m_gombszelesseg, 27)
        Me.btn5.TabIndex = 6
        Me.btn5.Text = "5"
        Me.btn5.Visible = False
        AddHandler Me.btn5.Click, AddressOf Me.btn5_Click

        Me.btn6.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btn6.Location = New System.Drawing.Point(288, 40)
        Me.btn6.Name = "btn6"
        Me.btn6.Size = New System.Drawing.Size(Me.m_gombszelesseg, 27)
        Me.btn6.TabIndex = 7
        Me.btn6.Text = "6"
        Me.btn6.Visible = False
        AddHandler Me.btn6.Click, AddressOf Me.btn6_Click

        Me.btn7.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btn7.Location = New System.Drawing.Point(288, 40)
        Me.btn7.Name = "btn7"
        Me.btn7.Size = New System.Drawing.Size(Me.m_gombszelesseg, 27)
        Me.btn7.TabIndex = 8
        Me.btn7.Text = "7"
        Me.btn7.Visible = False
        AddHandler Me.btn7.Click, AddressOf Me.btn7_Click

        Me.btn8.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btn8.Location = New System.Drawing.Point(288, 40)
        Me.btn8.Name = "btn8"
        Me.btn8.Size = New System.Drawing.Size(Me.m_gombszelesseg, 27)
        Me.btn8.TabIndex = 9
        Me.btn8.Text = "8"
        Me.btn8.Visible = False
        AddHandler Me.btn8.Click, AddressOf Me.btn8_Click

        Me.btn9.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btn9.Location = New System.Drawing.Point(288, 40)
        Me.btn9.Name = "btn9"
        Me.btn9.Size = New System.Drawing.Size(Me.m_gombszelesseg, 27)
        Me.btn9.TabIndex = 10
        Me.btn9.Text = "9"
        Me.btn9.Visible = False
        AddHandler Me.btn9.Click, AddressOf Me.btn9_Click

        Me.btn10.Location = New System.Drawing.Point(288, 40)
        Me.btn10.Name = "btn10"
        Me.btn10.Size = New System.Drawing.Size(Me.m_gombszelesseg, 27)
        Me.btn10.TabIndex = 11
        Me.btn10.Text = "10"
        Me.btn10.Visible = False
        AddHandler Me.btn10.Click, AddressOf Me.btn10_Click

        Me.btn11.Location = New System.Drawing.Point(288, 40)
        Me.btn11.Name = "btn11"
        Me.btn11.Size = New System.Drawing.Size(Me.m_gombszelesseg, 27)
        Me.btn11.TabIndex = 12
        Me.btn11.Text = "11"
        Me.btn11.Visible = False
        AddHandler Me.btn11.Click, AddressOf Me.btn11_Click

        Me.btn12.Location = New System.Drawing.Point(288, 40)
        Me.btn12.Name = "btn12"
        Me.btn12.Size = New System.Drawing.Size(Me.m_gombszelesseg, 27)
        Me.btn12.TabIndex = 13
        Me.btn12.Text = "12"
        Me.btn12.Visible = False
        AddHandler Me.btn12.Click, AddressOf Me.btn12_Click
        ' 
        ' IFSZ_MessageBoxForm
        ' 
        Me.AcceptButton = Me.btn1
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.CancelButton = Me.btn2
        Me.ClientSize = New System.Drawing.Size(Me.m_szelesseg, 150)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btn12, Me.btn11, Me.btn10, Me.btn9, Me.btn8, Me.btn7, Me.btn6, Me.btn5, Me.btn4, Me.btn3, Me.btn2, Me.lblText, Me.btn1})
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "IFSZ_MessageBoxForm"
        Me.Text = ""
        Me.StartPosition = FormStartPosition.CenterScreen
        AddHandler Me.Load, AddressOf Me.IFSZ_MessageBoxForm_Load

        If Me.m_darab >= 5 Then
            Me.m_szelesseg = Me.m_szelesseg + 90 * (Me.m_darab - 4)
            Me.ClientSize = New System.Drawing.Size(Me.m_szelesseg, 150)
        End If

        If Me.m_labels IsNot Nothing Then
            If Me.m_darab >= 1 Then
                Me.btn1.Location = New System.Drawing.Point(Me.GetKezdoPoz(1), 86)
                Me.btn1.Text = Me.m_labels(0)
                Me.btn1.Visible = True
            End If
            If Me.m_darab >= 2 Then
                Me.btn2.Location = New System.Drawing.Point(Me.GetKezdoPoz(2), 86)
                Me.btn2.Text = Me.m_labels(1)
                Me.btn2.Visible = True
            Else
                Me.btn2.Visible = False
            End If
            If Me.m_darab >= 3 Then
                Me.btn3.Location = New System.Drawing.Point(Me.GetKezdoPoz(3), 86)
                Me.btn3.Text = Me.m_labels(2)
                Me.btn3.Visible = True
            Else
                Me.btn3.Visible = False
            End If
            If Me.m_darab >= 4 Then
                Me.btn4.Location = New System.Drawing.Point(Me.GetKezdoPoz(4), 86)
                Me.btn4.Text = Me.m_labels(3)
                Me.btn4.Visible = True
            Else
                Me.btn4.Visible = False
            End If
            If Me.m_darab >= 5 Then
                Me.btn5.Location = New System.Drawing.Point(Me.GetKezdoPoz(5), 86)
                Me.btn5.Text = Me.m_labels(4)
                Me.btn5.Visible = True
            Else
                Me.btn5.Visible = False
            End If
            If Me.m_darab >= 6 Then
                Me.btn6.Location = New System.Drawing.Point(Me.GetKezdoPoz(6), 86)
                Me.btn6.Text = Me.m_labels(5)
                Me.btn6.Visible = True
            Else
                Me.btn6.Visible = False
            End If
            If Me.m_darab >= 7 Then
                Me.btn7.Location = New System.Drawing.Point(Me.GetKezdoPoz(7), 86)
                Me.btn7.Text = Me.m_labels(6)
                Me.btn7.Visible = True
            Else
                Me.btn7.Visible = False
            End If
            If Me.m_darab >= 8 Then
                Me.btn8.Location = New System.Drawing.Point(Me.GetKezdoPoz(8), 86)
                Me.btn8.Text = Me.m_labels(7)
                Me.btn8.Visible = True
            Else
                Me.btn8.Visible = False
            End If
            If Me.m_darab >= 9 Then
                Me.btn9.Location = New System.Drawing.Point(Me.GetKezdoPoz(9), 86)
                Me.btn9.Text = Me.m_labels(8)
                Me.btn9.Visible = True
            Else
                Me.btn9.Visible = False
            End If
            If Me.m_darab >= 10 Then
                Me.btn10.Location = New System.Drawing.Point(Me.GetKezdoPoz(10), 86)
                Me.btn10.Text = Me.m_labels(9)
                Me.btn10.Visible = True
            Else
                Me.btn10.Visible = False
            End If
            If Me.m_darab >= 11 Then
                Me.btn11.Location = New System.Drawing.Point(Me.GetKezdoPoz(11), 86)
                Me.btn11.Text = Me.m_labels(10)
                Me.btn11.Visible = True
            Else
                Me.btn11.Visible = False
            End If
            If Me.m_darab >= 12 Then
                Me.btn12.Location = New System.Drawing.Point(Me.GetKezdoPoz(12), 86)
                Me.btn12.Text = Me.m_labels(11)
                Me.btn12.Visible = True
            Else
                Me.btn12.Visible = False
            End If

        End If

        Me.ResumeLayout(False)

    End Sub
#End Region

    Private Function GetKezdoPoz(ByVal p_gomb As Integer) As Integer
        If p_gomb > Me.m_darab Then
            Return 0
        Else
            Return (Me.m_szelesseg - (Me.m_gombszelesseg * Me.m_darab) - (Me.m_gombkoz * (Me.m_darab - 1))) / 2 + (p_gomb - 1) * (Me.m_gombszelesseg + Me.m_gombkoz)
        End If

    End Function

    Private Sub IFSZ_MessageBoxForm_Load(ByVal sender As Object, ByVal e As System.EventArgs)
        If Not Me.pntStartLocation.IsEmpty Then
            Me.Top = Me.pntStartLocation.X
            Me.Left = Me.pntStartLocation.Y
        End If
    End Sub

    Private Sub btn1_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Me.strReturnValue = 1
        Me.Close()
    End Sub

    Private Sub btn2_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Me.strReturnValue = 2
        Me.Close()
    End Sub

    Private Sub btn3_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Me.strReturnValue = 3
        Me.Close()
    End Sub

    Private Sub btn4_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Me.strReturnValue = 4
        Me.Close()
    End Sub

    Private Sub btn5_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Me.strReturnValue = 5
        Me.Close()
    End Sub

    Private Sub btn6_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Me.strReturnValue = 6
        Me.Close()
    End Sub

    Private Sub btn7_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Me.strReturnValue = 7
        Me.Close()
    End Sub

    Private Sub btn8_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Me.strReturnValue = 8
        Me.Close()
    End Sub

    Private Sub btn9_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Me.strReturnValue = 9
        Me.Close()
    End Sub

    Private Sub btn10_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Me.strReturnValue = 10
        Me.Close()
    End Sub

    Private Sub btn11_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Me.strReturnValue = 11
        Me.Close()
    End Sub

    Private Sub btn12_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Me.strReturnValue = 12
        Me.Close()
    End Sub


    Public WriteOnly Property Title() As String
        Set(ByVal value As String)
            Me.Text = value
        End Set
    End Property

    Public WriteOnly Property Prompt() As String
        Set(ByVal value As String)
            Me.lblText.Text = value
        End Set
    End Property

    Public ReadOnly Property ReturnValue() As Integer
        Get
            Return strReturnValue
        End Get
    End Property

    Public WriteOnly Property StartLocation() As Point
        Set(ByVal value As Point)
            Me.pntStartLocation = value
        End Set
    End Property
End Class