Public Class IFSZ_Types
#Region "Structures"
    Public Structure EntityTipus
        Public ChildEntities() As IFSZ_IEntity
        Public ChildTableNames() As String
        Public ParentEntities() As IFSZ_IEntity
        Public ParentTableNames() As String

        Public Sub New(ByVal p_EntityName As String)
            If ChildTableNames Is Nothing Then
                ReDim Preserve ChildTableNames(0)
            Else
                ReDim Preserve ChildTableNames(ChildTableNames.GetUpperBound(0) + 1)
            End If
            ChildTableNames(ChildTableNames.GetUpperBound(0)) = p_EntityName

        End Sub

        Public Sub New(ByVal p_EntityName As String, ByVal p_Entity As IFSZ_IEntity)
            If ChildTableNames Is Nothing Then
                ReDim Preserve ChildTableNames(0)
            Else
                ReDim Preserve ChildTableNames(ChildTableNames.GetUpperBound(0) + 1)
            End If
            ChildTableNames(ChildTableNames.GetUpperBound(0)) = p_EntityName

            If ChildEntities Is Nothing Then
                ReDim Preserve ChildEntities(0)
            Else
                ReDim Preserve ChildEntities(ChildEntities.GetUpperBound(0) + 1)
            End If
            ChildEntities(ChildEntities.GetUpperBound(0)) = p_Entity

        End Sub

        Public Sub addParent(ByVal p_EntityName As String)
            If ParentTableNames Is Nothing Then
                ReDim Preserve ParentTableNames(0)
            Else
                ReDim Preserve ParentTableNames(ParentTableNames.GetUpperBound(0) + 1)
            End If
            ParentTableNames(ParentTableNames.GetUpperBound(0)) = p_EntityName

        End Sub

        Public Sub add(ByVal p_EntityName As String, ByVal p_entity As IFSZ_IEntity)

        End Sub
    End Structure

    Public Structure PointAPI
        Public X As Long
        Public Y As Long
    End Structure

    Public Enum PItemEvent
        ItemValidate
        ItemPreValidate
        KeyPressed
        AfterKeyPressed
        KeyDown
        KeyUp
        ItemClick
        GotFocus
        DoubleClick
        PositionChanged
        PreCreateRow
        CreateRow
        AfterQuery
        PostQuery
        CellClick
        CellDoubleClick
        CellPaint
        MultiLovSelected
        LinkPressed
        CheckStateChanged
        ComboIndexChanged
        CellMouseClick
        CellMouseUp
        CellShiftMouseClick
        CellShiftCtrlMouseClick
        CellShiftAltMouseClick
        CellShiftCtrlAltMouseClick
        CellCtrlMouseClick
        CellCtrlAltMouseClick
        CellAltMouseClick
        CellContentClick
        RowEnter
        PostCommit
        MouseEnter
        MouseUp
        BeforQueryEnter
        RowRemove
        CellBeginEdit
        CellEndEdit
        PreviewKeyDown
        CellContextMenuStripNeeded
        LovValidate
        FormClose
        TextBoxLeave
        SelectedIndexChanged
        SelectingTabPage
        AfterPositionChanged
        UserDeletingRow
        UserDeletedRow
        CurrentCellChanged
    End Enum

    Public Enum PAcceptEvent
        AfterCreateConnection
        BeforeFormCommit
        BeforeRowCommit
        PostRowCommit
        PostFormCommit
        AcceptFailed
    End Enum

    Public Enum Gomb
        Ok
        Aktualizal
        Keres
    End Enum

    Public Structure RelationTable
        Public Table As String
        Public PK_Columns As String()
        Public FK_Columns As String()
    End Structure

    Public Structure Relations
        Public Tables As RelationTable()

    End Structure

    Public Structure PrimaryKeys
        Public PK_Columns As String()

    End Structure


    Public Structure LOV_Form
        Public Title As String
        Public Width As Double
        Public Height As Double
        Public SENDER As String
        Public DefaultScrollIndex As Integer
        Public NextFocusedColumn As String
        Public OrderBy As String
        Public Where As String
        Public GridFontSize As Integer
        Public GridRowPixelSize As Integer
        Public Maximized As Boolean
        Public Sub New(ByVal Title As String, _
                       ByVal Width As Double, _
                       ByVal Height As Double, _
                       ByVal Sender As String, _
                       ByVal DefaultScrollIndex As Integer, _
                       ByVal NextFocusedColumn As String, _
                       ByVal OrderBy As String, _
                       ByVal Where As String)
            Me.Title = Title
            Me.Width = Width
            Me.Height = Height
            Me.SENDER = Sender
            Me.DefaultScrollIndex = DefaultScrollIndex
            Me.NextFocusedColumn = NextFocusedColumn
            Me.OrderBy = OrderBy
            Me.Where = Where
            Me.Maximized = False
        End Sub
        Public Sub New(ByVal Title As String, _
                       ByVal Width As Double, _
                       ByVal Height As Double, _
                       ByVal Sender As String, _
                       ByVal DefaultScrollIndex As Integer, _
                       ByVal NextFocusedColumn As String, _
                       ByVal OrderBy As String, _
                       ByVal GridFontSize As Integer, _
                       ByVal GridRowPixelSize As Integer)
            Me.Title = Title
            Me.Width = Width
            Me.Height = Height
            Me.SENDER = Sender
            Me.DefaultScrollIndex = DefaultScrollIndex
            Me.NextFocusedColumn = NextFocusedColumn
            Me.OrderBy = OrderBy
            Me.GridFontSize = GridFontSize
            Me.GridRowPixelSize = GridRowPixelSize
            Me.Maximized = False
        End Sub
    End Structure

    Public Structure LOV_VEntiy
        Public Entity As IFSZ_IEntity
        Public Oszlop As String
        Public Sub New(ByVal Entity As IFSZ_IEntity, _
                       ByVal Oszlop As String)
            Me.Entity = Entity
            Me.Oszlop = Oszlop
        End Sub
    End Structure

    Public Structure FRM_LOV
        Public OszlopTipus() As LOV_OszlopTipus
        Public Query As String
        Public Sub New(ByVal OszlopTipus() As LOV_OszlopTipus, _
                       ByVal Query As String)
            Me.OszlopTipus = OszlopTipus
            Me.Query = Query
        End Sub
    End Structure

    Public Structure LOV_OszlopTipus
        Public Title As String
        Public DbNev As String
        Public VNev As Object
        Public Tipus As String
        Public Description As String
        Public Visible As Boolean
        Public RightJustified As Boolean
        Public CenterJustified As Boolean
        Public Width As Double
        Public Height As Double
        Public Link As Boolean
        Public LinkOsztaly As String
        Public MenuUID As String
        Public FormUID As String
        Public ValidalTiltas As Boolean
        Public SBOColName As String
        Public Sub New(ByVal Title As String,
                       ByVal DBNev As String,
                       ByVal VNev As Object,
                       ByVal Tipus As String,
                       ByVal Descr As String,
                       ByVal Visible As Boolean,
                       ByVal RightJustified As Boolean,
                       ByVal Width As Double,
                       ByVal Height As Double,
                       ByVal Link As Boolean,
                       ByVal LinkOsztaly As String,
                       ByVal MenuUID As String,
                       ByVal FormUID As String,
                       ByVal ValidalTiltas As Boolean,
                       Optional ByVal SBOColName As String = "")
            Me.Title = Title
            Me.DbNev = DBNev
            Me.VNev = VNev
            Me.Tipus = Tipus
            Me.Description = Descr
            Me.Visible = Visible
            Me.RightJustified = RightJustified
            Me.Width = Width
            Me.Height = Height
            Me.Link = Link
            Me.LinkOsztaly = LinkOsztaly
            Me.MenuUID = MenuUID
            Me.FormUID = FormUID
            Me.ValidalTiltas = ValidalTiltas
            Me.SBOColName = SBOColName
        End Sub
    End Structure

    Public Enum DMLOperation
        Insert
        Update
        Delete
    End Enum

    Public Enum AcceptTypes
        AllError
        NoError
    End Enum

    Public Structure QueriedRow
        Public EntityName As String
        Public RowIndex As Long
        Public ID As String
        Public Sub New(ByVal EntityName As String, _
                       ByVal RowIndex As Long, _
                       ByVal ID As String)
            Me.EntityName = EntityName
            Me.RowIndex = RowIndex
            Me.ID = ID
        End Sub
    End Structure

    Public Structure DataGridMeasure
        Public DataGridName As String
        Public Width As Integer
        Public Height As Integer
        Public DisplayedRowNum As Integer
        Public HorizontalScrollBar As Boolean
        Public Sub New(ByVal DataGridName As String, _
                       ByVal Width As Integer, _
                       ByVal Height As Integer, _
                       ByVal DisplayedRowNum As Integer, _
                       ByVal HorizontalScrollBar As Boolean)
            Me.DataGridName = DataGridName
            Me.Width = Width
            Me.Height = Height
            Me.DisplayedRowNum = DisplayedRowNum
            Me.HorizontalScrollBar = HorizontalScrollBar
        End Sub

        Public Sub ModifyHeight(ByVal Height As Integer)
            Me.Height = Height
        End Sub
        Public Sub ModifyWidth(ByVal Width As Integer)
            Me.Width = Width
        End Sub
        Public Sub ModifyDisplayedRowNum(ByVal DisplayedRowNum As Integer)
            Me.DisplayedRowNum = DisplayedRowNum
        End Sub
        Public Sub ModifyHorizontalScrollBar(ByVal HorizontalScrollBar As Boolean)
            Me.HorizontalScrollBar = HorizontalScrollBar
        End Sub
    End Structure

    Public Structure AllVirtalRows
        Public DataGridName As String
        Public RowNum As Integer
        Public Sub New(ByVal DataGridName As String, _
                       ByVal RowNum As Integer)
            Me.DataGridName = DataGridName
            Me.RowNum = RowNum
        End Sub
        Public Sub ModifyRowNum(ByVal RowNum As Integer)
            Me.RowNum = RowNum
        End Sub
    End Structure

    Public Structure PreviousTextItem
        Public ItemName As String
        Public Value As String
        Public Sub New(ByVal ItemName As String, _
                       ByVal Value As String)
            Me.ItemName = ItemName
            Me.Value = Value
        End Sub
        Public Sub ModifyValue(ByVal Value As String)
            Me.Value = Value
        End Sub
    End Structure

    Public Structure EntityFieldType
        Public DataType As Type
        Public DataTypeName As String
        Public MaximumLength As Integer
        Public DecimalPlaces As Integer
        Public Format As String
        Public SeparateString As String
        Public NotNull As Boolean
        Public Sub New(ByVal p_DataType As Type, ByVal p_MaximumLength As Integer, ByVal p_DecimalPlaces As Integer, ByVal p_Format As String)
            DataType = p_DataType
            MaximumLength = p_MaximumLength
            DecimalPlaces = p_DecimalPlaces
            Format = p_Format
            NotNull = False
        End Sub
        Public Sub New(ByVal p_DataType As Type, ByVal p_MaximumLength As Integer, ByVal p_DecimalPlaces As Integer, ByVal p_Format As String, ByVal p_NotNull As Boolean)
            DataType = p_DataType
            MaximumLength = p_MaximumLength
            DecimalPlaces = p_DecimalPlaces
            Format = p_Format
            NotNull = p_NotNull
        End Sub

        Public Sub New(ByVal p_DataTypeName As String, ByVal SeparateString As String)
            DataTypeName = p_DataTypeName
            Me.SeparateString = SeparateString
        End Sub

        Public Function Validate(ByRef p_ertek As String, ByRef p_message As String) As Boolean

            If Not DataTypeName Is Nothing AndAlso DataTypeName.ToUpper = "TIME" Then
                Return Me.TimeValidate(p_ertek, p_message)
            ElseIf Not DataType Is Nothing AndAlso (DataType.Name.ToString.ToUpper = "STRING" Or DataTypeName = "STRING") Then
                Return Me.StringValidate(p_ertek, p_message)
            End If
        End Function

        Private Function StringValidate(ByRef p_ertek As String, ByRef p_message As String) As Boolean
            If NotNull = True AndAlso (p_ertek Is Nothing Or p_ertek = "") Then
                p_message = IFSZ_Globals.GetString("NOTNULL", IFSZ_Globals.GetPrompt("IFSZ_TURA_LEOSZTASOK", "FELDOLGOZVA", IFSZ_Types.EGetPromptTypes.Prompt))
                Return False
            End If

            If Not p_ertek Is Nothing And p_ertek <> "" And MaximumLength > 0 Then
                If p_ertek.Length > MaximumLength Then
                    p_message = IFSZ_Globals.GetString("CHARLEN_OVERRUN", MaximumLength.ToString)
                    Return False
                End If
            End If
            Return True
        End Function

        Private Function TimeValidate(ByRef p_ertek As String, ByRef p_message As String) As Boolean
            Dim l_ertek As String
            Dim l_ora, l_perc, l_elvalaszto As String
            Dim l_valt As Double
            l_ertek = p_ertek
            If l_ertek.Length = 5 Or l_ertek.Length = 4 Then
                l_ora = l_ertek.Substring(0, 2)
                If l_ora < "00" Or l_ora > "24" Then
                    p_message = "Az id�pont form�tuma hh:mm kell legyen!"
                    Return False

                End If
                Try
                    l_valt = CType(l_ora, Double)
                Catch ex As Exception
                    p_message = "Az id�pont form�tuma hh:mm kell legyen!"
                    Return False

                End Try
                l_perc = l_ertek.Substring(l_ertek.Length - 2, 2)
                If l_perc < "00" Or l_perc > "60" Then
                    p_message = "Az id�pont form�tuma hh:mm kell legyen!"
                    Return False

                End If
                Try
                    l_valt = CType(l_perc, Double)
                Catch ex As Exception
                    p_message = "Az id�pont form�tuma hh:mm kell legyen!"
                    Return False
                End Try
                If l_ertek.Length = 5 Then
                    l_elvalaszto = l_ertek.Substring(2, 1)
                    If l_elvalaszto <> Me.SeparateString Then
                        p_message = "Az id�pont form�tuma hh:mm kell legyen!"
                        Return False
                    End If
                Else
                    p_ertek = l_ora + ":" + l_perc
                End If
            Else
                p_message = "Az id�pont form�tuma hh:mm kell legyen!"
                Return False
            End If
            Return True
        End Function

    End Structure

    Public Structure EntityFieldType_Old
        Public DataType As Type
        Public MaximumLength As Integer
        Public DecimalPlaces As Integer
        Public Format As String
        Public Sub New(ByVal p_DataType As Type, ByVal p_MaximumLength As Integer, ByVal p_DecimalPlaces As Integer, ByVal p_Format As String)
            DataType = p_DataType
            MaximumLength = p_MaximumLength
            DecimalPlaces = p_DecimalPlaces
            Format = p_Format
        End Sub
    End Structure

    Public Enum EGetPromptTypes
        Title
        Prompt
        Description
        ShortPrompt
    End Enum

#End Region


    Public Sub New()

    End Sub
End Class