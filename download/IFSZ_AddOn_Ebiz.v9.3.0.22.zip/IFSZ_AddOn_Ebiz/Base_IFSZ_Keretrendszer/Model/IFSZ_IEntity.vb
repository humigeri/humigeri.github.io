Public Interface IFSZ_IEntity

#Region "Property"
    Property TableName() As String
    Property ViewName() As String
    Property DefaultWhere() As String
    Property LastWhere() As String
    Property LastQuery() As String
    Property ChildWhere() As String
    Property NewRowEnabled() As Boolean
    Property LastPosition() As Integer
    Property ChildRelation() As IFSZ_Types.Relations
    Property PrimaryKey() As IFSZ_Types.PrimaryKeys
    Property ArchivKey() As IFSZ_Types.PrimaryKeys
    Property ArchivQuery() As String
    Property ArchivOszlopTipus() As IFSZ_Types.LOV_OszlopTipus()
    Property ArchivFormTipus() As IFSZ_Types.LOV_Form
    Property m_IFSZ_Globals() As IFSZ_Globals
    ReadOnly Property Columns() As String()
    Property ArchivEnabled() As Boolean
#End Region

#Region "Function"
    Function Val_Attribute(ByVal p_oszlop As String, ByRef p_ertek As String, ByRef p_message As String) As Boolean
    Function GetAttribute(ByVal p_oszlop As String) As Object
    Function GetAttributeType(ByVal p_oszlop As String) As String
    Function GetAttributeDomain(ByVal p_oszlop As String) As Object
    Function get_ChildTableNames() As String()
    Function get_ParentTableNames() As String()
    Function get_DataTable(ByVal p_where As String) As DataTable
    Function get_DataRow(ByVal p_ID As Integer) As DataRow
    Function get_DataRows(ByVal p_where As String) As DataRowCollection
    Function get_ChildRows(ByVal p_TableName As String, ByVal p_FK_ID As Integer, Optional ByVal p_FkOszlop As String = "", Optional ByVal p_where As String = "") As DataRowCollection
    Function get_ParentRow(ByVal p_TableName As String, ByVal p_ID As String) As DataRow
    Function getChildEntity(ByVal p_TableName As String) As IFSZ_IEntity
    Function getParentEntity(ByVal p_TableName As String) As IFSZ_IEntity
#End Region

#Region "Procedure"
    Sub set_row(ByVal p_row As DataRow)
    Function Delete(ByRef p_record As Object, ByVal p_record_old As Object, Optional ByRef p_messege As String = "") As Integer
    Function Insert(ByRef p_record As Object, Optional ByRef p_messege As String = "") As Integer
    Function Update(ByRef p_record As Object, ByVal p_record_old As Object, Optional ByRef p_messege As String = "") As Integer
    Sub Create(ByRef p_record As Object)
    Sub set_item(ByVal p_oszlop As String, ByVal p_ertek As Object)
#End Region

End Interface

