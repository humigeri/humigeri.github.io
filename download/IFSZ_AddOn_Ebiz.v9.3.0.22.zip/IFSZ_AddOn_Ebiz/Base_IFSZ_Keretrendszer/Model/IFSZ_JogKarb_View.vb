﻿'----------------------------------------------------------------------------'
'Generálva: 2013.11.22
'FormViewGenerator. Verzió: 1.0.7.0
'----------------------------------------------------------------------------'

Public Class IFSZ_JogKarb_View
    Inherits ObjectDataBinding.BaseClasses.FSBindingItem

#Region "Variables"

    Private p_ID As Integer
    Private p_INTERNAL_K As String
    Private p_LEVELS As String
    Private p_VISORDER As String
    Private p_OPTIONS As String
    Private p_ACTION As String
    Private p_PERMISSION As String
    Private p_ISITEM As String
    Private p_ABSID As String
    Private p_USER_CODE As String
    Private p_U_NAME As String
    Private p_NAME As String
    Private p_FATHID As String
    Private p_TREEORDER As String

    Public m_userid As Integer
    Public m_tovabbi_userek As String
    Public m_jogosultsag_szures As String

#End Region


#Region "Constructor"

    Public Sub New()

    End Sub

#End Region

#Region "Property"

    Public Property ID() As Integer
        Get
            Return p_ID
        End Get
        Set(ByVal value As Integer)
            p_ID = value
        End Set
    End Property

    Public Property INTERNAL_K() As String
        Get
            Return p_INTERNAL_K
        End Get
        Set(ByVal value As String)
            p_INTERNAL_K = value
        End Set
    End Property

    Public Property LEVELS() As String
        Get
            Return p_LEVELS
        End Get
        Set(ByVal value As String)
            p_LEVELS = value
        End Set
    End Property

    Public Property VISORDER() As String
        Get
            Return p_VISORDER
        End Get
        Set(ByVal value As String)
            p_VISORDER = value
        End Set
    End Property

    Public Property OPTIONS() As String
        Get
            Return p_OPTIONS
        End Get
        Set(ByVal value As String)
            p_OPTIONS = value
        End Set
    End Property

    Public Property ACTION() As String
        Get
            Return p_ACTION
        End Get
        Set(ByVal value As String)
            p_ACTION = value
        End Set
    End Property

    Public Property PERMISSION() As String
        Get
            Return p_PERMISSION
        End Get
        Set(ByVal value As String)
            p_PERMISSION = value
        End Set
    End Property

    Public Property ISITEM() As String
        Get
            Return p_ISITEM
        End Get
        Set(ByVal value As String)
            p_ISITEM = value
        End Set
    End Property

    Public Property ABSID() As String
        Get
            Return p_ABSID
        End Get
        Set(ByVal value As String)
            p_ABSID = value
        End Set
    End Property

    Public Property USER_CODE() As String
        Get
            Return p_USER_CODE
        End Get
        Set(ByVal value As String)
            p_USER_CODE = value
        End Set
    End Property

    Public Property U_NAME() As String
        Get
            Return p_U_NAME
        End Get
        Set(ByVal value As String)
            p_U_NAME = value
        End Set
    End Property

    Public Property NAME() As String
        Get
            Return p_NAME
        End Get
        Set(ByVal value As String)
            p_NAME = value
        End Set
    End Property

    Public Property FATHID() As String
        Get
            Return p_FATHID
        End Get
        Set(ByVal value As String)
            p_FATHID = value
        End Set
    End Property

    Public Property TREEORDER() As String
        Get
            Return p_TREEORDER
        End Get
        Set(ByVal value As String)
            p_TREEORDER = value
        End Set
    End Property

#End Region

    Public Function getDataSet() As DataSet
        Dim sqlQuery As String = ""
        Dim dataSet As DataSet = New DataSet

        Try

            sqlQuery = sqlQuery & QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "jogkarb_getdataset")


            ' Get a data set from the query
            dataSet = DataProvider.GetDataSet(sqlQuery.ToString())


            ' Create variables for data set tables
            Dim Table As DataTable = dataSet.Tables(0)
            Table.TableName = "PERM"
            dataSet.Tables(0).TableName = "PERM"


            Return dataSet

        Finally
            If (Not dataSet Is Nothing) Then
                'System.Runtime.InteropServices.Marshal.ReleaseComObject(dataSet)
                dataSet.Dispose()
            End If

        End Try
    End Function

    Public Function getSqlQuery(ByVal p_table As String, Optional ByVal p_tipus As String = "") As String
        Select Case p_table
            Case "PERM"
                Select Case p_tipus
                    Case "MASTER/DETAIL"
                        Return QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "jogkarb_getdataset") + " "
                    Case "TABLE"
                        Return QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "jogkarb_getdataset") + " "
                    Case Else
                        Return QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "jogkarb_getdataset") + " "
                End Select
            Case Else
                Return ""
        End Select
    End Function

#Region "get_elso"

    Public Function get_elso_USR(ByVal p_code As String, ByVal p_tipus As String) As DataRowCollection
        Dim l_query As String
        Dim l_where As String = ""
        Dim l_rc As DataRowCollection

        If p_tipus = "CODE" Then
            l_query = QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "jogkarb_get_elso_usr_by_code", p_code)
            l_rc = DataProvider.GetDataRecord(l_query)
            If l_rc.Count = 1 Then
                Return l_rc
            End If
            l_query = QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "jogkarb_get_elso_usr_by_codelike", p_code + "%")
            l_rc = DataProvider.GetDataRecord(l_query)

        Else
            l_query = QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "jogkarb_get_elso_usr_by_name", p_code)
            l_rc = DataProvider.GetDataRecord(l_query)
            If l_rc.Count = 1 Then
                Return l_rc
            End If
            l_query = QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "jogkarb_get_elso_usr_by_namelike", p_code + "%")
            l_rc = DataProvider.GetDataRecord(l_query)

        End If

        Return l_rc
    End Function

#End Region

End Class
