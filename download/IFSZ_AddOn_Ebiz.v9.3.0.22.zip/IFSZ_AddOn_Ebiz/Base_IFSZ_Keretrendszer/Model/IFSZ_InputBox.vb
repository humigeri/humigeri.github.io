Imports SystemImports System.DrawingPublic Enum en_IFSZ_InputBoxFieldType    String_
    Integer_
    Double_
    Date_
    DateTime_
    Password_
    File_
    SaveFileDialog_
End EnumPublic Structure st_IFSZ_InputBoxField    Public Label As String
    Public FieldType As en_IFSZ_InputBoxFieldType
    Public DefaultValue As String
    Public LabelLength As Integer
    Public TextBoxLength As Integer
    Public ComboValues As DataView
    Public ComboValueMember As String
    Public ComboDisplayMember As String
    Sub New(ByVal p_label As String)
        Me.Label = p_label
        Me.FieldType = en_IFSZ_InputBoxFieldType.String_
        Me.DefaultValue = Nothing
        Me.LabelLength = 0
        Me.TextBoxLength = 0
        Me.ComboValues = Nothing
    End Sub
End StructurePublic Structure st_IFSZ_InputBoxLayout    Public Title As String
    Public XPos As Integer
    Public YPos As Integer
    Public Width As Integer
    Public Height As Integer
    Public TabStops() As Integer
    Public LineHeight As Integer
    Public LineSpacing As Integer
    Public Fields() As st_IFSZ_InputBoxField
    Sub New(ByVal p_title As String, ByVal p_prompt() As String)
        Me.Title = p_title
        Me.XPos = 0
        Me.YPos = 0
        Me.Width = 362
        Me.Height = 111
        ReDim Me.TabStops(0)
        Me.TabStops(0) = 8
        Me.LineHeight = 24
        Me.LineSpacing = 4
        ReDim Me.Fields(p_prompt.GetUpperBound(0))
        Dim i As Integer
        For i = 0 To p_prompt.GetUpperBound(0)
            Me.Fields(i) = New st_IFSZ_InputBoxField(p_prompt(i))
        Next
    End Sub
End Structure''' <summary>''' Displays a prompt in a dialog box, waits for the user to input text or click a button, and then returns a string containing the contents of the text box.''' </summary>Public Class IFSZ_InputBox    ''' <summary>    ''' Displays a prompt in a dialog box, waits for the user to input text or click a button, and then returns a string containing the contents of the text box.    ''' </summary>    ''' <param name="Prompt">String expression displayed as the message in the dialog box.</param>    ''' <param name="Title">String expression displayed in the title bar of the dialog box.</param>    ''' <returns>The value in the textbox is returned if the user clicks OK or presses the ENTER key. If the user clicks Cancel, a zero-length string is returned.</returns>    Public Shared Function Show(ByVal Prompt As String, ByVal Title As String, Optional ByVal p_PasswordField As Boolean = False) As String        Return Show(Prompt, Title, "", -1, -1, p_PasswordField)    End Function    ''' <summary>    ''' Displays a prompt in a dialog box, waits for the user to input text or click a button, and then returns a string containing the contents of the text box.    ''' </summary>    ''' <param name="Prompt">String expression displayed as the message in the dialog box.</param>    ''' <param name="Title">String expression displayed in the title bar of the dialog box.</param>    ''' <param name="DefaultResponse">String expression displayed in the text box as the default response if no other input is provided. If you omit DefaultResponse, the displayed text box is empty.</param>    ''' <returns>The value in the textbox is returned if the user clicks OK or presses the ENTER key. If the user clicks Cancel, a zero-length string is returned.</returns>    Public Shared Function Show(ByVal Prompt As String, ByVal Title As String, ByVal DefaultResponse As String, Optional ByVal p_PasswordField As Boolean = False) As String        Return Show(Prompt, Title, DefaultResponse, -1, -1, p_PasswordField)    End Function    ''' <summary>    ''' Displays a prompt in a dialog box, waits for the user to input text or click a button, and then returns a string containing the contents of the text box.    ''' </summary>    ''' <param name="Prompt">String expression displayed as the message in the dialog box.</param>    ''' <param name="Title">String expression displayed in the title bar of the dialog box.</param>    ''' <param name="DefaultResponse">String expression displayed in the text box as the default response if no other input is provided. If you omit DefaultResponse, the displayed text box is empty.</param>    ''' <param name="XPos">Integer expression that specifies, in pixels, the distance of the left edge of the dialog box from the left edge of the screen.</param>    ''' <param name="YPos">Integer expression that specifies, in pixels, the distance of the upper edge of the dialog box from the top of the screen.</param>    ''' <returns>The value in the textbox is returned if the user clicks OK or presses the ENTER key. If the user clicks Cancel, a zero-length string is returned.</returns>    Public Shared Function Show(ByVal Prompt As String, ByVal Title As String, ByVal DefaultResponse As String, ByVal XPos As Integer, ByVal YPos As Integer, Optional ByVal p_PasswordField As Boolean = False) As String        ' Create a new input box dialog        Dim frmInputBox As New IFSZ_InputBoxForm()        frmInputBox.Title = Title        frmInputBox.Prompt = Prompt        frmInputBox.DefaultResponse = DefaultResponse        If XPos >= 0 AndAlso YPos >= 0 Then            frmInputBox.StartLocation = New Point(XPos, YPos)        End If        If p_PasswordField Then            frmInputBox.txtResult.PasswordChar = "*"        End If        frmInputBox.ShowDialog()        Return frmInputBox.ReturnValue    End Function    Public Shared Function Show(ByVal p_layout As st_IFSZ_InputBoxLayout, Optional ByVal p_parent As System.Windows.Forms.IWin32Window = Nothing, Optional ByRef p_interim_sbo As IFSZ_Interim_SBO = Nothing) As String()        ' Create a new input box dialog        Dim frmInputBox As New IFSZ_InputBoxForm(p_interim_sbo)        frmInputBox.Title = p_layout.Title        If p_layout.XPos >= 0 AndAlso p_layout.YPos >= 0 Then            frmInputBox.StartLocation = New Point(p_layout.XPos, p_layout.YPos)        End If        If p_layout.Width >= 0 AndAlso p_layout.Height >= 0 Then            frmInputBox.ClientSize = New Point(p_layout.Width, p_layout.Height)        End If        frmInputBox.CreateLayout(p_layout)        If p_parent Is Nothing Then            frmInputBox.ShowDialog()        Else            frmInputBox.ShowDialog(p_parent)        End If        If frmInputBox.DialogResult = DialogResult.OK Then            Return frmInputBox.ReturnAllValues        Else            Return Nothing        End If    End FunctionEnd Class