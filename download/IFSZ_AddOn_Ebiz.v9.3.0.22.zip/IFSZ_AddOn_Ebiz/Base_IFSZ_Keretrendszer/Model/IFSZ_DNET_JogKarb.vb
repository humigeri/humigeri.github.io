'----------------------------------------------------------------------------'
'Generálva: 2013.11.22
'FormViewGenerator. Verzió: 1.0.7.0
'----------------------------------------------------------------------------'

Public Class IFSZ_DNET_JogKarb

    Private p_PERM As IFSZ_DUAL

    Private m_sor As Integer
    Private m_oszlop As String

    Private m_szin_teljes_jog As System.Drawing.Color
    Private m_szin_nincs_jog As System.Drawing.Color
    Private m_szin_csop_teljes_jog As System.Drawing.Color
    Private m_szin_csop_nincs_jog As System.Drawing.Color
    Private m_szin_csop_kulonbozo_jog As System.Drawing.Color
    Private m_szin_csop_sor As System.Drawing.Color

    Public Sub New()
        MyBase.New()
        Me.m_IFSZ_Globals = New IFSZ_Globals
        Me.controller = New IFSZ_JogKarb_Ctrl(Me)
        InitializeComponent()
        Me.LanguageUpdate()

        p_PERM = New IFSZ_DUAL(Me.entity, Me, Me.m_IFSZ_Globals)

        Me.DataGridView1.Tag = Me.entity(0)
        Me.Init()
    End Sub

    Sub New(ByRef p_ifsz_globals As IFSZ_Globals)
        MyBase.New()

        Me.m_IFSZ_Globals = p_ifsz_globals
        Me.controller = New IFSZ_JogKarb_Ctrl(Me)
        InitializeComponent()
        Me.LanguageUpdate()

        p_PERM = New IFSZ_DUAL(Me.entity, Me, Me.m_IFSZ_Globals)

        Me.DataGridView1.Tag = Me.entity(0)
        Me.Init()
    End Sub

    Sub New(ByRef p_parentAddon As SBOAddOn, ByRef p_Interim_SBO As IFSZ_Interim_SBO)
        MyBase.New(p_Interim_SBO)

        Me.m_IFSZ_Globals = New IFSZ_Globals
        Me.controller = New IFSZ_JogKarb_Ctrl(Me)
        InitializeComponent()
        Me.LanguageUpdate()

        p_PERM = New IFSZ_DUAL(Me.entity, Me, Me.m_IFSZ_Globals)

        Me.DataGridView1.Tag = Me.entity(0)

        Me.Init()
    End Sub

    Private Sub LanguageUpdate()
    End Sub

    Private Sub Init()
        Me.m_szin_teljes_jog = System.Drawing.Color.DarkOliveGreen
        Me.m_szin_nincs_jog = System.Drawing.Color.Tomato
        Me.m_szin_csop_teljes_jog = System.Drawing.Color.OliveDrab
        Me.m_szin_csop_nincs_jog = System.Drawing.Color.Salmon
        Me.m_szin_csop_kulonbozo_jog = System.Drawing.Color.Orange
        Me.m_szin_csop_sor = System.Drawing.Color.Lavender
    End Sub

    Private Sub DataGridView1_RowPrePaint(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowPrePaintEventArgs) Handles DataGridView1.RowPrePaint
        If Not IFSZ_Globals.IsNull(Me.DataGridView1.Rows(e.RowIndex).Cells("DG1_LEVELS").Value) Then
            Dim p As Padding = Me.DataGridView1.Rows(e.RowIndex).Cells("DG1_ABSID").Style.Padding
            Dim l_szint As Integer = Me.DataGridView1.Rows(e.RowIndex).Cells("DG1_LEVELS").Value
            Me.DataGridView1.Rows(e.RowIndex).Cells("DG1_ABSID").Style.Padding = New Padding((l_szint - 1) * 10, p.Top, p.Right, p.Bottom)
            Me.DataGridView1.Rows(e.RowIndex).Cells("DG1_NAME").Style.Padding = New Padding((l_szint - 1) * 10, p.Top, p.Right, p.Bottom)
        End If
    End Sub


    Private Sub DataGridView1_CellFormatting(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles DataGridView1.CellFormatting
        If CType(sender, DataGridView).Columns(e.ColumnIndex).Name.StartsWith("p_") Then
            Select Case e.Value
                Case "N"
                    e.Value = "Nincs jogosultság"
                    If CType(sender, DataGridView).Rows(e.RowIndex).Cells("DG1_ISITEM").Value = "Y" Then
                        CType(sender, DataGridView).Rows(e.RowIndex).Cells(e.ColumnIndex).Style.BackColor = Me.m_szin_nincs_jog
                    Else
                        CType(sender, DataGridView).Rows(e.RowIndex).Cells(e.ColumnIndex).Style.BackColor = Me.m_szin_csop_nincs_jog
                    End If
                Case "F"
                    e.Value = "Teljes jogosultság"
                    If CType(sender, DataGridView).Rows(e.RowIndex).Cells("DG1_ISITEM").Value = "Y" Then
                        CType(sender, DataGridView).Rows(e.RowIndex).Cells(e.ColumnIndex).Style.BackColor = Me.m_szin_teljes_jog
                    Else
                        CType(sender, DataGridView).Rows(e.RowIndex).Cells(e.ColumnIndex).Style.BackColor = Me.m_szin_csop_teljes_jog
                    End If
                Case Else
                    e.Value = "Különböző jogosultságok"
                    CType(sender, DataGridView).Rows(e.RowIndex).Cells(e.ColumnIndex).Style.BackColor = Me.m_szin_csop_kulonbozo_jog
            End Select
        Else
            If CType(sender, DataGridView).Rows(e.RowIndex).Cells("DG1_ISITEM").Value = "N" Then
                CType(sender, DataGridView).Rows(e.RowIndex).Cells(e.ColumnIndex).Style.BackColor = Me.m_szin_csop_sor
            End If
        End If
    End Sub

    Private Sub DataGridView1_CellContextMenuStripNeeded(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellContextMenuStripNeededEventArgs) Handles DataGridView1.CellContextMenuStripNeeded
        If sender.GetType Is GetType(DataGridView) Then
            Dim l_dgv As DataGridView
            If CType(sender, DataGridView).Name = "PERM" Then
                l_dgv = DataGridView1
            Else
                Exit Sub
            End If
            If e.RowIndex > -1 Then
                l_dgv.ClearSelection()
                l_dgv.Rows(e.RowIndex).Selected = True
                Dim l_row As DataRowView = Me.DataGridView1.Rows(e.RowIndex).DataBoundItem
                Dim l_columnname As String
                If e.ColumnIndex > -1 Then
                    l_columnname = Me.DataGridView1.Columns.Item(e.ColumnIndex).Name
                Else
                    l_columnname = ""
                End If
                If l_columnname.StartsWith("p_") Then
                    If l_row(l_columnname).ToString = "F" Then
                        Me.mi_full.Enabled = False
                        Me.mi_no.Enabled = True
                        Me.mi_copy.Enabled = True
                    ElseIf l_row(l_columnname).ToString = "N" Then
                        Me.mi_full.Enabled = True
                        Me.mi_no.Enabled = False
                        Me.mi_copy.Enabled = True
                    Else
                        Me.mi_full.Enabled = True
                        Me.mi_no.Enabled = True
                        Me.mi_copy.Enabled = True
                    End If
                Else
                    Me.mi_full.Enabled = True
                    Me.mi_no.Enabled = True
                    Me.mi_copy.Enabled = False
                End If
                Me.m_sor = e.RowIndex
                Me.m_oszlop = l_columnname
            Else
                l_dgv.ClearSelection()
                Dim l_columnname As String
                If e.ColumnIndex > -1 Then
                    l_columnname = Me.DataGridView1.Columns.Item(e.ColumnIndex).Name
                Else
                    l_columnname = ""
                End If
                If l_columnname.StartsWith("p_") Then
                    Me.mi_full.Enabled = True
                    Me.mi_no.Enabled = True
                    Me.mi_copy.Enabled = True
                Else
                    Me.mi_full.Enabled = False
                    Me.mi_no.Enabled = False
                    Me.mi_copy.Enabled = False
                End If
                Me.m_sor = e.RowIndex
                Me.m_oszlop = l_columnname
            End If
        End If
    End Sub

    Private Sub mi_full_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mi_full.Click
        CType(Me.controller, IFSZ_JogKarb_Ctrl).DuplaKlikk(Me.m_oszlop, Me.m_sor, "F")
    End Sub

    Private Sub mi_no_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mi_no.Click
        CType(Me.controller, IFSZ_JogKarb_Ctrl).DuplaKlikk(Me.m_oszlop, Me.m_sor, "N")
    End Sub

    Private Sub mi_copy_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mi_copy.Click
        CType(Me.controller, IFSZ_JogKarb_Ctrl).Masolas(Me.m_oszlop, Me.m_sor)
    End Sub

End Class
