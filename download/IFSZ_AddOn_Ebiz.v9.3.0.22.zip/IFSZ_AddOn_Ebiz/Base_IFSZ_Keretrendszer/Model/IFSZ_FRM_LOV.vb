Public Class IFSZ_FRM_LOV    Protected Overrides Sub Finalize()
        p_kilepes = True
        MyBase.Finalize()
    End Sub
End Class