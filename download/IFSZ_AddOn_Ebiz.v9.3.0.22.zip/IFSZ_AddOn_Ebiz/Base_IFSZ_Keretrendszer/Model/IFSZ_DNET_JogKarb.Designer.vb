<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class IFSZ_DNET_JogKarb
    'Inherits System.Windows.Forms.Form
    Inherits IFSZ_Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(IFSZ_DNET_JogKarb))
        Me.OK = New System.Windows.Forms.Button()
        Me.MEGSE = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.t_user_code = New System.Windows.Forms.TextBox()
        Me.t_user_name = New System.Windows.Forms.TextBox()
        Me.t_perm_name = New System.Windows.Forms.TextBox()
        Me.t_absid = New System.Windows.Forms.TextBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.mi_full = New System.Windows.Forms.ToolStripMenuItem()
        Me.mi_no = New System.Windows.Forms.ToolStripMenuItem()
        Me.mi_copy = New System.Windows.Forms.ToolStripMenuItem()
        Me.IFSZJogKarbViewBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.t_leiras = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.t_tovabbi_fhok = New System.Windows.Forms.TextBox()
        Me.b_tovabbi_fhok = New System.Windows.Forms.Button()
        Me.DG1_ID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_ABSID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_NAME = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_LEVELS = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_VISORDER = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_OPTIONS = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_ACTION = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_ISITEM = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_FATHID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_TREEORDER = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ContextMenuStrip1.SuspendLayout()
        CType(Me.IFSZJogKarbViewBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'OK
        '
        resources.ApplyResources(Me.OK, "OK")
        Me.OK.Name = "OK"
        Me.OK.UseVisualStyleBackColor = True
        '
        'MEGSE
        '
        resources.ApplyResources(Me.MEGSE, "MEGSE")
        Me.MEGSE.Name = "MEGSE"
        Me.MEGSE.UseVisualStyleBackColor = True
        '
        'Label1
        '
        resources.ApplyResources(Me.Label1, "Label1")
        Me.Label1.Name = "Label1"
        '
        'Label2
        '
        resources.ApplyResources(Me.Label2, "Label2")
        Me.Label2.Name = "Label2"
        '
        't_user_code
        '
        resources.ApplyResources(Me.t_user_code, "t_user_code")
        Me.t_user_code.Name = "t_user_code"
        '
        't_user_name
        '
        resources.ApplyResources(Me.t_user_name, "t_user_name")
        Me.t_user_name.Name = "t_user_name"
        '
        't_perm_name
        '
        resources.ApplyResources(Me.t_perm_name, "t_perm_name")
        Me.t_perm_name.Name = "t_perm_name"
        '
        't_absid
        '
        resources.ApplyResources(Me.t_absid, "t_absid")
        Me.t_absid.Name = "t_absid"
        '
        'DataGridView1
        '
        resources.ApplyResources(Me.DataGridView1, "DataGridView1")
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DG1_ID, Me.DG1_ABSID, Me.DG1_NAME, Me.DG1_LEVELS, Me.DG1_VISORDER, Me.DG1_OPTIONS, Me.DG1_ACTION, Me.DG1_ISITEM, Me.DG1_FATHID, Me.DG1_TREEORDER})
        Me.DataGridView1.ContextMenuStrip = Me.ContextMenuStrip1
        Me.DataGridView1.DataSource = Me.IFSZJogKarbViewBindingSource
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        '
        'ContextMenuStrip1
        '
        resources.ApplyResources(Me.ContextMenuStrip1, "ContextMenuStrip1")
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mi_full, Me.mi_no, Me.mi_copy})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        '
        'mi_full
        '
        resources.ApplyResources(Me.mi_full, "mi_full")
        Me.mi_full.Name = "mi_full"
        '
        'mi_no
        '
        resources.ApplyResources(Me.mi_no, "mi_no")
        Me.mi_no.Name = "mi_no"
        '
        'mi_copy
        '
        resources.ApplyResources(Me.mi_copy, "mi_copy")
        Me.mi_copy.Name = "mi_copy"
        '
        'IFSZJogKarbViewBindingSource
        '
        Me.IFSZJogKarbViewBindingSource.DataSource = GetType(IFSZ_AddOnBase.IFSZ_JogKarb_View)
        '
        't_leiras
        '
        resources.ApplyResources(Me.t_leiras, "t_leiras")
        Me.t_leiras.Name = "t_leiras"
        Me.t_leiras.ReadOnly = True
        '
        'Label3
        '
        resources.ApplyResources(Me.Label3, "Label3")
        Me.Label3.Name = "Label3"
        '
        'Label4
        '
        resources.ApplyResources(Me.Label4, "Label4")
        Me.Label4.Name = "Label4"
        '
        't_tovabbi_fhok
        '
        resources.ApplyResources(Me.t_tovabbi_fhok, "t_tovabbi_fhok")
        Me.t_tovabbi_fhok.Name = "t_tovabbi_fhok"
        Me.t_tovabbi_fhok.ReadOnly = True
        '
        'b_tovabbi_fhok
        '
        resources.ApplyResources(Me.b_tovabbi_fhok, "b_tovabbi_fhok")
        Me.b_tovabbi_fhok.Name = "b_tovabbi_fhok"
        Me.b_tovabbi_fhok.UseVisualStyleBackColor = True
        '
        'DG1_ID
        '
        Me.DG1_ID.DataPropertyName = "ID"
        resources.ApplyResources(Me.DG1_ID, "DG1_ID")
        Me.DG1_ID.Name = "DG1_ID"
        Me.DG1_ID.ReadOnly = True
        '
        'DG1_ABSID
        '
        Me.DG1_ABSID.DataPropertyName = "ABSID"
        resources.ApplyResources(Me.DG1_ABSID, "DG1_ABSID")
        Me.DG1_ABSID.Name = "DG1_ABSID"
        Me.DG1_ABSID.ReadOnly = True
        '
        'DG1_NAME
        '
        Me.DG1_NAME.DataPropertyName = "NAME"
        resources.ApplyResources(Me.DG1_NAME, "DG1_NAME")
        Me.DG1_NAME.Name = "DG1_NAME"
        Me.DG1_NAME.ReadOnly = True
        '
        'DG1_LEVELS
        '
        Me.DG1_LEVELS.DataPropertyName = "LEVELS"
        resources.ApplyResources(Me.DG1_LEVELS, "DG1_LEVELS")
        Me.DG1_LEVELS.Name = "DG1_LEVELS"
        Me.DG1_LEVELS.ReadOnly = True
        '
        'DG1_VISORDER
        '
        Me.DG1_VISORDER.DataPropertyName = "VISORDER"
        resources.ApplyResources(Me.DG1_VISORDER, "DG1_VISORDER")
        Me.DG1_VISORDER.Name = "DG1_VISORDER"
        Me.DG1_VISORDER.ReadOnly = True
        '
        'DG1_OPTIONS
        '
        Me.DG1_OPTIONS.DataPropertyName = "OPTIONS"
        resources.ApplyResources(Me.DG1_OPTIONS, "DG1_OPTIONS")
        Me.DG1_OPTIONS.Name = "DG1_OPTIONS"
        Me.DG1_OPTIONS.ReadOnly = True
        '
        'DG1_ACTION
        '
        Me.DG1_ACTION.DataPropertyName = "ACTION"
        resources.ApplyResources(Me.DG1_ACTION, "DG1_ACTION")
        Me.DG1_ACTION.Name = "DG1_ACTION"
        Me.DG1_ACTION.ReadOnly = True
        '
        'DG1_ISITEM
        '
        Me.DG1_ISITEM.DataPropertyName = "ISITEM"
        resources.ApplyResources(Me.DG1_ISITEM, "DG1_ISITEM")
        Me.DG1_ISITEM.Name = "DG1_ISITEM"
        Me.DG1_ISITEM.ReadOnly = True
        '
        'DG1_FATHID
        '
        Me.DG1_FATHID.DataPropertyName = "FATHID"
        resources.ApplyResources(Me.DG1_FATHID, "DG1_FATHID")
        Me.DG1_FATHID.Name = "DG1_FATHID"
        Me.DG1_FATHID.ReadOnly = True
        '
        'DG1_TREEORDER
        '
        Me.DG1_TREEORDER.DataPropertyName = "TREEORDER"
        resources.ApplyResources(Me.DG1_TREEORDER, "DG1_TREEORDER")
        Me.DG1_TREEORDER.Name = "DG1_TREEORDER"
        Me.DG1_TREEORDER.ReadOnly = True
        '
        'IFSZ_DNET_JogKarb
        '
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.b_tovabbi_fhok)
        Me.Controls.Add(Me.t_tovabbi_fhok)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.t_leiras)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.t_perm_name)
        Me.Controls.Add(Me.t_absid)
        Me.Controls.Add(Me.t_user_name)
        Me.Controls.Add(Me.t_user_code)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.MEGSE)
        Me.Controls.Add(Me.OK)
        Me.Name = "IFSZ_DNET_JogKarb"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ContextMenuStrip1.ResumeLayout(False)
        CType(Me.IFSZJogKarbViewBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents OK As System.Windows.Forms.Button
    Friend WithEvents MEGSE As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents t_user_code As System.Windows.Forms.TextBox
    Friend WithEvents t_user_name As System.Windows.Forms.TextBox
    Friend WithEvents t_perm_name As System.Windows.Forms.TextBox
    Friend WithEvents t_absid As System.Windows.Forms.TextBox
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents t_leiras As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents t_tovabbi_fhok As System.Windows.Forms.TextBox
    Friend WithEvents b_tovabbi_fhok As System.Windows.Forms.Button
    Friend WithEvents IFSZJogKarbViewBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents DG1_FORM_E As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DG1_LEIRAS As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents mi_full As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mi_no As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mi_copy As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DG1_ID As DataGridViewTextBoxColumn
    Friend WithEvents DG1_ABSID As DataGridViewTextBoxColumn
    Friend WithEvents DG1_NAME As DataGridViewTextBoxColumn
    Friend WithEvents DG1_LEVELS As DataGridViewTextBoxColumn
    Friend WithEvents DG1_VISORDER As DataGridViewTextBoxColumn
    Friend WithEvents DG1_OPTIONS As DataGridViewTextBoxColumn
    Friend WithEvents DG1_ACTION As DataGridViewTextBoxColumn
    Friend WithEvents DG1_ISITEM As DataGridViewTextBoxColumn
    Friend WithEvents DG1_FATHID As DataGridViewTextBoxColumn
    Friend WithEvents DG1_TREEORDER As DataGridViewTextBoxColumn
End Class
