Imports System.Globalization
Imports System.Resources
Imports System.Reflection
Imports System.IO
Imports IFSZ_AddOnBase.IFSZ_Types

Partial Class IFSZ_FRM_ARCHIV
    Inherits System.Windows.Forms.Form



#Region "Variables"

    Private P_Title As String
    Friend WithEvents IfszLov As System.Windows.Forms.DataGridView
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Private P_Szuresi_Ertek As String
    Private m_MultiSelect_e As Boolean
    Private m_SetPosition As Boolean
    Private p_Editable As New Collection
    Private p_KeresMod As Boolean = False
    Private p_gomb_allapot As IFSZ_Types.Gomb = IFSZ_Types.Gomb.Ok
    Private p_kilepes As Boolean = False
    Private m_GridHeight As Integer = 0
    Private m_GridWidth As Integer = 0
    Private GridFontSize As Integer = 8
    Private GridRowPixelSize As Integer = 16
    Private p_oszlop As LOV_OszlopTipus
    Private p_NextFocusedColumn As String

    Public anyRight As ContentAlignment = (ContentAlignment.BottomRight _
            Or (ContentAlignment.MiddleRight Or ContentAlignment.TopRight))

    Public anyTop As ContentAlignment = (ContentAlignment.TopRight _
                Or (ContentAlignment.TopCenter Or ContentAlignment.TopLeft))

    Public anyBottom As ContentAlignment = (ContentAlignment.BottomRight _
                Or (ContentAlignment.BottomCenter Or ContentAlignment.BottomLeft))

    Public anyCenter As ContentAlignment = (ContentAlignment.BottomCenter _
                Or (ContentAlignment.MiddleCenter Or ContentAlignment.TopCenter))

    Public anyMiddle As ContentAlignment = (ContentAlignment.MiddleRight _
                Or (ContentAlignment.MiddleCenter Or ContentAlignment.MiddleLeft))

    Private Structure Rendez
        Public oszlop As Integer
        Public irany As String
        Private Sub New(ByVal l_oszlop As String, ByVal l_irany As String)
            Me.oszlop = l_oszlop
            Me.irany = l_irany
        End Sub
    End Structure


    Private l_OszlopTipus() As IFSZ_Types.LOV_OszlopTipus
    Private l_FormAdat As LOV_Form
    Private l_ertek, l_select As String
    Private l_lookup_ertek As String
    Private l_tabla As String
    Private l_matrix As String
    Private oForm_Eredeti As IFSZ_Form
    Private oForm As Windows.Forms.Form
    Private oForm2 As IFSZ_Form
    Private l_sor As Integer
    Private p_validal As Boolean
    Private l_kivalasztott_sor As Integer
    Private l_a1 As String
    Private l_a2 As String
    Private p_rendez As Rendez
    Private l_sorok_szama As Integer
    Private p_select As String
    Private l_colID As String
    Friend l_FormID As String
    Friend l_Link_ertek As String
    Friend l_Osztaly As String
    Public PrevWidth As Integer
    Public PrevHeight As Integer

#End Region

#Region "Constructor"


    Public Sub New(ByRef oEredetiForm As IFSZ_Form, _
                   ByVal P_FormAdat As IFSZ_Types.LOV_Form, _
                   ByVal p_oszlop_tipus() As IFSZ_Types.LOV_OszlopTipus, _
                   ByVal p_select As String)

        oForm_Eredeti = oEredetiForm
        l_FormAdat = P_FormAdat
        ReDim l_OszlopTipus(p_oszlop_tipus.GetUpperBound(0))
        l_OszlopTipus = p_oszlop_tipus

        l_select = p_select
        Me.InitializeComponent()

        'Me.ThreadStarter("SBO")
        'Me.TextBox1.Text = Me.TextBox1.Text

    End Sub

#End Region

#Region "Initialize/Get Dataset"

    Private Sub InitializeComponent()
        Dim p_columname, l_oszlop_nev As String
        Dim i As LOV_OszlopTipus

        Dim index As Integer
        Me.Icon = System.Drawing.Icon.FromHandle(Global.IFSZ_AddOnBase.My.Resources.Resources.ifsz_icon.GetHicon)

        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.SuspendLayout()
        '
        'Form 
        '
        Me.BackColor = System.Drawing.Color.FromArgb(CType(222, Byte), CType(222, Byte), CType(206, Byte))

        If Me.l_FormAdat.Width = 0 Then
            Me.l_FormAdat.Width = 590
        End If

        If Me.l_FormAdat.Height = 0 Then
            Me.l_FormAdat.Height = 365
        End If

        P_Title = "Arh�v"
        Me.Text = Me.l_FormAdat.Title
        Me.Left = 236
        Me.Width = Me.l_FormAdat.Width
        Me.Top = 44
        Me.Height = Me.l_FormAdat.Height

        '
        'DataGridView1
        '
        Me.IfszLov = New System.Windows.Forms.DataGridView
        CType(Me.IfszLov, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.IfszLov.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.IfszLov.MultiSelect = Me.m_MultiSelect_e
        Me.IfszLov.AllowUserToAddRows = False
        Me.IfszLov.Name = "IfszLov"
        Me.IfszLov.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.IfszLov.TabIndex = 3
        Me.IfszLov.Left = 5
        Me.IfszLov.Width = Me.l_FormAdat.Width - 33 '557
        Me.IfszLov.Top = 35
        Me.IfszLov.Height = Me.l_FormAdat.Height - 110 '265

        CType(Me.IfszLov, DataGridView).RowTemplate.Height = 17
        CType(Me.IfszLov, DataGridView).BackgroundColor = System.Drawing.Color.FromArgb(CType(222, Byte), CType(222, Byte), CType(206, Byte))
        'CType(Me.IfszLov, DataGridView).RowTemplate.HeaderCell.Style.BackColor = System.Drawing.Color.FromArgb(CType(205, Byte), CType(205, Byte), CType(190, Byte))
        CType(Me.IfszLov, DataGridView).ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(215, Byte), CType(215, Byte), CType(200, Byte))

        CType(Me.IfszLov, DataGridView).RowTemplate.Height = Me.GridRowPixelSize
        CType(Me.IfszLov, DataGridView).DefaultCellStyle.Font = New System.Drawing.Font("Tahoma", Me.GridFontSize, System.Drawing.FontStyle.Regular)
        CType(Me.IfszLov, DataGridView).DefaultCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
        CType(Me.IfszLov, DataGridView).GridColor = System.Drawing.Color.FromArgb(CType(153, Byte), CType(153, Byte), CType(137, Byte))
        CType(Me.IfszLov, DataGridView).BorderStyle = BorderStyle.None
        CType(Me.IfszLov, DataGridView).BackgroundColor = System.Drawing.Color.FromArgb(CType(222, Byte), CType(222, Byte), CType(206, Byte))
        CType(Me.IfszLov, DataGridView).RowTemplate.HeaderCell.Style.BackColor = System.Drawing.Color.FromArgb(CType(205, Byte), CType(205, Byte), CType(190, Byte))
        CType(Me.IfszLov, DataGridView).ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(215, Byte), CType(215, Byte), CType(200, Byte))
        CType(Me.IfszLov, DataGridView).RowHeadersWidth = 18
        CType(Me.IfszLov, DataGridView).Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                                                    Or System.Windows.Forms.AnchorStyles.Left) _
                                                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)


        '
        'Label1 Keres
        '
        '
        'Button OK
        '
        Me.Button1 = New System.Windows.Forms.Button
        Me.Button1.Left = 5
        Me.Button1.Width = 65
        Me.Button1.Top = Me.l_FormAdat.Height - 65 '310
        Me.Button1.Height = 19
        Me.Button1.Text = "Ok"
        Me.Button1.Name = "OK"
        Me.Button1.TabIndex = 4
        Me.Button1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)

        '
        'Button Cancel
        '
        Me.Button2 = New System.Windows.Forms.Button
        Me.Button2.Left = 75
        Me.Button2.Width = 65
        Me.Button2.Top = Me.l_FormAdat.Height - 65 '310
        Me.Button2.Height = 19
        Me.Button2.Text = "M�gse"
        Me.Button2.Name = "Megse"
        Me.Button2.TabIndex = 5
        Me.Button2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)

        '
        'Column1
        '
        Me.Column1.HeaderText = "Column1"
        Me.Column1.Name = "Column1"
        '
        'Column2
        '
        Me.Column2.HeaderText = "Column2"
        Me.Column2.Name = "Column2"
        '
        'IFSZ_PUB_LOV
        '
        'Me.ClientSize = New System.Drawing.Size(443, 273)
        'Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Button2)
        'Me.Controls.Add(Me.Label1)
        'Me.Controls.Add(Me.IfszLov)


        Me.Name = "IFSZ_FRM_ARCHIV"
        CType(Me.IfszLov, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

        For Each i In l_OszlopTipus
            l_oszlop_nev = i.DbNev
            If i.Link Then
                Dim imgCell As TextAndImageColumn = New TextAndImageColumn
                Me.IfszLov.Columns.Add(imgCell)
                imgCell.Image = Global.IFSZ_AddOnBase.My.Resources.Resources.lefuras_be
                imgCell.Name = l_oszlop_nev
                imgCell.DataPropertyName = l_oszlop_nev
            Else
                Dim imgCell As DataGridViewTextBoxColumn = New DataGridViewTextBoxColumn
                Me.IfszLov.Columns.Add(imgCell)
                imgCell.Name = l_oszlop_nev
                imgCell.DataPropertyName = l_oszlop_nev
            End If

        Next

        Me.IfszLov.DataSource = Me.getDataSet(l_select).Tables.Item(0)
        Dim l As Integer
        Try
            For l = 0 To Me.IfszLov.Columns.Count - 1
                'Me.IfszLov.Columns.Item(l).Visible = False
            Next

        Catch ex As Exception
            l = 1
        End Try

        For Each i In l_OszlopTipus
            l_oszlop_nev = i.DbNev
            'If i.Link = False Then
            '    Me.DataGridView1.Columns.Add(l_oszlop_nev, i.Title)
            'Else
            '    Me.DataGridView1.Columns.Add(l_oszlop_nev, i.Title)
            'End If

            Me.IfszLov.Columns.Item(l_oszlop_nev).HeaderText = i.Title
            Me.IfszLov.Columns.Item(l_oszlop_nev).ReadOnly = True
            Me.IfszLov.Columns.Item(l_oszlop_nev).Visible = i.Visible
            Me.IfszLov.Columns.Item(l_oszlop_nev).ToolTipText = i.Description
            If i.Width <> 0 Then
                Me.IfszLov.Columns.Item(l_oszlop_nev).Width = i.Width
            End If

            If i.Tipus = "NUMBER" Then
                Me.IfszLov.Columns.Item(l_oszlop_nev).DefaultCellStyle.Format = "f2"
                Me.IfszLov.Columns.Item(l_oszlop_nev).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            End If

            If Me.IfszLov.Columns.Item(l_oszlop_nev).Visible Then
                If Me.IfszLov.Columns.Item(l_oszlop_nev).ReadOnly = True Then
                    Me.IfszLov.Columns.Item(l_oszlop_nev).DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(222, Byte), Integer))
                Else
                    Me.IfszLov.Columns.Item(l_oszlop_nev).DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(253, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(243, Byte), Integer))
                    Me.IfszLov.Columns.Item(l_oszlop_nev).DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(156, Byte), Integer))
                End If
            End If

            'oColumn.RightJustified = i.RightJustified
            index += 1
        Next

        CType(Me.Button1, Button).BackgroundImage = Global.IFSZ_AddOnBase.My.Resources.Resources.gomb_hatter
        CType(Me.Button1, Button).Font = New System.Drawing.Font("Tahoma", 8, System.Drawing.FontStyle.Regular)
        CType(Me.Button1, Button).Height = 22
        CType(Me.Button1, Button).TextAlign = ContentAlignment.TopCenter
        CType(Me.Button1, Button).FlatStyle = FlatStyle.Flat
        CType(Me.Button1, Button).BackgroundImageLayout = ImageLayout.Tile

        CType(Me.Button2, Button).BackgroundImage = Global.IFSZ_AddOnBase.My.Resources.Resources.gomb_hatter
        CType(Me.Button2, Button).Font = New System.Drawing.Font("Tahoma", 8, System.Drawing.FontStyle.Regular)
        CType(Me.Button2, Button).Height = 22
        CType(Me.Button2, Button).TextAlign = ContentAlignment.TopCenter
        CType(Me.Button2, Button).FlatStyle = FlatStyle.Flat
        CType(Me.Button2, Button).BackgroundImageLayout = ImageLayout.Tile

        Me.PrevWidth = Me.Width
        Me.PrevHeight = Me.Height

        'Me.Select()
        Me.IfszLov.Show()
        Try
            'Me.ActiveControl = Me.IfszLov
        Catch ex As Exception

        End Try


    End Sub

    Private Sub initialize()

    End Sub


    Public Function getDataSet(ByVal l_select As String) As DataSet
        Dim sqlQuery As String
        Dim dataSet As DataSet = New DataSet

        Try
            sqlQuery = l_select
            If Not Me.l_FormAdat.OrderBy Is Nothing AndAlso Me.l_FormAdat.OrderBy.ToString <> "" Then
                sqlQuery = sqlQuery + " order by " + Me.l_FormAdat.OrderBy.ToString
            End If
            ' Get a data set from the query
            dataSet = DataProvider.GetDataSet(sqlQuery.ToString())

            ' Create variables for data set tables
            Dim Table As DataTable = dataSet.Tables(0)

            Return dataSet

        Finally
            If (Not dataSet Is Nothing) Then
                'System.Runtime.InteropServices.Marshal.ReleaseComObject(dataSet)
                dataSet.Dispose()
            End If

        End Try
    End Function

#End Region

#Region "ItemEvent"

    Public Sub Item_Event(ByVal pEvent As IFSZ_Types.PItemEvent, ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try

            Select Case pEvent

                Case PItemEvent.ItemClick
                    Dim i As Integer
                    Dim index As Integer
                    Dim l_matrix_nev As String
                    Dim l_tabla_nev As String
                    Dim l_type As String
                    Dim l_count As Integer
                    Dim l_str As String
                    Dim p_columname, l_oszlop_nev As String
                    Dim l_oszlop As LOV_OszlopTipus
                    Dim p As DataGridViewCellValidatingEventArgs
                    Dim l_DataSet As New DataSet
                    'CType(e, DataGridViewCellValidatingEventArgs)


                    Select Case sender.name

                        Case "OK"

                            If Me.p_KeresMod = True Then
                                Me.kereses_vege(Me.IfszLov, Me.WhereOsszeallit())
                                Me.GombValtas(IFSZ_Types.Gomb.Ok)
                            Else


                                If (m_MultiSelect_e = False Or Me.IfszLov.SelectedRows.Count = 1) And Me.m_SetPosition = False Then
                                    For Each l_oszlop In l_OszlopTipus
                                        If Not l_oszlop.VNev Is Nothing Then
                                            If l_oszlop.VNev.GetType.Name = "DataGridViewTextBoxCell" Or l_oszlop.VNev.GetType.Name = "TextAndImageCell" Then
                                                CType(l_oszlop.VNev, DataGridViewTextBoxCell).Value = Me.IfszLov.Rows.Item(Me.IfszLov.SelectedRows.Item(0).Index).Cells(l_oszlop.DbNev).FormattedValue
                                                If Me.p_validal Then
                                                    If l_oszlop.ValidalTiltas = False Then
                                                        Me.oForm_Eredeti.controller.Item_Event(PItemEvent.ItemValidate, l_oszlop.VNev, e)
                                                    End If
                                                    'Me.oForm_Eredeti.controller.Item_Event(PItemEvent.ItemValidate, l_oszlop.VNev, e)
                                                End If
                                                If Not CType(l_oszlop.VNev, DataGridViewTextBoxCell).DataGridView.Tag Is Nothing Then
                                                    l_tabla_nev = CType(l_oszlop.VNev, DataGridViewTextBoxCell).DataGridView.Tag.tablename
                                                    'CType(l_oszlop.VNev, DataGridViewTextBoxCell).DataGridView.Tag.set_row(Me.oForm_Eredeti.BindingContext(Me.oForm_Eredeti.p_dataset, l_tabla_nev).Current.row)
                                                    'Me.oForm_Eredeti.BindingContext(Me.oForm_Eredeti.p_dataset, l_tabla_nev).Current.Item(l_oszlop.DbNev) = Me.IfszLov.Rows.Item(Me.IfszLov.SelectedRows.Item(0).Index).Cells(l_oszlop.DbNev).FormattedValue
                                                    Me.oForm_Eredeti.BindingContext(Me.oForm_Eredeti.p_dataset, l_tabla_nev).Current.Item(CType(l_oszlop.VNev, DataGridViewTextBoxCell).DataGridView.Columns.Item(l_oszlop.VNev.columnindex).DataPropertyName) = Me.IfszLov.Rows.Item(Me.IfszLov.SelectedRows.Item(0).Index).Cells(l_oszlop.DbNev).FormattedValue
                                                    CType(CType(l_oszlop.VNev, DataGridViewTextBoxCell).DataGridView.Tag, IFSZ_IEntity).set_row(Me.oForm_Eredeti.BindingContext(Me.oForm_Eredeti.p_dataset, l_tabla_nev).Current.row)
                                                    'CType(CType(l_oszlop.VNev, DataGridViewTextBoxCell).DataGridView.Tag, IFSZ_IEntity).Val_Attribute(CType(l_oszlop.VNev, DataGridViewTextBoxCell).DataGridView.Columns.Item(l_oszlop.VNev.columnindex).Name, Me.IfszLov.Rows.Item(Me.IfszLov.SelectedRows.Item(0).Index).Cells(l_oszlop.DbNev).FormattedValue, "")

                                                    Dim l_colindex As Integer = CType(l_oszlop.VNev, DataGridViewTextBoxCell).ColumnIndex
                                                    Dim j, l_vcolindex As Integer

                                                    l_vcolindex = -1
                                                    For j = l_colindex + 1 To CType(l_oszlop.VNev, DataGridViewTextBoxCell).DataGridView.Columns.Count - 1
                                                        If CType(l_oszlop.VNev, DataGridViewTextBoxCell).DataGridView.CurrentRow.Cells.Item(j).Visible = True Then
                                                            l_vcolindex = j
                                                            Exit For
                                                        End If
                                                    Next

                                                    If l_vcolindex = -1 Then
                                                        For j = 0 To l_colindex - 1
                                                            If CType(l_oszlop.VNev, DataGridViewTextBoxCell).DataGridView.CurrentRow.Cells.Item(j).Visible = True Then
                                                                l_vcolindex = j
                                                                Exit For
                                                            End If
                                                        Next
                                                    End If

                                                    If l_vcolindex > -1 Then
                                                        Dim l_sor_index As Integer
                                                        'CType(Me.oForm_Eredeti, Form4).DataGridView1.CurrentCell() = CType(Me.oForm_Eredeti, Form4).DataGridView1.Rows(0).Cells("ITEMCODE")
                                                        p_oszlop = l_oszlop
                                                        p_vcolindex = l_vcolindex
                                                        l_sor_index = CType(l_oszlop.VNev, DataGridViewTextBoxCell).DataGridView.CurrentRow.Index
                                                        If Me.l_FormAdat.NextFocusedColumn.ToString <> "" Then

                                                        Else
                                                            CType(l_oszlop.VNev, DataGridViewTextBoxCell).DataGridView.CurrentCell() = CType(l_oszlop.VNev, DataGridViewTextBoxCell).DataGridView.CurrentRow.Cells.Item(l_vcolindex)
                                                        End If


                                                    End If

                                                End If


                                                'CType(l_oszlop.VNev, DataGridViewTextBoxCell).DataGridView.Tag.set_row(CType(l_oszlop.VNev, DataGridViewTextBoxCell).DataGridView.CurrentRow)

                                            ElseIf l_oszlop.VNev.GetType.Name = "TextBox" Then
                                                'CType(l_oszlop.VNev, TextBox).Text = Me.IfszLov.Rows.Item(Me.IfszLov.SelectedRows.Item(0).Index).Cells(l_oszlop.DbNev).FormattedValue
                                                Me.oForm_Eredeti.SetText(l_oszlop.VNev, Me.IfszLov.Rows.Item(Me.IfszLov.SelectedRows.Item(0).Index).Cells(l_oszlop.DbNev).FormattedValue)
                                                If Me.p_validal Then
                                                    If l_oszlop.ValidalTiltas = False Then
                                                        Me.oForm_Eredeti.controller.Item_Event(PItemEvent.ItemValidate, l_oszlop.VNev, e)
                                                    End If
                                                End If
                                                If Not CType(l_oszlop.VNev, TextBox).Tag Is Nothing Then
                                                    l_tabla_nev = CType(l_oszlop.VNev, TextBox).Tag.tablename
                                                    CType(CType(l_oszlop.VNev, TextBox).Tag, IFSZ_IEntity).set_row(Me.oForm_Eredeti.BindingContext(Me.oForm_Eredeti.p_dataset, l_tabla_nev).Current.row)
                                                End If
                                                p_oszlop = l_oszlop
                                            ElseIf l_oszlop.VNev.GetType.Name = "LOV_VEntiy" Then
                                                Dim l_ertek As String = Me.IfszLov.Rows.Item(Me.IfszLov.SelectedRows.Item(0).Index).Cells(l_oszlop.DbNev).FormattedValue
                                                l_tabla_nev = CType(CType(l_oszlop.VNev, IFSZ_Types.LOV_VEntiy).Entity, IFSZ_IEntity).TableName
                                                CType(CType(l_oszlop.VNev, IFSZ_Types.LOV_VEntiy).Entity, IFSZ_IEntity).set_item(CType(l_oszlop.VNev, IFSZ_Types.LOV_VEntiy).Oszlop, l_ertek)
                                                'CType(CType(l_oszlop.VNev, TextBox).Tag, IFSZ_IEntity).set_row(Me.oForm_Eredeti.BindingContext(Me.oForm_Eredeti.p_dataset, l_tabla_nev).Current.row)
                                                p_oszlop = l_oszlop
                                            End If
                                        End If
                                    Next

                                ElseIf m_MultiSelect_e = True And Me.IfszLov.SelectedRows.Count > 1 And Me.m_SetPosition = False Then

                                    'Multiselect eset�n egy datasetet �ll�tunk �ssze
                                    If Me.l_FormAdat.SENDER.ToString = "" Then
                                        l_DataSet.Tables.Add("LOV")
                                    Else
                                        l_DataSet.Tables.Add(Me.l_FormAdat.SENDER.ToString)
                                    End If

                                    For Each l_oszlop In l_OszlopTipus
                                        l_DataSet.Tables(0).Columns.Add(l_oszlop.DbNev)
                                    Next

                                    For i = 0 To Me.IfszLov.SelectedRows.Count - 1
                                        l_DataSet.Tables(0).Rows.Add()
                                        For Each l_oszlop In l_OszlopTipus
                                            l_DataSet.Tables(0).Rows(i).Item(l_oszlop.DbNev) = Me.IfszLov.Rows.Item(Me.IfszLov.SelectedRows.Item(i).Index).Cells(l_oszlop.DbNev).Value
                                        Next
                                    Next

                                    '�s ha megvan a dataset, kiv�ltjuk az esem�nyt, ami a h�v� formban el fogja kapni
                                    '�n argumentumk�nt szeretn�m �tadni a datasetet, de nem vil�gos, hogy hogy lehet kezelni a System.EventArgs oszt�lyt, ez�rt mint sender adom �t
                                    Me.oForm_Eredeti.controller.Item_Event(PItemEvent.MultiLovSelected, l_DataSet, e)

                                ElseIf Me.m_MultiSelect_e = False And Me.m_SetPosition = True Then
                                    Me.oForm_Eredeti.set_position(Me.BindingContext(CType(Me.IfszLov.DataSource, DataTable)).Current.row)
                                End If

                                'Me.Dispose()
                                'Exit Sub
                                Me.oForm_Eredeti.p_LovForm = Nothing
                                Me.Dispose()
                                MyBase.Close()
                                'BubbleEvent = True
                                'm_sboform.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE
                                'm_sboform.Close()
                            End If
                        Case "Megse"
                            'Me.p_volt_e_lov = True
                            Me.oForm_Eredeti.p_LovForm = Nothing
                            Me.Dispose()
                            'm_sboform.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE
                            'm_sboform.Close()

                        Case "IfszLov"
                            'If m_sboform.Items.Item(pVal.ItemUID).Type() = SAPbouiCOM.BoFormItemTypes.it_MATRIX And pVal.Row > 0 Then
                            '    oMatrix = Me.m_SboForm.Items.Item("IfszLov").Specific
                            '    oMatrix.SelectionMode = SAPbouiCOM.BoMatrixSelect.ms_Single
                            '    Me.l_kivalasztott_sor = pVal.Row
                            '    oMatrix.SelectRow(pVal.Row, True, False)
                            'End If

                    End Select

                Case PItemEvent.DoubleClick
                    Dim i As Integer
                    Dim index As Integer
                    Dim l_matrix_nev As String
                    Dim l_tabla_nev As String
                    Dim l_type As String
                    Dim l_count As Integer
                    Dim l_str As String
                    Dim p_columname, l_oszlop_nev As String
                    Dim l_oszlop As LOV_OszlopTipus
                    Dim p As DataGridViewCellValidatingEventArgs
                    'CType(e, DataGridViewCellValidatingEventArgs)



                    If (m_MultiSelect_e = False Or Me.IfszLov.SelectedRows.Count = 1) And Me.m_SetPosition = False Then
                        For Each l_oszlop In l_OszlopTipus
                            If Not l_oszlop.VNev Is Nothing Then
                                p_oszlop = l_oszlop
                                If l_oszlop.VNev.GetType.Name = "DataGridViewTextBoxCell" Or l_oszlop.VNev.GetType.Name = "TextAndImageCell" Then
                                    CType(l_oszlop.VNev, DataGridViewTextBoxCell).Value = Me.IfszLov.CurrentRow.Cells(l_oszlop.DbNev).FormattedValue
                                    If Me.p_validal Then
                                        If l_oszlop.ValidalTiltas = False Then
                                            Me.oForm_Eredeti.controller.Item_Event(PItemEvent.ItemValidate, l_oszlop.VNev, e)
                                        End If
                                    End If
                                    If Not CType(l_oszlop.VNev, DataGridViewTextBoxCell).DataGridView.Tag Is Nothing Then
                                        l_tabla_nev = CType(l_oszlop.VNev, DataGridViewTextBoxCell).DataGridView.Tag.tablename
                                        'Me.oForm_Eredeti.BindingContext(Me.oForm_Eredeti.p_dataset, l_tabla_nev).Current.Item(l_oszlop.DbNev) = Me.IfszLov.Rows.Item(Me.IfszLov.SelectedRows.Item(0).Index).Cells(l_oszlop.DbNev).FormattedValue
                                        Try
                                            If Me.oForm_Eredeti.BindingContext(Me.oForm_Eredeti.p_dataset, l_tabla_nev).Current.Item(CType(l_oszlop.VNev, DataGridViewTextBoxCell).DataGridView.Columns.Item(l_oszlop.VNev.columnindex).DataPropertyName).GetType.Name = "DateTime" And Me.IfszLov.Rows.Item(Me.IfszLov.SelectedRows.Item(0).Index).Cells(l_oszlop.DbNev).FormattedValue = "" Then
                                                Me.oForm_Eredeti.BindingContext(Me.oForm_Eredeti.p_dataset, l_tabla_nev).Current.Item(CType(l_oszlop.VNev, DataGridViewTextBoxCell).DataGridView.Columns.Item(l_oszlop.VNev.columnindex).DataPropertyName) = System.DBNull.Value
                                            Else
                                                Me.oForm_Eredeti.BindingContext(Me.oForm_Eredeti.p_dataset, l_tabla_nev).Current.Item(CType(l_oszlop.VNev, DataGridViewTextBoxCell).DataGridView.Columns.Item(l_oszlop.VNev.columnindex).DataPropertyName) = Me.IfszLov.Rows.Item(Me.IfszLov.SelectedRows.Item(0).Index).Cells(l_oszlop.DbNev).FormattedValue
                                            End If

                                        Catch ex As Exception

                                        End Try

                                        CType(CType(l_oszlop.VNev, DataGridViewTextBoxCell).DataGridView.Tag, IFSZ_IEntity).set_row(Me.oForm_Eredeti.BindingContext(Me.oForm_Eredeti.p_dataset, l_tabla_nev).Current.row)
                                        'CType(CType(l_oszlop.VNev, DataGridViewTextBoxCell).DataGridView.Tag, IFSZ_IEntity).set_item()
                                    End If


                                    Dim l_colindex As Integer = CType(l_oszlop.VNev, DataGridViewTextBoxCell).ColumnIndex
                                    Dim j, l_vcolindex As Integer

                                    l_vcolindex = -1
                                    For j = l_colindex + 1 To CType(l_oszlop.VNev, DataGridViewTextBoxCell).DataGridView.Columns.Count - 1
                                        If CType(l_oszlop.VNev, DataGridViewTextBoxCell).DataGridView.CurrentRow.Cells.Item(j).Visible = True Then
                                            l_vcolindex = j
                                            Exit For
                                        End If
                                    Next

                                    If l_vcolindex = -1 Then
                                        For j = 0 To l_colindex - 1
                                            If CType(l_oszlop.VNev, DataGridViewTextBoxCell).DataGridView.CurrentRow.Cells.Item(j).Visible = True Then
                                                l_vcolindex = j
                                                Exit For
                                            End If
                                        Next
                                    End If

                                    If l_vcolindex > -1 Then
                                        'CType(Me.oForm_Eredeti, Form4).DataGridView1.CurrentCell() = CType(Me.oForm_Eredeti, Form4).DataGridView1.Rows(0).Cells("ITEMCODE")
                                        'CType(l_oszlop.VNev, DataGridViewTextBoxCell).DataGridView.CurrentCell() = CType(l_oszlop.VNev, DataGridViewTextBoxCell).DataGridView.CurrentRow.Cells.Item(l_vcolindex)
                                        If Me.l_FormAdat.NextFocusedColumn.ToString <> "" Then


                                        Else
                                            CType(l_oszlop.VNev, DataGridViewTextBoxCell).DataGridView.CurrentCell() = CType(l_oszlop.VNev, DataGridViewTextBoxCell).DataGridView.CurrentRow.Cells.Item(l_vcolindex)
                                        End If

                                    End If

                                    'CType(l_oszlop.VNev, DataGridViewTextBoxCell).DataGridView.Tag.set_row(CType(l_oszlop.VNev, DataGridViewTextBoxCell).DataGridView.CurrentRow)

                                ElseIf l_oszlop.VNev.GetType.Name = "TextBox" Then
                                    'CType(l_oszlop.VNev, TextBox).Text = Me.IfszLov.CurrentRow.Cells(l_oszlop.DbNev).FormattedValue
                                    Me.oForm_Eredeti.SetText(l_oszlop.VNev, Me.IfszLov.Rows.Item(Me.IfszLov.SelectedRows.Item(0).Index).Cells(l_oszlop.DbNev).FormattedValue)
                                    If Me.p_validal Then
                                        If l_oszlop.ValidalTiltas = False Then
                                            Me.oForm_Eredeti.controller.Item_Event(PItemEvent.ItemValidate, l_oszlop.VNev, e)
                                        End If
                                    End If
                                    If Not CType(l_oszlop.VNev, TextBox).Tag Is Nothing Then
                                        l_tabla_nev = CType(l_oszlop.VNev, TextBox).Tag.tablename
                                        CType(CType(l_oszlop.VNev, TextBox).Tag, IFSZ_IEntity).set_row(Me.oForm_Eredeti.BindingContext(Me.oForm_Eredeti.p_dataset, l_tabla_nev).Current.row)
                                    End If
                                ElseIf l_oszlop.VNev.GetType.Name = "LOV_VEntiy" Then
                                    Dim l_ertek As String = Me.IfszLov.Rows.Item(Me.IfszLov.SelectedRows.Item(0).Index).Cells(l_oszlop.DbNev).FormattedValue
                                    l_tabla_nev = CType(CType(l_oszlop.VNev, IFSZ_Types.LOV_VEntiy).Entity, IFSZ_IEntity).TableName
                                    CType(CType(l_oszlop.VNev, IFSZ_Types.LOV_VEntiy).Entity, IFSZ_IEntity).set_item(CType(l_oszlop.VNev, IFSZ_Types.LOV_VEntiy).Oszlop, l_ertek)
                                    'CType(CType(l_oszlop.VNev, TextBox).Tag, IFSZ_IEntity).set_row(Me.oForm_Eredeti.BindingContext(Me.oForm_Eredeti.p_dataset, l_tabla_nev).Current.row)
                                End If
                            End If
                        Next

                        If Me.l_FormAdat.NextFocusedColumn.ToString <> "" Then
                            For Each l_oszlop In l_OszlopTipus
                                If Not l_oszlop.VNev Is Nothing Then
                                    CType(l_oszlop.VNev, DataGridViewTextBoxCell).DataGridView.CurrentCell() = CType(l_oszlop.VNev, DataGridViewTextBoxCell).DataGridView.CurrentRow.Cells.Item(Me.l_FormAdat.NextFocusedColumn.ToString)
                                    Exit For
                                End If
                            Next

                        End If


                        Me.oForm_Eredeti.p_LovForm = Nothing

                        Me.Dispose()
                        'Me.Close()

                        'BubbleEvent = True
                        'm_sboform.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE
                        'm_sboform.Close()
                    ElseIf Me.m_MultiSelect_e = False And Me.m_SetPosition = True Then
                        Me.oForm_Eredeti.set_position(Me.BindingContext(CType(Me.IfszLov.DataSource, DataTable)).Current.row)
                    End If

                Case PItemEvent.GotFocus

                    'If m_sboform.Items.Item(pVal.ItemUID).Type() = SAPbouiCOM.BoFormItemTypes.it_MATRIX And pVal.Row > 0 Then
                    '    Me.l_kivalasztott_sor = pVal.Row
                    '    oMatrix = Me.m_SboForm.Items.Item("IfszLov").Specific
                    '    oMatrix.SelectRow(pVal.Row, True, False)
                    'End If

                Case PItemEvent.KeyPressed
                    Dim l_ertek As String
                    Dim l_string As String
                    Static Dim l_string_elozo As String = ""
                    Static Dim index As Integer = 1
                    Dim i As Integer
                    Dim l_pos As Integer
                    Dim l_ind As Integer
                    Dim p_cell As DataGridViewTextBoxCell

                    If sender.GetType.Name.ToString = "TextBox" Then
                        l_string = sender.text + CType(e, System.Windows.Forms.KeyPressEventArgs).KeyChar

                        If l_string.Length < l_string_elozo.Length Then
                            index = 1
                        End If
                        l_string_elozo = l_string

                        For i = 1 To Me.IfszLov.RowCount
                            l_ertek = Me.IfszLov.Item(p_rendez.oszlop, i).FormattedValue
                            l_pos = InStr(1, l_ertek.ToUpper, l_string.ToUpper)
                            Dim p_table_index As Integer
                            If l_pos = 1 Then
                                Me.IfszLov.FirstDisplayedScrollingRowIndex = i
                                Me.IfszLov.Rows.Item(i).Selected = True
                                p_table_index = CType(Me.IfszLov.DataSource, DataTable).Rows.IndexOf(CType(Me.IfszLov.Rows.Item(i).DataBoundItem, DataRowView).Row)
                                Me.BindingContext(CType(Me.IfszLov.DataSource, DataTable)).Position = i
                                Me.l_kivalasztott_sor = i
                                index = i
                                Exit Sub
                            End If

                        Next

                        'Case SAPbouiCOM.BoEventTypes.et_MATRIX_LINK_PRESSED
                        '    link_pressed(pVal.ItemUID, pVal.ColUID, pVal.Row)
                    Else
                        Me.Item_Event(PItemEvent.DoubleClick, sender, e)
                    End If
            End Select


        Catch ex As Exception

            'm_ParentAddon.BlockEvents = False
        End Try

    End Sub

#End Region

#Region "Link"

    Public Sub link_pressed(ByVal l_ColUID As String, ByVal l_Row As Integer, ByVal p_ertek As String)
        Dim l_index As String
        Dim p_osztaly As String
        Dim oArgs() As Object = {Me.oForm_Eredeti.m_ParentAddon, ""}
        Dim oForm As SboForm
        Dim Dummy As New IFSZ_Dummy_Addonbase

        l_index = l_ColUID

        If Me.l_OszlopTipus(CInt(l_index)).MenuUID > 0 Then
            Me.l_Link_ertek = p_ertek
            Me.l_colID = l_ColUID
            Me.l_FormID = Me.l_OszlopTipus(CInt(l_index)).FormUID
            Me.l_Osztaly = Me.l_OszlopTipus(CInt(l_index)).LinkOsztaly
            Me.oForm_Eredeti.m_ParentAddon.SboApplication.ActivateMenuItem(Me.l_OszlopTipus(CInt(l_index)).MenuUID)

        Else
            p_osztaly = Me.l_OszlopTipus(CInt(l_index)).LinkOsztaly

            oForm = [Assembly].GetExecutingAssembly.CreateInstance( _
                                           p_osztaly, _
                                           True, _
                                           BindingFlags.Public Or BindingFlags.Instance Or BindingFlags.CreateInstance, _
                                           Nothing, _
                                           oArgs, _
                                           Nothing, _
                                           Nothing)
            If (oForm Is Nothing) Then
                oForm = [Assembly].GetAssembly(Dummy.GetType()).CreateInstance( _
                                                                           p_osztaly, _
                                                                           True, _
                                                                           BindingFlags.Public Or BindingFlags.Instance Or BindingFlags.CreateInstance, _
                                                                           Nothing, _
                                                                           oArgs, _
                                                                           Nothing, _
                                                                           Nothing)
            End If
            If (Not oForm Is Nothing) Then
                ' If got an instance, add to our list
                Me.oForm_Eredeti.m_ParentAddon.SBOForms.Add(oForm, oForm.UniqueID)
            End If

        End If

    End Sub

#End Region

#Region "Query"

    Friend Sub GombValtas(ByVal p_tipus As IFSZ_Types.Gomb)
        Dim p_button As Windows.Forms.Button
        p_button = CType(Me.Controls.Item("OK"), Windows.Forms.Button)
        If p_tipus = IFSZ_Types.Gomb.Aktualizal Then
            If Me.p_gomb_allapot = IFSZ_Types.Gomb.Ok Then
                p_button.Text = "Aktualiz�l"
                Me.p_gomb_allapot = IFSZ_Types.Gomb.Aktualizal
            End If
        ElseIf p_tipus = IFSZ_Types.Gomb.Keres Then
            p_button.Text = "Keres"
            Me.p_gomb_allapot = IFSZ_Types.Gomb.Keres
        ElseIf p_tipus = IFSZ_Types.Gomb.Ok Then
            If Me.p_gomb_allapot = IFSZ_Types.Gomb.Aktualizal Then
                p_button.Text = "OK"
                Me.p_gomb_allapot = IFSZ_Types.Gomb.Ok
            ElseIf Me.p_gomb_allapot = IFSZ_Types.Gomb.Keres Then
                p_button.Text = "OK"
                Me.p_gomb_allapot = IFSZ_Types.Gomb.Ok
            End If
        End If

    End Sub

    Private Function get_Type(ByVal p_name As String) As String
        Dim i As LOV_OszlopTipus
        For Each i In l_OszlopTipus
            If i.DbNev = p_name Then
                Return i.Tipus
            End If
        Next
        Return "STRING"
    End Function

    Private Sub kereses_kezd(ByVal sender As Object)
        Dim p_eredmeny As MsgBoxResult
        Dim p_ctrl As Control
        Dim p_cell As DataColumnCollection
        Dim i As Integer

        Me.p_KeresMod = True

        CType(Me.IfszLov.DataSource, DataTable).Clear()

        If Not Me.p_Editable Is Nothing Then
            Me.p_Editable.Clear()
        End If
        p_ctrl = Me.IfszLov
        Select Case p_ctrl.GetType.Name
            Case "DataGridView"
                If CType(p_ctrl, DataGridView).Rows.Count = 0 Then
                    CType(CType(p_ctrl, DataGridView).DataSource, DataTable).Rows.Add()
                End If
                For i = 0 To CType(p_ctrl, DataGridView).Rows(0).Cells.Count - 1
                    If CType(p_ctrl, DataGridView).Columns(i).IsDataBound Then
                        CType(p_ctrl, DataGridView).Rows(0).Cells(i).Style.BackColor = Color.LightGreen
                        Me.p_Editable.Add(CType(p_ctrl, DataGridView).Rows(0).Cells(i).ReadOnly, CType(p_ctrl, DataGridView).Columns(i).Name)
                        CType(p_ctrl, DataGridView).Rows(0).Cells(i).ReadOnly = False
                    End If
                Next

        End Select
    End Sub

    Private Function WhereOsszeallit() As String
        Dim p_ctrl As Control
        Dim p_where As String
        Dim i As Integer
        Dim p_ertek As String
        Dim p_feltetel_szam As Integer = 0

        'p_where = "WHERE "

        p_ctrl = Me.IfszLov
        For i = 0 To CType(p_ctrl, DataGridView).Rows(0).Cells.Count - 1
            p_ertek = Me.get_item_value(p_ctrl.Name, CType(p_ctrl, DataGridView).Columns(i).Name, 0)
            If Me.get_Type(CType(p_ctrl, DataGridView).Columns(i).DataPropertyName) = "DATE" Then
                'p_ertek = "convert(nvarchar," + ItmsGrpCod)
                If p_ertek <> "" Then
                    p_ertek = IFSZ_Globals.DateTimeToString(p_ertek)
                End If
            End If
            If CType(p_ctrl, DataGridView).Columns(i).IsDataBound And CType(p_ctrl, DataGridView).Columns(i).Visible And p_ertek <> "" Then
                If p_feltetel_szam > 0 Then
                    p_where = p_where & " and "
                End If
                If p_ertek.Length > 1 Then
                    If p_ertek.Substring(p_ertek.Length - 1, 1) = "%" Or p_ertek.Substring(1, 1) = "%" Then
                        p_where = p_where & CType(p_ctrl, DataGridView).Columns(i).DataPropertyName & " like '" & p_ertek & "' "
                    ElseIf p_ertek.Substring(p_ertek.Length - 1, 1) = "*" Or p_ertek.Substring(1, 1) = "*" Then
                        p_where = p_where & CType(p_ctrl, DataGridView).Columns(i).DataPropertyName & " like '" & p_ertek.Replace("*", "%") & "' "
                    Else
                        p_where = p_where & CType(p_ctrl, DataGridView).Columns(i).DataPropertyName & " = '" & p_ertek & "' "
                    End If
                Else
                    If p_ertek <> "*" And p_ertek <> "%" Then
                        p_where = p_where & CType(p_ctrl, DataGridView).Columns(i).DataPropertyName & " = '" & p_ertek & "' "
                    End If
                End If
                p_feltetel_szam += 1
            End If
        Next
        Return p_where
    End Function

    Private Function QueryUpdate(ByVal p_where As String) As String
        Dim p_select, VisszaSelect As String
        p_select = l_select
        VisszaSelect = l_select
        p_select = p_select.ToUpper()
        Dim l_order_by As String = ""
        If p_select.IndexOf("ORDER BY") > 0 Then
            l_order_by = " " + VisszaSelect.Substring(p_select.IndexOf("ORDER BY"))
            VisszaSelect = VisszaSelect.Substring(0, p_select.IndexOf("ORDER BY") - 1)
        End If
        If p_where = "" Or p_where = " " Then
            Return l_select
        End If
        If p_select.IndexOf("WHERE") > 0 Then
            VisszaSelect = VisszaSelect + " and " + p_where
        Else
            VisszaSelect = VisszaSelect + " where " + p_where
        End If
        Return VisszaSelect + l_order_by
    End Function

    Private Sub kereses_vege(ByVal sender As Object, ByVal p_where As String)
        Dim p_ctrl As Control
        Dim i As Integer

        Me.p_KeresMod = False

        Try

            CType(Me.IfszLov.DataSource, DataTable).Clear()
            CType(Me.IfszLov.DataSource, DataTable).Merge(Me.getDataSet(Me.QueryUpdate(p_where)).Tables.Item(0))

            p_ctrl = Me.IfszLov
            If CType(p_ctrl, DataGridView).Rows.Count = 0 Then
                CType(CType(p_ctrl, DataGridView).DataSource.tables(sender.tag.TableName), DataTable).Rows.Add()
            End If
            For i = 0 To CType(p_ctrl, DataGridView).Columns.Count - 1
                If CType(p_ctrl, DataGridView).Columns(i).IsDataBound Then
                    CType(p_ctrl, DataGridView).Columns.Item(i).ReadOnly = Me.p_Editable.Item(CType(p_ctrl, DataGridView).Columns(i).Name)
                End If
            Next


        Catch ex As Exception
            'Me.show_error("IFSZ_01005", ex.ToString())
        Finally
            'Me.p_LekerdezesFut = False
        End Try

    End Sub

    Friend Function get_item_value(ByVal p_item As String, Optional ByVal p_oszlop As String = "", Optional ByVal p_sor As Integer = 0, Optional ByVal lookup_e As Boolean = False)
        Select Case Me.Controls(p_item).GetType.Name
            Case "DataGridView"
                Try
                    If CType(Me.Controls(p_item), DataGridView).Item(p_oszlop, p_sor).GetType.ToString = "System.Drawing.Bitmap" Or CType(Me.Controls(p_item), DataGridView).Item(p_oszlop, p_sor).GetType.ToString = "System.Windows.Forms.DataGridViewImageCell" Then
                        Return ""
                    End If
                    Return CType(Me.Controls(p_item), DataGridView).Item(p_oszlop, p_sor).FormattedValue
                Catch ex As Exception
                    Return ""
                End Try

            Case "TextBox"

        End Select

    End Function

#End Region

#Region "Events"

    Public Sub FormResize(ByVal sender As Object, ByVal e As EventArgs)
        ' Assume DataGrid DataSource is a DataSet that
        ' contains at least one table.

        If Me.PrevWidth = 0 Then
            Me.PrevWidth = Me.Width
            Me.PrevHeight = Me.Height
        End If
        If Me.PrevWidth = Me.Width Or Me.Width = 0 Then
            Exit Sub
        End If

        'If dg.TableStyles.Count > 0 Then
        '    dg.TableStyles.Clear()
        'End If
        Dim prevSumWidths As Single = 0.0F
        Dim maxHeight As Integer = 0
        Dim calcH As Integer = 0

        Dim col As GridColumnStylesCollection
        'col = dg.Columns(1) 'dg.DataGridViewControlCollection() 'dg.TableStyles(0).GridColumnStyles

        'Dim col As DataColumn

        Me.Button1.Top = Me.Height - 55
        Me.Button2.Top = Me.Height - 55

        Dim l_all As Double
        l_all = ((Me.Top + Me.PrevHeight) - (Me.IfszLov.Top + Me.IfszLov.Height))
        'Me.IfszLov.Top = (Me.Top + Me.Height) - (l_all + Me.IfszLov.Height * (Me.Height / Me.PrevHeight))
        If Me.IfszLov.Width > 0 Then
            Me.m_GridWidth = Me.IfszLov.Width
        End If
        If Me.IfszLov.Height > 0 Then
            Me.m_GridHeight = Me.IfszLov.Height
        End If
        Me.m_GridWidth = Me.m_GridWidth + (Me.Width - Me.PrevWidth)
        Me.m_GridHeight = Me.m_GridHeight + (Me.Height - Me.PrevHeight)
        Me.IfszLov.Size = New Size(Me.m_GridWidth, Me.m_GridHeight)

        Me.PrevWidth = Me.Width
        Me.PrevHeight = Me.Height

    End Sub

    Private Sub OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Item_Event(PItemEvent.ItemClick, sender, e)
    End Sub

    Private Sub Megse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Item_Event(PItemEvent.ItemClick, sender, e)
    End Sub

    Private Sub TextBox1_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox1.KeyPress
        Me.Item_Event(PItemEvent.KeyPressed, sender, e)
    End Sub

    Private Sub DataGrid1_ColumnHeaderMouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles IfszLov.ColumnHeaderMouseClick
        Dim t As Integer
        t = 0
        p_rendez.oszlop = e.ColumnIndex
    End Sub

    Private Sub DataGrid1_RowHeaderMouseDoubleClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles IfszLov.RowHeaderMouseDoubleClick
        Me.Item_Event(PItemEvent.DoubleClick, sender, e)
    End Sub

    Private Sub DataGrid1_CellDoubleClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles IfszLov.CellDoubleClick
        Me.Item_Event(PItemEvent.DoubleClick, sender, e)
    End Sub

    Private Sub DataGridView1_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles IfszLov.KeyPress
        'Me.Item_Event(PItemEvent.KeyPressed, sender, e)
    End Sub

    Private Sub DataGridView1_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles IfszLov.KeyDown
        If e.KeyCode = Keys.Enter Then
            Me.Item_Event(PItemEvent.KeyPressed, sender, e)
        End If

    End Sub

    Private Sub KeyUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        Select Case CType(e, System.Windows.Forms.KeyEventArgs).KeyCode
            Case Keys.F7
                Me.kereses_kezd(Me.IfszLov)
                Me.GombValtas(IFSZ_Types.Gomb.Keres)
            Case Keys.F8
                If Me.p_KeresMod = True Then
                    Me.kereses_vege(Me.IfszLov, Me.WhereOsszeallit())
                    Me.GombValtas(IFSZ_Types.Gomb.Ok)
                End If
        End Select
    End Sub

    Private Sub DataGridView1_KeyUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles IfszLov.KeyUp
        Select Case CType(e, System.Windows.Forms.KeyEventArgs).KeyCode
            Case Keys.F7
                Me.kereses_kezd(sender)
                Me.GombValtas(IFSZ_Types.Gomb.Keres)
            Case Keys.F8
                If Me.p_KeresMod = True Then
                    Me.kereses_vege(Me.IfszLov, Me.WhereOsszeallit())
                    Me.GombValtas(IFSZ_Types.Gomb.Ok)
                End If
        End Select
    End Sub

    Private p_row_index As Integer
    Private p_col_index As Integer

    Private Sub DataGridView1_CellDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles IfszLov.CellMouseDown
        If e.ColumnIndex >= 0 Then
            If Me.IfszLov.Columns(e.ColumnIndex).GetType.Name = "TextAndImageColumn" _
            AndAlso e.RowIndex >= 0 Then
                If e.X < CType(CType(sender, DataGridView).CurrentRow.Cells.Item(e.ColumnIndex), TextAndImageCell).Image.Size.Width Then
                    p_row_index = e.RowIndex
                    p_col_index = e.ColumnIndex
                End If
            End If
        End If

    End Sub

    Private Sub DataGridView1_CellClick1(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles IfszLov.CellMouseUp
        If e.ColumnIndex >= 0 Then
            If Me.IfszLov.Columns(e.ColumnIndex).GetType.Name = "TextAndImageColumn" _
            AndAlso e.RowIndex >= 0 Then
                If e.X < CType(CType(sender, DataGridView).CurrentCell, TextAndImageCell).Image.Size.Width And p_row_index = e.RowIndex And p_col_index = e.ColumnIndex Then

                    Try
                        Me.link_pressed(e.ColumnIndex, e.RowIndex, CType(sender, DataGridView).CurrentCell.FormattedValue)
                        p_row_index = 0
                        p_col_index = 0
                        Me.TopMost = False
                    Finally

                    End Try

                End If
            End If
        End If
    End Sub

    Private Sub Form_Deactivated(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Me.Disposed
        Dim i As Integer
        'Me.oForm_Eredeti.p_LovForm.Dispose(True)
        Me.Dispose(True)
        Me.oForm_Eredeti.p_LovForm = Nothing
        Me.p_kilepes = True
    End Sub

    Private Sub ItemGrid_CellPaintingEvent(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellPaintingEventArgs) Handles IfszLov.CellPainting
        DataGridView_CellPainting(sender, e)
    End Sub

    Private Sub Form_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim p_columname, l_oszlop_nev As String
        Dim i As LOV_OszlopTipus
        Dim index As Integer

        Me.IfszLov.Select()
        Me.ActiveControl = Me.IfszLov

        Exit Sub
        For Each i In l_OszlopTipus
            l_oszlop_nev = i.DbNev

            If Me.IfszLov.Columns.Item(l_oszlop_nev).Visible = True Then
                Me.IfszLov.CurrentCell = Me.IfszLov.Item(l_oszlop_nev, 0)
                Me.ActiveControl = Me.IfszLov
                Exit Sub
            End If
        Next
    End Sub

    Private Sub FormClose(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Me.Disposed

        If Not p_oszlop.VNev Is Nothing Then
            If p_oszlop.VNev.GetType.Name = "DataGridViewTextBoxCell" Or p_oszlop.VNev.GetType.Name = "TextAndImageCell" Then
                Me.oForm_Eredeti.ActiveControl = CType(p_oszlop.VNev, DataGridViewTextBoxCell).DataGridView
                Me.oForm_Eredeti.Activate()
            End If
        End If
    End Sub

#End Region

#Region "Private"

    Private Sub DataGridView_CellPainting(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellPaintingEventArgs)
        If e.RowIndex = -1 Then
            Dim img As Image
            img = My.Resources.gomb_hatter
            TekenAchtergrond(e.Graphics, img, e.CellBounds, 1)
            Dim format1 As StringFormat
            format1 = New StringFormat
            format1.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.Show
            Dim ef1 As SizeF = e.Graphics.MeasureString(e.Value, Me.Font, New SizeF(CType(e.CellBounds.Width, Single), CType(e.CellBounds.Height, Single)), format1)

            Dim txts As Size
            txts = Drawing.Size.Empty

            txts = Drawing.Size.Ceiling(ef1)
            e.CellBounds.Inflate(-4, -4)

            Dim txtr As Rectangle = e.CellBounds
            txtr = HAlignWithin(txts, txtr, ContentAlignment.MiddleLeft)
            txtr = VAlignWithin(txts, txtr, ContentAlignment.MiddleCenter)
            Dim brush2 As Brush
            format1 = New StringFormat
            format1.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.Show

            brush2 = New SolidBrush(Color.Black)

            e.Graphics.DrawString(e.Value, Me.Font, brush2, CType(txtr, RectangleF), format1)
            brush2.Dispose()
            Dim recBorder As New Rectangle(e.CellBounds.X - 1, e.CellBounds.Y, e.CellBounds.Width, e.CellBounds.Height - 1)
            e.Graphics.DrawRectangle(Pens.LightSlateGray, recBorder)

            e.Handled = True
        End If
    End Sub


    Private Sub TekenAchtergrond(ByVal g As Graphics, ByVal obj As Image, ByVal r As Rectangle, ByVal index As Integer)
        If (obj Is Nothing) Then
            Return
        End If
        Dim oWidth As Integer = obj.Width
        Dim lr As Rectangle = Rectangle.FromLTRB(0, 0, 0, 0)
        Dim r2 As Rectangle
        Dim r1 As Rectangle
        Dim x As Integer = ((index - 1) _
                    * oWidth)
        Dim y As Integer = 0
        Dim x1 As Integer = r.Left
        Dim y1 As Integer = r.Top
        If ((r.Height > obj.Height) _
                    AndAlso (r.Width <= oWidth)) Then
            g.DrawImage(obj, r)
            'r1 = New Rectangle(x, y, oWidth, lr.Top)
            'r2 = New Rectangle(x1, y1, r.Width, lr.Top)
            'g.DrawImage(obj, r2, r1, GraphicsUnit.Pixel)
            'r1 = New Rectangle(x, (y + lr.Top), oWidth, (obj.Height _
            '                - (lr.Top - lr.Bottom)))
            'r2 = New Rectangle(x1, (y1 + lr.Top), r.Width, (r.Height _
            '                - (lr.Top - lr.Bottom)))
            'If ((lr.Top + lr.Bottom) _
            '            = 0) Then
            '    r1.Height = (r1.Height - 1)
            'End If
            'g.DrawImage(obj, r2, r1, GraphicsUnit.Pixel)
            'r1 = New Rectangle(x, (y _
            '                + (obj.Height - lr.Bottom)), oWidth, lr.Bottom)
            'r2 = New Rectangle(x1, (y1 _
            '                + (r.Height - lr.Bottom)), r.Width, lr.Bottom)
            'g.DrawImage(obj, r2, r1, GraphicsUnit.Pixel)
        ElseIf ((r.Height <= obj.Height) _
                    AndAlso (r.Width > oWidth)) Then
            r1 = New Rectangle(x, y, lr.Left, obj.Height)
            r2 = New Rectangle(x1, y1, lr.Left, r.Height)
            g.DrawImage(obj, r2, r1, GraphicsUnit.Pixel)
            r1 = New Rectangle((x + lr.Left), y, (oWidth _
                            - (lr.Left - lr.Right)), obj.Height)
            r2 = New Rectangle((x1 + lr.Left), y1, (r.Width _
                            - (lr.Left - lr.Right)), r.Height)
            g.DrawImage(obj, r2, r1, GraphicsUnit.Pixel)
            r1 = New Rectangle((x _
                            + (oWidth - lr.Right)), y, lr.Right, obj.Height)
            r2 = New Rectangle((x1 _
                            + (r.Width - lr.Right)), y1, lr.Right, r.Height)
            g.DrawImage(obj, r2, r1, GraphicsUnit.Pixel)
        ElseIf ((r.Height <= obj.Height) _
                    AndAlso (r.Width <= oWidth)) Then
            r1 = New Rectangle(((index - 1) _
                            * oWidth), 0, oWidth, (obj.Height - 1))

            g.DrawImage(obj, New Rectangle(x1, y1, r.Width, r.Height), r1, GraphicsUnit.Pixel)
        ElseIf ((r.Height > obj.Height) _
                    AndAlso (r.Width > oWidth)) Then
            'top-left
            r1 = New Rectangle(x, y, lr.Left, lr.Top)
            r2 = New Rectangle(x1, y1, lr.Left, lr.Top)
            g.DrawImage(obj, r)
            'g.DrawImage(obj, r2, r1, GraphicsUnit.Pixel)
            ''top-bottom
            'r1 = New Rectangle(x, (y _
            '                + (obj.Height - lr.Bottom)), lr.Left, lr.Bottom)
            'r2 = New Rectangle(x1, (y1 _
            '                + (r.Height - lr.Bottom)), lr.Left, lr.Bottom)
            'g.DrawImage(obj, r2, r1, GraphicsUnit.Pixel)
            ''left
            'r1 = New Rectangle(x, (y + lr.Top), lr.Left, (obj.Height _
            '                - (lr.Top - lr.Bottom)))
            'r2 = New Rectangle(x1, (y1 + lr.Top), lr.Left, (r.Height _
            '                - (lr.Top - lr.Bottom)))
            'g.DrawImage(obj, r2, r1, GraphicsUnit.Pixel)
            ''top
            'r1 = New Rectangle((x + lr.Left), y, (oWidth _
            '                - (lr.Left - lr.Right)), lr.Top)
            'r2 = New Rectangle((x1 + lr.Left), y1, (r.Width _
            '                - (lr.Left - lr.Right)), lr.Top)
            'g.DrawImage(obj, r2, r1, GraphicsUnit.Pixel)
            ''right-top
            'r1 = New Rectangle((x _
            '                + (oWidth - lr.Right)), y, lr.Right, lr.Top)
            'r2 = New Rectangle((x1 _
            '                + (r.Width - lr.Right)), y1, lr.Right, lr.Top)
            'g.DrawImage(obj, r2, r1, GraphicsUnit.Pixel)
            ''Right
            'r1 = New Rectangle((x _
            '                + (oWidth - lr.Right)), (y + lr.Top), lr.Right, (obj.Height _
            '                - (lr.Top - lr.Bottom)))
            'r2 = New Rectangle((x1 _
            '                + (r.Width - lr.Right)), (y1 + lr.Top), lr.Right, (r.Height _
            '                - (lr.Top - lr.Bottom)))
            'g.DrawImage(obj, r2, r1, GraphicsUnit.Pixel)
            ''right-bottom
            'r1 = New Rectangle((x _
            '                + (oWidth - lr.Right)), (y _
            '                + (obj.Height - lr.Bottom)), lr.Right, lr.Bottom)
            'r2 = New Rectangle((x1 _
            '                + (r.Width - lr.Right)), (y1 _
            '                + (r.Height - lr.Bottom)), lr.Right, lr.Bottom)
            'g.DrawImage(obj, r2, r1, GraphicsUnit.Pixel)
            ''bottom
            'r1 = New Rectangle((x + lr.Left), (y _
            '                + (obj.Height - lr.Bottom)), (oWidth _
            '                - (lr.Left - lr.Right)), lr.Bottom)
            'r2 = New Rectangle((x1 + lr.Left), (y1 _
            '                + (r.Height - lr.Bottom)), (r.Width _
            '                - (lr.Left - lr.Right)), lr.Bottom)
            'g.DrawImage(obj, r2, r1, GraphicsUnit.Pixel)
            ''Center
            'r1 = New Rectangle((x + lr.Left), (y + lr.Top), (oWidth _
            '                - (lr.Left - lr.Right)), (obj.Height _
            '                - (lr.Top - lr.Bottom)))
            'r2 = New Rectangle((x1 + lr.Left), (y1 + lr.Top), (r.Width _
            '                - (lr.Left - lr.Right)), (r.Height _
            '                - (lr.Top - lr.Bottom)))
            'g.DrawImage(obj, r2, r1, GraphicsUnit.Pixel)
        End If
    End Sub

    Private Function HAlignWithin(ByVal alignThis As Size, ByVal withinThis As Rectangle, ByVal align As ContentAlignment) As Rectangle
        If ((align And anyRight) _
                    <> CType(0, ContentAlignment)) Then
            withinThis.X = (withinThis.X _
                        + (withinThis.Width - alignThis.Width))
        ElseIf ((align And anyCenter) _
                    <> CType(0, ContentAlignment)) Then
            withinThis.X = (withinThis.X _
                        + (((withinThis.Width - alignThis.Width) _
                        + 1) _
                        / 2))
        End If
        withinThis.Width = alignThis.Width
        Return withinThis
    End Function

    Private Function VAlignWithin(ByVal alignThis As Size, ByVal withinThis As Rectangle, ByVal align As ContentAlignment) As Rectangle
        If ((align And anyBottom) _
                    <> CType(0, ContentAlignment)) Then
            withinThis.Y = (withinThis.Y _
                        + (withinThis.Height - alignThis.Height))
        ElseIf ((align And anyMiddle) _
                    <> CType(0, ContentAlignment)) Then
            withinThis.Y = (withinThis.Y _
                        + (((withinThis.Height - alignThis.Height) _
                        + 1) _
                        / 2))
        End If
        withinThis.Height = alignThis.Height
        Return withinThis
    End Function

#End Region


#Region "ThreadStart"

    <STAThread()> _
    Public Sub ThreadStarter()
        Me.Show()
        Me.Activate()
        Me.TopLevel = True
        Me.WindowState = FormWindowState.Normal
        'Me.TopMost = True

        Do
            System.Windows.Forms.Application.DoEvents()
            System.Threading.Thread.Sleep(100)
            If Me.p_kilepes Then
                Exit Do
            End If
        Loop
    End Sub

    Public Sub ThreadStarter(ByVal lAddon As System.Windows.Forms.IWin32Window)
        Me.Show(lAddon)
        Me.Activate()
        Me.TopLevel = True
        Me.WindowState = FormWindowState.Normal
        'Me.TopMost = True

        Dim MyProcs() As Process
        Dim l_handleParent As IntPtr
        Dim l_eredeti_title As String
        Dim l_uj_title As String
        'Me.TopMost = True

        l_eredeti_title = IFSZ_Globals.m_ParentAddOn.SboApplication.Desktop.Title
        l_uj_title = "SBO under " + IFSZ_Globals.m_ParentAddOn.SboCompany.UserName + IFSZ_Globals.m_RandomClass.Next(0, 999999).ToString
        IFSZ_Globals.m_ParentAddOn.SboApplication.Desktop.Title = l_uj_title

        MyProcs = Process.GetProcessesByName("SAP Business One")

        If MyProcs.Length <> 0 Then
            For i As Integer = 0 To MyProcs.Length - 1
                If MyProcs(i).MainWindowTitle = l_uj_title Then
                    l_handleParent = MyProcs(i).MainWindowHandle
                End If
            Next
        End If

        IFSZ_Globals.m_ParentAddOn.SboApplication.Desktop.Title = l_eredeti_title
        If IntPtr.Zero.Equals(l_handleParent) Then
            l_handleParent = Process.GetProcessesByName("SAP Business One")(0).MainWindowHandle
        End If

        'Dim l_handleParent As IntPtr = Process.GetProcessesByName("SAP Business One")(0).MainWindowHandle
        Dim l_handleRealParent As IntPtr
        Dim l_handleChild As IntPtr = Me.Handle
        l_handleRealParent = Win32Helper.FindWindowEx(l_handleParent, Nothing, Nothing, Nothing)
        l_handleRealParent = Win32Helper.GetWindow(l_handleRealParent, 2) '2 = GW_HWNDNEXT
        If Not IntPtr.Zero.Equals(l_handleChild) And Not IntPtr.Zero.Equals(l_handleRealParent) Then
            Win32Helper.SetParent(l_handleChild, l_handleRealParent)
            Me.Invalidate()
        End If

        Do
            System.Windows.Forms.Application.DoEvents()
            System.Threading.Thread.Sleep(100)
            If Me.p_kilepes Then
                Exit Do
            End If
        Loop
    End Sub

    Public Sub ThreadStarter(ByVal lParent As String)
        Dim MyProcs() As Process
        Dim lPathName As String
        Dim lPoz As Integer

        Dim MyWindow As New WindowWrapper(IFSZ_Globals.GetMyProc().MainWindowHandle)
        ThreadStarter(MyWindow)

        'MyProcs = Process.GetProcessesByName(lParent)
        'If MyProcs.Length <> 0 Then
        '    For i As Integer = 0 To MyProcs.Length - 1
        '        Dim MyWindow As New WindowWrapper(MyProcs(i).MainWindowHandle)
        '        ThreadStarter(MyWindow)
        '        Exit Sub
        '    Next
        'Else

        'End If

        'MyProcs = Process.GetProcessesByName("IFSZ_AddOnBase")
        'If MyProcs.Length <> 0 Then
        '    For i As Integer = 0 To MyProcs.Length - 1
        '        Dim MyWindow As New WindowWrapper(MyProcs(i).MainWindowHandle)
        '        ThreadStarter(MyWindow)
        '        Exit Sub
        '    Next
        'Else

        'End If

        'MyProcs = Process.GetProcessesByName("IFSZ_Cash")
        'If MyProcs.Length <> 0 Then
        '    For i As Integer = 0 To MyProcs.Length - 1
        '        Dim MyWindow As New WindowWrapper(MyProcs(i).MainWindowHandle)
        '        ThreadStarter(MyWindow)
        '        Exit Sub
        '    Next
        'Else

        'End If

        'MyProcs = Process.GetProcessesByName("IFSZ_AddOnBase.vshost")
        'If MyProcs.Length <> 0 Then
        '    For i As Integer = 0 To MyProcs.Length - 1
        '        Dim MyWindow As New WindowWrapper(MyProcs(i).MainWindowHandle)
        '        ThreadStarter(MyWindow)
        '        Exit Sub
        '    Next
        'Else

        'End If



    End Sub

#End Region

    Private p_vcolindex As Integer
    Protected Overrides Sub Finalize()
        'Me.oForm_Eredeti.ActiveControl = CType(p_oszlop.VNev, DataGridViewTextBoxCell).DataGridView
        'Me.oForm_Eredeti.Activate()
        Me.oForm_Eredeti.p_LovForm = Nothing
        'Me.Dispose()
        MyBase.Close()
        MyBase.Finalize()
    End Sub
End Class
