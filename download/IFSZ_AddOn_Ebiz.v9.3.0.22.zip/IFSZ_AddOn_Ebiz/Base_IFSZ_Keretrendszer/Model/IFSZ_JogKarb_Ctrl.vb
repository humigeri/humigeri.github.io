﻿'----------------------------------------------------------------------------'
'Generálva: 2013.11.22
'FormViewGenerator. Verzió: 1.0.7.0
'----------------------------------------------------------------------------'

Imports IFSZ_AddOnBase.IFSZ_Types
Imports System
Imports System.IO
Imports System.Text

Public Class IFSZ_JogKarb_Ctrl
    Implements IFSZ_ICTRL
    Implements IIFSZ_FileDialogResult

    Public Sub New()

    End Sub

    Public Sub New(ByRef frmMain As Object)
        frmForm = frmMain
        plSaveFileDialog = New IFSZ_FileDialog()
        Me.m_frmView = New IFSZ_JogKarb_View()

        Me.UserId = -1
        Me.TovabbiUserek = ""

    End Sub

    Private frmForm As IFSZ_DNET_JogKarb
    Private plFileDialogOpen As Boolean = False
    Private plSaveFileDialog As IFSZ_FileDialog
    Private m_frmView As IFSZ_JogKarb_View

    Private m_userid As Integer
    Private m_tovabbi_userek As String
    Private m_regi_absid As String = ""
    Private m_regi_permname As String = ""
    Private m_regi_user_code As String
    Private m_regi_user_name As String
    Private m_user_val As Boolean = False

    Private Property UserId() As Integer
        Get
            Return m_userid
        End Get
        Set(ByVal value As Integer)
            m_userid = value
            Me.m_frmView.m_userid = m_userid
        End Set
    End Property

    Private Property TovabbiUserek() As String
        Get
            Return m_tovabbi_userek
        End Get
        Set(ByVal value As String)
            m_tovabbi_userek = value
            Me.m_frmView.m_tovabbi_userek = m_tovabbi_userek
        End Set
    End Property

    Public Sub Form_Event(ByVal pEvent As String, ByVal sender As Object, ByVal e As System.EventArgs) Implements IFSZ_ICTRL.Form_Event

        If pEvent = "PreForm" Then
            Me.frmForm.t_leiras.Tag = Me.frmForm.entity(0)

        ElseIf pEvent = "FormLoad" Then

            Me.frmForm.entity(0).NewRowEnabled = False

            Me.frmForm.VirtualRowEnabled = False

            Me.frmForm.p_dataset = m_frmView.getDataSet

            Me.frmForm.DataGridView1.DataSource = Me.frmForm.p_dataset
            Me.frmForm.DataGridView1.Name = "PERM"
            Me.frmForm.DataGridView1.DataMember = "PERM"

            Me.frmForm.entity(0).TableName = "PERM"

            Me.frmForm.t_leiras.DataBindings.Add("TEXT", Me.frmForm.p_dataset, "PERM.LEIRAS", True, DataSourceUpdateMode.OnValidation)

        ElseIf pEvent = "PostCommit" Then

            'Me.TablazatEngedelyezes()
            Me.JogosultsagSzures()

        ElseIf pEvent = "AfterFormLoad" Then
            Me.frmForm.t_user_code.Focus()

        End If
    End Sub

    Public Function get_DataTable(ByVal p_TableName As String, Optional ByVal p_tipus As String = "", Optional ByVal sender As Object = Nothing, Optional ByVal p_where As String = "") As System.Data.DataTable Implements IFSZ_ICTRL.get_DataTable
        Dim p_SqlQuery As String
        'Dim frm_view As IFSZ_EgyszBeszerTerv_View = New IFSZ_EgyszBeszerTerv_View()
        Dim i, j, p_pk_num As Integer
        'Dim p_relation As IFSZ_Types.Relations
        Dim p_table As IFSZ_Types.RelationTable
        'Dim p_pk_id, p_fk_id As String
        Dim l_datatable As DataTable
        Dim l_row As DataRow

        Select Case p_tipus
            Case "MASTER/DETAIL"
                For i = 0 To frmForm.entity.GetUpperBound(0)
                    If frmForm.entity(i).TableName = sender.current.row.table.tablename() Then
                        For Each p_table In frmForm.entity(i).ChildRelation.Tables
                            If p_table.Table = p_TableName Then
                                For p_pk_num = 0 To p_table.PK_Columns.GetUpperBound(0)
                                    If p_pk_num = 0 Then
                                        p_SqlQuery = Me.m_frmView.getSqlQuery(p_TableName, p_tipus) & "where " & p_table.FK_Columns(p_pk_num) & " = " & sender.current.row(p_table.PK_Columns(p_pk_num))
                                    Else
                                        p_SqlQuery = Me.m_frmView.getSqlQuery(p_TableName, p_tipus) & " and " & p_table.FK_Columns(p_pk_num) & " = " & sender.current.row(p_table.PK_Columns(p_pk_num))
                                    End If
                                Next
                                For j = 0 To frmForm.entity.GetUpperBound(0)
                                    If frmForm.entity(j).TableName = p_TableName Then
                                        frmForm.entity(j).ChildWhere = p_SqlQuery.Substring(p_SqlQuery.ToUpper.IndexOf("WHERE") + 5, p_SqlQuery.Length - p_SqlQuery.ToUpper.IndexOf("WHERE") - 5).Trim
                                        If frmForm.entity(j).DefaultWhere <> "" Then
                                            p_SqlQuery = p_SqlQuery & " and " & frmForm.entity(j).DefaultWhere
                                            'p_SqlQuery = p_SqlQuery & " and " & frmForm.entity(i).DefaultWhere
                                        End If
                                        'frmForm.entity(j).ChildWhere = p_SqlQuery.Substring(p_SqlQuery.ToUpper.IndexOf("WHERE") + 5, p_SqlQuery.Length - p_SqlQuery.ToUpper.IndexOf("WHERE") - 5).Trim
                                    End If
                                Next
                            End If
                        Next
                    End If

                    'If frmForm.entity(i).TableName = p_TableName Then
                    '    p_SqlQuery = frm_view.getSqlQuery(p_TableName, p_tipus) & sender.current.row("ID")
                    '    frmForm.entity(i).ChildWhere = p_SqlQuery.Substring(p_SqlQuery.ToUpper.IndexOf("WHERE") + 5, p_SqlQuery.Length - p_SqlQuery.ToUpper.IndexOf("WHERE") - 5).Trim
                    'End If
                    'frmForm.entity(i).ChildWhere = p_SqlQuery.Substring(p_SqlQuery.ToUpper.IndexOf("WHERE") + 5, p_SqlQuery.Length - p_SqlQuery.ToUpper.IndexOf("WHERE") - 5).Trim
                Next
                l_datatable = DataProvider.GetDataTable(p_SqlQuery)
                Return l_datatable
            Case "TABLE"
                p_SqlQuery = Me.m_frmView.getSqlQuery(p_TableName, p_tipus)
                If p_where = "" Then
                    p_where = "1=1"
                Else
                    p_where = p_where.Replace("'False'", "'N'").Replace("'True'", "'Y'")
                End If
                For i = 0 To frmForm.entity.GetUpperBound(0)
                    If frmForm.entity(i).TableName = p_TableName And frmForm.entity(i).DefaultWhere <> "" Then
                        p_where = p_where & " and " & frmForm.entity(i).DefaultWhere
                        If frmForm.entity(i).ChildWhere <> "" Then
                            p_where = p_where & " and " & frmForm.entity(i).ChildWhere
                        End If
                    ElseIf frmForm.entity(i).TableName = p_TableName And frmForm.entity(i).ChildWhere <> "" Then
                        p_where = p_where & " and " & frmForm.entity(i).ChildWhere
                    End If
                Next
                p_SqlQuery = p_SqlQuery & " where " & p_where
                l_datatable = DataProvider.GetDataTable(p_SqlQuery)
                Return l_datatable
            Case Else
                l_datatable = DataProvider.GetDataTable(p_SqlQuery)
                Return l_datatable
        End Select

    End Function

    '----------------------------------------------------------------------------
    '----------------------------------------------------------------------------
    'Item_Event
    '----------------------------------------------------------------------------
    '----------------------------------------------------------------------------
    Public Sub Item_Event(ByVal pEvent As IFSZ_Types.PItemEvent, ByVal sender As Object, ByVal e As System.EventArgs) Implements IFSZ_ICTRL.Item_Event
        Dim l_datarowcollection As DataRowCollection

        '----------------------------------------------------------------------------
        'Item validálás esemény
        '----------------------------------------------------------------------------
        If pEvent = PItemEvent.ItemValidate Then
            If sender.GetType().Name = "TextBox" Then
                Select Case sender.name
                    Case "t_user_code", "t_user_name"
                        If Not Me.m_user_val Then
                            Dim l_lookup_ertek As String = CType(sender, TextBox).Text
                            If l_lookup_ertek.Length > 0 Then
                                Dim l_lov As Boolean = l_lookup_ertek.EndsWith("*")
                                If l_lov Then
                                    l_lookup_ertek = l_lookup_ertek.Substring(0, l_lookup_ertek.Length - 1)
                                Else
                                    l_datarowcollection = Me.m_frmView.get_elso_USR(l_lookup_ertek, IIf(sender.name = "t_user_code", "CODE", "NAME"))
                                    If l_datarowcollection.Count = 1 Then
                                        If Me.UserId <> l_datarowcollection.Item(0).Item("INTERNAL_K") Then
                                            Dim l_regi_userid = Me.UserId
                                            Me.UserId = l_datarowcollection.Item(0).Item("INTERNAL_K")
                                            If Me.TablaFrissit() Then
                                                Try
                                                    Me.m_user_val = True
                                                    Me.frmForm.t_user_code.Text = l_datarowcollection.Item(0).Item("USER_CODE")
                                                    Me.frmForm.t_user_name.Text = l_datarowcollection.Item(0).Item("U_NAME")
                                                    Me.m_regi_user_code = l_datarowcollection.Item(0).Item("USER_CODE")
                                                    Me.m_regi_user_name = l_datarowcollection.Item(0).Item("U_NAME")
                                                Catch ex As Exception
                                                    Me.frmForm.show_error(ex.Message)
                                                Finally
                                                    Me.m_user_val = False
                                                End Try

                                            Else
                                                Me.UserId = l_regi_userid
                                                Try
                                                    Me.m_user_val = True
                                                    Me.frmForm.t_user_code.Text = Me.m_regi_user_code
                                                    Me.frmForm.t_user_name.Text = Me.m_regi_user_name
                                                Catch ex As Exception
                                                    Me.frmForm.show_error(ex.Message)
                                                Finally
                                                    Me.m_user_val = False
                                                End Try

                                            End If
                                        End If
                                    Else
                                        l_lov = True
                                    End If
                                End If
                                If l_lov Then
                                    CType(e, System.ComponentModel.CancelEventArgs).Cancel = True
                                    Me.USR_lov(sender, 0, l_lookup_ertek, IIf(sender.name = "t_user_code", "CODE", "NAME"))
                                End If
                            Else
                                Me.UserId = -1
                                Try
                                    Me.m_user_val = True
                                    Me.frmForm.t_user_code.Text = ""
                                    Me.frmForm.t_user_name.Text = ""
                                    Me.m_regi_user_code = ""
                                    Me.m_regi_user_name = ""
                                    Me.frmForm.DataGridView1.Visible = False
                                Catch ex As Exception
                                    Me.frmForm.show_error(ex.Message)
                                Finally
                                    Me.m_user_val = False
                                End Try
                            End If
                        End If
                    Case "t_absid", "t_perm_name"
                        If Me.frmForm.t_absid.Text = "InitPermIFSZ" Then
                            Me.frmForm.t_absid.Text = ""
                            Me.PermFeltolt()
                        Else

                            Dim l_lookup_ertek As String = CType(sender, TextBox).Text
                            If l_lookup_ertek.Length > 0 Then
                                Dim l_lov As Boolean = l_lookup_ertek.EndsWith("*")
                                If l_lov Then
                                    l_lookup_ertek = l_lookup_ertek.Substring(0, l_lookup_ertek.Length - 1)
                                Else
                                    If Me.frmForm.DataGridView1.Visible AndAlso (Me.m_regi_absid <> Me.frmForm.t_absid.Text OrElse Me.m_regi_permname <> Me.frmForm.t_perm_name.Text) Then
                                        Me.TablaFrissit()
                                    End If
                                End If
                                If l_lov Then
                                    CType(e, System.ComponentModel.CancelEventArgs).Cancel = True
                                    Me.PERM_lov(sender, 0, l_lookup_ertek, IIf(sender.name = "t_absid", "CODE", "NAME"))
                                End If
                            Else
                                If Me.frmForm.DataGridView1.Visible AndAlso (Me.m_regi_absid <> Me.frmForm.t_absid.Text OrElse Me.m_regi_permname <> Me.frmForm.t_perm_name.Text) Then
                                    Me.TablaFrissit()
                                End If
                            End If
                            Me.m_regi_absid = Me.frmForm.t_absid.Text
                            Me.m_regi_permname = Me.frmForm.t_perm_name.Text

                        End If
                End Select
            End If
        End If

        '----------------------------------------------------------------------------
        'ItemClick esemény
        '----------------------------------------------------------------------------
        If pEvent = PItemEvent.ItemClick Then
            If sender.GetType Is GetType(Button) Then
                If CType(sender, Button).Name.ToLower = "b_tovabbi_fhok" Then
                    If Me.frmForm.p_dataset.HasChanges Then
                        If Me.frmForm.show_question("folyt_elveszt_biztosan?") <> MsgBoxResult.Yes Then
                            Exit Sub
                        End If
                        Me.frmForm.p_dataset.RejectChanges()
                    End If

                    Me.USR_lov(Me.frmForm.t_tovabbi_fhok, 0, "", "MULTI")

                End If
            End If
        End If

        '----------------------------------------------------------------------------
        'MultiLovSelected esemény
        '----------------------------------------------------------------------------
        If pEvent = PItemEvent.MultiLovSelected Then
            Dim l_tipus As String = CType(sender, DataSet).Tables.Item(0).TableName
            If l_tipus = "USR" Then
                Try
                    Me.m_tovabbi_userek = ""
                    Me.frmForm.t_tovabbi_fhok.Text = ""
                    Dim l_text As String = ""
                    For Each l_row As DataRow In CType(sender, DataSet).Tables.Item(0).Rows
                        If Me.m_tovabbi_userek = "" Then
                            Me.m_tovabbi_userek = l_row("internal_k").ToString
                            l_text = l_row("u_name").ToString
                        Else
                            Me.m_tovabbi_userek += "," + l_row("internal_k").ToString
                            l_text += ", " + l_row("u_name").ToString
                        End If
                    Next
                    Me.frmForm.t_tovabbi_fhok.Text = l_text
                    Me.TablaFrissit()
                Catch ex As Exception
                    Me.frmForm.show_error(ex.Message)
                End Try
            End If
        End If

        '----------------------------------------------------------------------------
        'CellDoubleClick
        '----------------------------------------------------------------------------
        If pEvent = PItemEvent.CellDoubleClick Then
            If sender.GetType() Is GetType(DataGridView) Then
                If CType(sender, DataGridView).Name = "PERM" Then
                    Dim l_oszlop As String
                    Dim l_sor As Integer = CType(e, System.Windows.Forms.DataGridViewCellEventArgs).RowIndex

                    If CType(e, System.Windows.Forms.DataGridViewCellEventArgs).ColumnIndex > -1 Then
                        l_oszlop = Me.frmForm.DataGridView1.Columns(CType(e, System.Windows.Forms.DataGridViewCellEventArgs).ColumnIndex).Name
                    Else
                        l_oszlop = ""
                    End If

                    Me.DuplaKlikk(l_oszlop, l_sor)

                End If
            End If

        End If

    End Sub

    '----------------------------------------------------------------------------
    '----------------------------------------------------------------------------
    'ItemEvent vége
    '----------------------------------------------------------------------------
    '----------------------------------------------------------------------------

#Region "Implements IIFSZ_FileDialogResult"


    Public Sub SetFajlNev(ByVal pFajlNev As String) Implements IIFSZ_FileDialogResult.SetFajlNev
        plFileDialogOpen = False
        'ExportToCSV(pFajlNev)
    End Sub

    Public Sub NemValasztott() Implements IIFSZ_FileDialogResult.NemValasztott
        plFileDialogOpen = False
    End Sub

    Public Sub ShowFileDialog()

        Me.plSaveFileDialog.InitialDirectory = IFSZ_Globals.GetMyProc.StartInfo.WorkingDirectory
        Me.plSaveFileDialog.DefaultExt = ".csv"
        Me.plSaveFileDialog.InitialFileName = "IFSZ_JogKarb_" + DateTime.Now().ToString("yyyyMMddHHmmss") + ".csv"

        Me.plSaveFileDialog.SaveFileDialog(Me, IFSZ_Globals.GetMyProc)

    End Sub


    Public Function get_view() As Object Implements IFSZ_ICTRL.get_view

    End Function

#End Region

#Region "Private"

#Region "LOV"

    Private Sub USR_lov(ByRef sender As Object, ByVal p_sor As Integer, ByVal l_ertek As String, ByVal p_tipus As String)
        Dim p_oszlop_tipus(2) As LOV_OszlopTipus
        Dim p_ventity(0) As IFSZ_Types.LOV_VEntiy
        Dim p_form As LOV_Form
        Dim c As IFSZ_PUB_LOV
        Dim l_select As String
        Dim l_where As String = ""

        If l_ertek <> "" Then
            If p_tipus = "CODE" Then
                l_where = " and " + QueryResource.AzonPrep("USER_CODE") + " like " + IFSZ_Globals.SqlConstantPrepare(l_ertek + "%")
            Else
                l_where = " and " + QueryResource.AzonPrep("U_NAME") + " like " + IFSZ_Globals.SqlConstantPrepare(l_ertek + "%")
            End If
        End If
        l_where = " where " + QueryResource.AzonPrep("SUPERUSER") + " = 'N' and " + QueryResource.AzonPrep("Locked") + " = 'N' " + l_where

        p_oszlop_tipus(0).Title = "Id"
        p_oszlop_tipus(0).DbNev = "INTERNAL_K"
        p_oszlop_tipus(0).Tipus = "TEXT"
        p_oszlop_tipus(0).Description = "Belső azonosító"
        p_oszlop_tipus(0).Visible = False

        p_oszlop_tipus(1).Title = "Felhasználókód"
        p_oszlop_tipus(1).DbNev = "USER_CODE"
        Select Case sender.GetType.Name
            Case "TextBox"
                p_oszlop_tipus(1).VNev = Me.frmForm.t_user_code
        End Select
        p_oszlop_tipus(1).Tipus = "TEXT"
        p_oszlop_tipus(1).Description = "Felhasználókód"
        p_oszlop_tipus(1).Visible = True
        p_oszlop_tipus(1).Width = 100

        p_oszlop_tipus(2).Title = "Név"
        p_oszlop_tipus(2).DbNev = "U_NAME"
        p_oszlop_tipus(2).Tipus = "TEXT"
        p_oszlop_tipus(2).Description = "Felhasználó neve"
        p_oszlop_tipus(2).Visible = True
        p_oszlop_tipus(2).Width = 400

        l_select = QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "sel_internalk_usercode_name_from_ousr") & " " & l_where & " " & QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "order_by_user_code")

        p_form.Title = "Felhasználó"
        p_form.Width = 500
        p_form.Height = 250
        p_form.SENDER = "USR"
        If p_tipus = "MULTI" Then
            c = New IFSZ_PUB_LOV(Me.frmForm, p_form, p_oszlop_tipus, l_select, , , True)
        Else
            c = New IFSZ_PUB_LOV(Me.frmForm, p_form, p_oszlop_tipus, l_select)
        End If

    End Sub

    Private Sub PERM_lov(ByRef sender As Object, ByVal p_sor As Integer, ByVal l_ertek As String, ByVal p_tipus As String)
        Dim p_oszlop_tipus(2) As LOV_OszlopTipus
        Dim p_ventity(0) As IFSZ_Types.LOV_VEntiy
        Dim p_form As LOV_Form
        Dim c As IFSZ_PUB_LOV
        Dim l_select As String
        Dim l_where As String = ""

        If l_ertek <> "" Then
            If p_tipus = "CODE" Then
                l_where = " and " + QueryResource.AzonPrep("AbsId") + " like " + IFSZ_Globals.SqlConstantPrepare(l_ertek + "%")
            Else
                l_where = " and " + QueryResource.AzonPrep("Name") + " like " + IFSZ_Globals.SqlConstantPrepare(l_ertek + "%")
            End If
        End If
        l_where = " where 1=1 " + l_where

        p_oszlop_tipus(0).Title = "Kód"
        p_oszlop_tipus(0).DbNev = "ABSID"
        Select Case sender.GetType.Name
            Case "TextBox"
                p_oszlop_tipus(0).VNev = Me.frmForm.t_absid
        End Select
        p_oszlop_tipus(0).Tipus = "TEXT"
        p_oszlop_tipus(0).Description = "Kód"
        p_oszlop_tipus(0).Visible = True
        p_oszlop_tipus(0).Width = 130

        p_oszlop_tipus(1).Title = "Megnevezés"
        p_oszlop_tipus(1).DbNev = "NAME"
        Select Case sender.GetType.Name
            Case "TextBox"
                p_oszlop_tipus(1).VNev = Me.frmForm.t_perm_name
        End Select
        p_oszlop_tipus(1).Tipus = "TEXT"
        p_oszlop_tipus(1).Description = "Megnevezés"
        p_oszlop_tipus(1).Visible = True
        p_oszlop_tipus(1).Width = 300

        p_oszlop_tipus(2).Title = "Szint"
        p_oszlop_tipus(2).DbNev = "LEVELS"
        p_oszlop_tipus(2).Tipus = "TEXT"
        p_oszlop_tipus(2).Description = "Szint"
        p_oszlop_tipus(2).Visible = True
        p_oszlop_tipus(2).Width = 60

        l_select = QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "lov_oupttree").Replace("/*where*/", l_where)

        p_form.Title = "Jogosultság"
        p_form.Width = 500
        p_form.Height = 250
        c = New IFSZ_PUB_LOV(Me.frmForm, p_form, p_oszlop_tipus, l_select)

    End Sub

#End Region

    Private Function TablaFrissit() As Boolean
        Dim l_result As MsgBoxResult

        If Me.frmForm.p_dataset.HasChanges Then
            l_result = Me.frmForm.show_question("_mentetlen_folytatja")
            If Not l_result = MsgBoxResult.Ok AndAlso Not l_result = MsgBoxResult.Yes Then
                Return False
            End If
        End If

        Me.frmForm.DataGridView1.Visible = False

        Try
            Me.frmForm.Cursor = Cursors.WaitCursor

            'Későbbiekhez szükséges where-ek összeollózás
            Dim l_rc As DataRowCollection
            Dim l_oszlopok() As String
            Dim l_p_oszlopok() As String
            Dim l_hana_oszlopok() As String
            Dim l_hana_joinok() As String
            Dim i As Integer

            If Me.m_userid > -1 Then
                Dim l_x() As String
                Dim l_meret As Integer
                If Not String.IsNullOrEmpty(Me.m_tovabbi_userek) Then
                    l_x = Me.m_tovabbi_userek.Split(",")
                    l_meret = l_x.Length
                Else
                    l_meret = 0
                End If
                ReDim l_oszlopok(l_meret)
                l_oszlopok(0) = Me.m_userid
                For i = 1 To l_meret
                    l_oszlopok(i) = l_x(i - 1)
                Next
            Else
                Return False
            End If

            'Oszloplista meghatározása
            l_rc = DataProvider.GetDataRecord(QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "jogkarb_oszloplista", Me.m_userid).Replace("/*oszloplista*/", String.Join(",", l_oszlopok)))
            If l_rc IsNot Nothing AndAlso l_rc.Count > 0 Then
                ReDim l_oszlopok(l_rc.Count - 1)
                ReDim l_p_oszlopok(l_rc.Count - 1)
                ReDim l_hana_oszlopok(l_rc.Count - 1)
                ReDim l_hana_joinok(l_rc.Count - 1)
                For i = 0 To l_rc.Count - 1
                    l_oszlopok(i) = l_rc(i)("internal_k").ToString
                    l_p_oszlopok(i) = "p_" + l_rc(i)("internal_k").ToString
                    l_hana_oszlopok(i) = ", ifnull(u3_" + l_rc(i)("internal_k").ToString + ".""Permission"", 'N') as ""p_" + l_rc(i)("internal_k").ToString + """"
                    l_hana_joinok(i) = "left join usr3 u3_" + l_rc(i)("internal_k").ToString + " on u3_" + l_rc(i)("internal_k").ToString + ".""PermId"" = ou.absid and u3_" + l_rc(i)("internal_k").ToString + ".""UserLink"" = " + l_rc(i)("internal_k").ToString
                Next

                Dim l_tabla As DataTable

                Me.frmForm.p_dataset.Tables("PERM").BeginInit()
                Me.frmForm.p_dataset.Tables("PERM").Clear()

                For i = Me.frmForm.p_dataset.Tables("PERM").Columns.Count - 1 To 0 Step -1
                    If Me.frmForm.p_dataset.Tables("PERM").Columns.Item(i).ColumnName.Length >= 3 AndAlso Me.frmForm.p_dataset.Tables("PERM").Columns.Item(i).ColumnName.StartsWith("p_") Then
                        Me.frmForm.p_dataset.Tables("PERM").Columns.RemoveAt(i)
                    End If
                Next

                l_tabla = DataProvider.GetDataTable(Me.m_frmView.getSqlQuery("PERM", "TABLE"))
                Me.frmForm.p_dataset.Tables("PERM").Merge(l_tabla)

                For i = Me.frmForm.DataGridView1.Columns.Count - 1 To 0 Step -1
                    If Me.frmForm.DataGridView1.Columns.Item(i).Name.Length() >= 3 AndAlso Me.frmForm.DataGridView1.Columns.Item(i).Name.StartsWith("p_") Then
                        Me.frmForm.DataGridView1.Columns.RemoveAt(i)
                    End If
                Next

                Dim l_vlt_id As Integer = -1
                Dim l_pivcol2, l_header2 As String
                Dim l_bejott As Boolean = False
                Dim l_szamlalo As Integer = 0
                Dim l_oszlopnev, l_oszlopnev2 As String

                For i = 0 To l_rc.Count - 1
                    With l_rc.Item(i)
                        l_oszlopnev = .Item("pivcol")
                        Me.frmForm.p_dataset.Tables("PERM").Columns.Add(l_oszlopnev, System.Type.GetType("System.String"))
                        Me.frmForm.DataGridView1.Columns.Add(l_oszlopnev, .Item("header"))
                        Me.frmForm.DataGridView1.Columns.Item(l_oszlopnev).DataPropertyName = .Item("pivcol")
                        Me.frmForm.DataGridView1.Columns.Item(l_oszlopnev).SortMode = DataGridViewColumnSortMode.NotSortable
                        Me.frmForm.DataGridView1.Columns.Item(l_oszlopnev).FillWeight = 10
                        Me.frmForm.DataGridView1.Columns.Item(l_oszlopnev).ReadOnly = True
                        Me.frmForm.DataGridView1.Columns.Item(l_oszlopnev).Width = 140
                        Me.frmForm.DataGridView1.Columns.Item(l_oszlopnev).ToolTipText = .Item("u_name").ToString
                        Me.frmForm.ColumnEditableEnabled("PERM", l_oszlopnev, False)

                    End With
                Next

                Dim l_tabla2 As DataTable

#If HANADB Then
                l_tabla2 = DataProvider.GetDataTable(
                    ("select ou.visorder as ID, ou.ABSID " +
                    "     , ou.NAME, ou.LEVELS, ou.VISORDER, ou.OPTIONS, ou.ACTION, ou.ISITEM, ou.FATHID, ou.TREEORDER, ou.FORM_E, ou.LEIRAS " +
                    String.Join(" ", l_hana_oszlopok) +
                    "     from ifsz_oupt_tree_v ou " +
                    String.Join(" ", l_hana_joinok) +
                    " order by ou.treeorder ").Replace("left join usr3", IIf(CType(Me.frmForm.m_ParentAddon, IFSZ_Addon).m_JogSboUserPerm, "left join usr3", "left join IFSZ_USR3_REPLACEMENT"))
                )
#Else
                l_tabla2 = DataProvider.GetDataTable(QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "jogkarb_tablazat_select").Replace("/*oszloplista1*/", String.Join(",", l_p_oszlopok)).Replace("/*oszloplista2*/", String.Join(",", l_oszlopok)).Replace("left join usr3", IIf(CType(Me.frmForm.m_ParentAddon, IFSZ_Addon).m_JogSboUserPerm, "left join usr3", "left join IFSZ_USR3_REPLACEMENT usr3")))
#End If

                Me.frmForm.p_dataset.Tables("PERM").Merge(l_tabla2)

                Me.frmForm.p_dataset.Tables("PERM").EndLoadData()
                Me.frmForm.p_dataset.Tables("PERM").EndInit()
                Me.frmForm.p_dataset.AcceptChanges()

                Me.JogosultsagSzures()

                'Me.TablazatEngedelyezes()

                Me.frmForm.DataGridView1.Visible = True

            End If

        Catch ex As Exception
            Me.frmForm.show_error(ex.ToString())
        Finally
            Me.frmForm.Cursor = Cursors.Default
        End Try

        Return True

    End Function

    Public Sub DuplaKlikk(ByVal p_oszlop As String, ByVal p_sor As Integer, Optional ByVal p_perm As String = "")
        Dim i As Integer
        Dim l_full As Boolean = False

        If p_oszlop.StartsWith("p_") Then
            If p_sor = -1 Then
                'A fejlécre kattintott, ezért mindent át kell állítani
                'Ha nincs konkrét értéke a p_perm-nek, akkor először megnézzük, minden teljes jogosultságon van-e.
                If p_perm = "" Then
                    l_full = False
                    For i = 0 To Me.frmForm.p_dataset.Tables("PERM").Rows.Count - 1
                        If Me.frmForm.p_dataset.Tables("PERM").Rows(i)(p_oszlop).ToString <> "F" Then
                            l_full = True
                            Exit For
                        End If
                    Next
                Else
                    If p_perm = "F" Then
                        l_full = True
                    Else
                        l_full = False
                    End If
                End If

                For Each l_row As DataRow In Me.frmForm.p_dataset.Tables("PERM").Rows
                    If l_full Then
                        l_row(p_oszlop) = "F"
                    Else
                        l_row(p_oszlop) = "N"
                    End If
                Next

            Else
                Dim l_tree As String = Me.frmForm.DataGridView1.Rows(p_sor).Cells("DG1_TREEORDER").Value
                If p_perm = "" Then
                    If Me.frmForm.DataGridView1.Rows(p_sor).Cells(p_oszlop).Value = "F" Then
                        l_full = False
                    Else
                        l_full = True
                    End If
                Else
                    If p_perm = "F" Then
                        l_full = True
                    Else
                        l_full = False
                    End If
                End If

                For Each l_row As DataRow In Me.frmForm.p_dataset.Tables("PERM").Rows
                    If l_row("TREEORDER").ToString.StartsWith(l_tree) Then
                        If l_full Then
                            l_row(p_oszlop) = "F"
                        Else
                            l_row(p_oszlop) = "N"
                        End If
                    End If
                Next

                Me.KulonbozoJogBeallitas(p_oszlop)

            End If

        Else

            If p_sor > -1 Then
                'Az adott sorban mindent át kell állítani
                Dim l_aktrow As DataRow = CType(Me.frmForm.DataGridView1.Rows(p_sor).DataBoundItem, DataRowView).Row

                'Ha nincs konkrét értéke a p_perm-nek, akkor először megnézzük, minden teljes jogosultságon van-e.
                If p_perm = "" Then
                    l_full = False
                    For Each l_col As DataColumn In Me.frmForm.p_dataset.Tables("PERM").Columns
                        If l_col.ColumnName.StartsWith("p_") Then
                            If l_aktrow(l_col.ColumnName) <> "F" Then
                                l_full = True
                                Exit For
                            End If
                        End If
                    Next
                Else
                    If p_perm = "F" Then
                        l_full = True
                    Else
                        l_full = False
                    End If
                End If

                For Each l_row As DataRow In Me.frmForm.p_dataset.Tables("PERM").Rows
                    If l_row("TREEORDER").ToString.StartsWith(l_aktrow("TREEORDER")) Then
                        For Each l_col As DataColumn In Me.frmForm.p_dataset.Tables("PERM").Columns
                            If l_col.ColumnName.StartsWith("p_") Then
                                If l_full Then
                                    l_row(l_col.ColumnName) = "F"
                                Else
                                    l_row(l_col.ColumnName) = "N"
                                End If
                            End If
                        Next

                    End If
                Next

                For Each l_col As DataColumn In Me.frmForm.p_dataset.Tables("PERM").Columns
                    If l_col.ColumnName.StartsWith("p_") Then
                        Me.KulonbozoJogBeallitas(l_col.ColumnName)
                    End If
                Next

            End If

        End If
    End Sub

    Public Sub Masolas(ByVal p_oszlop As String, ByVal p_sor As Integer)

        If p_oszlop.StartsWith("p_") Then
            Dim l_sikeres As Boolean = False
            Dim l_tree As String
            If p_sor = -1 Then
                l_tree = ""
            Else
                l_tree = Me.frmForm.DataGridView1.Rows(p_sor).Cells("DG1_TREEORDER").Value
            End If

            For Each l_col As DataColumn In Me.frmForm.p_dataset.Tables("PERM").Columns
                If l_col.ColumnName.StartsWith("p_") AndAlso l_col.ColumnName <> p_oszlop Then
                    l_sikeres = True

                    For Each l_row As DataRow In Me.frmForm.p_dataset.Tables("PERM").Rows
                        If l_tree = "" OrElse l_row("TREEORDER").ToString.StartsWith(l_tree) Then
                            l_row(l_col.ColumnName) = l_row(p_oszlop)
                        End If
                    Next
                    Me.KulonbozoJogBeallitas(l_col.ColumnName)

                End If
            Next

            If Not l_sikeres Then
                Me.frmForm.show_error("_masolni_masik_felhasznalo")
            Else
                Me.frmForm.show_info("_jog_masolva")
            End If

        Else
            Me.frmForm.show_error("_alljon_ra_jogra")
        End If

    End Sub

    ''' <summary>
    ''' Ha átállítottuk egy levélelem jogosultságát, akkor előfordulhat, hogy ettől a szülőelemben is változnia kell. Ezt állítja be az eljárás
    ''' </summary>
    ''' <param name="p_oszlop"></param>
    ''' <remarks></remarks>
    Private Sub KulonbozoJogBeallitas(ByVal p_oszlop As String)
        Dim l_last_father As String
        Dim l_perm As String = ""
        Dim l_view, l_view2 As DataView
        l_view = New DataView(Me.frmForm.p_dataset.Tables("PERM"), "fathid is not null and fathid <> ''", "levels desc, treeorder", DataViewRowState.CurrentRows)

        For Each l_rowv As DataRowView In l_view
            If l_last_father <> l_rowv("FATHID") Then
                l_perm = l_rowv.Row(p_oszlop, DataRowVersion.Current)
                l_last_father = l_rowv("FATHID")
            Else
                If l_perm <> l_rowv.Row(p_oszlop, DataRowVersion.Current) Then
                    l_perm = "V"
                End If
            End If

            l_view2 = New DataView(Me.frmForm.p_dataset.Tables("PERM"), "absid = " + IFSZ_Globals.DataViewConstantPrepare(l_rowv("FATHID")), "", DataViewRowState.CurrentRows)
            If l_view2.Count = 1 Then
                Select Case l_view2(0)(p_oszlop)
                    Case "N"
                        If l_perm = "F" OrElse l_perm = "V" Then
                            l_view2(0).Row(p_oszlop) = l_perm
                        End If
                    Case "V"
                        If l_perm = "N" OrElse l_perm = "F" Then
                            l_view2(0).Row(p_oszlop) = l_perm
                        End If
                    Case "F"
                        If l_perm = "N" OrElse l_perm = "V" Then
                            l_view2(0).Row(p_oszlop) = l_perm
                        End If
                End Select
            End If

        Next
    End Sub

    Private Sub JogosultsagSzures()
        If Me.frmForm.t_absid.Text = "" AndAlso Me.frmForm.t_perm_name.Text = "" Then
            Exit Sub
        End If

        Dim l_treeorder As String
        Dim l_hide As New List(Of String)

        'Először elrejtésre állítok be mindent, majd vissza fogom állítani ami mégis kell
        For Each l_row As DataRow In Me.frmForm.p_dataset.Tables("PERM").Rows
            l_hide.Add(l_row("TREEORDER"))
        Next

        'Először a mintára illeszkedő sorokat veszem ki, és azok alárendeltjeit. Majd a fölötte lévőket is
        For Each l_row As DataRow In Me.frmForm.p_dataset.Tables("PERM").Rows
            If (Me.frmForm.t_absid.Text = "" OrElse l_row("ABSID").ToString.ToLower().Contains(Me.frmForm.t_absid.Text.ToLower())) _
                  AndAlso (Me.frmForm.t_perm_name.Text = "" OrElse l_row("NAME").ToString.ToLower().Contains(Me.frmForm.t_perm_name.Text.ToLower())) _
            Then
                l_treeorder = l_row("TREEORDER").ToString
                For i As Integer = l_hide.Count - 1 To 0 Step -1
                    If l_hide(i).StartsWith(l_treeorder) Then
                        l_hide.Remove(l_hide(i))
                    End If
                Next
                'most a szülőket
                For i As Integer = l_hide.Count - 1 To 0 Step -1
                    If l_treeorder.StartsWith(l_hide(i)) Then
                        l_hide.Remove(l_hide(i))
                    End If
                Next
            End If
        Next

        For Each l_dgr As DataGridViewRow In Me.frmForm.DataGridView1.Rows
            If l_hide.Contains(l_dgr.Cells("DG1_TREEORDER").Value.ToString) Then
                l_dgr.Visible = False
            End If
        Next

    End Sub

#End Region

#Region "Public"

    Public Function Accept(ByVal pAcceptEvent As IFSZ_Types.PAcceptEvent, ByVal pOperationType As IFSZ_Types.DMLOperation, ByVal sender As Object) As Object Implements IFSZ_ICTRL.Accept

        If pAcceptEvent = IFSZ_Types.PAcceptEvent.BeforeFormCommit Then

            Try
                Me.frmForm.Cursor = Cursors.WaitCursor
                IFSZ_Globals_SBO.StartDITransaction()

                For i As Integer = 0 To Me.frmForm.p_dataset.Tables("PERM").Columns.Count - 1
                    If Me.frmForm.p_dataset.Tables("PERM").Columns(i).ColumnName.StartsWith("p_") Then
                        Dim l_oszlop As String = Me.frmForm.p_dataset.Tables("PERM").Columns(i).ColumnName
                        Dim l_internal_k As Integer
                        Dim l_usercode As String
                        If Integer.TryParse(l_oszlop.Substring(2), l_internal_k) Then

                            If CType(Me.frmForm.m_ParentAddon, IFSZ_Addon).m_JogSboUserPerm Then
                            Dim l_usr As SAPbobsCOM.Users
                            l_usr = CType(IFSZ_Globals.m_ParentAddOn, IFSZ_Addon).SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oUsers)
                            If l_usr.GetByKey(l_internal_k) Then

                                For Each l_row As DataRow In Me.frmForm.p_dataset.Tables("PERM").Rows
                                    If l_row.RowState = DataRowState.Modified AndAlso l_row(l_oszlop, DataRowVersion.Current) <> l_row(l_oszlop, DataRowVersion.Original) Then
                                        If l_usr.UserPermission.Count > 0 Then
                                            Try
                                                For j As Integer = 0 To l_usr.UserPermission.Count - 1
                                                    l_usr.UserPermission.SetCurrentLine(j)
                                                    If l_usr.UserPermission.PermissionID = l_row("absid") Then
                                                        Exit Try
                                                    End If
                                                Next
                                                'Nem találta meg:
                                                l_usr.UserPermission.Add()
                                            Catch ex As Exception
                                                Throw
                                            End Try
                                        End If
                                        l_usr.UserPermission.PermissionID = l_row("absid")
                                        Select Case l_row(l_oszlop)
                                            Case "F"
                                                l_usr.UserPermission.Permission = SAPbobsCOM.BoPermission.boper_Full
                                            Case "N"
                                                l_usr.UserPermission.Permission = SAPbobsCOM.BoPermission.boper_None
                                            Case "V"
                                                l_usr.UserPermission.Permission = SAPbobsCOM.BoPermission.boper_Various
                                        End Select
                                    End If
                                Next

                                If l_usr.Update <> 0 Then
                                    Dim RetVal As Long
                                    Dim ErrMsg As String
                                    CType(IFSZ_Globals.m_ParentAddOn, IFSZ_Addon).SboCompany.GetLastError(RetVal, ErrMsg)
                                    Throw New Exception("Hiba a felhasználó jogosultság beállításánál. (DI " + l_oszlop.Substring(2) + "): " + ErrMsg)

                                End If
                            Else
                                Throw New Exception("Hiba a felhasználó visszakeresésénél. (DI " + l_oszlop.Substring(2) + ")")

                            End If

                        Else

                                l_usercode = DataProvider.ExecuteScalarString("select user_code from ousr " + QueryResource.SQL_WithNolock + " where internal_k = " + IFSZ_Globals.SqlConstantPrepare(l_internal_k))

                                For Each l_row As DataRow In Me.frmForm.p_dataset.Tables("PERM").Rows
                                    If l_row.RowState = DataRowState.Modified AndAlso l_row(l_oszlop, DataRowVersion.Current) <> l_row(l_oszlop, DataRowVersion.Original) Then
                                        Dim l_code, l_name, l_u_role, l_letezik_sql As String
                                        l_name = l_row("absid").ToString + "." + l_usercode
                                        l_u_role = DataProvider.ExecuteScalarString("select ""Code"" from ""@IFSZ_ROLES"" " + QueryResource.SQL_WithNolock + " where ""Name"" = " + IFSZ_Globals.SqlConstantPrepare(l_row("absid").ToString))
                                        l_letezik_sql = " where ""U_Role"" = " + IFSZ_Globals.SqlConstantPrepare(l_u_role) + " and ""U_UserCode"" = " + IFSZ_Globals.SqlConstantPrepare(l_usercode) + " "

                                        If Not String.IsNullOrEmpty(l_u_role) Then
                                            Select Case l_row(l_oszlop)
                                                Case "F"
                                                    If String.IsNullOrEmpty(DataProvider.ExecuteScalarString("select 'x' from ""@IFSZ_USER_ROLES"" " + l_letezik_sql)) Then
                                                        l_code = IFSZ_Globals.get_next_seq("DEFAULT").PadLeft(8, "0")
                                                        DataProvider.EExecuteNonQuery( _
                                                         "insert into ""@IFSZ_USER_ROLES""(""Code"", ""Name"", ""U_Role"", ""U_UserCode"") values (" + IFSZ_Globals.SQLConstantPrepare(l_code) + ", " + IFSZ_Globals.SQLConstantPrepare(l_name) + ", " + IFSZ_Globals.SQLConstantPrepare(l_u_role) + ", " + IFSZ_Globals.SQLConstantPrepare(l_usercode) + ") " _
                                                        )
                                                    End If
                                                Case "N"
                                                    DataProvider.EExecuteNonQuery( _
                                                      "delete from ""@IFSZ_USER_ROLES"" " + l_letezik_sql _
                                                    )
                                                Case "V"
                                            End Select
                                        End If
                                    End If
                                Next

                            End If

                        Else
                            Throw New Exception("Hiba a felhasználó visszakeresésénél. (" + l_oszlop.Substring(2) + ")")

                        End If

                    End If

                Next

                IFSZ_Globals_SBO.CommitDITransaction()

                Me.frmForm.p_dataset.AcceptChanges()

            Catch ex As Exception
                IFSZ_Globals_SBO.RollbackDITransaction()
                Me.frmForm.show_error(ex.Message)
                Return False
            Finally
                Me.frmForm.Cursor = Cursors.Default
            End Try

        End If

    End Function

#End Region


#Region "Install"

    Private Sub AddPerm(ByVal p_perm As String, ByVal p_name As String, ByVal p_father As String, ByVal p_isitem As Boolean)
        Dim RetVal As Long
        Dim ErrCode As Long
        Dim ErrMsg As String
        Dim mUserPermission As SAPbobsCOM.UserPermissionTree
        mUserPermission = CType(IFSZ_Globals.m_ParentAddOn, IFSZ_Addon).SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oUserPermissionTree)

        mUserPermission.PermissionID = p_perm

        mUserPermission.Name = p_name

        mUserPermission.Options = SAPbobsCOM.BoUPTOptions.bou_FullNone
        If p_isitem Then
            mUserPermission.IsItem = SAPbobsCOM.BoYesNoEnum.tYES
        Else
            mUserPermission.IsItem = SAPbobsCOM.BoYesNoEnum.tNO
        End If

        If Not String.IsNullOrEmpty(p_father) Then
            mUserPermission.ParentID = p_father
        End If
        RetVal = mUserPermission.Add

    End Sub

    Private Sub AddUserPerm()
        Dim l_rc As DataRowCollection = DataProvider.GetDataRecord(QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "sel_internalk_usercode_from_ousr_nolocked_nosuperuser"))
        Dim l_rc2 As DataRowCollection

        If l_rc Is Nothing OrElse l_rc.Count = 0 Then
            Exit Sub
        End If

        For Each l_rowu As DataRow In l_rc
            Dim l_usr As SAPbobsCOM.Users

            Try
                Me.frmForm.Cursor = Cursors.WaitCursor
                IFSZ_Globals_SBO.StartDITransaction()

                l_usr = CType(IFSZ_Globals.m_ParentAddOn, IFSZ_Addon).SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oUsers)
                If l_usr.GetByKey(l_rowu("internal_k")) Then

                    l_rc2 = DataProvider.GetDataRecord(QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "adduserperm_select", l_rowu("user_code")))
                    If l_rc2 Is Nothing OrElse l_rc2.Count = 0 Then
                        Continue For
                    End If
                    For Each l_row As DataRow In l_rc2
                        If l_row("AbsId").GetType() Is GetType(DBNull) Then
                            'Me.frmForm.show_error(l_rowu("user_code").ToString + " felhasználónak " + l_row("Name").ToString + " jogosultság nem adható meg, nem létezik")
                        Else
                            If l_usr.UserPermission.Count > 0 Then
                                Try
                                    For j As Integer = 0 To l_usr.UserPermission.Count - 1
                                        l_usr.UserPermission.SetCurrentLine(j)
                                        If l_usr.UserPermission.PermissionID = l_row("AbsId") Then
                                            Exit Try
                                        End If
                                    Next
                                    'Nem találta meg:
                                    l_usr.UserPermission.Add()
                                Catch ex As Exception
                                    Throw
                                End Try
                            End If
                            l_usr.UserPermission.PermissionID = l_row("AbsId")
                            l_usr.UserPermission.Permission = SAPbobsCOM.BoPermission.boper_Full
                        End If
                    Next

                    If l_usr.Update <> 0 Then
                        Dim RetVal As Long
                        Dim ErrMsg As String
                        CType(IFSZ_Globals.m_ParentAddOn, IFSZ_Addon).SboCompany.GetLastError(RetVal, ErrMsg)
                        Throw New Exception("Hiba a felhasználó jogosultság beállításánál. (DI " + l_rowu("user_code").ToString + "): " + ErrMsg)

                    End If
                Else
                    Throw New Exception("Hiba a felhasználó visszakeresésénél. (DI " + l_rowu("user_code").ToString + ")")

                End If

                IFSZ_Globals_SBO.CommitDITransaction()

            Catch ex As Exception
                IFSZ_Globals_SBO.RollbackDITransaction()
                'Me.frmForm.show_error(l_rowu("user_code").ToString + ": " + ex.Message)
            Finally
                Me.frmForm.Cursor = Cursors.Default
                IFSZ_Globals.ReleaseObject(l_usr)
            End Try
        Next
    End Sub

    Private Sub PermFeltolt()
        If DataProvider.ExecuteScalarDouble(QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "exists_oupttree")) > 0 Then
            Me.frmForm.show_error("Már létre vannak hozva a jogosultságok")
        Else

            Dim l_sql As String
            Dim l_rc As DataRowCollection
            l_sql = QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "permfeltolt_select")

            l_rc = DataProvider.GetDataRecord( _
                QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "permfeltolt_kulso").Replace("/*innersql*/", l_sql) _
            )

            If l_rc IsNot Nothing AndAlso l_rc.Count > 1 Then
                Me.AddPerm("IFSZ_ADDON", "IFSZ AddOn Jogosultságok", "", False)

                For Each l_row As DataRow In l_rc
                    Me.AddPerm(l_row("csoportkod"), l_row("csoportnev"), "IFSZ_ADDON", False)
                Next

                l_rc = DataProvider.GetDataRecord(l_sql)
                For Each l_row As DataRow In l_rc
                    Me.AddPerm(l_row("code"), l_row("name"), l_row("csoportkod"), True)
                Next

            End If

        End If

        If Me.frmForm.show_question("Felhasználók jogosultságainak áttöltése az [@IFSZ_USER_ROLES] táblából?") = MsgBoxResult.Yes Then
            AddUserPerm()
        End If

    End Sub

#End Region

End Class

