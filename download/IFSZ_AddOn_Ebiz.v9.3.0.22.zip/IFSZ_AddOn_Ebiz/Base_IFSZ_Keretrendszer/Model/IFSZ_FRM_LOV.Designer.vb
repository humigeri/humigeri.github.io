Imports System.GlobalizationImports System.ResourcesImports System.ReflectionImports System.IOImports IFSZ_AddOnBase.IFSZ_Types<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _Partial Class IFSZ_FRM_LOV    'Inherits System.Windows.Forms.Form    Inherits IFSZ_Form    'Form overrides dispose to clean up the component list.    <System.Diagnostics.DebuggerNonUserCode()> _    Protected Overrides Sub Dispose(ByVal disposing As Boolean)        p_kilepes = True        If disposing AndAlso components IsNot Nothing Then            components.Dispose()        End If        MyBase.Dispose(disposing)    End Sub    'Required by the Windows Form Designer    Private components As System.ComponentModel.IContainer    'NOTE: The following procedure is required by the Windows Form Designer    'It can be modified using the Windows Form Designer.      'Do not modify it using the code editor.    Private Sub InitializeComponent()        Dim p_columname, l_oszlop_nev As String        Dim i As LOV_OszlopTipus        Dim index As Integer        'Me.DataGridView1 = New System.Windows.Forms.DataGridView        'Me.Label1 = New System.Windows.Forms.Label        'Me.Button1 = New System.Windows.Forms.Button        'Me.TextBox1 = New System.Windows.Forms.TextBox        'Me.Icon = CType(GetObject("$this.Icon"), System.Drawing.Icon)        Me.Icon = System.Drawing.Icon.FromHandle(Global.IFSZ_AddOnBase.My.Resources.Resources.ifsz_icon.GetHicon)        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn        'CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()        Me.SuspendLayout()        '        'Form         '        Me.BackColor = System.Drawing.Color.FromArgb(CType(222, Byte), CType(222, Byte), CType(206, Byte))        If Me.l_FormAdat.Width = 0 Then            Me.l_FormAdat.Width = 590        End If        If Me.l_FormAdat.Height = 0 Then            Me.l_FormAdat.Height = 365        End If        P_Title = "Pr�ba"        Me.Text = Me.l_FormAdat.Title        Me.Left = 236        Me.Width = Me.l_FormAdat.Width        Me.Top = 44        Me.Height = Me.l_FormAdat.Height        'P_Title = "Pr�ba"        'Me.Text = P_Title        'Me.Left = 236        'Me.Width = 590        'Me.Top = 44        'Me.Height = 365        'Me.ClientSize = New System.Drawing.Size(576, 236)        '        'DataGridView1        '        Me.IfszLov = New System.Windows.Forms.DataGridView        CType(Me.IfszLov, System.ComponentModel.ISupportInitialize).BeginInit()        Me.IfszLov.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize        Me.IfszLov.MultiSelect = Me.m_MultiSelect_e        Me.IfszLov.AllowUserToAddRows = False        Me.IfszLov.Name = "IfszLov"        Me.IfszLov.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect        Me.IfszLov.TabIndex = 4        Me.IfszLov.Left = 5        Me.IfszLov.Width = Me.l_FormAdat.Width - 33 '557        Me.IfszLov.Top = 35        Me.IfszLov.Height = Me.l_FormAdat.Height - 110 '265        CType(Me.IfszLov, DataGridView).RowTemplate.Height = 17        CType(Me.IfszLov, DataGridView).BackgroundColor = System.Drawing.Color.FromArgb(CType(222, Byte), CType(222, Byte), CType(206, Byte))        'CType(Me.IfszLov, DataGridView).RowTemplate.HeaderCell.Style.BackColor = System.Drawing.Color.FromArgb(CType(205, Byte), CType(205, Byte), CType(190, Byte))        CType(Me.IfszLov, DataGridView).ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(215, Byte), CType(215, Byte), CType(200, Byte))        CType(Me.IfszLov, DataGridView).RowTemplate.Height = Me.GridRowPixelSize        CType(Me.IfszLov, DataGridView).DefaultCellStyle.Font = New System.Drawing.Font("Tahoma", Me.GridFontSize, System.Drawing.FontStyle.Regular)        CType(Me.IfszLov, DataGridView).DefaultCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft        CType(Me.IfszLov, DataGridView).GridColor = System.Drawing.Color.FromArgb(CType(153, Byte), CType(153, Byte), CType(137, Byte))        CType(Me.IfszLov, DataGridView).BorderStyle = BorderStyle.None        CType(Me.IfszLov, DataGridView).BackgroundColor = System.Drawing.Color.FromArgb(CType(222, Byte), CType(222, Byte), CType(206, Byte))        CType(Me.IfszLov, DataGridView).RowTemplate.HeaderCell.Style.BackColor = System.Drawing.Color.FromArgb(CType(205, Byte), CType(205, Byte), CType(190, Byte))        CType(Me.IfszLov, DataGridView).ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(215, Byte), CType(215, Byte), CType(200, Byte))        CType(Me.IfszLov, DataGridView).RowHeadersWidth = 18        CType(Me.IfszLov, DataGridView).Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _                                                    Or System.Windows.Forms.AnchorStyles.Left) _                                                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)        'DataGridView2 = New System.Windows.Forms.DataGridView        'CType(DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()        'DataGridView2.AllowUserToAddRows = False        'DataGridView2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _        '            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)        'DataGridView2.AutoGenerateColumns = False        'DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize        ''frmForm.DataGridView2.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DG2_batchnum, Me.DG2_debrecen, Me.DG2_budapest, Me.DG2_deb_foglalt, Me.DG2_bud_foglalt, Me.DG2_deb_beerkezo, Me.DG2_bud_beerkezo, Me.DG2_itemname, Me.DG2_itemcode})        ''frmForm.DataGridView2.DataSource = Me.BindingSource1        'DataGridView2.Location = New System.Drawing.Point(12, 275)        'DataGridView2.Name = "DataGridView2"        'DataGridView2.RowHeadersWidth = 22        'DataGridView2.Size = New System.Drawing.Size(925, 151)        'DataGridView2.TabIndex = 1        'CType(DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()        '        'Label1 Keres        '        Me.Label1 = New System.Windows.Forms.Label        Me.Label1.Left = 5        Me.Label1.Width = 25        Me.Label1.Top = 5        Me.Label1.Height = 20        Me.Label1.Text = "Keres�s"        Me.Label1.AutoSize = True        Me.Label1.TabIndex = 2        Me.Label1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)        '        'TextBox1 Keres        '        Me.TextBox1 = New System.Windows.Forms.TextBox        Me.TextBox1.Name = "TextBox1"        Me.TextBox1.Left = 51        Me.TextBox1.Width = 100        Me.TextBox1.Top = 5        Me.TextBox1.Height = 14        Me.TextBox1.TabIndex = 30        If P_Szuresi_Ertek <> "" Then            Me.TextBox1.Text = P_Szuresi_Ertek            Me.TextBox1.BackColor = Color.Blue        End If        Me.TextBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.TextBox1.TabIndex = 1
        '
        'Button OK
        '
        Me.Button1 = New System.Windows.Forms.Button        Me.Button1.Left = 5        Me.Button1.Width = 65        Me.Button1.Top = Me.l_FormAdat.Height - 65 '310        Me.Button1.Height = 19        Me.Button1.Text = "Ok"        Me.Button1.Name = "OK"        Me.Button1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)        Me.Button1.TabIndex = 5
        '
        'Button Cancel
        '
        Me.Button2 = New System.Windows.Forms.Button        Me.Button2.Left = 75        Me.Button2.Width = 65        Me.Button2.Top = Me.l_FormAdat.Height - 65 '310        Me.Button2.Height = 19        Me.Button2.Text = "M�gse"        Me.Button2.Name = "MEGSE"        Me.Button2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)        Me.Button2.TabIndex = 6
        '
        'Column1
        '
        Me.Column1.HeaderText = "Column1"        Me.Column1.Name = "Column1"        '        'Column2        '        Me.Column2.HeaderText = "Column2"        Me.Column2.Name = "Column2"        '        'IFSZ_PUB_LOV        '        'Me.ClientSize = New System.Drawing.Size(443, 273)        Me.Controls.Add(Me.TextBox1)        Me.Controls.Add(Me.Button1)        Me.Controls.Add(Me.Button2)        Me.Controls.Add(Me.Label1)        Me.Controls.Add(Me.IfszLov)        Me.Name = "IFSZ_FRM_LOV"        CType(Me.IfszLov, System.ComponentModel.ISupportInitialize).EndInit()        Me.ResumeLayout(False)        Me.PerformLayout()        For Each i In l_OszlopTipus            l_oszlop_nev = i.DbNev            If i.Link Then                Dim imgCell As TextAndImageColumn = New TextAndImageColumn
                Me.IfszLov.Columns.Add(imgCell)
                imgCell.Image = Global.IFSZ_AddOnBase.My.Resources.Resources.lefuras_be                imgCell.Name = l_oszlop_nev                imgCell.DataPropertyName = l_oszlop_nev                imgCell.MenuUID = 3073                imgCell.FormUID = "150"                CType(CType(IfszLov, DataGridView).Columns.Item(l_oszlop_nev), TextAndImageColumn).MenuUID = i.MenuUID            Else                Dim imgCell As DataGridViewTextBoxColumn = New DataGridViewTextBoxColumn                Me.IfszLov.Columns.Add(imgCell)                imgCell.Name = l_oszlop_nev                imgCell.DataPropertyName = l_oszlop_nev            End If        Next        Dim l As Integer        Try            For l = 0 To Me.IfszLov.Columns.Count - 1                Me.IfszLov.Columns.Item(l).Visible = False            Next        Catch ex As Exception            l = 1        End Try        For Each i In l_OszlopTipus            l_oszlop_nev = i.DbNev            'If i.Link = False Then            '    Me.DataGridView1.Columns.Add(l_oszlop_nev, i.Title)            'Else            '    Me.DataGridView1.Columns.Add(l_oszlop_nev, i.Title)            'End If            Me.IfszLov.Columns.Item(l_oszlop_nev).HeaderText = i.Title            Me.IfszLov.Columns.Item(l_oszlop_nev).ReadOnly = True            Me.IfszLov.Columns.Item(l_oszlop_nev).Visible = i.Visible            Me.IfszLov.Columns.Item(l_oszlop_nev).ToolTipText = i.Description            If i.Width <> 0 Then                Me.IfszLov.Columns.Item(l_oszlop_nev).Width = i.Width            End If            If i.Tipus = "NUMBER" Then                Me.IfszLov.Columns.Item(l_oszlop_nev).DefaultCellStyle.Format = "f2"                Me.IfszLov.Columns.Item(l_oszlop_nev).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight            End If            If Me.IfszLov.Columns.Item(l_oszlop_nev).Visible Then                If Me.IfszLov.Columns.Item(l_oszlop_nev).ReadOnly = True Then                    Me.IfszLov.Columns.Item(l_oszlop_nev).DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(222, Byte), Integer))                Else                    Me.IfszLov.Columns.Item(l_oszlop_nev).DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(253, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(243, Byte), Integer))                    Me.IfszLov.Columns.Item(l_oszlop_nev).DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(156, Byte), Integer))                End If            End If
            If i.RightJustified = True Then
                Me.IfszLov.Columns.Item(l_oszlop_nev).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            End If

            'oColumn.RightJustified = i.RightJustified
            index += 1        Next        CType(Me.Button1, Button).BackgroundImage = Global.IFSZ_AddOnBase.My.Resources.Resources.gomb_hatter        CType(Me.Button1, Button).Font = New System.Drawing.Font("Tahoma", 8, System.Drawing.FontStyle.Regular)        CType(Me.Button1, Button).Height = 22        CType(Me.Button1, Button).TextAlign = ContentAlignment.TopCenter        CType(Me.Button1, Button).FlatStyle = FlatStyle.Flat        CType(Me.Button1, Button).BackgroundImageLayout = ImageLayout.Tile        CType(Me.Button2, Button).BackgroundImage = Global.IFSZ_AddOnBase.My.Resources.Resources.gomb_hatter        CType(Me.Button2, Button).Font = New System.Drawing.Font("Tahoma", 8, System.Drawing.FontStyle.Regular)        CType(Me.Button2, Button).Height = 22        CType(Me.Button2, Button).TextAlign = ContentAlignment.TopCenter        CType(Me.Button2, Button).FlatStyle = FlatStyle.Flat        CType(Me.Button2, Button).BackgroundImageLayout = ImageLayout.Tile        Me.PrevWidth = Me.Width        Me.PrevHeight = Me.Height        'Me.Select()        'Me.IfszLov.Show()        Me.ActiveControl = Me.IfszLov    End Sub    Private p_Dual As IFSZ_DUAL    Private P_Title As String    Friend WithEvents IfszLov As System.Windows.Forms.DataGridView    Friend WithEvents DataGridView2 As System.Windows.Forms.DataGridView    Friend WithEvents Label1 As System.Windows.Forms.Label    Friend WithEvents Button1 As System.Windows.Forms.Button    Friend WithEvents Button2 As System.Windows.Forms.Button    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewTextBoxColumn    Friend WithEvents Column2 As System.Windows.Forms.DataGridViewTextBoxColumn    Friend WithEvents ChBox1 As System.Windows.Forms.CheckBox    Friend WithEvents ChBox2 As System.Windows.Forms.CheckBox    Friend WithEvents ChBox3 As System.Windows.Forms.CheckBox    Friend WithEvents ChBox4 As System.Windows.Forms.CheckBox    Friend WithEvents ChBox5 As System.Windows.Forms.CheckBox    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox    Friend WithEvents ComboBox2 As System.Windows.Forms.ComboBox    Friend WithEvents ComboBox3 As System.Windows.Forms.ComboBox    Friend WithEvents ComboBox4 As System.Windows.Forms.ComboBox    Friend WithEvents ComboBox5 As System.Windows.Forms.ComboBox    Public P_Szuresi_Ertek As String    Public p_keresesMod = True    Public m_MultiSelect_e As Boolean    Public m_SetPosition As Boolean    Public p_Editable As New Collection    'Private p_KeresMod As Boolean = False    Public p_gomb_allapot As IFSZ_Types.Gomb = IFSZ_Types.Gomb.Ok    Public p_kilepes As Boolean = False    Public m_GridHeight As Integer = 0    Public m_GridWidth As Integer = 0    'Public GridFontSize As Integer = 8    'Public GridRowPixelSize As Integer = 16    Public p_oszlop As LOV_OszlopTipus    Public p_NextFocusedColumn As String    Public Structure Rendez        Public oszlop As Integer        Public irany As String        Private Sub New(ByVal l_oszlop As String, ByVal l_irany As String)            Me.oszlop = l_oszlop            Me.irany = l_irany        End Sub    End Structure    Public l_OszlopTipus() As IFSZ_Types.LOV_OszlopTipus    Public l_FormAdat As LOV_Form    Public l_ertek, l_select As String    Public l_lookup_ertek As String    Private l_tabla As String    Private l_matrix As String    Public oForm_Eredeti As IFSZ_Form    Public oSBOFormEredeti As SboForm    Public oForm As Windows.Forms.Form    Public oForm2 As IFSZ_Form    Private l_sor As Integer    Public p_validal As Boolean    Public l_kivalasztott_sor As Integer    Private l_a1 As String    Private l_a2 As String    Public p_rendez As Rendez    Private l_sorok_szama As Integer    Public p_select As String    Public l_colID As String    Friend l_FormID As String    Friend l_Link_ertek As String    Friend l_Osztaly As String    Public PrevWidth As Integer    Public PrevHeight As Integer    Public oMatrix As SAPbouiCOM.Matrix    Public pSor As String    Public pOszlop As String    Public KivalasztasIndul As Boolean    Public p_sorKivalasztasOszlopa As String    Public Sub New(ByRef p_Interim_SBO As IFSZ_Interim_SBO, _
               ByRef oEredetiForm As IFSZ_Form, _
               ByRef oLovCtrl As IFSZ_ILOV_CTRL, _
               ByVal P_FormAdat As IFSZ_Types.LOV_Form, _
               ByVal p_oszlop_tipus() As IFSZ_Types.LOV_OszlopTipus, _
               ByVal p_select As String, _
               Optional ByVal P_SzuresiErtek As String = "", _
               Optional ByRef l_validal As Boolean = True, _
               Optional ByVal p_MultiSelect_e As Boolean = False, _
               Optional ByVal p_SetPosition As Boolean = False)        MyBase.New(p_Interim_SBO)        Me.m_IFSZ_Globals = New IFSZ_Globals        Me.controller = New IFSZ_LOV_CTRL(Me, oLovCtrl)        p_Dual = New IFSZ_DUAL(Me.entity, Me, Me.m_IFSZ_Globals)        oForm_Eredeti = oEredetiForm        ReDim l_OszlopTipus(p_oszlop_tipus.GetUpperBound(0))        l_OszlopTipus = p_oszlop_tipus        l_FormAdat = P_FormAdat        If l_FormAdat.NextFocusedColumn Is Nothing Then            l_FormAdat.NextFocusedColumn = ""        End If        l_select = p_select        P_Szuresi_Ertek = P_SzuresiErtek        p_validal = l_validal        m_MultiSelect_e = p_MultiSelect_e        m_SetPosition = p_SetPosition        Me.InitializeComponent()        Me.IfszLov.Tag = Me.entity(0)        Dim i As Integer        If l_FormAdat.DefaultScrollIndex = 0 Then            For i = 0 To l_OszlopTipus.GetUpperBound(0) - 1                If l_OszlopTipus(i).Visible Then                    Me.p_rendez.oszlop = i                    Me.IfszLov.Columns.Item(i).HeaderText = Me.IfszLov.Columns.Item(i).HeaderText & "<>"                    Exit For                End If            Next        Else            Me.p_rendez.oszlop = l_FormAdat.DefaultScrollIndex        End If        Me.oForm_Eredeti.p_FrmLovForm = Me
        'Me.ThreadStarter(IFSZ_Globals.GetMyWindow(), Me)
        'ThreadStarter(IFSZ_Globals.GetMyWindow(), Me)
        Try
            'Me.Visible = True
        Catch ex As Exception        End Try

        'Me.ThreadStarterSBO("SBO")

    End Sub    Public Sub New(ByRef oEredetiForm As IFSZ_Form, _
               ByRef oLovCtrl As IFSZ_ILOV_CTRL, _
               ByVal P_FormAdat As IFSZ_Types.LOV_Form, _
               ByVal p_oszlop_tipus() As IFSZ_Types.LOV_OszlopTipus, _
               ByVal p_select As String, _
               Optional ByVal P_SzuresiErtek As String = "", _
               Optional ByRef l_validal As Boolean = True, _
               Optional ByVal p_MultiSelect_e As Boolean = False, _
               Optional ByVal p_SetPosition As Boolean = False)        MyBase.New()        Me.m_IFSZ_Globals = New IFSZ_Globals        Me.controller = New IFSZ_LOV_CTRL(Me, oLovCtrl)        p_Dual = New IFSZ_DUAL(Me.entity, Me, Me.m_IFSZ_Globals)        oForm_Eredeti = oEredetiForm        ReDim l_OszlopTipus(p_oszlop_tipus.GetUpperBound(0))        l_OszlopTipus = p_oszlop_tipus        l_FormAdat = P_FormAdat        If l_FormAdat.NextFocusedColumn Is Nothing Then            l_FormAdat.NextFocusedColumn = ""        End If        l_select = p_select        P_Szuresi_Ertek = P_SzuresiErtek        p_validal = l_validal        m_MultiSelect_e = p_MultiSelect_e        m_SetPosition = p_SetPosition

        If P_FormAdat.GridFontSize > 0 Then
            Me.GridFontSize = P_FormAdat.GridFontSize
            Me.GridRowPixelSize = P_FormAdat.GridRowPixelSize
        End If        Me.InitializeComponent()        Me.IfszLov.Tag = Me.entity(0)        Dim i As Integer        If l_FormAdat.DefaultScrollIndex = 0 Then            For i = 0 To l_OszlopTipus.GetUpperBound(0) - 1                If l_OszlopTipus(i).Visible Then                    Me.p_rendez.oszlop = i                    Me.IfszLov.Columns.Item(i).HeaderText = Me.IfszLov.Columns.Item(i).HeaderText & "<>"                    Exit For                End If            Next        Else            Me.p_rendez.oszlop = l_FormAdat.DefaultScrollIndex        End If        Me.oForm_Eredeti.p_FrmLovForm = Me


        'Me.ThreadStarter(IFSZ_Globals.GetMyWindow(), Me)
        'ThreadStarter(IFSZ_Globals.GetMyWindow(), Me)
        Try
            'Me.Visible = True
        Catch ex As Exception        End Try

        'Me.ThreadStarterSBO("SBO")

    End Sub


    Public Sub New(ByRef oEredetiForm As IFSZ_Form, _
               ByRef oEntity As IFSZ_IEntity, _
               ByRef oLovCtrl As IFSZ_ILOV_CTRL, _
               ByVal P_FormAdat As IFSZ_Types.LOV_Form, _
               ByVal p_oszlop_tipus() As IFSZ_Types.LOV_OszlopTipus, _
               ByVal p_select As String, _
               Optional ByVal P_SzuresiErtek As String = "", _
               Optional ByRef l_validal As Boolean = True, _
               Optional ByVal p_MultiSelect_e As Boolean = False, _
               Optional ByVal p_SetPosition As Boolean = False)        MyBase.New()        Me.m_IFSZ_Globals = New IFSZ_Globals        Me.controller = New IFSZ_LOV_CTRL(Me, oLovCtrl)        p_Dual = oEntity        ReDim Preserve entity(0)        entity(0) = p_Dual        oForm_Eredeti = oEredetiForm        ReDim l_OszlopTipus(p_oszlop_tipus.GetUpperBound(0))        l_OszlopTipus = p_oszlop_tipus        l_FormAdat = P_FormAdat        If l_FormAdat.NextFocusedColumn Is Nothing Then            l_FormAdat.NextFocusedColumn = ""        End If        l_select = p_select        P_Szuresi_Ertek = P_SzuresiErtek        p_validal = l_validal        m_MultiSelect_e = p_MultiSelect_e        m_SetPosition = p_SetPosition        Me.InitializeComponent()        Me.IfszLov.Tag = Me.entity(0)        Dim i As Integer        If l_FormAdat.DefaultScrollIndex = 0 Then            For i = 0 To l_OszlopTipus.GetUpperBound(0) - 1                If l_OszlopTipus(i).Visible Then                    Me.p_rendez.oszlop = i                    Me.IfszLov.Columns.Item(i).HeaderText = Me.IfszLov.Columns.Item(i).HeaderText & "<>"                    Exit For                End If            Next        Else            Me.p_rendez.oszlop = l_FormAdat.DefaultScrollIndex        End If        Me.oForm_Eredeti.p_FrmLovForm = Me
        'Me.ThreadStarter(IFSZ_Globals.GetMyWindow(), Me)
        'ThreadStarter(IFSZ_Globals.GetMyWindow(), Me)
        Try
            'Me.Visible = True
        Catch ex As Exception        End Try

        'Me.ThreadStarterSBO("SBO")

    End Sub    Public Sub New(ByRef p_Interim_SBO As IFSZ_Interim_SBO,
               ByRef oEredetiForm As SboForm,
               ByRef oLovCtrl As IFSZ_ILOV_CTRL,
               ByVal P_FormAdat As IFSZ_Types.LOV_Form,
               ByVal p_oszlop_tipus() As IFSZ_Types.LOV_OszlopTipus,
               ByVal p_select As String,
               ByVal p_sor As String,
               ByVal p_oszlop As String,
               ByRef pMatrix As Object,
               Optional ByVal P_SzuresiErtek As String = "",
               Optional ByRef l_validal As Boolean = True,
               Optional ByVal p_MultiSelect_e As Boolean = False,
               Optional ByVal p_SetPosition As Boolean = False,
               Optional ByVal sorKivalasztasOszlopa As String = "")        MyBase.New(p_Interim_SBO)        Me.m_IFSZ_Globals = New IFSZ_Globals        Me.controller = New IFSZ_SBO_LOV_CTRL(Me, oLovCtrl)        p_Dual = New IFSZ_DUAL(Me.entity, Me, Me.m_IFSZ_Globals)        ReDim l_OszlopTipus(p_oszlop_tipus.GetUpperBound(0))        l_OszlopTipus = p_oszlop_tipus        l_FormAdat = P_FormAdat        If l_FormAdat.NextFocusedColumn Is Nothing Then            l_FormAdat.NextFocusedColumn = ""        End If        l_select = p_select        P_Szuresi_Ertek = P_SzuresiErtek        p_validal = l_validal        m_MultiSelect_e = True        m_SetPosition = p_SetPosition        oMatrix = pMatrix        pSor = p_sor        pOszlop = p_oszlop        oSBOFormEredeti = oEredetiForm        p_sorKivalasztasOszlopa = sorKivalasztasOszlopa        Me.oSBOFormEredeti.p_LovForm = Me        Me.InitializeComponent()        Me.IfszLov.Tag = Me.entity(0)        Dim i As Integer        If l_FormAdat.DefaultScrollIndex = 0 Then            For i = 0 To l_OszlopTipus.GetUpperBound(0) - 1                If l_OszlopTipus(i).Visible Then                    Me.p_rendez.oszlop = i                    Me.IfszLov.Columns.Item(i).HeaderText = Me.IfszLov.Columns.Item(i).HeaderText & "<>"                    Exit For                End If            Next        Else            Me.p_rendez.oszlop = l_FormAdat.DefaultScrollIndex        End If

        'Me.ThreadStarter(IFSZ_Globals.GetMyWindow(), Me)
        'ThreadStarter(IFSZ_Globals.GetMyWindow(), Me)
        'Me.ThreadStarter("SBO")

        Try
            'Me.Visible = True
        Catch ex As Exception        End Try

        'Me.ThreadStarterSBO("SBO")

    End Sub

    <STAThread()> _
    Public Sub ThreadStarterSBO()
        Me.Show()
        Me.Activate()
        Me.TopLevel = True
        Me.WindowState = FormWindowState.Normal
        'Me.TopMost = True

        Do
            System.Windows.Forms.Application.DoEvents()
            System.Threading.Thread.Sleep(100)
            If Me.p_kilepes Then
                Exit Do
            End If
        Loop
    End Sub



    Public Sub ThreadStarter(ByVal lParent As String)
        Dim MyProcs() As Process
        Dim lPathName As String
        Dim lPoz As Integer

        Dim MyWindow As New WindowWrapper(IFSZ_Globals.GetMyProc().MainWindowHandle)
        ThreadStarter(MyWindow)



    End Sub

    Public Sub ThreadStarter(ByVal lAddon As System.Windows.Forms.IWin32Window)
        Me.Show(lAddon)
        Me.Activate()
        Me.TopLevel = True
        Me.WindowState = FormWindowState.Normal
        'Me.TopMost = True

        IFSZ_Globals.SBOMDIAblakhozCsatol(Me)

        Do
            System.Windows.Forms.Application.DoEvents()
            System.Threading.Thread.Sleep(100)
            If Me.p_kilepes Then
                Exit Do
            End If
        Loop
    End Sub

    Public Sub ThreadStarterSBO(ByVal lAddon As System.Windows.Forms.IWin32Window)
        Me.Show()
        Me.Activate()
        Me.TopLevel = True
        Me.WindowState = FormWindowState.Normal
        'Me.TopMost = True

        Dim MyProcs() As Process
        Dim l_handleParent As IntPtr
        Dim l_eredeti_title As String
        Dim l_uj_title As String
        'Me.TopMost = True

        l_eredeti_title = IFSZ_Globals.m_ParentAddOn.SboApplication.Desktop.Title
        l_uj_title = "SBO under " + IFSZ_Globals.m_ParentAddOn.SboCompany.UserName + IFSZ_Globals.m_RandomClass.Next(0, 999999).ToString
        IFSZ_Globals.m_ParentAddOn.SboApplication.Desktop.Title = l_uj_title

        MyProcs = Process.GetProcessesByName("SAP Business One")

        If MyProcs.Length <> 0 Then
            For i As Integer = 0 To MyProcs.Length - 1
                If MyProcs(i).MainWindowTitle = l_uj_title Then
                    l_handleParent = MyProcs(i).MainWindowHandle
                End If
            Next
        End If

        IFSZ_Globals.m_ParentAddOn.SboApplication.Desktop.Title = l_eredeti_title
        If IntPtr.Zero.Equals(l_handleParent) Then
            l_handleParent = Process.GetProcessesByName("SAP Business One")(0).MainWindowHandle
        End If

        'Dim l_handleParent As IntPtr = Process.GetProcessesByName("SAP Business One")(0).MainWindowHandle
        Dim l_handleRealParent As IntPtr
        Dim l_handleChild As IntPtr = Me.Handle
        l_handleRealParent = Win32Helper.FindWindowEx(l_handleParent, Nothing, Nothing, Nothing)
        l_handleRealParent = Win32Helper.GetWindow(l_handleRealParent, 2) '2 = GW_HWNDNEXT
        If Not IntPtr.Zero.Equals(l_handleChild) And Not IntPtr.Zero.Equals(l_handleRealParent) Then
            Win32Helper.SetParent(l_handleChild, l_handleRealParent)
            Me.Invalidate()
        End If
        Me.controller.Form_Event("AfterFormLoad", Nothing, Nothing)

        Do
            System.Windows.Forms.Application.DoEvents()
            System.Threading.Thread.Sleep(100)
            If Me.p_kilepes Then
                Exit Do
            End If
        Loop
    End Sub

    Public Sub ThreadStarterSBO(ByVal lParent As String)
        Dim MyProcs() As Process
        Dim lPathName As String
        Dim lPoz As Integer

        Dim MyWindow As New WindowWrapper(IFSZ_Globals.GetMyProc().MainWindowHandle)
        ThreadStarterSBO(MyWindow)



    End Sub

    Public Sub New()        Me.m_IFSZ_Globals = New IFSZ_Globals        'Me.controller = New IFSZ_LOV_CTRL(Me)        InitializeComponent()        ' Add any initialization after the InitializeComponent() call.    End Sub    Public Function getDataSet(ByVal l_select As String) As DataSet        Dim sqlQuery As String        Dim dataSet As DataSet = New DataSet        Try            sqlQuery = l_select            ' Get a data set from the query            dataSet = DataProvider.EGetDataSet(sqlQuery.ToString(), 100)            ' Create variables for data set tables            Dim Table As DataTable = dataSet.Tables(0)            Table.TableName = "IFSZ_DUAL"            dataSet.Tables(0).TableName = "IFSZ_DUAL"            Return dataSet        Finally            If (Not dataSet Is Nothing) Then                'System.Runtime.InteropServices.Marshal.ReleaseComObject(dataSet)                dataSet.Dispose()            End If        End Try    End Function    Private Sub DataGrid1_ColumnHeaderMouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles IfszLov.ColumnHeaderMouseClick        Dim t, i As Integer        t = 0        p_rendez.oszlop = e.ColumnIndex        For i = 0 To CType(sender, DataGridView).Columns.Count - 1            CType(sender, DataGridView).Columns.Item(i).HeaderText = CType(sender, DataGridView).Columns.Item(i).HeaderText.Replace("<>", "")        Next        CType(sender, DataGridView).Columns.Item(e.ColumnIndex).HeaderText = CType(sender, DataGridView).Columns.Item(e.ColumnIndex).HeaderText & "<>"    End Sub    Private Sub IFSZ_FRM_LOV_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing        Dim i As Integer        i = 0        Me.oSBOFormEredeti.p_LovForm = Nothing        Me.oSBOFormEredeti = Nothing        IFSZ_Globals.ActivateSBOWindow()    End Sub    Private Sub KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles IfszLov.KeyDown        Me.controller.Item_Event(PItemEvent.KeyDown, sender, e)    End Sub#Region "Link"    Public Sub link_pressed(ByVal l_ColUID As String, ByVal l_Row As Integer, ByVal p_ertek As String)        Dim l_index As String        Dim p_osztaly As String        Dim oArgs() As Object = {Me.oForm_Eredeti.m_ParentAddon, ""}        Dim oForm As SboForm        Dim Dummy As New IFSZ_Dummy_Addonbase        l_index = l_ColUID        If Me.l_OszlopTipus(CInt(l_index)).MenuUID > 0 Then            Me.l_Link_ertek = p_ertek            Me.l_colID = l_ColUID            Me.l_FormID = Me.l_OszlopTipus(CInt(l_index)).FormUID            Me.l_Osztaly = Me.l_OszlopTipus(CInt(l_index)).LinkOsztaly            Me.oForm_Eredeti.m_ParentAddon.SboApplication.ActivateMenuItem(Me.l_OszlopTipus(CInt(l_index)).MenuUID)        Else            p_osztaly = Me.l_OszlopTipus(CInt(l_index)).LinkOsztaly            oForm = [Assembly].GetExecutingAssembly.CreateInstance( _                                           p_osztaly, _                                           True, _                                           BindingFlags.Public Or BindingFlags.Instance Or BindingFlags.CreateInstance, _                                           Nothing, _                                           oArgs, _                                           Nothing, _                                           Nothing)            If (oForm Is Nothing) Then                oForm = [Assembly].GetAssembly(Dummy.GetType()).CreateInstance( _                                                                           p_osztaly, _                                                                           True, _                                                                           BindingFlags.Public Or BindingFlags.Instance Or BindingFlags.CreateInstance, _                                                                           Nothing, _                                                                           oArgs, _                                                                           Nothing, _                                                                           Nothing)            End If            If (Not oForm Is Nothing) Then                ' If got an instance, add to our list                Me.oForm_Eredeti.m_ParentAddon.SBOForms.Add(oForm, oForm.UniqueID)            End If        End If    End Sub#End RegionEnd Class