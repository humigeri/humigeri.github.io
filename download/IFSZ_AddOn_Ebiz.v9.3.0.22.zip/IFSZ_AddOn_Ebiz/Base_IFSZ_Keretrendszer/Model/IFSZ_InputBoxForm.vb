Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
''' <summary>
''' Summary description for InputBoxForm.
''' </summary>
Friend Class IFSZ_InputBoxForm
    Inherits System.Windows.Forms.Form
    Implements IIFSZ_FileDialogResult

    Private btnOK As System.Windows.Forms.Button
    Private btnCancel As System.Windows.Forms.Button
    Private lblText As System.Windows.Forms.Label
    Public txtResult As System.Windows.Forms.TextBox
    Private strReturnValue As String
    Private pntStartLocation As Point
    ''' <summary>
    ''' Required designer variable.
    ''' </summary>
    Private components As System.ComponentModel.Container = Nothing

    Public txtResultArray() As System.Windows.Forms.Control
    Private lblTextArray() As System.Windows.Forms.Label
    Private m_layout As st_IFSZ_InputBoxLayout

    Private Const c_horizontal_margin As Integer = 16
    Private Const c_btnOK_width As Integer = 64
    Private Const c_btnOK_height As Integer = 24

    Private plFileDialogOpen As Boolean = False
    Private plBetoltFileDialog As IFSZ_FileDialog
    Private m_FileTextBox As String = Nothing
    Private m_interim_sbo As IFSZ_Interim_SBO

    Public Sub New(Optional ByRef p_interim_sbo As IFSZ_Interim_SBO = Nothing)
        ' Required for Windows Form Designer support
        InitializeComponent()
        Me.strReturnValue = ""
        Me.m_interim_sbo = p_interim_sbo
    End Sub

    ''' <summary>
    ''' Clean up any resources being used.
    ''' </summary>
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If components IsNot Nothing Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

#Region "Windows Form Designer generated code"
    ''' <summary>
    ''' Required method for Designer support - do not modify
    ''' the contents of this method with the code editor.
    ''' </summary>
    Private Sub InitializeComponent()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.txtResult = New System.Windows.Forms.TextBox()
        Me.lblText = New System.Windows.Forms.Label()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        ' 
        ' btnOK
        ' 
        Me.btnOK.Location = New System.Drawing.Point(288, 8)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(64, 24)
        Me.btnOK.TabIndex = 1
        Me.btnOK.Text = "OK"
        AddHandler Me.btnOK.Click, AddressOf Me.btnOK_Click
        ' 
        ' txtResult
        ' 
        Me.txtResult.Location = New System.Drawing.Point(8, 80)
        Me.txtResult.Name = "txtResult"
        Me.txtResult.Size = New System.Drawing.Size(344, 20)
        Me.txtResult.TabIndex = 0
        Me.txtResult.Text = ""
        ' 
        ' lblText
        ' 
        Me.lblText.Location = New System.Drawing.Point(16, 8)
        Me.lblText.Name = "lblText"
        Me.lblText.Size = New System.Drawing.Size(264, 64)
        Me.lblText.TabIndex = 2
        Me.lblText.Text = "InputBox"
        ' 
        ' btnCancel
        ' 
        Me.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnCancel.Location = New System.Drawing.Point(288, 40)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(64, 24)
        Me.btnCancel.TabIndex = 3
        Me.btnCancel.Text = "Cancel"
        AddHandler Me.btnCancel.Click, AddressOf Me.btnCancel_Click
        ' 
        ' InputBoxForm
        ' 
        Me.AcceptButton = Me.btnOK
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.CancelButton = Me.btnCancel
        Me.ClientSize = New System.Drawing.Size(362, 111)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnCancel, Me.lblText, Me.txtResult, Me.btnOK})
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "InputBoxForm"
        Me.Text = "InputBox"
        AddHandler Me.Load, AddressOf Me.InputBoxForm_Load
        Me.ResumeLayout(False)

    End Sub
#End Region

    Private Sub InputBoxForm_Load(ByVal sender As Object, ByVal e As System.EventArgs)
        If Not Me.pntStartLocation.IsEmpty Then
            Me.Top = Me.pntStartLocation.X
            Me.Left = Me.pntStartLocation.Y
        End If
        If Me.m_layout.Fields IsNot Nothing Then
            For i As Integer = 0 To Me.m_layout.Fields.GetUpperBound(0)
                If Me.m_layout.Fields(i).ComboValues IsNot Nothing AndAlso Not String.IsNullOrEmpty(Me.m_layout.Fields(i).DefaultValue) Then
                    CType(Me.txtResultArray(i), ComboBox).SelectedValue = Me.m_layout.Fields(i).DefaultValue
                End If
            Next
        End If
    End Sub

    Private Sub btnOK_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Me.strReturnValue = Me.txtResult.Text
        Me.DialogResult = Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    Private Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Me.DialogResult = Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub txtBoxDateValidate(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs)
        Dim l_datum As DateTime
        If Not String.IsNullOrEmpty(CType(sender, TextBox).Text) Then
            IFSZ_Globals.FormStringToDate(CType(sender, TextBox).Text, l_datum)
        End If
    End Sub

    Private Sub txtBoxDateTimeValidate(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs)
        Dim l_datum As DateTime
        If Not String.IsNullOrEmpty(CType(sender, TextBox).Text) Then
            IFSZ_Globals.FormStringToDateTime(CType(sender, TextBox).Text, l_datum)
        End If
    End Sub

    Private Sub txtBoxDoubleValidate(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs)
        Dim l_ertek As String = CType(sender, TextBox).Text
        If Not String.IsNullOrEmpty(l_ertek) Then
            Dim l_szamertek As Double
            If Not IFSZ_Globals.FormStringToDouble(l_ertek, l_szamertek) Then
                MsgBox("Nem megfelel� sz�mform�tum", MsgBoxStyle.OkOnly, "Hiba!")
                CType(e, System.ComponentModel.CancelEventArgs).Cancel = True
                Exit Sub
            End If
        End If
    End Sub

    Private Sub btnFDialog_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Me.m_FileTextBox = CType(sender, Button).Name.Substring(10)
        Me.ThreadShowFileDialog(False)
    End Sub

    Private Sub btnSaveFDialog_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Me.m_FileTextBox = CType(sender, Button).Name.Substring(10)
        Me.ThreadShowFileDialog(True)
    End Sub

    Public Sub CreateLayout(ByVal p_layout As st_IFSZ_InputBoxLayout)
        Me.m_layout = p_layout
        If m_layout.XPos >= 0 AndAlso m_layout.YPos >= 0 Then
            Me.StartLocation = New Point(m_layout.XPos, m_layout.YPos)
        End If
        If m_layout.Width >= 0 AndAlso m_layout.Height >= 0 Then
            Me.ClientSize = New Point(m_layout.Width, m_layout.Height)
        End If
        Me.m_layout.Width = Me.ClientSize.Width
        Me.m_layout.Height = Me.ClientSize.Height
        Me.Size = New System.Drawing.Size(400, 800)
        If m_layout.Width >= 0 AndAlso m_layout.Height >= 0 Then
            Me.ClientSize = New Point(m_layout.Width, m_layout.Height)
        End If

        Me.btnOK.Size = New System.Drawing.Size(c_btnOK_width, c_btnOK_height)
        Me.btnCancel.Size = New System.Drawing.Size(c_btnOK_width, c_btnOK_height)
        Me.btnOK.TabIndex = (Me.m_layout.TabStops.GetUpperBound(0) + 1) * 2 + 1
        Me.btnCancel.TabIndex = (Me.m_layout.TabStops.GetUpperBound(0) + 1) * 2 + 2

        Me.txtResult.Visible = False
        Me.lblText.Visible = False

        Me.SetWindowSize(0)

        ReDim Me.lblTextArray(Me.m_layout.Fields.GetUpperBound(0))
        ReDim Me.txtResultArray(Me.m_layout.Fields.GetUpperBound(0))

        Dim i As Integer
        Dim l_col, l_row, l_temp, l_width As Integer
        l_row = 0
        l_col = 0

        For i = 0 To Me.m_layout.Fields.GetUpperBound(0)
            'Megn�zz�k, hogy kif�r-e m�g ebbe a sorba. Ha nem, akkor �j sor
            If l_col > 0 Then
                Dim l_tempcol As Integer = l_col
                Dim l_temprow As Integer = l_row
                Dim l_kezd As Integer = Me.m_layout.TabStops(l_col)
                Dim l_veg As Integer
                If Me.m_layout.TabStops.GetUpperBound(0) >= l_tempcol + 1 Then
                    l_veg = Me.m_layout.TabStops(l_tempcol + 1)
                Else
                    l_veg = Me.m_layout.Width - 16
                End If
                l_temp = l_row
                While l_temp >= l_temprow AndAlso l_veg - l_kezd < Me.m_layout.Fields(i).LabelLength
                    Me.NextTabStop(l_tempcol, l_temprow)
                    If Me.m_layout.TabStops.GetUpperBound(0) >= l_tempcol + 1 Then
                        l_veg = Me.m_layout.TabStops(l_tempcol + 1)
                    Else
                        l_veg = Me.m_layout.Width - 16
                    End If
                End While
                Me.NextTabStop(l_tempcol, l_temprow)
                If Me.m_layout.TabStops.GetUpperBound(0) >= l_tempcol + 1 Then
                    l_veg = Me.m_layout.TabStops(l_tempcol + 1)
                Else
                    l_veg = Me.m_layout.Width - 16
                End If
                l_kezd = Me.m_layout.TabStops(l_tempcol)
                While l_temp >= l_temprow AndAlso l_veg - l_kezd < Me.m_layout.Fields(i).TextBoxLength
                    Me.NextTabStop(l_tempcol, l_temprow)
                    If Me.m_layout.TabStops.GetUpperBound(0) >= l_tempcol + 1 Then
                        l_veg = Me.m_layout.TabStops(l_tempcol + 1)
                    Else
                        l_veg = Me.m_layout.Width - 16
                    End If
                End While
                If l_temprow > l_row Then
                    l_col = 0
                    l_row += 1
                End If

            End If
            'Prompt
            If (l_col And 1) = 1 Then
                'Csak p�ros tabstopra tesz�nk promptot
                Me.NextTabStop(l_col, l_row)
            End If
            'Megvan a helye, l�trehozhatjuk a promptot
            Me.lblTextArray(i) = New System.Windows.Forms.Label()
            Me.lblTextArray(i).Location = Me.GetTabStopPoint(l_col, l_row)
            Me.lblTextArray(i).Name = "lblText" + i.ToString
            Me.lblTextArray(i).Size = Me.GetTabStopSize(l_col, Me.m_layout.Fields(i).LabelLength)
            Me.lblTextArray(i).TabIndex = 1 + i * 5
            Me.lblTextArray(i).Text = Me.m_layout.Fields(i).Label
            l_width = Me.lblTextArray(i).Size.Width

            '�tl�p�nk a k�vetkez� tabstopra. Ha az nincs el�g messze, mert belel�gna a prompt, akkor m�gtov�bb l�p�nk
            l_temp = l_row
            Me.NextTabStop(l_col, l_row)
            While l_temp >= l_row AndAlso Me.GetTabStopPoint(l_col, l_row).X - Me.lblTextArray(i).Location.X < l_width
                Me.NextTabStop(l_col, l_row)
            End While

            'Megvan a helye a textboxnak is, l�trehozhatjuk

            If Me.m_layout.Fields(i).ComboValues Is Nothing Then
                Me.txtResultArray(i) = New System.Windows.Forms.TextBox()
                Me.txtResultArray(i).Location = Me.GetTabStopPoint(l_col, l_row)
                Me.txtResultArray(i).Name = "txtResult" + i.ToString
                Me.txtResultArray(i).TabIndex = 0 + i * 5
                If Me.m_layout.Fields(i).FieldType = en_IFSZ_InputBoxFieldType.Password_ Then
                    CType(Me.txtResultArray(i), System.Windows.Forms.TextBox).UseSystemPasswordChar = True
                End If

                If Me.m_layout.Fields(i).FieldType = en_IFSZ_InputBoxFieldType.File_ OrElse Me.m_layout.Fields(i).FieldType = en_IFSZ_InputBoxFieldType.SaveFileDialog_ Then
                    If Me.m_FileTextBox Is Nothing Then
                        'Ha van a formunkon f�jlv�laszt�, akkor p�ld�nyos�tani kell ezt az oszt�lyt
                        plBetoltFileDialog = New IFSZ_FileDialog()
                        Me.m_FileTextBox = ""
                    End If
                    Me.txtResultArray(i).Size = Me.GetTabStopSize(l_col, Me.m_layout.Fields(i).TextBoxLength)
                    Me.txtResultArray(i).Width = Me.txtResultArray(i).Width - 25
                    l_width = Me.txtResultArray(i).Size.Width + 25

                    Dim l_button As New Button
                    l_button.Top = CType(Me.txtResultArray(i), TextBox).Top
                    l_button.Left = CType(Me.txtResultArray(i), TextBox).Left + CType(Me.txtResultArray(i), TextBox).Width
                    l_button.Width = 25
                    l_button.Height = CType(Me.txtResultArray(i), TextBox).Height
                    l_button.Text = "..."

                    l_button.Name = "btnFDialog" + i.ToString
                    l_button.TabIndex = 2 + i * 5
                    If Me.m_layout.Fields(i).FieldType = en_IFSZ_InputBoxFieldType.File_ Then
                        AddHandler l_button.Click, AddressOf Me.btnFDialog_Click
                    Else
                        AddHandler l_button.Click, AddressOf Me.btnSaveFDialog_Click
                    End If
                    Me.Controls.Add(l_button)

                Else
                    Me.txtResultArray(i).Size = Me.GetTabStopSize(l_col, Me.m_layout.Fields(i).TextBoxLength)
                    Select Case Me.m_layout.Fields(i).FieldType
                        Case en_IFSZ_InputBoxFieldType.Date_
                            If String.IsNullOrEmpty(Me.m_layout.Fields(i).DefaultValue) Then
                                Me.txtResultArray(i).Text = ""
                            Else
                                Me.txtResultArray(i).Text = IFSZ_Globals.DateToFormString(IFSZ_Globals.GetInternalStringToDate(Me.m_layout.Fields(i).DefaultValue))
                            End If
                            AddHandler Me.txtResultArray(i).Validating, AddressOf Me.txtBoxDateValidate
                        Case en_IFSZ_InputBoxFieldType.DateTime_
                            If String.IsNullOrEmpty(Me.m_layout.Fields(i).DefaultValue) Then
                                Me.txtResultArray(i).Text = ""
                            Else
                                Me.txtResultArray(i).Text = IFSZ_Globals.DateTimeToFormString(IFSZ_Globals.GetInternalStringToDateTime(Me.m_layout.Fields(i).DefaultValue))
                            End If
                            AddHandler Me.txtResultArray(i).Validating, AddressOf Me.txtBoxDateTimeValidate
                        Case en_IFSZ_InputBoxFieldType.Double_
                            Me.txtResultArray(i).Text = IFSZ_Globals.DecimalToFormString(IFSZ_Globals.GetInternalStringToDecimal(Me.m_layout.Fields(i).DefaultValue))
                            AddHandler Me.txtResultArray(i).Validating, AddressOf Me.txtBoxDoubleValidate
                        Case Else
                            Me.txtResultArray(i).Text = Me.m_layout.Fields(i).DefaultValue
                    End Select
                    l_width = Me.txtResultArray(i).Size.Width
                End If
            Else
                Me.txtResultArray(i) = New System.Windows.Forms.ComboBox()
                CType(Me.txtResultArray(i), ComboBox).Location = Me.GetTabStopPoint(l_col, l_row)
                CType(Me.txtResultArray(i), ComboBox).Name = "txtResult" + i.ToString
                CType(Me.txtResultArray(i), ComboBox).Size = Me.GetTabStopSize(l_col, Me.m_layout.Fields(i).TextBoxLength)
                CType(Me.txtResultArray(i), ComboBox).TabIndex = 0 + i * 5
                CType(Me.txtResultArray(i), ComboBox).DataSource = Me.m_layout.Fields(i).ComboValues
                CType(Me.txtResultArray(i), ComboBox).ValueMember = Me.m_layout.Fields(i).ComboValueMember
                CType(Me.txtResultArray(i), ComboBox).DisplayMember = Me.m_layout.Fields(i).ComboDisplayMember
                CType(Me.txtResultArray(i), ComboBox).DropDownStyle = ComboBoxStyle.DropDownList
                If Not String.IsNullOrEmpty(Me.m_layout.Fields(i).DefaultValue) Then
                    CType(Me.txtResultArray(i), ComboBox).SelectedValue = Me.m_layout.Fields(i).DefaultValue
                End If
                l_width = CType(Me.txtResultArray(i), ComboBox).Size.Width
            End If

            '�tl�p�nk a k�vetkez� tabstopra. Ha az nincs el�g messze, mert belel�gna a textbox, akkor m�gtov�bb l�p�nk
            l_temp = l_row
            Me.NextTabStop(l_col, l_row)
            While l_temp >= l_row AndAlso Me.GetTabStopPoint(l_col, l_row).X - Me.txtResultArray(i).Location.X < l_width
                Me.NextTabStop(l_col, l_row)
            End While

            Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblTextArray(i), Me.txtResultArray(i)})

        Next

        If l_col = 0 Then
            'Minden �j sorba l�p�sn�l n�velj�k az ablakm�retet. Viszont akkor m�g nem biztos, hogy az �j sorba ker�l is mez�.
            'Ha az l_col=0, akkor nem ker�lt az utols� sorba semmi, ez�rt visszal�p�nk az ablakm�retben.
            Me.SetWindowSize(l_row - 1)
        End If

    End Sub

    Private Sub NextTabStop(ByRef p_col As Integer, ByRef p_row As Integer)
        p_col += 1
        If p_col > m_layout.TabStops.GetUpperBound(0) Then
            p_col = 0
            p_row += 1
            Me.SetWindowSize(p_row) ' + 1)
        End If
    End Sub

    Private Function GetTabStopPoint(ByRef p_col As Integer, ByRef p_row As Integer) As System.Drawing.Point
        Dim l_x, l_y As String
        l_x = Me.m_layout.TabStops(p_col)
        l_y = 16 + (p_row * (Me.m_layout.LineHeight + Me.m_layout.LineSpacing))
        Return New System.Drawing.Point(l_x, l_y)
    End Function

    Private Function GetTabStopSize(ByRef p_col As Integer, ByVal p_fieldwidth As Integer) As System.Drawing.Size
        Dim l_width As Integer
        If p_col >= Me.m_layout.TabStops.GetUpperBound(0) Then
            l_width = Me.m_layout.Width - Me.m_layout.TabStops(p_col) - Me.m_layout.TabStops(0)
        Else
            l_width = Me.m_layout.TabStops(p_col + 1) - Me.m_layout.TabStops(p_col)
        End If
        If l_width < p_fieldwidth Then
            l_width = p_fieldwidth
        End If
        Return New System.Drawing.Size(l_width, Me.m_layout.LineHeight)
    End Function

    Private Sub SetWindowSize(ByRef p_row As Integer)
        Me.btnOK.Location = New System.Drawing.Point(Me.m_layout.TabStops(0), c_horizontal_margin + ((p_row + 1) * (Me.m_layout.LineHeight + Me.m_layout.LineSpacing)))
        Me.btnCancel.Location = New System.Drawing.Point(Me.m_layout.TabStops(0) * 2 + c_btnOK_width, c_horizontal_margin + ((p_row + 1) * (Me.m_layout.LineHeight + Me.m_layout.LineSpacing)))

        Dim l_newHeight As Integer
        l_newHeight = c_horizontal_margin * 2 + (p_row * (Me.m_layout.LineHeight + Me.m_layout.LineSpacing)) + c_btnOK_height
        If l_newHeight > Me.m_layout.Height Then
            Me.m_layout.Height = l_newHeight
            Me.ClientSize = New Point(Me.m_layout.Width, l_newHeight)
        End If

    End Sub

    Public WriteOnly Property Title() As String
        Set(ByVal value As String)
            Me.Text = value
        End Set
    End Property

    Public WriteOnly Property Prompt() As String
        Set(ByVal value As String)
            Me.lblText.Text = value
        End Set
    End Property

    Public ReadOnly Property ReturnValue() As String
        Get
            Return strReturnValue
        End Get
    End Property

    Public ReadOnly Property ReturnAllValues() As String()
        Get
            Dim i As Integer
            Dim l_ret(Me.m_layout.Fields.GetUpperBound(0)) As String
            Dim l_ertek As String
            For i = 0 To Me.m_layout.Fields.GetUpperBound(0)
                If Me.txtResultArray(i).GetType() Is GetType(TextBox) Then
                    l_ertek = Me.txtResultArray(i).Text
                ElseIf Me.txtResultArray(i).GetType() Is GetType(ComboBox) Then
                    l_ertek = CType(Me.txtResultArray(i), ComboBox).SelectedValue
                Else
                    l_ertek = Nothing
                End If
                If String.IsNullOrEmpty(l_ertek) Then
                    l_ret(i) = l_ertek
                Else
                    Select Case Me.m_layout.Fields(i).FieldType
                        Case en_IFSZ_InputBoxFieldType.Date_
                            Dim l_datum As DateTime
                            IFSZ_Globals.FormStringToDate(l_ertek, l_datum)
                            l_ret(i) = IFSZ_Globals.GetInternalDateToString(l_datum)
                        Case en_IFSZ_InputBoxFieldType.DateTime_
                            Dim l_datum As DateTime
                            IFSZ_Globals.FormStringToDateTime(l_ertek, l_datum)
                            l_ret(i) = IFSZ_Globals.GetInternalDateTimeToString(l_datum)
                        Case en_IFSZ_InputBoxFieldType.Double_
                            Dim l_szamertek As Double
                            If Not IFSZ_Globals.FormStringToDecimal(l_ertek, l_szamertek) Then
                                l_ret(i) = Nothing
                            Else
                                l_ret(i) = IFSZ_Globals.GetInternalDecimalToString(l_szamertek)
                            End If
                        Case Else
                            l_ret(i) = l_ertek
                    End Select
                End If
            Next
            Return l_ret
        End Get
    End Property

    Public WriteOnly Property DefaultResponse() As String
        Set(ByVal value As String)
            Me.txtResult.Text = value
            Me.txtResult.SelectAll()
        End Set
    End Property

    Public WriteOnly Property StartLocation() As Point
        Set(ByVal value As Point)
            Me.pntStartLocation = value
        End Set
    End Property


    Delegate Sub FajlNevTextBoxbaCallback(ByVal p_fajlnev As String)

    Public Sub FajlnevTextBoxba(ByVal p_fajlnev As String)
        If Me.InvokeRequired Then
            Dim d As New FajlNevTextBoxbaCallback(AddressOf FajlnevTextBoxba)
            Me.Invoke(d, New Object() {p_fajlnev})
        Else
            If p_fajlnev IsNot Nothing Then
                CType(Me.Controls("txtResult" + Me.m_FileTextBox), TextBox).Text = p_fajlnev
            End If
            CType(Me.Controls("btnFDialog" + Me.m_FileTextBox), Button).Enabled = True
            Me.m_FileTextBox = ""
        End If
    End Sub

#Region "Implements IIFSZ_FileDialogResult"


    Public Sub SetFajlNev(ByVal pFajlNev As String) Implements IIFSZ_FileDialogResult.SetFajlNev
        plFileDialogOpen = False
        Me.FajlnevTextBoxba(pFajlNev)
    End Sub

    Public Sub NemValasztott() Implements IIFSZ_FileDialogResult.NemValasztott
        plFileDialogOpen = False
        Me.FajlnevTextBoxba(Nothing)
    End Sub

    Public Sub ShowFileDialog()

        Me.plBetoltFileDialog.InitialDirectory = IFSZ_Globals.GetMyProc.StartInfo.WorkingDirectory
        Me.plBetoltFileDialog.DefaultExt = ".csv"

        Me.plBetoltFileDialog.OpenFileDialog(Me, IFSZ_Globals.GetMyProc)

    End Sub

    Public Sub ShowSaveFileDialog()

        Me.plBetoltFileDialog.InitialDirectory = IFSZ_Globals.GetMyProc.StartInfo.WorkingDirectory
        Me.plBetoltFileDialog.DefaultExt = ".csv"

        Me.plBetoltFileDialog.SaveFileDialog(Me, IFSZ_Globals.GetMyProc)

    End Sub

    Public Sub ThreadShowFileDialog(ByVal p_savedialog As Boolean)

        If Me.m_interim_sbo Is Nothing Then
            MsgBox("F�jl dial�gusos megold�shoz �t kell adni az InputBox f�ggv�nynek az interim_sbo-t")
        Else
            With Me.m_interim_sbo
                If .m_Threads Is Nothing Then
                    .m_Threads = New Dictionary(Of String, System.Threading.Thread)
                End If

                If Not p_savedialog Then
                    If .m_Threads.ContainsKey("InputBoxFileDialog") Then
                        .m_Threads("InputBoxFileDialog") = New System.Threading.Thread(AddressOf ShowFileDialog)
                    Else
                        .m_Threads.Add("InputBoxFileDialog", New System.Threading.Thread(AddressOf ShowFileDialog))
                    End If
                Else
                    If .m_Threads.ContainsKey("InputBoxFileDialog") Then
                        .m_Threads("InputBoxFileDialog") = New System.Threading.Thread(AddressOf ShowSaveFileDialog)
                    Else
                        .m_Threads.Add("InputBoxFileDialog", New System.Threading.Thread(AddressOf ShowSaveFileDialog))
                    End If
                End If
                .m_Threads.Item("InputBoxFileDialog").SetApartmentState(Threading.ApartmentState.STA)
                .m_Threads.Item("InputBoxFileDialog").Start()
                CType(Me.Controls("btnFDialog" + Me.m_FileTextBox), Button).Enabled = False

            End With
        End If

    End Sub

#End Region

End Class