﻿Option Explicit On
Imports IFSZ_AddOnBase
Imports SAPbouiCOM

''' <summary>
''' Azt tudja, amit a sima IFSZ_Interim_SBO, de ez szorosabban kapcsolódik az SBO-s kerethez.
''' Egyrészt létrejön egy dummy SBO-s ablak is, ami ugyanúgy megjelenik az ablakok felsorolásában, mint egy natív ablak. Ha az ablakfelsorolásban váltogatunk, akkor a program előtérbe hozza a keretrendszeres formot
''' így olyan hatást kelt, mintha ez valóban az SBO ablaka lenne.
''' Másik előnye, hogy kezeli az SBO-s menüpontokat is. Egyelőre 5 menübeli funkció van beépítve: keresés, hozzáadás, előző, következő rekord és szűrés. Ez utóbbi az F7-F8-at végzi el a keretrendszeres formon.
''' Használatához csak annyit kell tenni, hogy a konkrét IFSZ_... állományunk ne az IFSZ_Interim_SBO-ból öröklődjön, hanem az IFSZ_InterimBridge_SBO-ból.
''' A HANDLE_MENU_EVENTS ne legyen Override-olva, vagy ha mégis van, akkor legyenek beépítve az itt lévő funkciók is, mert a sima override ezeket elveszi.
''' </summary>
''' <remarks></remarks>
Public MustInherit Class IFSZ_InterimBridge_SBO
    Inherits IFSZ_Interim_SBO

    Public Shared m_LockObject As New Object    Public m_ClosedFromSBOMenu As Boolean = False
    Public Sub New(
        ByRef ParentAddon As SBOAddOn,
        ByVal FunctionCode As String
    )
        MyBase.New(ParentAddon, FunctionCode)
        p_ParentAddon = ParentAddon
    End Sub
    Public Overrides Sub HANDLE_MENU_EVENTS(ByRef pVal As SAPbouiCOM.MenuEvent, ByRef BubbleEvent As Boolean)
        Dim i As Integer
        i = 0
        If Me.m_SboForm IsNot Nothing Then
            Try
                Me.m_ParentAddon.SboApplication.Forms.GetFormByTypeAndCount(m_SboForm.Type, m_SboForm.TypeCount)
            Catch
                'Ha ez hibára fut, akkor bezárták alattunk az ablakot, ezért megtesszük a további lépéseket
                IFSZ_Globals.ReleaseObject(m_SboForm)
                m_SboForm = Nothing
                m_ClosedFromSBOMenu = True
                Me.FormClose()
                Exit Sub
            End Try
        End If
        If Me.m_SboForm IsNot Nothing AndAlso Me.m_SboForm.Selected Then
            If pVal.BeforeAction Then
                Select Case pVal.MenuUID
                    Case "1281"  'Keresés
                        Me.oForm.FindRecord()
                    Case "1282" 'Hozzáadás
                        Me.oForm.AddRecord()
                    Case "1288" 'Következő rekord
                        Me.oForm.NextRecord()
                    Case "1289" 'Előző rekord
                        Me.oForm.PrevRecord()
                    Case "4870" 'Szűrés
                        Me.oForm.FilterRecord()
                    Case "7169" 'Excel
                        Me.oForm.BridgeExcelExport()
                End Select
            End If
        End If

        If Not pVal.BeforeAction Then
            Select Case pVal.MenuUID
                Case "1031", "1032", "1033", "1034", "1035", "1036", "1037", "1038", "1039", "1040", "1041", "1042", "1043", "1044", "1045", "1046", "1047", "1048", "1049"
                    'Lehet, hogy ablakváltás történt, ezért az aktuális sbo-s ablakhoz tartozó keretrendszeres ablakot megjelenítjük.
                    If Me.m_SboForm IsNot Nothing AndAlso Me.m_SboForm.Selected Then
                        Me.oForm.SelectWindow()
                    End If
            End Select
        End If

    End Sub

    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub

    Public Sub MenuBeallitas()
        Try
            Me.m_SboForm.EnableMenu("1281", True)
            Me.m_SboForm.EnableMenu("1282", True)
            Me.m_SboForm.EnableMenu("1288", True)
            Me.m_SboForm.EnableMenu("1289", True)
            Me.m_SboForm.EnableMenu("4870", True)
            Me.m_SboForm.EnableMenu("7169", True)
        Catch ex As Exception

        End Try
    End Sub

    Public Overrides Sub OpenForm()
        SyncLock m_LockObject
            Try

                System.Threading.Thread.Sleep(200)
                ConstructForm()
                If Not oForm Is Nothing Then
                    Me.m_FormNyitva = True

                    Dim l_item As SAPbouiCOM.Item

                    Dim oCreationParams As SAPbouiCOM.FormCreationParams
                    oCreationParams = SBO_Application.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_FormCreationParams)
                    oCreationParams.BorderStyle = SAPbouiCOM.BoFormBorderStyle.fbs_Fixed
                    oCreationParams.UniqueID = Me.m_ParentAddon.GetNewFormUID()
                    m_SboForm = SBO_Application.Forms.AddEx(oCreationParams)

                    If Me.m_SboForm Is Nothing Then
                        Try
                            Me.m_ParentAddon.SBOForms.Remove(Me.m_FormUID)
                            Me.Finalize()
                        Catch ex As Exception
                            Me.SBO_Application.SetStatusBarMessage(ex.Message(), SAPbouiCOM.BoMessageTime.bmt_Short, True)
                        End Try
                        Me.m_FormNyitva = False
                        Me.Finalize()
                        Exit Sub
                    End If

                    Me.m_SboForm.Visible = False

                    Me.m_SboForm.Width = 210
                    Me.m_SboForm.Height = 1

                    TitleChanged(oForm.Text)

                    l_item = Me.m_SboForm.Items.Add("lnkentry", SAPbouiCOM.BoFormItemTypes.it_EDIT)
                    l_item.Left = -1990
                    l_item.Visible = True

                    l_item = Me.m_SboForm.Items.Add("lnklink", SAPbouiCOM.BoFormItemTypes.it_LINKED_BUTTON)
                    l_item.Left = -2000
                    l_item.Visible = True
                    l_item.LinkTo = "lnkentry"

                    Me.m_SboForm.DataSources.UserDataSources.Add("d_lnk", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 254)
                    CType(Me.m_SboForm.Items.Item("lnkentry").Specific, SAPbouiCOM.EditText).DataBind.SetBound(True, "", "d_lnk")

                End If
            Catch ex As Exception
                Me.SBO_Application.SetStatusBarMessage(ex.Message(), SAPbouiCOM.BoMessageTime.bmt_Short, True)
            End Try
        End SyncLock

        If Not oForm Is Nothing Then
            oForm.ThreadStarter(IFSZ_Globals.GetMyWindow(), Me)
        End If

    End Sub

    Public Overrides Sub FormClose()
        'MENÜHÖZ:Me.m_SboForm.Close()
        If Not m_ClosedFromSBOMenu AndAlso m_SboForm IsNot Nothing Then
            m_ClosedFromSBOMenu = True
            Me.m_SboForm.Close()
            IFSZ_Globals.ReleaseObject(Me.m_SboForm)
        End If
        MyBase.FormClose()
    End Sub

    Public Overrides Sub SBOLefur(ByVal p_LinkedObject As SAPbouiCOM.BoLinkedObject, ByVal p_kulcs As String)
        Dim l_item As SAPbouiCOM.Item

        'Me.m_SboForm = Me.m_ParentAddon.CreateSBOForm("SboFormSimpleForm")

        'Me.m_SboForm.Width = 210
        'Me.m_SboForm.Height = 1

        'Me.m_SboForm.Title = "Kérem, várjon..."

        'l_item = Me.m_SboForm.Items.Add("lnkentry", SAPbouiCOM.BoFormItemTypes.it_EDIT)
        'l_item.Left = -1990
        'l_item.Visible = True

        'l_item = Me.m_SboForm.Items.Add("lnklink", SAPbouiCOM.BoFormItemTypes.it_LINKED_BUTTON)
        'l_item.Left = -2000
        'l_item.Visible = True
        'l_item.LinkTo = "lnkentry"

        'Me.m_SboForm.DataSources.UserDataSources.Add("d_lnk", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 254)
        'CType(Me.m_SboForm.Items.Item("lnkentry").Specific, SAPbouiCOM.EditText).DataBind.SetBound(True, "", "d_lnk")

        CType(Me.m_SboForm.Items.Item("lnklink").Specific, SAPbouiCOM.LinkedButton).LinkedObject = p_LinkedObject

        Me.m_SboForm.DataSources.UserDataSources.Item("d_lnk").ValueEx = p_kulcs
        CType(Me.m_SboForm.Items.Item("lnkentry").Specific, SAPbouiCOM.EditText).String = p_kulcs
        Me.m_SboForm.Items.Item("lnklink").Click(SAPbouiCOM.BoCellClickType.ct_Linked)

        'Me.m_SboForm.Close()

        'IFSZ_Globals.ReleaseObject(Me.m_SboForm)

    End Sub

    Public Sub SelectWindow()
        Try
            Me.m_SboForm.Select()
        Catch ex As Exception
            Dim x As Integer = 1
        End Try
    End Sub

    Public Sub TitleChanged(ByVal p_title As String)
        If Me.m_SboForm IsNot Nothing Then
            Me.m_SboForm.Title = p_title
            'Trükk: hozzáadok egy új ablakot, akkor fogja frissíteni a többi ablak title-ját
            Dim oCreationParams As SAPbouiCOM.FormCreationParams
            oCreationParams = SBO_Application.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_FormCreationParams)
            oCreationParams.BorderStyle = SAPbouiCOM.BoFormBorderStyle.fbs_Fixed
            oCreationParams.UniqueID = m_SboForm.UniqueID + "_dummy"
            Dim l_dummy_form As SAPbouiCOM.Form = SBO_Application.Forms.AddEx(oCreationParams)
            l_dummy_form.Close()
        End If
    End Sub

End Class
