﻿Option Explicit On

Imports System.Globalization
    Imports System.Resources
    Imports System.Reflection
    Imports System.IO
    Imports IFSZ_AddOnBase

Public MustInherit Class IFSZ_Interim_SBO2
    Inherits SboForm
    Implements IFSZ_IFormMonitor


    Public m_Threads As Dictionary(Of String, System.Threading.Thread)

    Public Sub New(
            ByRef ParentAddon As SBOAddOn,
            ByVal FunctionCode As String
        )
        'MENÜHÖZ:MyBase.New(ParentAddon, enSboFormTypes.GuiByCode, enSAPFormTypes.IFSZ_Arazas, FunctionCode, "")
        MyBase.New(ParentAddon, enSboFormTypes.LogicOnly, enSAPFormTypes.IFSZ_Arazas, FunctionCode, "")
        p_ParentAddon = ParentAddon
        Me.FunctionCode = FunctionCode
        initialize()
    End Sub

    Public Sub New(
            ByRef ParentAddon As SBOAddOn,
            ByVal FunctionCode As String,
            ByVal UNIQ As String
        )
        'MENÜHÖZ:MyBase.New(ParentAddon, enSboFormTypes.GuiByCode, enSAPFormTypes.IFSZ_Arazas, FunctionCode, "")
        MyBase.New(ParentAddon, enSboFormTypes.LogicOnly, -150, FunctionCode, "FORD")
        p_ParentAddon = ParentAddon
        Me.FunctionCode = FunctionCode
        initialize()
    End Sub

    Public p_ParentAddon As SBOAddOn
    Public p_constructor_lefutott As Boolean = False
    Public Shared lefurasFut As Boolean = False
    Public oForm As IFSZ_Form
    Public FunctionCode As String
    'MENÜHÖZ:Private m_FormNumber As Integer

    Protected m_FormNyitva As Boolean

    Private Sub initialize()

        OpenForm()

        'MENÜHÖZ:m_SboForm.Visible = False
        'MENÜHÖZ:m_SboForm.Title = "Árazás"

        'MENÜHÖZ:Me.m_FormNumber = Me.m_ParentAddon.SboApplication.Forms.Count - 3

        Exit Sub

    End Sub

    'Ebben a következőt kell tenni: oForm = New IFSZ_DNET_...(Me, ...)
    'Tehát létrehozzuk magát a formot. Legyen olyan konstruktora, amiben átadjuk me-t. Ezt használjuk itt
    'Ebben hívjuk meg a bázis konstruktort ( Sub New(ByRef p_Interim_SBO As IFSZ_Interim_SBO) )
    'Mert ez a Me-t (m_Interim_SBO as IFSZ_Interim_SBO) és a me.p_parentAddon-t (m_ParentAddon as SboAddon) elteszi változóba
    Public MustOverride Sub ConstructForm()
    Public MustOverride Sub FormEvent(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)

    Public Overridable Sub OpenForm()
        System.Threading.Thread.Sleep(200)
        ConstructForm()
        If Not oForm Is Nothing Then
            Me.m_FormNyitva = True
            oForm.Show()
        End If
    End Sub

    Public Overrides Sub HANDLE_FORM_EVENTS(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)

        If pVal.Before_Action = False Then
            If Not oForm Is Nothing Then
                If Not (Me.oForm.p_LovForm Is Nothing) Then
                    If pVal.EventType = SAPbouiCOM.BoEventTypes.et_FORM_LOAD And Me.oForm.p_LovForm.l_FormID <> "" Then
                        Dim l_index As String
                        Dim l_osztaly As String
                        Dim oArgs() As Object = {Me.m_ParentAddon, "F_LOV", pVal.FormUID, Me.oForm.p_LovForm.l_Link_ertek}
                        Dim oForm As SboForm
                        Dim Dummy As New IFSZ_Dummy_Addonbase

                        If Me.oForm.p_LovForm.l_FormID = pVal.FormType And pVal.FormType <> 0 Then
                            oForm = [Assembly].GetExecutingAssembly.CreateInstance(
                                                               Me.oForm.p_LovForm.l_Osztaly,
                                                               True,
                                                               BindingFlags.Public Or BindingFlags.Instance Or BindingFlags.CreateInstance,
                                                               Nothing,
                                                               oArgs,
                                                               Nothing,
                                                               Nothing)
                            If (oForm Is Nothing) Then
                                oForm = [Assembly].GetAssembly(Dummy.GetType()).CreateInstance(
                                                                                               Me.oForm.p_LovForm.l_Osztaly,
                                                                                               True,
                                                                                               BindingFlags.Public Or BindingFlags.Instance Or BindingFlags.CreateInstance,
                                                                                               Nothing,
                                                                                               oArgs,
                                                                                               Nothing,
                                                                                               Nothing)
                            End If
                            If (Not oForm Is Nothing) Then
                                ' If got an instance, add to our list
                                Try
                                    Me.m_ParentAddon.SBOForms.Remove(oForm.UniqueID + "_L")
                                Catch ex As Exception

                                End Try
                                Me.m_ParentAddon.SBOForms.Add(oForm, oForm.UniqueID + "_L")
                            End If
                            Me.m_ParentAddon.SboApplication.Forms.ActiveForm.Select()
                            Exit Sub
                        End If
                    Else
                        'Me.FormEvent(FormUID, pVal, BubbleEvent)
                    End If
                    '-----------------------------
                    '-----------------------------
                ElseIf Me.oForm.l_AutoLinkPressed Then
                    If pVal.EventType = SAPbouiCOM.BoEventTypes.et_FORM_LOAD And Me.oForm.l_AutoLinkPressed = True And Me.oForm.l_FormID <> "" Then
                        Dim l_index As String
                        Dim l_osztaly As String
                        Dim oArgs() As Object = {Me.m_ParentAddon, "F_LOV", pVal.FormUID, Me.oForm.l_Link_ertek}
                        Dim oForm As SboForm
                        Dim Dummy As New IFSZ_Dummy_Addonbase
                        Me.oForm.l_AutoLinkPressed = False
                        If Me.oForm.l_FormID = pVal.FormType And pVal.FormType <> 0 Then
                            Me.lefurasFut = True
                            oForm = [Assembly].GetExecutingAssembly.CreateInstance(
                                                               Me.oForm.l_Osztaly,
                                                               True,
                                                               BindingFlags.Public Or BindingFlags.Instance Or BindingFlags.CreateInstance,
                                                               Nothing,
                                                               oArgs,
                                                               Nothing,
                                                               Nothing)
                            If (oForm Is Nothing) Then
                                oForm = [Assembly].GetAssembly(Dummy.GetType()).CreateInstance(
                                                                                               Me.oForm.l_Osztaly,
                                                                                               True,
                                                                                               BindingFlags.Public Or BindingFlags.Instance Or BindingFlags.CreateInstance,
                                                                                               Nothing,
                                                                                               oArgs,
                                                                                               Nothing,
                                                                                               Nothing)
                            End If
                            If (Not oForm Is Nothing) Then
                                ' If got an instance, add to our list
                                Try
                                    Me.m_ParentAddon.SBOForms.Remove(oForm.UniqueID + "_L")
                                Catch ex As Exception

                                End Try
                                Me.m_ParentAddon.SBOForms.Add(oForm, oForm.UniqueID + "_L")
                            End If
                            'Me.m_ParentAddon.SboApplication.Forms.ActiveForm.Select()
                            System.Threading.Thread.Sleep(1000)
                            'Me.lefurasFut = False
                            Exit Sub
                        End If
                    Else
                        'Me.FormEvent(FormUID, pVal, BubbleEvent)
                    End If


                Else
                    Me.FormEvent(FormUID, pVal, BubbleEvent)
                End If
            End If
        End If
    End Sub

    Public Overrides Sub HANDLE_MENU_EVENTS(ByRef pVal As SAPbouiCOM.MenuEvent, ByRef BubbleEvent As Boolean)

        'MENÜHÖZ:If pVal.BeforeAction Then
        'MENÜHÖZ:If pVal.MenuUID = enSAPMenuUIDs.AblakokKezd + Me.m_FormNumber - 1 Then
        'MENÜHÖZ:oForm.ShowWindowOnNextProcess()
        'MENÜHÖZ:End If
        'MENÜHÖZ:End If
        If lefurasFut = True Then
            System.Threading.Thread.Sleep(1000)
            lefurasFut = False
        End If
    End Sub

    'MENÜHÖZ:Public Sub FormActivated()
    'MENÜHÖZ:Me.m_ParentAddon.SboApplication.ActivateMenuItem(enSAPMenuUIDs.AblakokKezd + Me.m_FormNumber - 1)
    'MENÜHÖZ:End Sub

    Public Overridable Sub FormClose()
        'MENÜHÖZ:Me.m_SboForm.Close()
        Try

            'Esetleges futó threadek bezárása
            For Each l_pair As KeyValuePair(Of String, System.Threading.Thread) In Me.m_Threads
                If l_pair.Value IsNot Nothing AndAlso l_pair.Value.IsAlive Then
                    l_pair.Value.Abort()
                    'l_pair.Value.Join()
                End If
            Next
        Catch ex As Exception

        End Try
        Try

            Me.m_ParentAddon.SBOForms.Remove(Me.m_FormUID)
            Me.Finalize()
        Catch ex As Exception

        End Try

        Me.m_FormNyitva = False

        Me.Finalize()
    End Sub

    Public Property FormNyitva() As Boolean Implements IFSZ_IFormMonitor.FormNyitva
        Get
            Return m_FormNyitva
        End Get
        Set(ByVal value As Boolean)
            m_FormNyitva = value
        End Set
    End Property

    Public Overridable Sub SBOLefur(ByVal p_LinkedObject As SAPbouiCOM.BoLinkedObject, ByVal p_kulcs As String)
        Dim l_item As SAPbouiCOM.Item

        Me.m_SboForm = Me.m_ParentAddon.CreateSBOForm("SboFormSimpleForm")

        Me.m_SboForm.Width = 210
        Me.m_SboForm.Height = 1

        Me.m_SboForm.Title = "Kérem, várjon..."

        l_item = Me.m_SboForm.Items.Add("lnkentry", SAPbouiCOM.BoFormItemTypes.it_EDIT)
        l_item.Left = -1990
        l_item.Visible = True

        l_item = Me.m_SboForm.Items.Add("lnklink", SAPbouiCOM.BoFormItemTypes.it_LINKED_BUTTON)
        l_item.Left = -2000
        l_item.Visible = True
        l_item.LinkTo = "lnkentry"

        Me.m_SboForm.DataSources.UserDataSources.Add("d_lnk", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 254)
        CType(Me.m_SboForm.Items.Item("lnkentry").Specific, SAPbouiCOM.EditText).DataBind.SetBound(True, "", "d_lnk")

        CType(Me.m_SboForm.Items.Item("lnklink").Specific, SAPbouiCOM.LinkedButton).LinkedObject = p_LinkedObject

        Me.m_SboForm.DataSources.UserDataSources.Item("d_lnk").ValueEx = p_kulcs
        CType(Me.m_SboForm.Items.Item("lnkentry").Specific, SAPbouiCOM.EditText).String = p_kulcs
        Me.m_SboForm.Items.Item("lnklink").Click(SAPbouiCOM.BoCellClickType.ct_Linked)

        Me.m_SboForm.Close()

        IFSZ_Globals.ReleaseObject(Me.m_SboForm)

    End Sub

End Class
