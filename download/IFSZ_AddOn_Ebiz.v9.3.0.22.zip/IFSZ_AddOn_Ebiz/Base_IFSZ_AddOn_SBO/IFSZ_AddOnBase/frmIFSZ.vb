Option Explicit On Imports SboAddOnBaseImports System.Windows.FormsImports System.ReflectionPublic Class frmIFSZ    Inherits System.Windows.Forms.Form    Private m_IFSZ_Addon As SBOAddOn#Region " Windows Form Designer generated code "    Public Sub New()        MyBase.New()        'This call is required by the Windows Form Designer.        InitializeComponent()        'Add any initialization after the InitializeComponent() call    End Sub    'Form overrides dispose to clean up the component list.    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)        If disposing Then            If Not (components Is Nothing) Then                components.Dispose()            End If        End If        MyBase.Dispose(disposing)    End Sub    'Required by the Windows Form Designer    Private components As System.ComponentModel.IContainer    'NOTE: The following procedure is required by the Windows Form Designer    'It can be modified using the Windows Form Designer.      'Do not modify it using the code editor.    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmIFSZ))        '        'frmCash        '        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)        Me.ClientSize = New System.Drawing.Size(328, 296)        Me.Enabled = False        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None        Me.MaximizeBox = False        Me.MinimumSize = New System.Drawing.Size(145, 88)        Me.Name = "frmCash"        Me.ShowInTaskbar = False        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen        Me.WindowState = System.Windows.Forms.FormWindowState.Minimized    End Sub#End Region    <STAThread()> _      Shared Sub Main()        Application.Run(New frmIFSZ)    End Sub 'Main    Function AssemblyResolve(ByVal sender As Object, ByVal e As ResolveEventArgs) As Assembly
        Static Dim l_crystalversions As New List(Of String)

        If l_crystalversions.Count = 0 Then
            l_crystalversions.Add("14.0.3500.0")
            l_crystalversions.Add("13.0.2000.0")
            l_crystalversions.Add("12.0.2000.0")
        End If

        If l_crystalversions(0) = "ERR" Then
            Return Nothing
        End If

        If e.Name.StartsWith("CrystalDecisions") Then
            Dim l_name As String = e.Name
            Dim l_version As String
            Dim l_ujname As String

            Dim l_regex As New System.Text.RegularExpressions.Regex("(.*Version=)(\d+\.\d+\.\d+\.\d+)(,.*)")            If l_regex.IsMatch(l_name) Then                l_version = l_regex.Replace(l_name, "$2")                If String.IsNullOrEmpty(l_version) Then                    Return Nothing
                End If                If l_crystalversions.Contains(l_version) Then                    l_crystalversions.Remove(l_version)
                End If                If l_crystalversions.Count = 0 Then                    l_crystalversions.Add("ERR")
                    Return Nothing
                End If                l_ujname = l_regex.Replace(l_name, "$1")                l_ujname += l_crystalversions(0)                l_ujname += l_regex.Replace(l_name, "$3")                Return Assembly.Load(l_ujname)
            Else                Return Nothing            End If

        Else
            Return Nothing
        End If

    End Function    Private Sub frmStart_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load        AddHandler AppDomain.CurrentDomain.AssemblyResolve, AddressOf AssemblyResolve

        m_IFSZ_Addon = New IFSZ_Addon(Application.StartupPath, "IFSZ AddOn")        If m_IFSZ_Addon.Connected = True Then            'Dim l_handleParent As IntPtr = Process.GetProcessesByName("SAP Business One")(0).MainWindowHandle            'Dim l_handleRealParent As IntPtr            'Dim l_handleChild As IntPtr = Me.Handle 'lAddon.Handle 'IFSZ_Globals.GetMyWindow().Handle 'IFSZ_Globals.GetMyProc().MainWindowHandle            'l_handleRealParent = Win32Helper.FindWindowEx(l_handleParent, Nothing, Nothing, Nothing)            'l_handleRealParent = Win32Helper.GetWindow(l_handleRealParent, 2) '2 = GW_HWNDNEXT            'If Not IntPtr.Zero.Equals(l_handleChild) And Not IntPtr.Zero.Equals(l_handleRealParent) Then            '    Win32Helper.SetParent(l_handleChild, l_handleRealParent)            '    Me.Invalidate()            'End If        End If    End SubEnd Class