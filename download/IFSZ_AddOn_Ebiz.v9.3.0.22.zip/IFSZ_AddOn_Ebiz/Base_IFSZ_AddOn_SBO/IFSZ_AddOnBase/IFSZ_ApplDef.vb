Option Explicit On 

Imports SboAddOnBase

Public Class IFSZ_ApplDef

#Region "Variables"
    Dim m_ParentAddon As SBOAddOn
    Dim formCmdCenter As SAPbouiCOM.Form
#End Region

#Region "Constructor"
    Public Sub New(ByRef ParentAddon As SBOAddOn)
        m_ParentAddon = ParentAddon
        formCmdCenter = m_ParentAddon.SboApplication.Forms.GetFormByTypeAndCount(169, 1)
    End Sub
#End Region

#Region "Public"
    Public Function GetSelectedForm() As SAPbouiCOM.Form
        Dim MyObject As SAPbouiCOM.Form
        Dim i As Integer

        For i = 0 To m_ParentAddon.SboApplication.Forms.Count - 1
            MyObject = m_ParentAddon.SboApplication.Forms.Item(i)
            If MyObject.Selected Then
                Return MyObject
            End If
        Next
        Return MyObject
    End Function

    Public Function IsCommandCenter( _
        ByVal form As SAPbouiCOM.Form _
    ) As Boolean
        Dim MyObject As SAPbouiCOM.Form

        Return (form.Type = 169 And form.TypeCount = 1)
    End Function

    Public Sub SetCCSelected()
        Dim MyObject As SAPbouiCOM.Form
        Dim i As Integer

        With m_ParentAddon.SboApplication
            For i = 0 To .Forms.Count - 1
                MyObject = .Forms.Item(i)
                If MyObject.Type = 169 And MyObject.TypeCount = 1 And MyObject.Selected = False Then
                    For j As Integer = 1 To 20
                        Try
                            MyObject.Select()
                        Catch ex As Exception
                            If Not ex.Message().Contains("Modal") Then
                                MsgBox("Az IFSZ_AddOn nem tudja el�t�rbe hozni a f�men�t - az AddOn befejezi fut�s�t. (" + ex.Message + ")")
                                Application.Exit()
                            Else
                                System.Threading.Thread.Sleep(5000)
                                Continue For
                            End If
                        End Try
                        'Siker�lt a Select, ez�rt kil�phet�nk
                        Exit Sub
                    Next
                    '20 pr�b�lkoz�s ut�n sem siker�lt
                    MsgBox("Az IFSZ_AddOn nem tudja el�t�rbe hozni a f�men�t - az AddOn befejezi fut�s�t")
                    Application.Exit()
                End If
            Next
        End With
    End Sub

    Public Sub DelMenus()
        Dim delimStr As String = "."
        Dim delimiter As Char() = delimStr.ToCharArray()
        Dim menupath As String 'Name mez�
        Dim tomb As String() = Nothing
        Dim i As Integer
        Dim j As Integer
        Dim val As Integer
        Dim uMenus As SAPbouiCOM.Menus
        Dim uMenuitem As SAPbouiCOM.MenuItem
        Dim RecSet As SAPbobsCOM.Recordset        'A men�t�bl�k tartalm�t Recordset-be
        Dim lMenuItem As IFSZ_MenuItem

        Try
            lMenuItem = New IFSZ_MenuItem(m_ParentAddon)

            RecSet = m_ParentAddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            lMenuItem.SetMenuItemsRS(RecSet, m_ParentAddon.SboApplication.Language, "desc")

            If RecSet.RecordCount > 0 Then
                'Freeze command center
                formCmdCenter.Freeze(True)

                With m_ParentAddon.SboApplication
                    'Recordset elej�re
                    RecSet.MoveFirst()
                    'sorok feldolgoz�sa ciklusban
                    For i = 0 To RecSet.RecordCount - 1
                        'els� sor feldolgoz�sa
                        'nevet sz�tdaraboljuk, t�mbbe tessz�k
                        menupath = RecSet.Fields.Item(1).Value

                        tomb = menupath.Split(delimiter)
                        Try
                            For j = 0 To tomb.Length - 1
                                val = tomb.GetValue(j)
                                If j = 0 Then
                                    'els� szint
                                    uMenus = .Menus.Item(val).SubMenus
                                ElseIf j < tomb.Length - 1 Then
                                    'nem els� szint �s nem utols� szint
                                    uMenus = uMenus.Item(val).SubMenus
                                Else
                                    'utols� szint
                                    uMenuitem = uMenus.Item(val)
                                    If Not uMenuitem.SubMenus Is Nothing Then
                                        Dim k As Integer
                                        k = 0
                                    End If
                                    If uMenuitem.String = "�rt�kes�t�s napi m�r�sz�mai" Then
                                        Dim k As Integer
                                        k = 0
                                    End If
                                    uMenus.Remove(uMenuitem)
                                End If
                            Next

                        Catch f As System.Exception
                            'nem l�tezik a men�item, nincs tennival�
                        End Try
                        RecSet.MoveNext()
                    Next
                End With

                'Unfreeze and update the Command Center form
                formCmdCenter.Freeze(False)
                formCmdCenter.Update()

            End If

        Catch e As System.Exception
            'ifsz-04001:Hiba a felhaszn�l�i men�pontok t�rl�se sor�n
            Throw New Exception(m_ParentAddon.LocRM.GetString("ifsz-04001") & vbNewLine & e.ToString)
        Finally
            If (Not RecSet Is Nothing) Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(RecSet)
                RecSet = Nothing
            End If
            If (Not lMenuItem Is Nothing) Then
                lMenuItem = Nothing
            End If
        End Try

    End Sub

    Public Sub BuildMenus()
        Dim delimStr As String = "."
        Dim delimiter As Char() = delimStr.ToCharArray()
        Dim menupath As String 'Name mez�
        Dim menucode As String 'Code mez�
        Dim itemtype As String 'U_Itemtype mez�
        Dim fcocode As String 'U_Function mez�
        Dim tomb As String() = Nothing
        Dim i As Integer
        Dim j As Integer
        Dim lMenuType As SAPbouiCOM.BoMenuType
        Dim val As Integer
        Dim strMenuUID As String 'sajat egyedi menuitem azonosito
        Dim ulabel As String 'men� c�mke
        Dim uMenus As SAPbouiCOM.Menus
        Dim uMenuitem As SAPbouiCOM.MenuItem
        Dim RecSet As SAPbobsCOM.Recordset
        Dim lMenuItem As IFSZ_MenuItem
        Dim lRole As IFSZ_Role = New IFSZ_Role(m_ParentAddon)
        Dim l_menudict As New Dictionary(Of String, SAPbouiCOM.MenuItem)
        Dim l_parentcode As String

        lMenuItem = New IFSZ_MenuItem(m_ParentAddon)

        'Men� fel�p�t�se a RecSet feldolgoz�s�val
        RecSet = m_ParentAddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        lMenuItem.SetMenuItemsRS(RecSet, m_ParentAddon.SboApplication.Language, "asc")

        If RecSet.RecordCount > 0 Then
            Try
                'Freeze the Command Center form
                formCmdCenter.Freeze(True)

                'Recordset elej�re
                RecSet.MoveFirst()
                'sorok feldolgoz�sa ciklusban
                For i = 0 To RecSet.RecordCount - 1

                    'els� sor feldolgoz�sa
                    'nevet sz�tdaraboljuk, t�mbbe tessz�k
                    menucode = RecSet.Fields.Item(0).Value
                    menupath = RecSet.Fields.Item(1).Value
                    itemtype = RecSet.Fields.Item(2).Value
                    fcocode = RecSet.Fields.Item(3).Value
                    ulabel = lMenuItem.GetMenulabel(RecSet.Fields, m_ParentAddon.SboApplication.Language)
                    If (itemtype <> "F" Or lRole.HasRole(fcocode)) Then
                        'Hi�ba adjuk meg egy men�pontnak, hogy az az x. poz�ci�n legyen, ha van el�tte lyuk, akkor azt kezdi el bet�mni.
                        'Emiatt nem oda fog ker�lni egy-egy men�pont, ahova gondoljuk. Pl. a 6.15 val�j�ban a 6.14-re ker�l. Eddig m�g ez nem baj
                        'De onnan kezdve, hogy a 6.15.00-t ki akarom tenni, az m�r nem fogja a 6.15-�t tal�lni.
                        'Ez�rt �p�tem fel ezt a dictionary-t, ami tartalmazza a t�nyleges men�pontokat, �s ha a sz�l� itt megtal�lhat�, akkor azt haszn�ljuk sz�l�k�nt
                        If menupath.LastIndexOf(delimiter) < 0 Then
                            l_parentcode = ""
                        Else
                            l_parentcode = menupath.Substring(0, menupath.LastIndexOf(delimiter))
                        End If
                        If Not String.IsNullOrEmpty(l_parentcode) AndAlso l_menudict.ContainsKey(l_parentcode) Then
                            uMenus = l_menudict(l_parentcode).SubMenus
                        Else

                            tomb = menupath.Split(delimiter)
                            Try
                                For j = 0 To tomb.Length - 1
                                    val = tomb.GetValue(j)
                                    If j = 0 Then
                                        'els� szint
                                        uMenus = m_ParentAddon.SboApplication.Menus.Item(val).SubMenus
                                    ElseIf j < tomb.Length - 1 Then
                                        'nem els� szint �s nem utols� szint
                                        uMenus = uMenus.Item(val).SubMenus
                                    Else
                                        'utols� szint
                                        uMenuitem = uMenus.Item(val)
                                    End If
                                Next
                            Catch f As System.Exception
                            End Try
                        End If
                        'men�item(hozz�ad�sa)
                        't�mb utols� el�ttieleme (uMenus) al�
                        val = tomb.GetValue(tomb.Length - 1)
                        strMenuUID = " "
                        Select Case itemtype
                            Case "F"
                                lMenuType = SAPbouiCOM.BoMenuType.mt_STRING
                            Case "M"
                                lMenuType = SAPbouiCOM.BoMenuType.mt_POPUP
                            Case "S"
                                lMenuType = SAPbouiCOM.BoMenuType.mt_SEPERATOR
                            Case Else
                                Throw New Exception(m_ParentAddon.LocRM.GetString("ifsz-04004"))
                        End Select
                        strMenuUID = CreateIFSZMenuUID(i, fcocode)
                        Try
                            If uMenus.Exists(strMenuUID) Then
                                uMenuitem = uMenus.Item(strMenuUID)
                            Else
                                uMenuitem = uMenus.Add(strMenuUID, ulabel, lMenuType, val)
                            End If
                            l_menudict.Add(menupath, uMenuitem)
                        Catch ex As Exception

                        End Try

                    End If
                    RecSet.MoveNext()

                Next

                'Unfreeze and update the Command Center form
                formCmdCenter.Freeze(False)
                formCmdCenter.Update()

            Catch e As System.Exception
                formCmdCenter.Freeze(False)
                'ifsz-04002:Hiba a felhaszn�l�i men�pontok hozz�ad�sa sor�n
                Throw New Exception(m_ParentAddon.LocRM.GetString("ifsz-04002") & vbCrLf & e.ToString)
            Finally
                If (Not RecSet Is Nothing) Then
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(RecSet)
                    RecSet = Nothing
                End If
                If (Not lMenuItem Is Nothing) Then
                    lMenuItem = Nothing
                End If
            End Try

        Else

            If (Not RecSet Is Nothing) Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(RecSet)
                RecSet = Nothing
            End If
            If (Not lMenuItem Is Nothing) Then
                lMenuItem = Nothing
            End If

        End If

    End Sub

    Public Sub DisableMenus()
        Dim uMenus As SAPbouiCOM.Menus
        Dim uMenuitem As SAPbouiCOM.MenuItem

        Try
            'Freeze the Command Center form
            formCmdCenter.Freeze(True)

            uMenus = m_ParentAddon.SboApplication.Menus.Item(6).SubMenus.Item(11).SubMenus
            'm_ParentAddon.SboApplication.Menus.Item(6).SubMenus.Item(14).String
            For Each uMenuitem In uMenus
                If IsIFSZMenuItem(uMenuitem.String) Then
                    uMenuitem.Enabled = False
                End If
            Next

            'Unfreeze and update the Command Center form
            formCmdCenter.Freeze(False)
            formCmdCenter.Update()

        Catch e As System.Exception

            'ifsz-04005:Hiba a felhaszn�l�i t�bl�kat kezel� men�pontok letilt�sa sor�n
            Throw New Exception(m_ParentAddon.LocRM.GetString("ifsz-04005") & vbCrLf & e.ToString)

        Finally
        End Try

    End Sub

    Public Function IsIFSZMenuItem(ByVal menuUID As String) As Boolean
        Dim retval As Boolean = False

        ' Menu items inserted by IFSZ are like "IFSZ_nnn_FcoCode"
        If menuUID.Length > 9 Then
            If menuUID.Substring(0, 5) = "IFSZ_" Then
                retval = True
            End If
        End If
        Return retval
    End Function

    Public Function GetMenuItemByTitle( _
        ByVal strTitle As String, _
        ByRef mnus As SAPbouiCOM.Menus _
    ) As SAPbouiCOM.MenuItem
        Dim mnuitem As SAPbouiCOM.MenuItem

        mnuitem = Nothing
        If mnus.Count > 0 Then
            For Each mnuitem In mnus

                If mnuitem.Type = SAPbouiCOM.BoMenuType.mt_STRING And mnuitem.String = strTitle Then
                    Return mnuitem
                ElseIf mnuitem.Type = SAPbouiCOM.BoMenuType.mt_POPUP Then
                    Return GetMenuItemByTitle(strTitle, mnuitem.SubMenus)
                End If

            Next mnuitem
        End If
        Return mnuitem
    End Function

    Public Function GetIFSZMenuFco( _
        ByVal menuUID As String _
    ) As String
        Dim retval As String = ""

        ' Menu items inserted by IFSZ are like "IFSZ_nnn_FcoCode"
        If menuUID.Length > 9 Then
            If menuUID.Substring(0, 5) = "IFSZ_" Then
                retval = menuUID.Substring(9)
            End If
        End If
        Return retval
    End Function

    Public Function CreateIFSZMenuUID( _
        ByVal i As Integer, _
        ByVal fcocode As String _
    ) As String
        Dim strMenuUID As String

        If i > 999 Then
            Throw New Exception(m_ParentAddon.LocRM.GetString("ifsz-04003"))
        End If
        Return "IFSZ_" & i.ToString.PadLeft(3, "0") & "_" & fcocode
    End Function
#End Region

End Class