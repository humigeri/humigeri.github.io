Imports System
Imports System.IO
Imports System.Security.Cryptography
Imports System.Text

Public Class IFSZ_Security

    Public Shared Function RSAEncrypt(ByVal DataToEncrypt() As Byte, ByVal RSAKeyInfo As RSAParameters, ByVal DoOAEPPadding As Boolean) As Byte()
        Try
            'Create a new instance of RSACryptoServiceProvider.
            Dim RSA As New RSACryptoServiceProvider()

            RSA.ImportParameters(RSAKeyInfo)
            Return RSA.Encrypt(DataToEncrypt, DoOAEPPadding)

        Catch e As CryptographicException
            Console.WriteLine(e.Message)

            Return Nothing
        End Try
    End Function


    Public Shared Function RSADecrypt(ByVal DataToDecrypt() As Byte, ByVal RSAKeyInfo As RSAParameters, ByVal DoOAEPPadding As Boolean) As Byte()
        Try
            'Create a new instance of RSACryptoServiceProvider.
            Dim RSA As New RSACryptoServiceProvider()

            RSA.ImportParameters(RSAKeyInfo)
            Return RSA.Decrypt(DataToDecrypt, DoOAEPPadding)
            'Catch and display a CryptographicException  
            'to the console.
        Catch e As CryptographicException
            Console.WriteLine(e.ToString())

            Return Nothing
        End Try
    End Function

    Public Shared Function DESEncrypt(ByVal PlainText As String, ByVal key As SymmetricAlgorithm) As Byte()
        ' Create a memory stream.
        Dim ms As New MemoryStream()


        ' Create a CryptoStream using the memory stream and the 
        ' CSP DES key.  
        Dim encStream As New CryptoStream(ms, key.CreateEncryptor(IFSZ_Globals.p_Key, IFSZ_Globals.p_IV), CryptoStreamMode.Write)

        Dim sw As New StreamWriter(encStream)

        sw.WriteLine(PlainText)

        sw.Close()
        encStream.Close()

        Dim buffer As Byte() = ms.ToArray()

        ms.Close()

        ' Return the encrypted byte array.
        Return buffer
    End Function 'Encrypt


    ' Decrypt the byte array.
    Public Shared Function DESDecrypt(ByVal CypherText() As Byte, ByVal key As SymmetricAlgorithm) As String
        ' Create a memory stream to the passed buffer.
        Dim ms As New MemoryStream(CypherText)

        Dim encStream As New CryptoStream(ms, key.CreateDecryptor(IFSZ_Globals.p_Key, IFSZ_Globals.p_IV), CryptoStreamMode.Read)

        Dim sr As New StreamReader(encStream)

        Dim val As String = sr.ReadLine()


        sr.Close()
        encStream.Close()
        ms.Close()

        Return val
    End Function 'Decrypt

    Public Shared Function GetEncryptedByte(ByVal p_kulcs As String) As Byte()
        Dim l_length As Integer
        Dim l_encrypted_byte() As Byte
        Dim l_index As Integer = 0
        Do
            ReDim Preserve l_encrypted_byte(l_index)
            If p_kulcs.Contains("&") Then
                l_encrypted_byte(l_index) = p_kulcs.Substring(0, p_kulcs.IndexOf("&"))
                p_kulcs = p_kulcs.Substring(p_kulcs.IndexOf("&") + 1)
            Else
                l_encrypted_byte(l_index) = CType(p_kulcs, Byte)
                Exit Do
            End If
            l_index = l_index + 1

        Loop
        Return l_encrypted_byte
    End Function

    Public Shared Function getPassword(ByVal p_kod As String) As String
        Return IFSZ_Security.visszakodol(p_kod)
    End Function

    Public Shared Function visszakodol(ByVal p_kod As String) As String
        Dim ByteConverter As Encoding = Encoding.Unicode
        Dim i As Integer
        Dim l_encrypted_kulcs() As Byte
        Dim l_decrypted_kulcs() As Byte
        Dim l_moduleName, l_Module, l_azonosito, l_tipus As String
        Dim l_kulcs As String

        l_encrypted_kulcs = IFSZ_Security.GetEncryptedByte(p_kod)
        Dim key As New DESCryptoServiceProvider()
        Dim plaintext As String = IFSZ_Security.DESDecrypt(l_encrypted_kulcs, key)
        Return plaintext
    End Function

    Public Shared Function bekodol(ByVal p_kod As String) As String
        Dim ByteConverter As Encoding = Encoding.Unicode
        Dim dataToEncrypt As Byte() = ByteConverter.GetBytes(p_kod)
        Dim l_kulcs As String
        Dim key As New DESCryptoServiceProvider()
        Dim buffer As Byte() = IFSZ_Security.DESEncrypt(p_kod, key)
        l_kulcs = ByteConverter.GetString(buffer)

        Dim l_string As String
        Dim j As Integer
        For j = 1 To buffer.Length
            If l_string <> "" Then
                l_string = l_string & "&" & buffer(j - 1).ToString
            Else
                l_string = l_string & buffer(j - 1).ToString
            End If
        Next

        ' Decrypt the byte array back to a string.
        Dim plaintext As String = IFSZ_Security.DESDecrypt(buffer, key)
        Return l_string
    End Function

End Class