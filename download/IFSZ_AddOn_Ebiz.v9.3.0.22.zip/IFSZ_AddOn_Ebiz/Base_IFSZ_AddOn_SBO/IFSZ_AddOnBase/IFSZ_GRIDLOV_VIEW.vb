﻿Imports System.GlobalizationImports System.ResourcesImports System.ReflectionImports System.IOImports SboAddOnBasePublic Class IFSZ_GRIDLOV_VIEW
    Inherits SboForm    Private P_Title As String    Private P_Szuresi_Ertek As String    Public Sub New(ByRef ParentAddon As SBOAddOn, _                   ByRef oEredetiForm As SboForm, _                   ByVal p_oszlop_tipus() As OszlopTipus, _                   ByVal p_ertek As String, _                   ByVal p_lookup_ertek As String, _                   ByVal p_sor As Integer, _                   ByVal p_tabla As String, _                   ByVal p_matrix As String, _                   ByVal P_Cimke As String, _                   ByVal p_select As String, _                   Optional ByVal p_order_by As String = "", _                   Optional ByVal P_SzuresiErtek As String = "", _                   Optional ByRef l_validal As Boolean = True)        MyBase.New(ParentAddon, enSboFormTypes.XmlFile, enSAPFormTypes.IFSZ_LOV)        oForm_Eredeti = oEredetiForm        l_ertek = p_ertek        l_lookup_ertek = p_lookup_ertek        l_sor = p_sor        l_tabla = p_tabla        l_matrix = p_matrix        ReDim l_OszlopTipus(p_oszlop_tipus.GetUpperBound(0))        l_OszlopTipus = p_oszlop_tipus        P_Title = P_Cimke        l_select = p_select        l_order_by = p_order_by        P_Szuresi_Ertek = P_SzuresiErtek        p_validal = l_validal        initialize()    End Sub    Private Structure Rendez        Public oszlop As String        Public irany As String        Private Sub New(ByVal l_oszlop As String, ByVal l_irany As String)            Me.oszlop = l_oszlop            Me.irany = l_irany        End Sub    End Structure    Private l_OszlopTipus() As OszlopTipus    Private l_ertek, l_select, l_order_by As String    Private l_lookup_ertek As String    Private l_tabla As String    Private l_matrix As String    Private oConditions As SAPbouiCOM.Conditions    Private oForm_Eredeti As SboForm    Private oForm As SAPbouiCOM.Form    Private oForm2 As IFSZ_MatrixControl    Private l_sor As Integer    Private p_validal As Boolean    Private l_kivalasztott_sor As Integer = -1    Private l_a1 As String    Private l_a2 As String    Private p_rendez As Rendez    Private l_sorok_szama As Integer    Private p_select As String    Private l_colID As String    Private l_FormID As String    Private l_Link_ertek As String    Public Overrides Sub HANDLE_FORM_EVENTS(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)        Try            If pVal.Before_Action = True And BubbleEvent = True Then                Select Case pVal.EventType                    Case SAPbouiCOM.BoEventTypes.et_CLICK                        Dim oMatrix As SAPbouiCOM.Matrix                        Dim oGrid As SAPbouiCOM.Grid                        Dim oEditText As SAPbouiCOM.EditText                        Dim i As Integer                        Dim index As Integer                        Dim l_matrix_nev As String                        Dim l_tabla_nev As String                        Dim oColumn As SAPbouiCOM.Column                        Dim l_type As String                        Select Case pVal.ItemUID                            Case "1"                                Try                                    Me.oForm_Eredeti.m_LovVisszairas = True
                                    If l_kivalasztott_sor = -1 Then                                        oForm = Me.m_ParentAddon.SboApplication.Forms.Item(oForm_Eredeti.UniqueID)                                        If l_matrix <> "" Then                                            oMatrix = oForm.Items.Item(l_matrix).Specific                                            oMatrix.Columns.Item(l_ertek).Cells.Item(l_sor).Click()                                            oColumn = oMatrix.Columns.Item(l_ertek)                                            Me.oForm_Eredeti.p_validal_e = False                                            oEditText = oColumn.Cells.Item(l_sor).Specific                                            oEditText.String = Nothing                                            If l_lookup_ertek <> "" Then                                                oColumn = oMatrix.Columns.Item(l_lookup_ertek)                                                oEditText = oColumn.Cells.Item(l_sor).Specific                                                oEditText.String = Nothing                                            End If                                            Me.oForm_Eredeti.p_validal_e = True                                        Else                                            oForm.Items.Item(l_ertek).Click()                                            Me.oForm_Eredeti.p_validal_e = False                                            oEditText = oForm.Items.Item(l_ertek).Specific()                                            oEditText.String = Nothing                                            If l_lookup_ertek <> "" Then                                                oEditText = oForm.Items.Item(l_lookup_ertek).Specific                                                oEditText.String = Nothing                                            End If                                            Me.oForm_Eredeti.p_validal_e = True                                        End If                                        Exit Sub                                    End If                                    l_a1 = Me.m_SboForm.DataSources.DataTables.Item(0).GetValue(0, l_kivalasztott_sor)  'TODO: melyik oszlop                                    l_a2 = Me.m_SboForm.DataSources.DataTables.Item(0).GetValue(1, l_kivalasztott_sor)                                    l_type = oForm_Eredeti.FormType                                    oForm = Me.m_ParentAddon.SboApplication.Forms.Item(oForm_Eredeti.UniqueID)                                    If l_matrix <> "" Then                                        oMatrix = oForm.Items.Item(l_matrix).Specific                                        oColumn = oMatrix.Columns.Item(l_ertek)                                        oEditText = oColumn.Cells.Item(l_sor).Specific                                        If Me.p_validal = False Then                                            Me.oForm_Eredeti.p_validal_e = False                                            oEditText.String = l_a1                                            Me.oForm_Eredeti.p_validal_e = True                                        Else                                            Me.oForm_Eredeti.p_validal_e = False                                            oEditText.String = l_a1                                            If GetType(IFSZ_MatrixControl).IsAssignableFrom(oForm_Eredeti.GetType()) Then
                                                CType(oForm_Eredeti, IFSZ_MatrixControl).item_validate(True, l_matrix, l_ertek, l_sor, l_a1, "", BubbleEvent)
                                            Else
                                                oForm_Eredeti.item_validate(True, l_matrix, l_ertek, l_sor, l_a1, "", BubbleEvent)                                            End If                                            Me.oForm_Eredeti.p_validal_e = True                                        End If                                        oForm_Eredeti.lookup_id = l_a1                                        If l_lookup_ertek <> "" Then                                            Me.oForm_Eredeti.p_validal_e = False                                            oColumn = oMatrix.Columns.Item(l_lookup_ertek)                                            oEditText = oColumn.Cells.Item(l_sor).Specific                                            oEditText.String = l_a2                                            Me.oForm_Eredeti.p_validal_e = True                                        End If                                    Else                                        oEditText = oForm.Items.Item(l_ertek).Specific                                        oEditText.String = l_a1                                        If l_lookup_ertek <> "" Then                                            oEditText = oForm.Items.Item(l_lookup_ertek).Specific                                            oEditText.String = l_a2                                        End If                                    End If                                Catch ex As Exception
                                    Me.m_ParentAddon.SboApplication.SetStatusBarMessage(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, True)
                                Finally
                                    Me.oForm_Eredeti.m_LovVisszairas = False
                                End Try                                m_SboForm.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE                                m_SboForm.Close()                            Case "2"                                Try                                    Me.oForm_Eredeti.m_LovVisszairas = True
                                    If l_matrix <> "" Then                                        Dim p_ertek As String                                        p_ertek = ""                                        oForm = Me.m_ParentAddon.SboApplication.Forms.Item(oForm_Eredeti.UniqueID)                                        oMatrix = oForm.Items.Item(l_matrix).Specific                                        oColumn = oMatrix.Columns.Item(l_ertek)                                        oForm_Eredeti.p_validal_e = False                                        oEditText = oColumn.Cells.Item(l_sor).Specific                                        oEditText.String = Nothing                                        If l_lookup_ertek <> "" Then                                            oColumn = oMatrix.Columns.Item(l_lookup_ertek)                                            oEditText = oColumn.Cells.Item(l_sor).Specific                                            oEditText.String = Nothing                                        End If                                        oForm_Eredeti.p_validal_e = True                                        If oMatrix.Columns.Item(l_ertek).Visible = True Then                                            oMatrix.Columns.Item(l_ertek).Cells.Item(l_sor).Click()                                        ElseIf l_lookup_ertek <> "" Then                                            If oMatrix.Columns.Item(l_lookup_ertek).Visible = True Then                                                oMatrix.Columns.Item(l_lookup_ertek).Cells.Item(l_sor).Click()                                            End If                                        End If                                        'Me.p_volt_e_lov = False                                    Else                                        oForm = Me.m_ParentAddon.SboApplication.Forms.Item(oForm_Eredeti.UniqueID)                                        oForm_Eredeti.p_validal_e = False                                        oEditText = oForm.Items.Item(l_ertek).Specific                                        oEditText.String = Nothing                                        If l_lookup_ertek <> "" Then                                            oEditText = oForm.Items.Item(l_lookup_ertek).Specific                                            oEditText.String = Nothing                                        End If                                        oForm.Items.Item(l_ertek).Click()                                        oForm_Eredeti.p_validal_e = True                                    End If                                Catch ex As Exception
                                    Me.m_ParentAddon.SboApplication.SetStatusBarMessage(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, True)
                                Finally
                                    Me.oForm_Eredeti.m_LovVisszairas = False
                                End Try                                m_SboForm.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE                                m_SboForm.Close()                            Case "IfszLov"                                If m_SboForm.Items.Item(pVal.ItemUID).Type() = SAPbouiCOM.BoFormItemTypes.it_GRID And pVal.Row > -1 Then                                    oGrid = Me.m_SboForm.Items.Item("IfszLov").Specific                                    oGrid.SelectionMode = SAPbouiCOM.BoMatrixSelect.ms_Single                                    Me.l_kivalasztott_sor = pVal.Row                                    oGrid.Rows.SelectedRows.Clear()                                    oGrid.Rows.SelectedRows.Add(pVal.Row)
                                End If                        End Select                    Case SAPbouiCOM.BoEventTypes.et_DOUBLE_CLICK                        Dim oTitle As SAPbouiCOM.ColumnTitle                        Dim oMatrix As SAPbouiCOM.Matrix                        Dim oEditText As SAPbouiCOM.EditText                        Dim i As Integer                        Dim index As Integer                        Dim l_matrix_nev As String                        Dim l_tabla_nev As String                        Dim oColumn As SAPbouiCOM.Column                        Dim l_type As String                        Dim l_str As String                        If Me.m_SboForm.Items.Item(pVal.ItemUID).Type = SAPbouiCOM.BoFormItemTypes.it_GRID And pVal.Row = -1 And pVal.ColUID <> "" Then  'TODO: rendezés                            Me.fejlec_aktival(pVal, BubbleEvent)                        ElseIf Me.m_SboForm.Items.Item(pVal.ItemUID).Type = SAPbouiCOM.BoFormItemTypes.it_GRID And pVal.Row > -1 And pVal.ColUID <> "" Then

                            If pVal.ColUID = "RowsHeader" Then
                                Me.link_pressed("IfszLov", l_OszlopTipus(0).DbNev, pVal.Row)
                            Else

                                Try
                                    Me.oForm_Eredeti.m_LovVisszairas = True

                                    If l_kivalasztott_sor = -1 Then
                                        oForm = Me.m_ParentAddon.SboApplication.Forms.Item(oForm_Eredeti.UniqueID)
                                        If l_matrix <> "" Then
                                            oMatrix = oForm.Items.Item(l_matrix).Specific
                                            oMatrix.Columns.Item(l_ertek).Cells.Item(l_sor).Click()
                                            oColumn = oMatrix.Columns.Item(l_ertek)
                                            Me.oForm_Eredeti.p_validal_e = False
                                            oEditText = oColumn.Cells.Item(l_sor).Specific
                                            oEditText.String = Nothing
                                            If l_lookup_ertek <> "" Then
                                                oColumn = oMatrix.Columns.Item(l_lookup_ertek)
                                                oEditText = oColumn.Cells.Item(l_sor).Specific
                                                oEditText.String = Nothing
                                            End If
                                            Me.oForm_Eredeti.p_validal_e = True
                                        Else
                                            oForm.Items.Item(l_ertek).Click()
                                            Me.oForm_Eredeti.p_validal_e = False
                                            oEditText = oForm.Items.Item(l_ertek).Specific()
                                            oEditText.String = Nothing
                                            If l_lookup_ertek <> "" Then
                                                oEditText = oForm.Items.Item(l_lookup_ertek).Specific
                                                oEditText.String = Nothing
                                            End If
                                            Me.oForm_Eredeti.p_validal_e = True
                                        End If
                                        Exit Sub
                                    End If

                                    l_a1 = Me.m_SboForm.DataSources.DataTables.Item(0).GetValue(0, l_kivalasztott_sor)  'TODO: melyik oszlop
                                    l_a2 = Me.m_SboForm.DataSources.DataTables.Item(0).GetValue(1, l_kivalasztott_sor)

                                    l_type = oForm_Eredeti.FormType
                                    oForm = Me.m_ParentAddon.SboApplication.Forms.Item(oForm_Eredeti.UniqueID)
                                    'oForm2 = Me.SBO_Application.Forms.Item(oForm_Eredeti.UniqueID)
                                    'Me.SBO_Application.Forms.GetFormByTypeAndCount(oForm_Eredeti.FormType, oForm_Eredeti.Count)
                                    If l_matrix <> "" Then
                                        oMatrix = oForm.Items.Item(l_matrix).Specific
                                        oColumn = oMatrix.Columns.Item(l_ertek)
                                        oEditText = oColumn.Cells.Item(l_sor).Specific
                                        If Me.p_validal = False Then
                                            Me.oForm_Eredeti.p_validal_e = False
                                            oEditText.String = l_a1
                                            Me.oForm_Eredeti.p_validal_e = True
                                        Else
                                            Me.oForm_Eredeti.p_validal_e = False
                                            oEditText.String = l_a1
                                            If GetType(IFSZ_MatrixControl).IsAssignableFrom(oForm_Eredeti.GetType()) Then
                                                CType(oForm_Eredeti, IFSZ_MatrixControl).item_validate(True, l_matrix, l_ertek, l_sor, l_a1, "", BubbleEvent)
                                            Else
                                                oForm_Eredeti.item_validate(True, l_matrix, l_ertek, l_sor, l_a1, "", BubbleEvent)                                            End If                                            Me.oForm_Eredeti.p_validal_e = True
                                        End If
                                        'oForm_Eredeti.item_validate(True, l_matrix, l_ertek, l_sor, l_a1, "", BubbleEvent)

                                        oForm_Eredeti.lookup_id = l_a1

                                        If l_lookup_ertek <> "" Then
                                            Me.oForm_Eredeti.p_validal_e = False
                                            oColumn = oMatrix.Columns.Item(l_lookup_ertek)
                                            oEditText = oColumn.Cells.Item(l_sor).Specific
                                            oEditText.String = l_a2
                                            'oForm_Eredeti.item_validate(True, l_matrix, l_lookup_ertek, l_sor, l_a2, "", BubbleEvent)
                                            Me.oForm_Eredeti.p_validal_e = True
                                        End If
                                    Else
                                        oEditText = oForm.Items.Item(l_ertek).Specific
                                        oEditText.String = l_a1
                                        'oForm_Eredeti.item_validate(True, l_ertek, "", l_sor, l_a1, "", BubbleEvent)

                                        'If Me.p_validal = False Then
                                        '    Me.oForm_Eredeti.p_validal_e = False
                                        '    oEditText.String = l_a1
                                        '    Me.oForm_Eredeti.p_validal_e = True
                                        'Else
                                        '    Me.oForm_Eredeti.p_validal_e = False
                                        '    oEditText.String = l_a1
                                        '    oForm_Eredeti.item_validate(True, l_ertek, "", l_sor, l_a1, "", BubbleEvent)
                                        '    Me.oForm_Eredeti.p_validal_e = True
                                        'End If

                                        If l_lookup_ertek <> "" Then
                                            oEditText = oForm.Items.Item(l_lookup_ertek).Specific
                                            oEditText.String = l_a2
                                            'oForm_Eredeti.item_validate(True, l_lookup_ertek, "", l_sor, l_a2, "", BubbleEvent)
                                        End If
                                    End If

                                Catch ex As Exception
                                    Me.m_ParentAddon.SboApplication.SetStatusBarMessage(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, True)
                                Finally
                                    Me.oForm_Eredeti.m_LovVisszairas = False
                                End Try

                                'BubbleEvent = True
                                m_SboForm.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE
                                m_SboForm.Close()                            End If
                        End If                End Select            ElseIf pVal.Before_Action = False Then                Select Case pVal.EventType                    Case SAPbouiCOM.BoEventTypes.et_KEY_DOWN                        Dim oEditText As SAPbouiCOM.EditText                        Dim oMatrix As SAPbouiCOM.Grid                        Dim oColumn As SAPbouiCOM.Column                        Dim l_ertek As String                        Dim l_string As String                        Static Dim l_string_elozo As String = ""                        Static Dim index As Integer = 1                        Dim i As Integer                        Dim l_min, l_max As Integer                        Dim l_ind As Integer                        Dim l_oszlopszam As Integer = -1                        Dim l_temp As String                        Dim l_irany As String                        If pVal.ItemUID = "Keres" Then                            oEditText = Me.m_SboForm.Items.Item(pVal.ItemUID).Specific                            l_string = oEditText.String()                            If l_string.Length < l_string_elozo.Length Then                                index = 1                            End If                            l_string_elozo = l_string                            If p_rendez.oszlop Is Nothing Then
                                'Alap order by-nál is tudunk keresni, de csak ha order by <oszlopszám> formában lett megadva
                                If String.IsNullOrEmpty(Me.l_order_by) Then
                                    Exit Sub
                                End If
                                Dim l_regex As New System.Text.RegularExpressions.Regex("^\s*order\s*by\s*([^\s]+)*(\s+(asc|desc)){0,1}", System.Text.RegularExpressions.RegexOptions.IgnoreCase)
                                If l_regex.IsMatch(Me.l_order_by) Then
                                    l_temp = l_regex.Replace(Me.l_order_by, "$1")
                                    If Not Integer.TryParse(l_temp, l_oszlopszam) Then
                                        If (l_temp.ToLower.StartsWith("lower(") Or l_temp.ToLower.StartsWith("upper(")) And l_temp.EndsWith(")") Then
                                            l_temp = l_temp.Substring(6, l_temp.Length - 7).Trim()
                                        End If
                                        l_oszlopszam = Me.GetOszlopSorszam(l_temp.TrimStart("""").TrimStart("[").TrimEnd("""").TrimEnd("]"))
                                    Else
                                        ' "order by 1" módon van megadva
                                    End If
                                    If l_oszlopszam > 0 Then
                                        l_temp = l_regex.Replace(Me.l_order_by, "$3")
                                        If String.IsNullOrEmpty(l_temp) Then
                                            l_irany = "asc"
                                        Else
                                            l_irany = l_temp.ToLower()
                                        End If
                                    Else
                                        Exit Sub
                                    End If
                                Else
                                    Exit Sub
                                End If

                            Else
                                l_irany = p_rendez.irany.ToLower()
                            End If                            oMatrix = Me.m_SboForm.Items.Item("IfszLov").Specific                            If l_irany = "asc" Then                                l_min = -1                                l_max = Me.m_SboForm.DataSources.DataTables.Item(0).Rows.Count - 1                                i = l_min + 1                            Else                                l_min = Me.m_SboForm.DataSources.DataTables.Item(0).Rows.Count                                l_max = 0                                i = l_min - 1                            End If                            'Az l_min-l_max intervallum jelenti azt a sávot, ahol elhelyezkedhet a keresett rekord (Pontosabban: l_min még nem jó, l_max még jó lehet) - desc irány esetén fejre fordul az egész                            While (l_irany = "asc" AndAlso l_min < l_max) OrElse (l_irany = "desc" AndAlso l_min > l_max)                                If p_rendez.oszlop Is Nothing Then
                                    l_ertek = Me.m_SboForm.DataSources.DataTables.Item(0).GetValue(l_oszlopszam - 1, i).ToString()
                                Else
                                    l_ertek = Me.m_SboForm.DataSources.DataTables.Item(0).GetValue(p_rendez.oszlop, i).ToString()
                                End If                                If l_ertek.Length >= l_string.Length AndAlso l_ertek.Substring(0, l_string.Length).ToLower = l_string.ToLower AndAlso IIf(l_irany = "asc", l_min + 1, l_min - 1) = i Then
                                    oMatrix.SelectionMode = SAPbouiCOM.BoMatrixSelect.ms_Single                                    oMatrix.Rows.SelectedRows.Clear()
                                    oMatrix.Rows.SelectedRows.Add(i)
                                    Me.l_kivalasztott_sor = i
                                    Exit While
                                    'ElseIf (l_irany = "asc" AndAlso l_ertek.ToLower < l_string.ToLower) OrElse (l_irany = "desc" AndAlso l_ertek.ToLower > l_string.ToLower) Then ' (l_irany = "desc" AndAlso l_ertek.Substring(0, Math.Min(l_string.Length, l_ertek.Length)).ToLower >= l_string.Substring(0, Math.Min(l_string.Length, l_ertek.Length)).ToLower) Then
                                ElseIf l_ertek.ToLower < l_string.ToLower Then
                                    'Ez azt jelenti, hogy az i. pozíció biztosan nem a keresett sor, ezért az l_min-t felnyomom
                                    l_min = i
                                    'És egy új i-t határozok meg. Sebességi okokból felezéses technikát használok
                                    If l_irany = "asc" Then
                                        i = Math.Ceiling((l_min + 1 + l_max) / 2)
                                    Else
                                        i = Math.Floor((l_min - 1 + l_max) / 2)
                                    End If
                                Else
                                    'Az i. pozíció magasabb, mint a keresett szövegrészlet, ezért még lehet, hogy ez jó lesz nekünk, de ebben már csak akkor lehetünk biztosak, ha az l_min-t is elég magasra feltornáztuk
                                    'i pozíció fölött már biztos nem lesz a keresett sor, ezért az l_max-ot lehozzuk i-re
                                    l_max = i
                                    'És egy új i-t határozok meg. Sebességi okokból felezéses technikát használok
                                    If l_irany = "asc" Then
                                        i = Math.Floor((l_min + 1 + l_max) / 2)
                                    Else
                                        i = Math.Ceiling((l_min - 1 + l_max) / 2)
                                    End If
                                End If
                                'Konkrétan nem találtuk meg a keresett szövegrészletet, de összecsukódott az l_min l_max olló
                                If IIf(l_irany = "asc", l_min + 1, l_min - 1) = l_max Then
                                    'Az l_min biztosan olyat tartalmaz, ami még nem jó, ezért az ennél 1-el nagyobb sorszámot jelöljük ki
                                    oMatrix.SelectionMode = SAPbouiCOM.BoMatrixSelect.ms_Single                                    oMatrix.Rows.SelectedRows.Clear()
                                    If l_irany = "asc" Then
                                        If l_min + 1 > Me.m_SboForm.DataSources.DataTables.Item(0).Rows.Count - 1 Then
                                            i = l_min
                                        Else
                                            i = l_min + 1
                                        End If
                                    Else
                                        If l_min - 1 < 0 Then
                                            i = l_min
                                        Else
                                            i = l_min - 1
                                        End If
                                    End If
                                    oMatrix.Rows.SelectedRows.Add(i)
                                    Me.l_kivalasztott_sor = i
                                    Exit While
                                End If
                            End While                            'If Me.p_rendez.oszlop = Nothing Then                            '    'Exit Sub                            '    p_rendez.oszlop = "A1"                            'End If                            'oMatrix.SelectionMode = SAPbouiCOM.BoMatrixSelect.ms_Single                            'oColumn = oMatrix.Columns.Item(p_rendez.oszlop)                            'l_ind = oColumn.Cells.Count                            'i = index                            'For i = index To oColumn.Cells.Count                            '    oEditText = oColumn.Cells.Item(i).Specific                            '    l_ertek = oEditText.String                            '    l_pos = InStr(1, l_ertek.ToUpper, l_string.ToUpper)                            '    If l_pos = 1 Then                            '        oMatrix.SelectRow(i, True, False)                            '        Me.l_kivalasztott_sor = i                            '        index = i                            '        Exit Sub                            '    End If                            'Next                            'oEditText = oColumn.Cells.Item(l_kivalasztott_sor).Specific                            'l_a1 = oEditText.String                        End If                        'Case SAPbouiCOM.BoEventTypes.et_MATRIX_LINK_PRESSED                        '    link_pressed(pVal.ItemUID, pVal.ColUID, pVal.Row)                    Case SAPbouiCOM.BoEventTypes.et_FORM_LOAD
                        Dim l_index As String
                        Dim l_osztaly As String
                        Dim oArgs() As Object = {Me.m_ParentAddon, "", pVal.FormUID, Me.l_Link_ertek}
                        Dim oForm As SboForm
                        Dim Dummy As New IFSZ_Dummy_Addonbase

                        If Me.l_FormID = pVal.FormType And pVal.FormType <> 0 Then
                            l_index = "1" 'l_colID.Remove(0, 1)
                            l_osztaly = Me.l_OszlopTipus(CInt(l_index) - 1).LinkOsztaly
                            oForm = [Assembly].GetExecutingAssembly.CreateInstance(
                                                               l_osztaly,
                                                               True,
                                                               BindingFlags.Public Or BindingFlags.Instance Or BindingFlags.CreateInstance,
                                                               Nothing,
                                                               oArgs,
                                                               Nothing,
                                                               Nothing)
                            If (oForm Is Nothing) Then
                                oForm = [Assembly].GetAssembly(Dummy.GetType()).CreateInstance(
                                                                                               l_osztaly,
                                                                                               True,
                                                                                               BindingFlags.Public Or BindingFlags.Instance Or BindingFlags.CreateInstance,
                                                                                               Nothing,
                                                                                               oArgs,
                                                                                               Nothing,
                                                                                               Nothing)
                            End If
                            If (Not oForm Is Nothing) Then
                                ' If got an instance, add to our list
                                Try
                                    Me.m_ParentAddon.SBOForms.Add(oForm, oForm.UniqueID)
                                Catch ex As Exception
                                    Me.m_ParentAddon.SBOForms.Remove(oForm.UniqueID)
                                    Me.m_ParentAddon.SBOForms.Add(oForm, oForm.UniqueID)
                                End Try
                            End If
                            Exit Sub
                        End If                End Select            End If        Catch ex As Exception            m_ParentAddon.SboApplication.MessageBox(ex.ToString)            'm_ParentAddon.BlockEvents = False        End Try    End Sub    Public Overrides Sub HANDLE_MENU_EVENTS(ByRef pVal As SAPbouiCOM.MenuEvent, ByRef BubbleEvent As Boolean)    End Sub    Private Sub initialize()        CreateFormWithMatrix()        AddDataSourceToForm()        '// Bind the Form's items with the desired data source        BindDataToForm()        '// Fill the matrix with data        GetDataFromDataSource()        '// Show my Simple Form        m_SboForm.Visible = True        '//*************************************************************        '// Enable the desired tool bar items        '//*************************************************************    End Sub    Private Sub CreateFormWithMatrix()        Dim oItem As SAPbouiCOM.Item        Dim oButton As SAPbouiCOM.Button        Dim oMatrix As SAPbouiCOM.Grid        Dim oColumns As SAPbouiCOM.Columns        Dim oColumn As SAPbouiCOM.Column        Dim oEditText As SAPbouiCOM.EditText        Dim oStaticText As SAPbouiCOM.StaticText        Dim i As OszlopTipus        Dim l_oszlop_nev As String        Dim index As Integer        m_SboForm.Title = P_Title        m_SboForm.Left = 336        m_SboForm.Width = 636        m_SboForm.Top = 44        m_SboForm.Height = 344        oItem = m_SboForm.Items.Add("1", SAPbouiCOM.BoFormItemTypes.it_BUTTON)        oItem.Left = 5        oItem.Width = 65        oItem.Top = 293        oItem.Height = 19        oButton = oItem.Specific        oButton.Caption = "Ok"        oItem = m_SboForm.Items.Add("2", SAPbouiCOM.BoFormItemTypes.it_BUTTON)        oItem.Left = 75        oItem.Width = 65        oItem.Top = 293        oItem.Height = 19        oButton = oItem.Specific        oButton.Caption = "Cancel"        oItem = m_SboForm.Items.Add("Pt_Keres", SAPbouiCOM.BoFormItemTypes.it_STATIC)        oItem.Left = 5        oItem.Width = 25        oItem.Top = 5        oItem.Height = 20        oItem.LinkTo = "Keres"        oStaticText = oItem.Specific        oStaticText.Caption = "Keresés"        oItem = m_SboForm.Items.Add("Keres", SAPbouiCOM.BoFormItemTypes.it_EDIT)        oItem.Left = 51        oItem.Width = 100        oItem.Top = 5        oItem.Height = 14        oEditText = oItem.Specific        If P_Szuresi_Ertek <> "" Then            oEditText.String = P_Szuresi_Ertek            oEditText.BackColor = 3            '0:          Classic            '1:          Grey            '2:          Violet            '3:          Blue            '4:          Green            '5:          Yellow            '6:          Orange            '7:          Red            '8:          Brown            '>8:         Black        End If        oItem = m_SboForm.Items.Add("IfszLov", SAPbouiCOM.BoFormItemTypes.it_GRID)        oItem.Left = 5        oItem.Width = 617        oItem.Top = 25        oItem.Height = 260        oMatrix = oItem.Specific        'oColumns = oMatrix.Columns        'oColumn = oColumns.Add("Ssz", SAPbouiCOM.BoFormItemTypes.it_EDIT)        'oColumn.TitleObject.Caption = "Ssz."        'oColumn.Width = 30        'oColumn.Editable = False        'oColumn.RightJustified = True        'index = 1        'For Each i In l_OszlopTipus        '    l_oszlop_nev = "A" & index        '    If i.Link = False Then        '        oColumn = oColumns.Add(l_oszlop_nev, SAPbouiCOM.BoFormItemTypes.it_EDIT)        '    Else        '        oColumn = oColumns.Add(l_oszlop_nev, SAPbouiCOM.BoFormItemTypes.it_LINKED_BUTTON)        '    End If        '    oColumn.TitleObject.Caption = i.Title        '    oColumn.Width = 127        '    oColumn.Editable = False        '    'oColumn.DisplayDesc = True   a számok egyébként csak szemétként jönnének fel !!!!!!        '    oColumn.Description = i.Description        '    oColumn.Visible = i.Visible        '    oColumn.RightJustified = i.RightJustified        '    index += 1        'Next    End Sub    Public Sub AddDataSourceToForm()        Dim i As OszlopTipus        Dim index As Integer        'm_SboForm.DataSources.DBDataSources.Add(l_tabla)        'm_SboForm.DataSources.UserDataSources.Add("Sorszam", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 30)        'index = 1        'For Each i In l_OszlopTipus        '    If i.Tipus = "TEXT" Then        '        m_SboForm.DataSources.UserDataSources.Add("DSource" & index.ToString, SAPbouiCOM.BoDataType.dt_LONG_TEXT, 30)        '    ElseIf i.Tipus = "DATE" Then        '        m_SboForm.DataSources.UserDataSources.Add("DSource" & index.ToString, SAPbouiCOM.BoDataType.dt_DATE, 30)        '    ElseIf i.Tipus = "NUMBER" Then        '        m_SboForm.DataSources.UserDataSources.Add("DSource" & index.ToString, SAPbouiCOM.BoDataType.dt_LONG_NUMBER, 30)        '    End If        '    index += 1        'Next    End Sub    Public Sub BindDataToForm()        'Dim oMatrix As SAPbouiCOM.Grid        'Dim oColumns As SAPbouiCOM.Columns        'Dim oColumn As SAPbouiCOM.Column        'Dim oEditText As SAPbouiCOM.EditText        'Dim i As OszlopTipus        'Dim index As Integer        'Dim l_oszlop_nev As String        'oMatrix = m_SboForm.Items.Item("IfszLov").Specific        'oMatrix.SelectionMode = SAPbouiCOM.BoMatrixSelect.ms_Single        'oColumns = oMatrix.Columns        'index = 1        'oColumn = oColumns.Item("Ssz")        'oColumn.DataBind.SetBound(True, "", "Sorszam")        ''Dim utdTable As SAPbobsCOM.UserTable        ''utdTable = m_ParentAddon.SboCompany.UserTables.Item(Replace(l_tabla, "@", ""))        'For Each i In l_OszlopTipus        '    l_oszlop_nev = "A" & index        '    oColumn = oColumns.Item(l_oszlop_nev)        '    oColumn.DataBind.SetBound(True, "", "DSource" & index)        '    index += 1        '    If oColumn.Type = SAPbouiCOM.BoFormItemTypes.it_COMBO_BOX Then        '        oColumn.DisplayDesc = True        '    End If        'Next    End Sub    Public Sub GetDataFromDataSource()        Dim oDBDataSource As SAPbouiCOM.DBDataSource        Dim oUserDataSource As SAPbouiCOM.UserDataSource        Dim oMatrix As SAPbouiCOM.Grid        Dim oColumn As SAPbouiCOM.GridColumn        Dim oEditText As SAPbouiCOM.EditText        Dim oUserData As SAPbouiCOM.UserDataSource        Dim oRecordSet As SAPbobsCOM.Recordset        Dim oUserData1 As SAPbouiCOM.UserDataSource        Dim oUserData2 As SAPbouiCOM.UserDataSource        Dim oUserData3 As SAPbouiCOM.UserDataSource        Dim oUserData4 As SAPbouiCOM.UserDataSource        Dim oUserData5 As SAPbouiCOM.UserDataSource        Dim oUserData6 As SAPbouiCOM.UserDataSource        Dim oUserData7 As SAPbouiCOM.UserDataSource        Dim oUserData8 As SAPbouiCOM.UserDataSource        Dim oUserData9 As SAPbouiCOM.UserDataSource        Dim oUserData10 As SAPbouiCOM.UserDataSource        Dim oUserData11 As SAPbouiCOM.UserDataSource        Dim oUserData12 As SAPbouiCOM.UserDataSource        Dim oUserData13 As SAPbouiCOM.UserDataSource        Dim oUserData14 As SAPbouiCOM.UserDataSource        Dim oUserData15 As SAPbouiCOM.UserDataSource        Dim oUserData16 As SAPbouiCOM.UserDataSource        Dim oUserData17 As SAPbouiCOM.UserDataSource        Dim oUserData18 As SAPbouiCOM.UserDataSource        Dim oUserData19 As SAPbouiCOM.UserDataSource        Dim oUserData20 As SAPbouiCOM.UserDataSource        Dim l_ert As String        Dim i, j As Integer '// to be used as counter        Dim l As OszlopTipus        Dim index As Integer = 0        'Dim l_select As String        'oDBDataSource = m_SboForm.DataSources.DBDataSources.Item(l_tabla)        Try            'oUserData = m_SboForm.DataSources.UserDataSources.Item("Sorszam")            '// getting the matrix from the form            oMatrix = m_SboForm.Items.Item("IfszLov").Specific            Me.m_SboForm.DataSources.DataTables.Add("IfszLov")
            Me.m_SboForm.DataSources.DataTables.Item(0).ExecuteQuery(l_select & " " & l_order_by)
            oMatrix.DataTable = Me.m_SboForm.DataSources.DataTables.Item("IfszLov")

            Me.OszlopokBeallitasa()

            'oColumn = oMatrix.Columns.Item("Ssz")            'oMatrix.Clear()            'For j = 1 To l_OszlopTipus.Length            '    Select Case j            '        Case "1"            '            oUserData1 = m_SboForm.DataSources.UserDataSources.Item("DSource1")            '        Case "2"            '            oUserData2 = m_SboForm.DataSources.UserDataSources.Item("DSource2")            '        Case "3"            '            oUserData3 = m_SboForm.DataSources.UserDataSources.Item("DSource3")            '        Case "4"            '            oUserData4 = m_SboForm.DataSources.UserDataSources.Item("DSource4")            '        Case "5"            '            oUserData5 = m_SboForm.DataSources.UserDataSources.Item("DSource5")            '        Case "6"            '            oUserData6 = m_SboForm.DataSources.UserDataSources.Item("DSource6")            '        Case "7"            '            oUserData7 = m_SboForm.DataSources.UserDataSources.Item("DSource7")            '        Case "8"            '            oUserData8 = m_SboForm.DataSources.UserDataSources.Item("DSource8")            '        Case "9"            '            oUserData9 = m_SboForm.DataSources.UserDataSources.Item("DSource9")            '        Case "10"            '            oUserData10 = m_SboForm.DataSources.UserDataSources.Item("DSource10")            '        Case "11"            '            oUserData11 = m_SboForm.DataSources.UserDataSources.Item("DSource11")            '        Case "12"            '            oUserData12 = m_SboForm.DataSources.UserDataSources.Item("DSource12")            '        Case "13"            '            oUserData13 = m_SboForm.DataSources.UserDataSources.Item("DSource13")            '        Case "14"            '            oUserData14 = m_SboForm.DataSources.UserDataSources.Item("DSource14")            '        Case "15"            '            oUserData15 = m_SboForm.DataSources.UserDataSources.Item("DSource15")            '        Case "16"            '            oUserData16 = m_SboForm.DataSources.UserDataSources.Item("DSource16")            '        Case "17"            '            oUserData17 = m_SboForm.DataSources.UserDataSources.Item("DSource17")            '        Case "18"            '            oUserData18 = m_SboForm.DataSources.UserDataSources.Item("DSource18")            '        Case "19"            '            oUserData19 = m_SboForm.DataSources.UserDataSources.Item("DSource19")            '        Case "20"            '            oUserData20 = m_SboForm.DataSources.UserDataSources.Item("DSource20")            '    End Select            'Next            'oRecordSet = Me.SBO_Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)            'oRecordSet.DoQuery(l_select & " " & l_order_by)            'If oRecordSet.RecordCount > 0 Then            '    For i = 0 To oRecordSet.RecordCount - 1            '        oUserData.Value = i + 1            '        For j = 1 To l_OszlopTipus.Length            '            l_ert = oRecordSet.Fields.Item(j - 1).Value            '            Select Case j            '                Case "1"            '                    oUserData1.Value = oRecordSet.Fields.Item(j - 1).Value            '                Case "2"            '                    oUserData2.Value = oRecordSet.Fields.Item(j - 1).Value            '                Case "3"            '                    oUserData3.Value = oRecordSet.Fields.Item(j - 1).Value            '                Case "4"            '                    oUserData4.Value = oRecordSet.Fields.Item(j - 1).Value            '                Case "5"            '                    oUserData5.Value = oRecordSet.Fields.Item(j - 1).Value            '                Case "6"            '                    oUserData6.Value = oRecordSet.Fields.Item(j - 1).Value            '                Case "7"            '                    oUserData7.Value = oRecordSet.Fields.Item(j - 1).Value            '                Case "8"            '                    oUserData8.Value = oRecordSet.Fields.Item(j - 1).Value            '                Case "9"            '                    oUserData9.Value = oRecordSet.Fields.Item(j - 1).Value            '                Case "10"            '                    oUserData10.Value = oRecordSet.Fields.Item(j - 1).Value            '                Case "11"            '                    oUserData11.Value = oRecordSet.Fields.Item(j - 1).Value            '                Case "12"            '                    oUserData12.Value = oRecordSet.Fields.Item(j - 1).Value            '                Case "13"            '                    oUserData13.Value = oRecordSet.Fields.Item(j - 1).Value            '                Case "14"            '                    oUserData14.Value = oRecordSet.Fields.Item(j - 1).Value            '                Case "15"            '                    oUserData15.Value = oRecordSet.Fields.Item(j - 1).Value            '                Case "16"            '                    oUserData16.Value = oRecordSet.Fields.Item(j - 1).Value            '                Case "17"            '                    oUserData17.Value = oRecordSet.Fields.Item(j - 1).Value            '                Case "18"            '                    oUserData18.Value = oRecordSet.Fields.Item(j - 1).Value            '                Case "19"            '                    oUserData19.Value = oRecordSet.Fields.Item(j - 1).Value            '                Case "20"            '                    oUserData20.Value = oRecordSet.Fields.Item(j - 1).Value            '            End Select            '        Next            '        oMatrix.AddRow()            '        oEditText = oColumn.Cells.Item(i + 1).Specific            '        oEditText.String = i + 1            '        oRecordSet.MoveNext()            '    Next i            'End If        Finally            If (Not oRecordSet Is Nothing) Then                System.Runtime.InteropServices.Marshal.ReleaseComObject(oRecordSet)                oRecordSet = Nothing            End If        End Try        oMatrix.AutoResizeColumns()    End Sub    Private Sub SaveAsXML()        Dim oXmlDoc As New Xml.XmlDocument        Dim sXmlString As String        sXmlString = Me.m_SboForm.GetAsXML        oXmlDoc.LoadXml(sXmlString)        oXmlDoc.Save("C:\IFSZ_GRIDLOV_VIEW.xml")    End Sub

    'TODO: link_pressed
    Public Sub link_pressed(ByVal l_ItemUID As String, ByVal l_ColUID As String, ByVal l_Row As Integer)        Dim l_index As String        Dim l_osztaly As String        Dim oArgs() As Object = {Me.m_ParentAddon, ""}        Dim oForm As SboForm        Dim Dummy As New IFSZ_Dummy_Addonbase        l_index = "1"        If Me.l_OszlopTipus(CInt(l_index) - 1).MenuUID > 0 Then            Me.l_Link_ertek = Me.m_SboForm.DataSources.DataTables.Item(0).GetValue(0, l_Row)  ' Me.get_item_value(l_ItemUID, l_ColUID, l_Row)
            Me.l_colID = l_ColUID            Me.l_FormID = Me.l_OszlopTipus(CInt(l_index) - 1).FormUID            Me.m_ParentAddon.SboApplication.ActivateMenuItem(Me.l_OszlopTipus(CInt(l_index) - 1).MenuUID)        Else            l_osztaly = Me.l_OszlopTipus(CInt(l_index)).LinkOsztaly            oForm = [Assembly].GetExecutingAssembly.CreateInstance(
                                           l_osztaly,
                                           True,
                                           BindingFlags.Public Or BindingFlags.Instance Or BindingFlags.CreateInstance,
                                           Nothing,
                                           oArgs,
                                           Nothing,
                                           Nothing)            If (oForm Is Nothing) Then                oForm = [Assembly].GetAssembly(Dummy.GetType()).CreateInstance(
                                                                           l_osztaly,
                                                                           True,
                                                                           BindingFlags.Public Or BindingFlags.Instance Or BindingFlags.CreateInstance,
                                                                           Nothing,
                                                                           oArgs,
                                                                           Nothing,
                                                                           Nothing)            End If            If (Not oForm Is Nothing) Then
                ' If got an instance, add to our list
                Me.m_ParentAddon.SBOForms.Add(oForm) ', oForm.UniqueID
            End If        End If    End Sub    Public Overridable Sub fejlec_aktival(ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)        Dim oTitle As SAPbouiCOM.ColumnTitle        Dim oGrid As SAPbouiCOM.Grid        Dim l_prompt As String        If pVal.ColUID = "RowsHeader" Then            Exit Sub
        End If        oGrid = Me.m_SboForm.Items.Item(pVal.ItemUID).Specific        If p_rendez.oszlop = Nothing Then            p_rendez.oszlop = pVal.ColUID            p_rendez.irany = "Asc"            oTitle = oGrid.Columns.Item(pVal.ColUID).TitleObject            l_prompt = oTitle.Caption            oTitle.Caption = l_prompt & " ^"        Else            oTitle = oGrid.Columns.Item(p_rendez.oszlop).TitleObject            l_prompt = oTitle.Caption            l_prompt = Replace(l_prompt, " ", "")            l_prompt = Replace(l_prompt, "^", "")            l_prompt = Replace(l_prompt, "ˇ", "")            oTitle.Caption = l_prompt            If p_rendez.oszlop = pVal.ColUID Then                p_rendez.oszlop = pVal.ColUID                If p_rendez.irany = "Asc" Then                    p_rendez.irany = "Desc"                Else                    p_rendez.irany = "Asc"                End If            Else                p_rendez.oszlop = pVal.ColUID                p_rendez.irany = "Asc"            End If        End If        Dim l_ordby As String = " order by "        l_ordby += "lower(" + QueryResource.AzonPrep(p_rendez.oszlop) + ") " + p_rendez.irany        Me.m_SboForm.DataSources.DataTables.Item(0).ExecuteQuery(l_select & " " & l_ordby)

        Me.OszlopokBeallitasa()
    End Sub    Public Function get_item_value(ByVal p_item As String, ByVal p_oszlop As String, ByVal p_sor As Integer, Optional ByVal lookup_e As Boolean = False)        Dim oMatrix As SAPbouiCOM.Matrix        Dim oColumn As SAPbouiCOM.Column        Dim oEditText As SAPbouiCOM.EditText        Dim oComboBox As SAPbouiCOM.ComboBox        Dim oCheckBox As SAPbouiCOM.CheckBox        Dim l_ertek As String        If m_SboForm.Items.Item(p_item).Type = SAPbouiCOM.BoFormItemTypes.it_MATRIX Then            oMatrix = m_SboForm.Items.Item(p_item).Specific            oColumn = oMatrix.Columns.Item(p_oszlop)            Select Case oColumn.Type                Case SAPbouiCOM.BoFormItemTypes.it_EDIT                    oEditText = oColumn.Cells.Item(p_sor).Specific                    l_ertek = oEditText.String                    Return l_ertek                Case SAPbouiCOM.BoFormItemTypes.it_LINKED_BUTTON                    oEditText = oColumn.Cells.Item(p_sor).Specific                    l_ertek = oEditText.String                    Return l_ertek                Case SAPbouiCOM.BoFormItemTypes.it_COMBO_BOX                    oComboBox = oColumn.Cells.Item(p_sor).Specific                    If lookup_e = True Then                        Return oComboBox.Selected.Description                    Else                        Return oComboBox.Selected.Value                    End If                Case SAPbouiCOM.BoFormItemTypes.it_CHECK_BOX                    oCheckBox = oColumn.Cells.Item(p_sor).Specific                    If oCheckBox.Checked Then                        Return oCheckBox.ValOn                    Else                        Return oCheckBox.ValOff                    End If            End Select        ElseIf m_SboForm.Items.Item(p_item).Type = SAPbouiCOM.BoFormItemTypes.it_EDIT Then            oEditText = m_SboForm.Items.Item(p_item).Specific            l_ertek = oEditText.String            Return l_ertek        ElseIf m_SboForm.Items.Item(p_item).Type = SAPbouiCOM.BoFormItemTypes.it_COMBO_BOX Then            oComboBox = m_SboForm.Items.Item(p_item).Specific            If (Not oComboBox.Selected Is Nothing) Then                If lookup_e = True Then                    Return oComboBox.Selected.Description                Else                    Return oComboBox.Selected.Value                End If            Else                Return ""            End If        ElseIf m_SboForm.Items.Item(p_item).Type = SAPbouiCOM.BoFormItemTypes.it_CHECK_BOX Then            oCheckBox = m_SboForm.Items.Item(p_item).Specific            If oCheckBox.Checked Then                Return oCheckBox.ValOn            Else                Return oCheckBox.ValOff            End If        End If        Return ""    End Function    Private Sub OszlopokBeallitasa()        Dim oGrid As SAPbouiCOM.Grid        Dim l_oszlciklus As OszlopTipus        Dim index As Integer = 0        Try
            oGrid = Me.m_SboForm.Items.Item("IfszLov").Specific
            For Each l_oszlciklus In l_OszlopTipus                oGrid.Columns.Item(index).Description = l_oszlciklus.Title                oGrid.Columns.Item(index).Editable = False                If p_rendez.oszlop = Me.m_SboForm.DataSources.DataTables.Item(0).Columns.Item(index).Name Then                    If p_rendez.irany = "Asc" Then
                        oGrid.Columns.Item(index).TitleObject.Caption = l_oszlciklus.Title + " ^"                    Else                        oGrid.Columns.Item(index).TitleObject.Caption = l_oszlciklus.Title + " ˇ"                    End If
                Else
                    oGrid.Columns.Item(index).TitleObject.Caption = l_oszlciklus.Title                End If                oGrid.Columns.Item(index).Type = SAPbouiCOM.BoGridColumnType.gct_EditText                index += 1            Next
        Catch ex As Exception
            Me.m_ParentAddon.SboApplication.SetStatusBarMessage(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, True)
        Finally
            IFSZ_Globals.ReleaseObject(oGrid)
        End Try    End Sub    ''' <summary>
    ''' Visszaadja, hogy az adott oszlopnév hányadik a lov oszlopai között
    ''' 1-től kezdve! Ha ezt akarjuk használni a DataTable oszlopának számához, akkor ebből ki kell vonni egyet
    ''' ToLower-ez mindent, akkor is megtalálja, ha kisbetű nagybetű eltérés van.
    ''' Ha 0-t ad vissza, akkor nem talált
    ''' </summary>
    ''' <param name="p_oszlop"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>    Private Function GetOszlopSorszam(ByVal p_oszlop As String) As Integer        Dim oGrid As SAPbouiCOM.Grid        Dim l_oszlciklus As OszlopTipus        Dim index As Integer = 0        Try
            oGrid = Me.m_SboForm.Items.Item("IfszLov").Specific
            For Each l_oszlciklus In l_OszlopTipus                If Me.m_SboForm.DataSources.DataTables.Item(0).Columns.Item(index).Name.ToLower = p_oszlop.ToLower Then                    Return index + 1                End If                index += 1            Next        Catch ex As Exception
            Me.m_ParentAddon.SboApplication.SetStatusBarMessage(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, True)
        Finally
            IFSZ_Globals.ReleaseObject(oGrid)
        End Try        Return 0
    End FunctionEnd Class