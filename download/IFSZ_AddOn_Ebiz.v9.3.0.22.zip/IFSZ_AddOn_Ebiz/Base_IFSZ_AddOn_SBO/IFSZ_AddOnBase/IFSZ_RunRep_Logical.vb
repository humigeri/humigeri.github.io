Imports SboAddOnBasePublic Class IFSZ_RunRep_Logical    'Inherits IFSZ_MatrixControl    Inherits SboForm#Region "Constructor"    Public Sub New( _        ByRef ParentAddon As SBOAddOn, _        ByVal RiportNev As String, _        Optional ByVal FormUID As String = "", _        Optional ByVal FunctionCode As String = "" _    )        MyBase.New(ParentAddon, enSboFormTypes.LogicOnly, enSAPFormTypes.IFSZ_CashTxn_RunRep, FunctionCode, FormUID)        Me.m_Riport_Nev = RiportNev    End Sub#End Region#Region "Variables"    Public Shared RiportIndit As Boolean = False    Private m_Riport_Nev As String
    Private oSAPForm As SAPbouiCOM.Form



#End Region
#Region "Overrides"    '    Public Overrides Sub pre_event(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
    Public Overrides Sub HANDLE_FORM_EVENTS(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)        Dim oMatrix As SAPbouiCOM.Matrix        Dim oEditText As SAPbouiCOM.EditText        Dim i As Integer        Dim j As Integer        Try            If pVal.Before_Action = False Then                If (IFSZ_RunReportControl.RiportIndit And pVal.FormType = enSAPFormTypes.sapUserReports) Then                    Select Case pVal.EventType                        Case SAPbouiCOM.BoEventTypes.et_FORM_CLOSE                            IFSZ_RunReportControl.RiportIndit = False                            IFSZ_RunReportControl.RiportInditoForm = Nothing                        Case SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE                            oSAPForm = Me.m_ParentAddon.SboApplication.Forms.GetFormByTypeAndCount(pVal.FormType, pVal.FormTypeCount)                            oMatrix = oSAPForm.Items.Item("5").Specific                            'oEditText = oMatrix.Columns.Item(1).Cells.Item(2).Specific                            j = oMatrix.Columns.Item(1).Cells.Count                            For i = 1 To j                                oEditText = oMatrix.Columns.Item(1).Cells.Item(i).Specific                                If oEditText.String = Me.m_Riport_Nev Then                                    oMatrix.Columns.Item(1).Cells.Item(i).Click()
                                    'A lehet� legk�s�bb t�rt�nik a commit:
                                    If m_ParentAddon.SboCompany.InTransaction = True Then                                        m_ParentAddon.SboCompany.EndTransaction(SAPbobsCOM.BoWfTransOpt.wf_Commit)                                    End If

                                    If Me.m_ParentAddon.SboCompany.Version >= 920000 Then
                                        Dim l_menuactivatethread As New System.Threading.Thread(AddressOf Me.threadmenuactivate)
                                        l_menuactivatethread.Start()
                                    Else
                                        Me.threadmenuactivate()
                                    End If

                                    'Me.m_ParentAddon.SboApplication.ActivateMenuItem(enSAPMenuUIDs.PrintPreview)

                                    ''oSAPForm.Close()
                                    ''Most m�r m�s param�terformr�l is ind�that riportot
                                    'IFSZ_RunReportControl.RiportIndit = False
                                    'IFSZ_RunReportControl.RiportInditoForm = Nothing
                                    ''Rollbackel�nk, hogy a where felt�tel ne maradjon meg
                                    ''Me.m_ParentAddon.SboCompany.EndTransaction(SAPbobsCOM.BoWfTransOpt.wf_RollBack)
                                    'If Me.m_Riport_Nev <> "IFSZ_Penztaribevet" Then
                                    '    oSAPForm.Items.Item("2").Click()
                                    'End If
                                    Exit For                                End If                            Next i                    End Select                End If            End If        Catch ex As Exception        End Try    End Sub    '    Public Overrides Sub post_event(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)    '    End Sub    '    Public Overrides Sub item_validate(ByVal p_ItemChanged As Boolean, ByVal p_matrix As String, ByVal p_oszlop As String, ByVal p_sor As Integer, ByVal p_ertek As String, ByVal p_lookup_ertek As String, ByRef BubbleEvent As Boolean)    '    End Sub    Public Overrides Sub HANDLE_MENU_EVENTS(ByRef pVal As SAPbouiCOM.MenuEvent, ByRef BubbleEvent As Boolean)        If pVal.BeforeAction = True AndAlso pVal.MenuUID = enSAPMenuUIDs.PrintPreview AndAlso IFSZ_RunReportControl.RiportIndit = False Then            Dim lRdoc As IFSZ_Rdoc            lRdoc = New IFSZ_Rdoc(Me.m_ParentAddon)            Try                m_ParentAddon.SboCompany.StartTransaction()                lRdoc.SetReportQueryStrCopyNum(Me.m_Riport_Nev)                m_ParentAddon.SboCompany.EndTransaction(SAPbobsCOM.BoWfTransOpt.wf_Commit)            Catch e As NoRowsOwnException                MsgBox(e.Message)                BubbleEvent = False            Catch f As TooManyRowsOwnException                MsgBox(f.Message)                BubbleEvent = False            Catch g As System.Exception                'ifsz-00002: V�ratlan kiv�tel                MsgBox(LocRM.GetString("ifsz-00002") & ":" & Chr(10) & g.ToString)                BubbleEvent = False            Finally                If m_ParentAddon.SboCompany.InTransaction Then                    m_ParentAddon.SboCompany.EndTransaction(SAPbobsCOM.BoWfTransOpt.wf_RollBack)                End If                lRdoc = Nothing            End Try        End If    End Sub





#End Region
    Public Sub threadmenuactivate()
        If Me.m_ParentAddon.SboCompany.Version >= 920000 Then
            Dim m_oProgBar As SAPbouiCOM.ProgressBar
            m_oProgBar = Me.m_ParentAddon.SboApplication.StatusBar.CreateProgressBar("Nyomtat�s", 10, False)
            Dim i As Integer = 0
            For i = 0 To 5
                m_oProgBar.Value = i
                System.Threading.Thread.Sleep(10)
            Next
            m_oProgBar.Stop()
            m_oProgBar = Nothing
        End If

        Try
            Me.m_ParentAddon.SboApplication.ActivateMenuItem(enSAPMenuUIDs.PrintPreview)

            IFSZ_RunReportControl.RiportIndit = False
            IFSZ_RunReportControl.RiportInditoForm = Nothing

            If oSAPForm IsNot Nothing AndAlso Me.m_Riport_Nev <> "IFSZ_Penztaribevet" Then
                oSAPForm.Items.Item("2").Click()
            End If
        Catch ex As Exception
            Me.m_ParentAddon.SboApplication.SetStatusBarMessage("Hiba a nyomtat�s sor�n: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, True)
        End Try

    End Sub

End Class