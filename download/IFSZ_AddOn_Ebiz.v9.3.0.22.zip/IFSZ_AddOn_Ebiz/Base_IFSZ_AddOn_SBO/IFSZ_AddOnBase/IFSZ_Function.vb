Option Explicit On 


' uj sor

Imports SboAddOnBase

Public Class IFSZ_Function

#Region "Variables"
    Dim m_ParentAddon As SBOAddOn
    Public Shared m_Code8 As Boolean = False
#End Region

#Region "Constructor"
    Public Sub New(ByRef ParentAddon As SBOAddOn)
        m_ParentAddon = ParentAddon
    End Sub
#End Region

#Region "Public"
    Public Function GetFconame( _
        ByVal fcocode As String, _
        ByVal lang As String _
    ) As String
        Dim oRecordSet As SAPbobsCOM.Recordset
        Dim retval As String

        Try
            'Kor�bbi 8 hossz� Code-dal nem m�k�dnek bizonyos form azonos�t�k
            If m_Code8 AndAlso (fcocode = "540010007") Then
                fcocode = "54001t7"
            End If
            oRecordSet = m_ParentAddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            oRecordSet.DoQuery(QueryResource.GetQuery("Base_IFSZ_AddOn_SBO", "sel_title_from_functions_by_func_lang", fcocode, lang))
            If oRecordSet.RecordCount <= 0 Then
                oRecordSet.DoQuery(QueryResource.GetQuery("Base_IFSZ_AddOn_SBO", "sel_name_from_functions_by_code", fcocode))
            End If
            retval = oRecordSet.Fields.Item(0).Value
            Return retval
        Catch ex As Exception
            m_ParentAddon.SboApplication.MessageBox(ex.ToString)
            m_ParentAddon.BlockEvents = False
            Return fcocode
        Finally
            If (Not oRecordSet Is Nothing) Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oRecordSet)
                oRecordSet = Nothing
            End If
        End Try

    End Function

    Public Function GetModule( _
        ByVal fcoCode As String _
    ) As String
        Dim oRecordSet As SAPbobsCOM.Recordset
        Dim retval As String
        Dim l_role As IFSZ_Role
        Try
            'Kor�bbi 8 hossz� Code-dal nem m�k�dnek bizonyos form azonos�t�k
            If m_Code8 AndAlso (fcoCode = "540010007") Then
                fcoCode = "54001t7"
            End If
            l_role = New IFSZ_Role(Me.m_ParentAddon)
            If Not l_role.GetFcoModuleRights(fcoCode) Then
                Me.m_ParentAddon.SboApplication.MessageBox(Me.m_ParentAddon.LocRM.GetString("ifsz-00018"))
                Return ""
            End If
            oRecordSet = m_ParentAddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            oRecordSet.DoQuery(QueryResource.GetQuery("Base_IFSZ_AddOn_SBO", "sel_module_from_functions_by_code", fcoCode))
            If oRecordSet.RecordCount > 0 Then
                retval = oRecordSet.Fields.Item(0).Value
            Else
                retval = Nothing
            End If
            Return retval
        Catch ex As Exception
            m_ParentAddon.SboApplication.MessageBox(ex.ToString)
            m_ParentAddon.BlockEvents = False
        Finally
            If (Not oRecordSet Is Nothing) Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oRecordSet)
                oRecordSet = Nothing
            End If
        End Try
    End Function

    Public Function GetMenuItem( _
        ByVal fcoCode As String _
    ) As SAPbouiCOM.MenuItem
        Dim oRecordSet As SAPbobsCOM.Recordset
        Dim retval As String
        Dim uMenus As SAPbouiCOM.Menus
        Dim uMenuitem As SAPbouiCOM.MenuItem

        Try
            'Kor�bbi 8 hossz� Code-dal nem m�k�dnek bizonyos form azonos�t�k
            If m_Code8 AndAlso (fcoCode = "540010007") Then
                fcoCode = "54001t7"
            End If
            oRecordSet = m_ParentAddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            oRecordSet.DoQuery(QueryResource.GetQuery("Base_IFSZ_AddOn_SBO", "sel_menuitem_from functions_by_code", fcoCode))

            uMenus = m_ParentAddon.SboApplication.Menus.Item("51200").SubMenus
            For Each uMenuitem In uMenus
                If InStr(uMenuitem.String, oRecordSet.Fields.Item(1).Value) = 1 Then
                    'Return uMenuitem.UID
                    Return uMenuitem
                End If
            Next


            'If oRecordSet.RecordCount > 0 Then
            '    retval = oRecordSet.Fields.Item(0).Value
            'Else
            '    retval = Nothing
            'End If
            'Return retval
            Return Nothing
        Catch ex As Exception
            m_ParentAddon.SboApplication.MessageBox(ex.ToString)
            m_ParentAddon.BlockEvents = False

        Finally
            If (Not oRecordSet Is Nothing) Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oRecordSet)
                oRecordSet = Nothing
            End If
        End Try
    End Function

    Public Function GetFunctionType( _
        ByVal fcoCode As String _
    ) As String
        Dim oRecordSet As SAPbobsCOM.Recordset
        Dim retval As String
        Try
            'Kor�bbi 8 hossz� Code-dal nem m�k�dnek bizonyos form azonos�t�k
            If m_Code8 AndAlso (fcoCode = "540010007") Then
                fcoCode = "54001t7"
            End If
            oRecordSet = m_ParentAddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            oRecordSet.DoQuery(QueryResource.GetQuery("Base_IFSZ_AddOn_SBO", "sel_type_from_functions_by_code", fcoCode))
            If oRecordSet.RecordCount > 0 Then
                retval = oRecordSet.Fields.Item(0).Value
            Else
                retval = Nothing
            End If
            Return retval

        Catch ex As Exception
            'm_ParentAddon.SboApplication.MessageBox(ex.ToString)
            m_ParentAddon.BlockEvents = False
            Return Nothing

        Finally
            If (Not oRecordSet Is Nothing) Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oRecordSet)
                oRecordSet = Nothing
            End If
        End Try
    End Function

#End Region

End Class