Option Explicit On Imports SboAddOnBasePublic Class IFSZ_Rdoc    Protected m_ParentAddOn As SBOAddOn    Protected m_Company As SAPbobsCOM.Company    Public Sub New(ByVal ParentAddOn As SBOAddOn)        m_ParentAddOn = ParentAddOn        m_Company = ParentAddOn.SboCompany    End Sub    Public Sub SetReportQueryStr(ByVal pRname As String, ByVal pQstring As String)        Dim RecSet As SAPbobsCOM.Recordset        Dim l_code As String        Dim l_query As String        Dim l_rows As DataRowCollection        Try

            'RecSet = m_Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            l_query = QueryResource.GetQuery("Base_IFSZ_AddOn_SBO", "sel_doccode_from_rdoc_usrp_by_docname", pRname)
            l_rows = DataProvider.GetDataRecord(l_query)
            'RecSet.DoQuery(QueryResource.GetQuery("Base_IFSZ_AddOn_SBO", "sel_doccode_from_rdoc_usrp_by_docname", pRname))

            'If RecSet.RecordCount = 0 Then
            '    'ifsz-11001: Nem l�tez� felhaszn�l�i riport 
            '    Dim e As New NoRowsOwnException(m_ParentAddOn.LocRM.GetString("ifsz-11001") & " (" & pRname & ")")
            '    Throw e
            'End If

            If l_rows.Count = 0 Then
                'ifsz-11001: Nem l�tez� felhaszn�l�i riport 
                Dim e As New NoRowsOwnException(m_ParentAddOn.LocRM.GetString("ifsz-11001") & " (" & pRname & ")")                Throw e            End If


            'If RecSet.RecordCount > 1 Then
            '    'ifsz-11002: T�bb �rv�nyes felhaszn�l�i riport is l�tezik az adott n�vvel (ILYEN NEM FORDUL EL�!!!)
            '    Dim e As New TooManyRowsOwnException(m_ParentAddOn.LocRM.GetString("ifsz-11002") & " (" & pRname & ")")
            '    Throw e
            'End If

            If l_rows.Count > 1 Then
                'ifsz-11002: T�bb �rv�nyes felhaszn�l�i riport is l�tezik az adott n�vvel (ILYEN NEM FORDUL EL�!!!)
                Dim e As New TooManyRowsOwnException(m_ParentAddOn.LocRM.GetString("ifsz-11002") & " (" & pRname & ")")                Throw e            End If


            'l_code = RecSet.Fields.Item(0).Value
            l_code = l_rows.Item(0).Item(0).ToString

            l_query = QueryResource.GetQuery("Base_IFSZ_AddOn_SBO", "upd_rdoc_qstring_numcopy1_by_doccode", pQstring, l_code)
            'RecSet.DoQuery(QueryResource.GetQuery("Base_IFSZ_AddOn_SBO", "upd_rdoc_qstring_numcopy1_by_doccode", pQstring, l_code))
            'Dini valami�rt kikommentezte kor�bban. Lehet, csak t�ved�sb�l. De ha nincs update, az biztos nem j�, ez�rt visszateszem. Mivel fent m�r DataProvider van, itt is azt haszn�lom.
            'REM�LJ�K M�SHOL NEM OKOZ GONDOT
            Dim p_message As String
            Dim l_ret As Integer

            l_ret = DataProvider.ExecuteNonQuery(l_query, p_message)
            If l_ret < 0 Then
                Dim e As New TooManyRowsOwnException(p_message)                Throw e
            End If

        Finally            If (Not RecSet Is Nothing) Then                System.Runtime.InteropServices.Marshal.ReleaseComObject(RecSet)                RecSet = Nothing            End If        End Try    End Sub    Public Sub SetReportQueryStrCopyNum(ByVal pRname As String)        Dim RecSet As SAPbobsCOM.Recordset        Dim l_code, l_qstring As String        Try            RecSet = m_Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)            RecSet.DoQuery(QueryResource.GetQuery("Base_IFSZ_AddOn_SBO", "sel_doccode_qstring_from_rdoc_usrp_by_docname", pRname))            If RecSet.RecordCount = 0 Then                'ifsz-11001: Nem l�tez� felhaszn�l�i riport                 Dim e As New NoRowsOwnException(m_ParentAddOn.LocRM.GetString("ifsz-11001") & " (" & pRname & ")")                Throw e            End If            If RecSet.RecordCount > 1 Then                'ifsz-11002: T�bb �rv�nyes felhaszn�l�i riport is l�tezik az adott n�vvel (ILYEN NEM FORDUL EL�!!!)                Dim e As New TooManyRowsOwnException(m_ParentAddOn.LocRM.GetString("ifsz-11002") & " (" & pRname & ")")                Throw e            End If            l_code = RecSet.Fields.Item(0).Value            RecSet.DoQuery(QueryResource.GetQuery("Base_IFSZ_AddOn_SBO", "upd_rdoc_numcopy_plus1_by_doccode", l_code))        Finally            If (Not RecSet Is Nothing) Then                System.Runtime.InteropServices.Marshal.ReleaseComObject(RecSet)                RecSet = Nothing            End If        End Try    End SubEnd Class