﻿Imports System.ComponentModel

Public Class IFSZ_DNET_HTMLEditor
    Public Sub New(ByVal p_html As String, ByVal p_html_hossz As Integer, ByVal p_html_default As String)

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        m_html_code = p_html
        m_html_hossz = p_html_hossz
        Dim l_row As DataRow
        Dim l_tab As New DataTable()
        l_tab.Columns.Add("num", GetType(Integer))
        l_tab.Columns.Add("kod", GetType(String))
        l_tab.Columns.Add("nev", GetType(String))
        l_row = l_tab.NewRow()
        l_row("num") = 1
        l_row("kod") = "Arial"
        l_row("nev") = "Arial"
        l_tab.Rows.Add(l_row)
        l_row = l_tab.NewRow()
        l_row("num") = 2
        l_row("kod") = "Courier"
        l_row("nev") = "Courier new"
        l_tab.Rows.Add(l_row)
        l_row = l_tab.NewRow()
        l_row("num") = 3
        l_row("kod") = "Times"
        l_row("nev") = "Times New Roman"
        l_tab.Rows.Add(l_row)
        l_row = l_tab.NewRow()
        l_row("num") = 4
        l_row("kod") = "Tahoma"
        l_row("nev") = "Tahoma"
        l_tab.Rows.Add(l_row)
        l_tab.AcceptChanges()
        m_fontname_tab = l_tab
        FontNameToolStripComboBox.ComboBox.DataSource = New DataView(m_fontname_tab, "", "num", DataViewRowState.CurrentRows)
        FontNameToolStripComboBox.ComboBox.ValueMember = "kod"
        FontNameToolStripComboBox.ComboBox.DisplayMember = "nev"
        FontNameToolStripComboBox.ComboBox.SelectedIndex = 0
        FontNameToolStripComboBox.ComboBox.DropDownStyle = ComboBoxStyle.DropDownList

        Dim l_strip As ToolStripMenuItem
        For Each l_row In m_fontname_tab.Rows
            l_strip = New ToolStripMenuItem()
            l_strip.Name = l_row("kod").ToString() + "ToolStripMenuItem"
            l_strip.Text = l_row("nev").ToString()
            FontNameToolStripMenuItem.DropDownItems.Add(l_strip)
        Next

        l_tab = l_tab.Clone()
        l_row = l_tab.NewRow()
        l_row("num") = 1
        l_row("kod") = "1"
        l_row("nev") = "1"
        l_tab.Rows.Add(l_row)
        l_row = l_tab.NewRow()
        l_row("num") = 2
        l_row("kod") = "2"
        l_row("nev") = "2"
        l_tab.Rows.Add(l_row)
        l_row = l_tab.NewRow()
        l_row("num") = 3
        l_row("kod") = "3"
        l_row("nev") = "3"
        l_tab.Rows.Add(l_row)
        l_row = l_tab.NewRow()
        l_row("num") = 4
        l_row("kod") = "4"
        l_row("nev") = "4"
        l_tab.Rows.Add(l_row)
        l_row = l_tab.NewRow()
        l_row("num") = 5
        l_row("kod") = "5"
        l_row("nev") = "5"
        l_tab.Rows.Add(l_row)
        l_row = l_tab.NewRow()
        l_row("num") = 6
        l_row("kod") = "6"
        l_row("nev") = "6"
        l_tab.Rows.Add(l_row)
        l_row = l_tab.NewRow()
        l_row("num") = 7
        l_row("kod") = "7"
        l_row("nev") = "7"
        l_tab.Rows.Add(l_row)
        l_tab.AcceptChanges()
        m_fontsize_tab = l_tab
        FontSizeToolStripComboBox.ComboBox.DataSource = New DataView(m_fontsize_tab, "", "num", DataViewRowState.CurrentRows)
        FontSizeToolStripComboBox.ComboBox.ValueMember = "kod"
        FontSizeToolStripComboBox.ComboBox.DisplayMember = "nev"
        FontSizeToolStripComboBox.ComboBox.SelectedIndex = 0
        FontSizeToolStripComboBox.ComboBox.DropDownStyle = ComboBoxStyle.DropDownList

        For Each l_row In m_fontsize_tab.Rows
            l_strip = New ToolStripMenuItem()
            l_strip.Name = l_row("kod").ToString() + "ToolStripMenuItem"
            l_strip.Text = l_row("nev").ToString()
            FontSizeToolStripMenuItem.DropDownItems.Add(l_strip)
        Next



    End Sub

    Private resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(IFSZ_Form))
    Private m_fontname_tab As DataTable
    Private m_fontsize_tab As DataTable

    Public m_html_code As String = ""
    Public m_html_hossz As Integer = 0

    Public Structure stCommandBinding
        Public command As String
        Public param As String
        Public paramnum As Integer
        Public menuStrip As ToolStripMenuItem
        Public toolbarStrip As ToolStripItem

        Public Sub New(ByVal p_command As String, ByRef p_menuStrip As ToolStripMenuItem, ByRef p_toolbarStrip As ToolStripItem)
            command = p_command
            param = Nothing
            menuStrip = p_menuStrip
            toolbarStrip = p_toolbarStrip
            paramnum = 1
        End Sub

        Public Sub New(ByVal p_command As String, ByVal p_param As String, ByVal p_paramnum As Integer, ByRef p_menuStrip As ToolStripMenuItem, ByRef p_toolbarStrip As ToolStripItem)
            command = p_command
            param = p_param
            paramnum = p_paramnum
            menuStrip = p_menuStrip
            toolbarStrip = p_toolbarStrip
        End Sub

    End Structure

    Private m_commandbindings As New List(Of stCommandBinding)
    Private l_doc As mshtml.HTMLDocument
    Private m_fnev As String

    Private Sub IFSZ_DNET_HTMLEditor_Load(sender As Object, e As EventArgs) Handles Me.Load
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)

        m_fnev = System.IO.Path.GetTempFileName()
        Using sw As New System.IO.StreamWriter(System.IO.File.Open(m_fnev, System.IO.FileMode.OpenOrCreate), System.Text.Encoding.UTF8)
            sw.WriteLine("<!DOCTYPE HTML PUBLIC ""-/W3C/DTD HTML 3.2/EN""><html><body></body></html>")
        End Using

        AxWebBrowser1.Navigate(m_fnev)

        l_doc = AxWebBrowser1.Document
        l_doc.designMode = "On"

        AxWebBrowser1.InvokeEditMode()

        CommandBind()

        Dim HtmlCodeBetoltesThread As New Threading.Thread(AddressOf KesleltetettBetoltes)
        HtmlCodeBetoltesThread.ApartmentState = Threading.ApartmentState.STA
        HtmlCodeBetoltesThread.Start()

    End Sub

    Private Sub CommandBind()
        m_commandbindings.Add(New stCommandBinding("Cut", Me.CutToolStripMenuItem, Nothing))
        m_commandbindings.Add(New stCommandBinding("Copy", Me.CopyToolStripMenuItem, Nothing))
        m_commandbindings.Add(New stCommandBinding("Paste", Me.PasteToolStripMenuItem, Nothing))
        m_commandbindings.Add(New stCommandBinding("Undo", Me.UndoToolStripMenuItem, Me.UndoToolStripButton))
        m_commandbindings.Add(New stCommandBinding("Redo", Me.RedoToolStripMenuItem, Me.RedoToolStripButton))
        m_commandbindings.Add(New stCommandBinding("Bold", Me.BoldToolStripMenuItem, Me.BoldToolStripButton))
        m_commandbindings.Add(New stCommandBinding("Italic", Me.ItalicToolStripMenuItem, Me.ItalicToolStripButton))
        m_commandbindings.Add(New stCommandBinding("Underline", Me.UnderLineToolStripMenuItem, Me.UnderlineToolStripButton))

        m_commandbindings.Add(New stCommandBinding("Indent", Me.IndentToolStripMenuItem, Nothing))
        m_commandbindings.Add(New stCommandBinding("Outdent", Me.OutdentToolStripMenuItem, Nothing))

        m_commandbindings.Add(New stCommandBinding("JustifyLeft", Me.LeftToolStripMenuItem, Me.JustifyLeftToolStripButton))
        m_commandbindings.Add(New stCommandBinding("JustifyCenter", Me.CenterToolStripMenuItem, Me.JustifyCenterToolStripButton))
        m_commandbindings.Add(New stCommandBinding("JustifyRight", Me.RightToolStripMenuItem, Me.JustifyRightToolStripButton))
        m_commandbindings.Add(New stCommandBinding("JustifyFull", Me.JustifyToolStripMenuItem, Me.JustifyFillToolStripButton))

        m_commandbindings.Add(New stCommandBinding("InsertImage", Me.PictureToolStripMenuItem, Me.PictureToolStripButton))
        m_commandbindings.Add(New stCommandBinding("InsertUnorderedList", Me.UnorderedListToolStripMenuItem, Me.UnorderedListToolStripButton))
        m_commandbindings.Add(New stCommandBinding("InsertOrderedList", Me.OrderedListToolStripMenuItem, Me.OrderedListToolStripButton))

        m_commandbindings.Add(New stCommandBinding("ForeColor", "black", 1, Me.FCBlackToolStripMenuItem, Nothing))
        m_commandbindings.Add(New stCommandBinding("ForeColor", "silver", 1, Me.FCSilverToolStripMenuItem, Nothing))
        m_commandbindings.Add(New stCommandBinding("ForeColor", "gray", 1, Me.FCGrayToolStripMenuItem, Nothing))
        m_commandbindings.Add(New stCommandBinding("ForeColor", "white", 1, Me.FCWhiteToolStripMenuItem, Nothing))
        m_commandbindings.Add(New stCommandBinding("ForeColor", "maroon", 1, Me.FCMaroonToolStripMenuItem, Nothing))
        m_commandbindings.Add(New stCommandBinding("ForeColor", "red", 1, Me.FCRedToolStripMenuItem, Nothing))
        m_commandbindings.Add(New stCommandBinding("ForeColor", "purple", 1, Me.FCPurpleToolStripMenuItem, Nothing))
        m_commandbindings.Add(New stCommandBinding("ForeColor", "fuchsia", 1, Me.FCFuchsiaToolStripMenuItem, Nothing))
        m_commandbindings.Add(New stCommandBinding("ForeColor", "green", 1, Me.FCGreenToolStripMenuItem, Nothing))
        m_commandbindings.Add(New stCommandBinding("ForeColor", "lime", 1, Me.FCLimeToolStripMenuItem, Nothing))
        m_commandbindings.Add(New stCommandBinding("ForeColor", "olive", 1, Me.FCOliveToolStripMenuItem, Nothing))
        m_commandbindings.Add(New stCommandBinding("ForeColor", "yellow", 1, Me.FCYellowToolStripMenuItem, Nothing))
        m_commandbindings.Add(New stCommandBinding("ForeColor", "navy", 1, Me.FCNavyToolStripMenuItem, Nothing))
        m_commandbindings.Add(New stCommandBinding("ForeColor", "blue", 1, Me.FCBlueToolStripMenuItem, Nothing))
        m_commandbindings.Add(New stCommandBinding("ForeColor", "teal", 1, Me.FCTealToolStripMenuItem, Nothing))
        m_commandbindings.Add(New stCommandBinding("ForeColor", "aqua", 1, Me.FCAquaToolStripMenuItem, Nothing))

        m_commandbindings.Add(New stCommandBinding("BackColor", "black", 1, Me.BCBlackToolStripMenuItem, Nothing))
        m_commandbindings.Add(New stCommandBinding("BackColor", "silver", 1, Me.BCSilverToolStripMenuItem, Nothing))
        m_commandbindings.Add(New stCommandBinding("BackColor", "gray", 1, Me.BCGrayToolStripMenuItem, Nothing))
        m_commandbindings.Add(New stCommandBinding("BackColor", "white", 1, Me.BCWhiteToolStripMenuItem, Nothing))
        m_commandbindings.Add(New stCommandBinding("BackColor", "maroon", 1, Me.BCMaroonToolStripMenuItem, Nothing))
        m_commandbindings.Add(New stCommandBinding("BackColor", "red", 1, Me.BCRedToolStripMenuItem, Nothing))
        m_commandbindings.Add(New stCommandBinding("BackColor", "purple", 1, Me.BCPurpleToolStripMenuItem, Nothing))
        m_commandbindings.Add(New stCommandBinding("BackColor", "fuchsia", 1, Me.BCFuchsiaToolStripMenuItem, Nothing))
        m_commandbindings.Add(New stCommandBinding("BackColor", "green", 1, Me.BCGreenToolStripMenuItem, Nothing))
        m_commandbindings.Add(New stCommandBinding("BackColor", "lime", 1, Me.BCLimeToolStripMenuItem, Nothing))
        m_commandbindings.Add(New stCommandBinding("BackColor", "olive", 1, Me.BCOliveToolStripMenuItem, Nothing))
        m_commandbindings.Add(New stCommandBinding("BackColor", "yellow", 1, Me.BCYellowToolStripMenuItem, Nothing))
        m_commandbindings.Add(New stCommandBinding("BackColor", "navy", 1, Me.BCNavyToolStripMenuItem, Nothing))
        m_commandbindings.Add(New stCommandBinding("BackColor", "blue", 1, Me.BCBlueToolStripMenuItem, Nothing))
        m_commandbindings.Add(New stCommandBinding("BackColor", "teal", 1, Me.BCTealToolStripMenuItem, Nothing))
        m_commandbindings.Add(New stCommandBinding("BackColor", "aqua", 1, Me.BCAquaToolStripMenuItem, Nothing))

        For Each l_row As DataRow In m_fontname_tab.Rows
            m_commandbindings.Add(New stCommandBinding("FontName", l_row("kod"), l_row("num"), GetToolStripMenuItemByName(l_row("kod").ToString() + "ToolStripMenuItem"), Me.FontNameToolStripComboBox))
        Next
        For Each l_row As DataRow In m_fontname_tab.Rows
            m_commandbindings.Add(New stCommandBinding("FontSize", l_row("kod"), l_row("num"), GetToolStripMenuItemByName(l_row("kod").ToString() + "ToolStripMenuItem"), Me.FontSizeToolStripComboBox))
        Next

        For Each l_temp As stCommandBinding In m_commandbindings
            If l_temp.menuStrip IsNot Nothing Then
                AddHandler l_temp.menuStrip.Click, AddressOf ToolStripMenuItem_Click
            End If
            If l_temp.toolbarStrip IsNot Nothing Then
                If l_temp.toolbarStrip.GetType() Is GetType(ToolStripButton) Then
                    AddHandler l_temp.toolbarStrip.Click, AddressOf ToolStripButton_Click
                End If
                If l_temp.toolbarStrip.GetType() Is GetType(ToolStripComboBox) AndAlso l_temp.paramnum = 1 Then
                    AddHandler CType(l_temp.toolbarStrip, ToolStripComboBox).SelectedIndexChanged, AddressOf ToolStripComboBox_SelectedIndexChanged
                End If
            End If
        Next
    End Sub

    Private Sub CommandBeallit()
        Dim l_enabled As Boolean
        For Each l_temp As stCommandBinding In m_commandbindings
            l_enabled = l_doc.queryCommandEnabled(l_temp.command)
            If l_temp.menuStrip IsNot Nothing Then
                l_temp.menuStrip.Enabled = l_enabled
            End If
            If l_temp.toolbarStrip IsNot Nothing Then
                l_temp.toolbarStrip.Enabled = l_enabled
                If l_temp.toolbarStrip.GetType() Is GetType(ToolStripComboBox) Then
                    'Dim l_text As String = l_doc.queryCommandText(l_temp.command)
                    'If Not String.IsNullOrEmpty(l_text) Then
                    '    CType(l_temp.toolbarStrip, ToolStripComboBox).ComboBox.SelectedValue = l_text
                    'End If
                End If
            End If
        Next
    End Sub

    Private Sub AxWebBrowser1_CommandStateChange(sender As Object, e As AxSHDocVw.DWebBrowserEvents2_CommandStateChangeEvent) Handles AxWebBrowser1.CommandStateChange
        CommandBeallit()
    End Sub

    Public Sub ToolStripMenuItem_Click(sender As Object, e As EventArgs)
        If sender.GetType() Is GetType(ToolStripMenuItem) Then
            For Each l_temp As stCommandBinding In m_commandbindings
                If l_temp.menuStrip IsNot Nothing AndAlso l_temp.menuStrip.Name = CType(sender, ToolStripMenuItem).Name Then
                    If l_temp.command = "InsertImage" Then
                        l_doc.execCommand(l_temp.command, True)
                    Else
                        If String.IsNullOrEmpty(l_temp.param) Then
                            l_doc.execCommand(l_temp.command)
                        Else
                            l_doc.execCommand(l_temp.command, False, l_temp.param)
                        End If
                    End If
                End If
            Next
        End If
    End Sub

    Private Sub ToolStripButton_Click(sender As Object, e As EventArgs)
        If sender.GetType() Is GetType(ToolStripButton) Then
            For Each l_temp As stCommandBinding In m_commandbindings
                If l_temp.toolbarStrip IsNot Nothing AndAlso l_temp.toolbarStrip.Name = CType(sender, ToolStripButton).Name Then
                    If l_temp.command = "InsertImage" Then
                        l_doc.execCommand(l_temp.command, True)
                    Else
                        If String.IsNullOrEmpty(l_temp.param) Then
                            l_doc.execCommand(l_temp.command)
                        Else
                            l_doc.execCommand(l_temp.command, False, l_temp.param)
                        End If
                    End If
                End If
            Next
        End If
    End Sub

    Private Sub ToolStripComboBox_SelectedIndexChanged(sender As Object, e As EventArgs)
        If sender.GetType() Is GetType(ToolStripComboBox) Then
            For Each l_temp As stCommandBinding In m_commandbindings
                If l_temp.toolbarStrip IsNot Nothing AndAlso l_temp.toolbarStrip.Name = CType(sender, ToolStripComboBox).Name Then
                    If CType(sender, ToolStripComboBox).ComboBox.SelectedIndex > -1 Then
                        AxWebBrowser1.Focus()
                        l_doc.execCommand(l_temp.command, False, CType(sender, ToolStripComboBox).ComboBox.SelectedValue)
                        l_doc.body.focus
                    End If
                End If
            Next
        End If
    End Sub

    Private Function GetToolStripMenuItemByName(ByVal p_name As String, Optional ByVal p_items As ToolStripItemCollection = Nothing) As ToolStripMenuItem
        If p_items Is Nothing Then
            p_items = Me.MainMenuStrip.Items
        End If
        For Each l_item As ToolStripItem In p_items
            If l_item.GetType() Is GetType(ToolStripMenuItem) Then
                If l_item.Name = p_name Then
                    Return l_item
                End If
                If CType(l_item, ToolStripMenuItem).DropDownItems IsNot Nothing Then
                    Dim l_ret As ToolStripMenuItem = GetToolStripMenuItemByName(p_name, CType(l_item, ToolStripMenuItem).DropDownItems)
                    If l_ret IsNot Nothing Then
                        Return l_ret
                    End If
                End If
            End If
        Next
        Return Nothing
    End Function

    Private Sub OKToolStripButton_Click(sender As Object, e As EventArgs) Handles OKToolStripButton.Click
        Befejez()
    End Sub

    Private Sub Befejez()
        If l_doc Is Nothing OrElse l_doc.body Is Nothing Then
            m_html_code = ""
        Else
            If l_doc.body.innerHTML.Length > m_html_hossz Then
                MsgBox("Túl nagy lett a html kód, nem fér bele a mezőbe. Kérem, rövidítse! (" + l_doc.body.innerHTML.Length.ToString() + " - " + m_html_hossz.ToString() + ")")
                Exit Sub
            End If
            m_html_code = l_doc.body.innerHTML
        End If
        Me.DialogResult = DialogResult.OK
    End Sub

    Private Sub OKToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OKToolStripMenuItem.Click
        Befejez()
    End Sub

    Private Sub CancelToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CancelToolStripMenuItem.Click
        Me.DialogResult = DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub ViewSourceToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ViewSourceToolStripMenuItem.Click
        'TODO
    End Sub

    Private Sub IFSZ_DNET_HTMLEditor_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        Dim TorlesThread As New Threading.Thread(AddressOf KesletetettTorles)
        TorlesThread.ApartmentState = Threading.ApartmentState.STA
        TorlesThread.Start()
    End Sub

    Private Sub KesletetettTorles()
        Try            Dim l_fajl As String = Me.m_fnev
            System.Threading.Thread.Sleep(30000)
            System.IO.File.Delete(l_fajl)
        Catch        End Try    End Sub

    Private Sub KesleltetettBetoltes()
        Try            System.Threading.Thread.Sleep(500)
            l_doc.body.innerHTML = m_html_code
        Catch ex As Exception            MsgBox(ex.Message)        End Try    End Sub
End Class