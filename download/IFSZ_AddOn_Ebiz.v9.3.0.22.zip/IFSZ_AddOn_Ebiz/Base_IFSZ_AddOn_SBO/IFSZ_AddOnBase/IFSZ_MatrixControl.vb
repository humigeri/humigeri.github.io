Imports SboAddOnBase

Public MustInherit Class IFSZ_MatrixControl
    Inherits SboForm

    Public Structure MatrixTomb
        Public nev As String
        Public kod As String
        Public sor As Integer
        Public torles_e As Boolean
        Public volt_e_torles As Boolean
        Public Sub New(ByVal nev As String, ByVal kod As String, ByVal sor As Integer, ByVal torles_e As Boolean, Optional ByVal volt_e_torles As Boolean = False)
            Me.nev = nev
            Me.kod = kod
            Me.sor = sor
            Me.torles_e = torles_e
            Me.volt_e_torles = volt_e_torles
        End Sub
    End Structure

    Private Structure Rendez
        Public oszlop As String
        Public irany As String
        Private Sub New(ByVal l_oszlop As String, ByVal l_irany As String)
            Me.oszlop = l_oszlop
            Me.irany = l_irany
        End Sub
    End Structure

    Private m_esemenyek As String = ""

#Region "Variables"
    Private l_sor_tomb(0) As MatrixTomb

    Private l_kivalasztott_sor As Integer
    Private matrix_nev As String
    Private l_matrix As String
    Private DBTable_nev As String
    Private l_utolso_sor As String
    Private l_utolso_oszlop As String
    Private l_kivalasztott_kod As String
    Private l_utolso_matrix_nev As String
    Private l_torlse_e As Boolean = False
    Private item_kod As String
    Public p_uj_sor_e As Boolean = False
    Private p_ModalFormUID As String = Nothing
    Private p_modosithat_e As Boolean = True
    Private p_conditions As SAPbouiCOM.Conditions
    Private p_where_sort As String
    Public p_EzresEvt As String
    Public p_TizedesEvt As String
#End Region

#Region "Constructor"
    Public Sub New( _
        ByRef ParentAddon As SBOAddOn, _
        ByVal SboFormType As enSboFormTypes, _
        ByVal FormType As enSAPFormTypes, _
        Optional ByVal FunctionCode As String = "", _
        Optional ByVal FormUID As String = "", _
        Optional ByRef ITable As IIFSZ_Table = Nothing _
    )
        MyBase.New(ParentAddon, SboFormType, FormType, FunctionCode) ', FormUID
        Me.l_kivalasztott_sor = 0
        Me.m_SboForm.Freeze(True)
        m_SboForm.DataSources.UserDataSources.Add("DBL", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 30)
        m_SboForm.DataSources.UserDataSources.Add("DTE", SAPbouiCOM.BoDataType.dt_DATE, 30)
        Me.m_SboForm.Freeze(False)

        If (Not ITable Is Nothing) Then
            ITable.ParentAddon = ParentAddon
        End If

        Dim oRecordSet As SAPbobsCOM.Recordset
        Dim p_select As String

        Try
            oRecordSet = Me.SBO_Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            p_select = QueryResource.GetQuery("Base_IFSZ_AddOn_SBO", "sel_decsep_thoussep_from_oadm")
            oRecordSet.DoQuery(p_select)

            oRecordSet.MoveFirst()
            Me.p_TizedesEvt = oRecordSet.Fields.Item(0).Value
            Me.p_EzresEvt = oRecordSet.Fields.Item(1).Value
        Finally
            If (Not oRecordSet Is Nothing) Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oRecordSet)
                oRecordSet = Nothing
            End If
        End Try


    End Sub
#End Region

#Region "MustOverrides"
    Public MustOverride Sub pre_event(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
    Public MustOverride Sub post_event(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
    Public MustOverride Sub item_validate(ByVal p_ItemChanged As Boolean, ByVal p_matrix As String, ByVal p_oszlop As String, ByVal p_sor As Integer, ByVal p_ertek As String, ByVal p_lookup_ertek As String, ByRef BubbleEvent As Boolean)
#End Region

#Region "Properties"
    Public Property Item_Matrix_nev() As String
        Get
            Return Me.matrix_nev
        End Get
        Set(ByVal Value As String)
            Me.matrix_nev = Value
        End Set
    End Property

    Public Property Tabla_nev()
        Get
            Return Me.DBTable_nev
        End Get
        Set(ByVal Value)
            Me.DBTable_nev = Value
        End Set
    End Property

    Public ReadOnly Property KivalasztottSor() As Integer
        Get
            Return Me.l_kivalasztott_sor
        End Get
    End Property

    Public ReadOnly Property KivalasztottKod() As String
        Get
            Return Me.l_kivalasztott_kod
        End Get
    End Property

    Public ReadOnly Property KivalasztottMatrix() As String
        Get
            Return Me.l_matrix
        End Get
    End Property

    Public Property ModalFormUID() As String
        Get
            Return Me.p_ModalFormUID
        End Get
        Set(ByVal Value As String)
            Me.p_ModalFormUID = Value
        End Set
    End Property

    Public Property Modosithat_E() As Boolean
        Get
            Return Me.p_modosithat_e
        End Get
        Set(ByVal Value As Boolean)
            Me.p_modosithat_e = Value
        End Set
    End Property

    Public Property Conditions() As SAPbouiCOM.Conditions
        Get
            Return Me.p_conditions
        End Get
        Set(ByVal Value As SAPbouiCOM.Conditions)
            Me.p_conditions = Value
        End Set
    End Property

    Public Property WhereSort() As String
        Get
            Return Me.p_where_sort
        End Get
        Set(ByVal Value As String)
            Me.p_where_sort = Value
        End Set
    End Property

    Public Property Utolso_Matrix_nev() As String
        Get
            Return Me.l_utolso_matrix_nev
        End Get
        Set(ByVal Value As String)
            Me.l_utolso_matrix_nev = Value
        End Set
    End Property


#End Region

#Region "Overridables"

    Public Overridable Sub AfterUjSor(ByVal l_sor_index As Integer)

    End Sub

    Public Overridable Sub pre_dml(ByVal p_matrix_nev As String, ByVal p_index As Integer, ByVal p_kod As String, ByVal p_torles_e As Boolean, ByRef BubbleEvent As Boolean)

    End Sub

    Public Overridable Sub key_delete(ByVal p_matrix_nev As String, ByVal p_index As Integer, ByVal p_kod As String, ByRef BubbleEvent As Boolean)

    End Sub

    Public Overridable Sub link_pressed(ByVal ItemUID As String, ByVal ColUID As String, ByVal Row As Integer)

    End Sub

    Public Overridable Sub post_query(ByVal l_sor_index As Integer)

    End Sub

    Public Overridable Sub nyomtat()

    End Sub

    Public Overridable Sub uj_sor_letrehozas(Optional ByVal l_sor_index As Integer = -1)
        Dim oMatrix As SAPbouiCOM.Matrix
        Dim oDBsource As SAPbouiCOM.DBDataSource
        Dim oConditions = New SAPbouiCOM.Conditions
        Dim ocondition = oConditions.Add
        Dim l_matrix_nev As String
        Dim l_tabla_nev As String
        Dim l_kovetkezo_sor As Integer
        Dim i As Integer

        l_matrix_nev = Me.l_matrix
        If l_matrix_nev = "" Then
            For i = 0 To Me.m_SboForm.Items.Count - 1
                If Me.m_SboForm.Items.Item(i).Type = SAPbouiCOM.BoFormItemTypes.it_MATRIX Then
                    l_matrix_nev = Me.m_SboForm.Items.Item(i).UniqueID
                End If
            Next
        End If
        Me.l_utolso_matrix_nev = l_matrix_nev
        Me.l_matrix = l_matrix_nev

        l_tabla_nev = Me.get_tabla(l_matrix_nev)

        oMatrix = Me.m_SboForm.Items.Item(l_matrix_nev).Specific

        oDBsource = Me.m_SboForm.DataSources.DBDataSources.Item(l_tabla_nev)
        ocondition.Alias = "Code"
        ocondition.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL
        ocondition.CondVal = "XXXX"

        oDBsource.Query(oConditions)
        oDBsource.Offset = 0

        If l_sor_index = -1 Then
            l_kovetkezo_sor = Me.l_kivalasztott_sor + 1
            If Me.l_kivalasztott_sor = Nothing Then
                Me.l_kivalasztott_sor = 1
                l_kovetkezo_sor = 1
            End If
            oMatrix.AddRow(1, Me.l_kivalasztott_sor)
        Else
            l_kovetkezo_sor = l_sor_index
            oMatrix.AddRow(1, l_kovetkezo_sor)
        End If

        For Each oColumn As SAPbouiCOM.Column In oMatrix.Columns
            If oColumn.Visible And oColumn.Editable Then
                oColumn.Cells.Item(l_kovetkezo_sor).Click()  'HG !!!!
                Exit For
            End If
        Next
        Me.p_uj_sor_e = True
        If Me.l_kivalasztott_sor = Nothing Then
            Me.l_kivalasztott_sor = l_kovetkezo_sor
        End If
        If l_sor_index = -1 Then
            AfterUjSor(Me.l_kivalasztott_sor)
        Else
            AfterUjSor(l_sor_index)
        End If

    End Sub

    'Public Overridable Sub esemeny_kezelo(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)

    Public Overridable Sub fejlec_aktival(ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Static Dim p_rendez As Rendez
        Dim oTitle As SAPbouiCOM.ColumnTitle
        Dim oMatrix As SAPbouiCOM.Matrix
        Dim l_prompt As String

        oMatrix = Me.m_SboForm.Items.Item(pVal.ItemUID).Specific
        If p_rendez.oszlop = Nothing Then
            p_rendez.oszlop = pVal.ColUID
            p_rendez.irany = "Asc"
            oTitle = oMatrix.Columns.Item(pVal.ColUID).TitleObject
            l_prompt = oTitle.Caption
            oTitle.Caption = l_prompt & " ^"
        Else
            oTitle = oMatrix.Columns.Item(p_rendez.oszlop).TitleObject
            l_prompt = oTitle.Caption
            l_prompt = Replace(l_prompt, " ", "")
            l_prompt = Replace(l_prompt, "^", "")
            l_prompt = Replace(l_prompt, "�", "")
            oTitle.Caption = l_prompt

            If p_rendez.oszlop = pVal.ColUID Then
                p_rendez.oszlop = pVal.ColUID
                If p_rendez.irany = "Asc" Then
                    oTitle = oMatrix.Columns.Item(pVal.ColUID).TitleObject
                    l_prompt = oTitle.Caption
                    oTitle.Caption = l_prompt & " �"
                    p_rendez.irany = "Desc"
                Else
                    oTitle = oMatrix.Columns.Item(pVal.ColUID).TitleObject
                    l_prompt = oTitle.Caption
                    oTitle.Caption = l_prompt & " ^"
                    p_rendez.irany = "Asc"
                End If
            Else
                p_rendez.oszlop = pVal.ColUID
                oTitle = oMatrix.Columns.Item(pVal.ColUID).TitleObject
                l_prompt = oTitle.Caption
                oTitle.Caption = l_prompt & " ^"
                p_rendez.irany = "Asc"
            End If

        End If

        Me.matrix_sort(pVal.ItemUID, pVal.ColUID, p_rendez.irany)
    End Sub

    Public Overridable Sub matrix_query(ByRef oDBDataSource As SAPbouiCOM.DBDataSource, ByRef p_select As String)
        oDBDataSource.Query(Me.p_conditions)
        p_select = ""
    End Sub

    Public Overridable Sub Leptet(ByVal l_irany As Integer)

    End Sub

#End Region

#Region "Public"
    Public Overridable Sub set_item_value(ByVal p_item As String, ByVal p_oszlop As String, ByVal p_sor As Integer, ByVal p_ertek As String, Optional ByVal p_combo_index As Integer = 0, Optional ByVal p_raiseexc As Boolean = True)
        Dim oMatrix As SAPbouiCOM.Matrix
        Dim oColumn As SAPbouiCOM.Column
        Dim oEditText As SAPbouiCOM.EditText
        Dim oComboBox As SAPbouiCOM.ComboBox
        Dim oCheckBox As SAPbouiCOM.CheckBox
        Dim oItem As SAPbouiCOM.Item

        Try
            If m_SboForm.Items.Item(p_item).Type = SAPbouiCOM.BoFormItemTypes.it_MATRIX Then

                oMatrix = m_SboForm.Items.Item(p_item).Specific
                oColumn = oMatrix.Columns.Item(p_oszlop)

                Select Case oColumn.Type
                    Case SAPbouiCOM.BoFormItemTypes.it_EDIT
                        oEditText = oColumn.Cells.Item(p_sor).Specific
                        'oColumn.Editable = True
                        If p_ertek = "" Then
                            oEditText.String = Nothing
                        Else
                            oEditText.String = p_ertek
                        End If
                        'oColumn.Editable = False
                    Case SAPbouiCOM.BoFormItemTypes.it_COMBO_BOX
                        oComboBox = oColumn.Cells.Item(p_sor).Specific
                        oComboBox.Select(p_ertek, p_combo_index)
                    Case SAPbouiCOM.BoFormItemTypes.it_CHECK_BOX
                        oCheckBox = oColumn.Cells.Item(p_sor).Specific
                        If oCheckBox.Checked() <> p_ertek Then
                            'oCheckBox.Checked = True
                            oMatrix.Columns.Item(p_oszlop).Cells.Item(p_sor).Click()
                        End If
                    Case SAPbouiCOM.BoFormItemTypes.it_LINKED_BUTTON
                        oEditText = oColumn.Cells.Item(p_sor).Specific
                        'oLink = oColumn.Cells.Item(p_sor).Specific
                        'oColumn.Editable = True
                        If p_ertek = "" Then
                            'oLink.String = Nothing
                            oEditText.String = Nothing
                        Else
                            'oLink.String = p_ertek
                            oEditText.String = p_ertek
                        End If

                End Select

            ElseIf m_SboForm.Items.Item(p_item).Type = SAPbouiCOM.BoFormItemTypes.it_EDIT Then
                oEditText = m_SboForm.Items.Item(p_item).Specific
                oItem = m_SboForm.Items.Item(p_item)
                If p_ertek = "" Then
                    oEditText.String = Nothing
                Else
                    oEditText.String = p_ertek
                End If
            ElseIf m_SboForm.Items.Item(p_item).Type = SAPbouiCOM.BoFormItemTypes.it_COMBO_BOX Then
                oComboBox = m_SboForm.Items.Item(p_item).Specific
                oComboBox.Select(p_ertek, p_combo_index)
            ElseIf m_SboForm.Items.Item(p_item).Type = SAPbouiCOM.BoFormItemTypes.it_CHECK_BOX Then
                oCheckBox = m_SboForm.Items.Item(p_item).Specific
                If oCheckBox.Checked() <> p_ertek Then
                    m_SboForm.Items.Item(p_item).Click()
                End If
            End If
        Catch ex As Exception
            If p_raiseexc Then
                m_ParentAddon.SboApplication.MessageBox("set:" + p_item + ":" + p_oszlop + ":" + p_sor.ToString() + " " + p_ertek + " " + ex.ToString)
            End If
            m_ParentAddon.BlockEvents = False
        End Try

    End Sub

    Public Function get_item_value(ByVal p_item As String, ByVal p_oszlop As String, ByVal p_sor As Integer, Optional ByVal lookup_e As Boolean = False)
        Dim oMatrix As SAPbouiCOM.Matrix
        Dim oColumn As SAPbouiCOM.Column
        Dim oEditText As SAPbouiCOM.EditText
        Dim oComboBox As SAPbouiCOM.ComboBox
        Dim oCheckBox As SAPbouiCOM.CheckBox
        Dim l_ertek As String
        Try
            If m_SboForm.Items.Item(p_item).Type = SAPbouiCOM.BoFormItemTypes.it_MATRIX Then

                oMatrix = m_SboForm.Items.Item(p_item).Specific
                oColumn = oMatrix.Columns.Item(p_oszlop)

                Select Case oColumn.Type
                    Case SAPbouiCOM.BoFormItemTypes.it_EDIT
                        oEditText = oColumn.Cells.Item(p_sor).Specific
                        l_ertek = oEditText.String
                        Return l_ertek
                    Case SAPbouiCOM.BoFormItemTypes.it_LINKED_BUTTON
                        oEditText = oColumn.Cells.Item(p_sor).Specific
                        l_ertek = oEditText.String
                        Return l_ertek
                    Case SAPbouiCOM.BoFormItemTypes.it_COMBO_BOX
                        Try
                            oComboBox = oColumn.Cells.Item(p_sor).Specific
                            If lookup_e = True Then
                                Return oComboBox.Selected.Description
                            Else
                                Return oComboBox.Selected.Value
                            End If
                        Catch ex As Exception
                            Return ""
                        End Try

                    Case SAPbouiCOM.BoFormItemTypes.it_CHECK_BOX
                        oCheckBox = oColumn.Cells.Item(p_sor).Specific
                        If oCheckBox.Checked Then
                            Return oCheckBox.ValOn
                        Else
                            Return oCheckBox.ValOff
                        End If

                End Select

            ElseIf m_SboForm.Items.Item(p_item).Type = SAPbouiCOM.BoFormItemTypes.it_EDIT Then
                oEditText = m_SboForm.Items.Item(p_item).Specific
                l_ertek = oEditText.String
                Return l_ertek
            ElseIf m_SboForm.Items.Item(p_item).Type = SAPbouiCOM.BoFormItemTypes.it_COMBO_BOX Then
                Try
                    oComboBox = m_SboForm.Items.Item(p_item).Specific
                    If (Not oComboBox.Selected Is Nothing) Then
                        If lookup_e = True Then
                            Return oComboBox.Selected.Description
                        Else
                            Return oComboBox.Selected.Value
                        End If
                    Else
                        Return Nothing
                    End If
                Catch ex As Exception
                    Return Nothing
                End Try
            ElseIf m_SboForm.Items.Item(p_item).Type = SAPbouiCOM.BoFormItemTypes.it_CHECK_BOX Then
                oCheckBox = m_SboForm.Items.Item(p_item).Specific
                If oCheckBox.Checked Then
                    Return oCheckBox.ValOn
                Else
                    Return oCheckBox.ValOff
                End If
            End If
            Return Nothing
        Catch ex As Exception
            m_ParentAddon.SboApplication.MessageBox("get:" + p_item + ":" + p_oszlop + ":" + p_sor.ToString() + " " + ex.ToString)
            m_ParentAddon.BlockEvents = False
            Return Nothing
        End Try

    End Function

    Public Sub load_combo(ByVal p_item As String, ByVal p_oszlop As String, ByVal p_select As String, Optional ByVal p_dummy_ertek As String = Nothing, Optional ByVal p_dummy_descr As String = Nothing)
        Dim oMatrix As SAPbouiCOM.Matrix
        Dim oColumn As SAPbouiCOM.Column
        Dim oComboBox As SAPbouiCOM.ComboBox
        Dim oRecordSet As SAPbobsCOM.Recordset
        Dim l_count As Integer
        Dim l_kod As String
        Dim l_lookup_ertek As String

        If m_sboform.Items.Item(p_item).Type = SAPbouiCOM.BoFormItemTypes.it_MATRIX Then
            oMatrix = m_sboform.Items.Item(p_item).Specific
            oColumn = oMatrix.Columns.Item(p_oszlop)
            If oColumn.Type <> SAPbouiCOM.BoFormItemTypes.it_COMBO_BOX Then
                Exit Sub
            Else
                oComboBox = oColumn.Cells.Item(1).Specific
            End If
        ElseIf m_sboform.Items.Item(p_item).Type = SAPbouiCOM.BoFormItemTypes.it_COMBO_BOX Then
            oComboBox = m_sboform.Items.Item(p_item).Specific
        Else
            Exit Sub
        End If

        Try
            oRecordSet = Me.SBO_Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

            oRecordSet.DoQuery(p_select)
            If oRecordSet.RecordCount <= 0 Then
                Exit Sub
            End If
            If (Not p_dummy_ertek Is Nothing) Then
                oComboBox.ValidValues.Add(p_dummy_ertek, p_dummy_descr)
            End If

            If oRecordSet.RecordCount > 0 Then
                oRecordSet.MoveFirst()
                For l_count = 1 To oRecordSet.RecordCount
                    l_kod = oRecordSet.Fields.Item(0).Value
                    l_lookup_ertek = oRecordSet.Fields.Item(1).Value
                    Try
                        oComboBox.ValidValues.Add(l_kod, l_lookup_ertek)
                    Catch ex As Exception

                    End Try
                    oRecordSet.MoveNext()
                Next
            End If
        Catch excE As Exception
            m_ParentAddon.SboApplication.MessageBox(excE.ToString)
            m_ParentAddon.BlockEvents = False
        Finally
            If (Not oRecordSet Is Nothing) Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oRecordSet)
                oRecordSet = Nothing
            End If
        End Try

    End Sub

    Public Function get_FormatedString(ByVal p_string As String) As String
        If p_string Is Nothing Or p_string = "" Then
            Return p_string
        End If
        Return Replace(p_string, Me.p_EzresEvt, "")
    End Function

    Public Sub erteklista(ByVal p_oszlop_tipus() As OszlopTipus, _
                          ByVal p_mezo As String, _
                          ByVal p_mezo_lookup_ertek As String, _
                          ByVal p_tabla As String, _
                          ByRef oConditions As SAPbouiCOM.Conditions, _
                          ByVal P_Cimke As String, _
                          Optional ByVal P_Select As String = "", _
                          Optional ByVal P_SzuresiErtek As String = "", _
                          Optional ByRef l_validal As Boolean = True)
        Dim oForm As SboForm
        Try
            oForm = New IFSZ_LOV(Me.m_ParentAddon, _
                                 Me, _
                                 p_oszlop_tipus, _
                                 p_mezo, _
                                 p_mezo_lookup_ertek, _
                                 Me.l_kivalasztott_sor, _
                                 p_tabla, _
                                 Me.l_utolso_matrix_nev, _
                                 oConditions, _
                                 P_Cimke, _
                                 P_Select, _
                                 P_SzuresiErtek, _
                                 l_validal)
            Me.m_ParentAddon.SBOForms.Add(oForm, oForm.UniqueID)
            Me.m_LovAlattValidateEnged = False 'Ennek seg�ts�g�vel a validate esem�nyeket is blokkolni fogja a matrixcontrol, hacsak az m_LovVisszairas-t true-ra nem �ll�tjuk
            Me.p_ModalFormUID = oForm.UniqueID
        Catch ex As Exception
            m_ParentAddon.SboApplication.MessageBox(ex.ToString)
            m_ParentAddon.BlockEvents = False
        End Try
    End Sub

    Public Sub erteklista_ctrl(ByVal p_oszlop_tipus() As OszlopTipus, _
                          ByVal p_mezo As String, _
                          ByVal p_mezo_lookup_ertek As String, _
                          ByVal p_tabla As String, _
                          ByRef oConditions As SAPbouiCOM.Conditions, _
                          ByVal P_Cimke As String, _
                          Optional ByVal P_Select As String = "", _
                          Optional ByVal P_SzuresiErtek As String = "", _
                          Optional ByRef l_validal As Boolean = True)
        Dim oForm As SboForm
        oForm = New IFSZ_LOV(Me.m_ParentAddon, _
                             Me, _
                             p_oszlop_tipus, _
                             p_mezo, _
                             p_mezo_lookup_ertek, _
                             0, _
                             p_tabla, _
                             "", _
                             oConditions, _
                             P_Cimke, _
                             P_Select, _
                             P_SzuresiErtek, _
                             l_validal)
        Me.m_ParentAddon.SBOForms.Add(oForm, oForm.UniqueID)
        Me.m_LovAlattValidateEnged = False 'Ennek seg�ts�g�vel a validate esem�nyeket is blokkolni fogja a matrixcontrol, hacsak az m_LovVisszairas-t true-ra nem �ll�tjuk
        Me.p_ModalFormUID = oForm.UniqueID
    End Sub

    Public Sub erteklista_view(ByVal p_oszlop_tipus() As OszlopTipus, _
                          ByVal p_mezo As String, _
                          ByVal p_mezo_lookup_ertek As String, _
                          ByVal P_Cimke As String, _
                          ByVal P_select As String, _
                          Optional ByVal P_order_by As String = "", _
                          Optional ByVal P_SzuresiErtek As String = "", _
                          Optional ByRef l_validal As Boolean = True)
        Dim oForm As SboForm
        Try
            oForm = New IFSZ_GRIDLOV_VIEW(Me.m_ParentAddon, _
                                 Me, _
                                 p_oszlop_tipus, _
                                 p_mezo, _
                                 p_mezo_lookup_ertek, _
                                 Me.l_kivalasztott_sor, _
                                 "", _
                                 Me.l_utolso_matrix_nev, _
                                 P_Cimke, _
                                 P_select, _
                                 P_order_by, _
                                 P_SzuresiErtek, _
                                 l_validal)
            Me.m_ParentAddon.SBOForms.Add(oForm, oForm.UniqueID)
            Me.m_LovAlattValidateEnged = False 'Ennek seg�ts�g�vel a validate esem�nyeket is blokkolni fogja a matrixcontrol, hacsak az m_LovVisszairas-t true-ra nem �ll�tjuk
            Me.p_ModalFormUID = oForm.UniqueID
        Catch ex As Exception
            m_ParentAddon.SboApplication.MessageBox(ex.ToString)
            m_ParentAddon.BlockEvents = False
        End Try
    End Sub


    Public Sub erteklista_view_ctrl(ByVal p_oszlop_tipus() As OszlopTipus, _
                          ByVal p_mezo As String, _
                          ByVal p_mezo_lookup_ertek As String, _
                          ByVal P_Cimke As String, _
                          ByVal P_select As String, _
                          Optional ByVal P_order_by As String = "", _
                          Optional ByVal P_SzuresiErtek As String = "", _
                          Optional ByRef l_validal As Boolean = True)
        Dim oForm As SboForm
        Try
            oForm = New IFSZ_LOV_VIEW(Me.m_ParentAddon, _
                                 Me, _
                                 p_oszlop_tipus, _
                                 p_mezo, _
                                 p_mezo_lookup_ertek, _
                                 0, _
                                 "", _
                                 "", _
                                 P_Cimke, _
                                 P_select, _
                                 P_order_by, _
                                 P_SzuresiErtek, _
                                 l_validal)

            Me.m_ParentAddon.SBOForms.Add(oForm, oForm.UniqueID)
            Me.m_LovAlattValidateEnged = False 'Ennek seg�ts�g�vel a validate esem�nyeket is blokkolni fogja a matrixcontrol, hacsak az m_LovVisszairas-t true-ra nem �ll�tjuk
            Me.p_ModalFormUID = oForm.UniqueID
        Catch ex As Exception
            m_ParentAddon.SboApplication.MessageBox(ex.ToString)
            m_ParentAddon.BlockEvents = False
        End Try
    End Sub

    Public Sub kereses()
        Dim oDBDataSource As SAPbouiCOM.DBDataSource
        Dim oConditions As New SAPbouiCOM.Conditions
        Dim oCondition = oConditions.Add
        Dim oMatrix As SAPbouiCOM.Matrix
        Dim oColumn As SAPbouiCOM.Column
        Dim l_szamlal As Integer = 0

        Dim i As Integer
        Dim l_matrix_nev, l_tabla_nev, l_alias_nev, l_ertek As String

        Try
            l_matrix_nev = Me.l_matrix
            If l_matrix_nev = "" Then

                For i = 0 To Me.m_SboForm.Items.Count - 1
                    If Me.m_SboForm.Items.Item(i).Type = SAPbouiCOM.BoFormItemTypes.it_MATRIX Then
                        l_matrix_nev = Me.m_SboForm.Items.Item(i).UniqueID
                    End If
                Next


            End If
            l_tabla_nev = Me.get_tabla(l_matrix_nev)

            oMatrix = Me.m_SboForm.Items.Item(l_matrix_nev).Specific


            oDBDataSource = m_SboForm.DataSources.DBDataSources.Item(l_tabla_nev)

            If Not Me.p_conditions Is Nothing Then
                oConditions = Me.p_conditions
            End If

            Dim utdTable As SAPbobsCOM.UserTable
            utdTable = m_ParentAddon.SboCompany.UserTables.Item(Replace(l_tabla_nev, "@", ""))

            For Each oColumn In oMatrix.Columns
                l_alias_nev = oColumn.DataBind.Alias
                l_alias_nev = Replace(l_alias_nev, " ", "")
                If l_alias_nev <> "" And oColumn.DataBind.TableName = l_tabla_nev And oColumn.Visible = True And oColumn.Editable = True Then
                    l_ertek = Me.get_item_value(l_matrix_nev, oColumn.UniqueID, 1)
                    If l_ertek <> "" Then
                        l_szamlal += 1
                        If Not p_conditions Is Nothing And l_szamlal < 2 Then
                            If l_alias_nev <> "Code" And l_alias_nev <> "Name" Then
                                If utdTable.UserFields.Fields.Item(l_alias_nev).Type = SAPbobsCOM.BoFieldTypes.db_Alpha Then
                                    If l_ertek.Substring(l_ertek.Length - 1, 1) = "*" Then
                                        oCondition.Relationship = SAPbouiCOM.BoConditionRelationship.cr_AND
                                        oCondition.BracketOpenNum = 2
                                        oCondition.Alias = l_alias_nev
                                        oCondition.Operation = SAPbouiCOM.BoConditionOperation.co_GRATER_EQUAL
                                        oCondition.CondVal = l_ertek.Substring(0, l_ertek.Length - 1)
                                        oCondition.BracketCloseNum = 1
                                        oCondition.Relationship = SAPbouiCOM.BoConditionRelationship.cr_AND

                                        oCondition = oConditions.Add
                                        oCondition.BracketOpenNum = 1
                                        oCondition.Alias = l_alias_nev
                                        oCondition.Operation = SAPbouiCOM.BoConditionOperation.co_LESS_EQUAL
                                        oCondition.CondVal = l_ertek.Substring(0, l_ertek.Length - 1) & "zzz"
                                        oCondition.BracketCloseNum = 2
                                    Else
                                        oCondition.Relationship = SAPbouiCOM.BoConditionRelationship.cr_AND
                                        oCondition.BracketOpenNum = 1
                                        oCondition.Alias = l_alias_nev
                                        oCondition.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL
                                        oCondition.CondVal = l_ertek
                                        oCondition.BracketCloseNum = 1
                                    End If
                                ElseIf utdTable.UserFields.Fields.Item(l_alias_nev).Type = SAPbobsCOM.BoFieldTypes.db_Date Then
                                    oCondition.Relationship = SAPbouiCOM.BoConditionRelationship.cr_AND
                                    oCondition.BracketOpenNum = 1
                                    oCondition.Alias = l_alias_nev
                                    oCondition.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL
                                    oCondition.CondVal = l_ertek
                                    oCondition.BracketCloseNum = 1
                                ElseIf utdTable.UserFields.Fields.Item(l_alias_nev).Type = SAPbobsCOM.BoFieldTypes.db_Numeric Or utdTable.UserFields.Fields.Item(l_alias_nev).Type = SAPbobsCOM.BoFieldTypes.db_Float Then
                                    oCondition.Relationship = SAPbouiCOM.BoConditionRelationship.cr_AND
                                    oCondition.BracketOpenNum = 1
                                    oCondition.Alias = l_alias_nev
                                    oCondition.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL
                                    oCondition.CondVal = CDbl(Replace(l_ertek, Me.p_EzresEvt, ""))
                                    oCondition.BracketCloseNum = 1
                                End If
                            Else
                                If l_ertek.Substring(l_ertek.Length - 1, 1) = "*" Then
                                    oCondition.Relationship = SAPbouiCOM.BoConditionRelationship.cr_AND
                                    oCondition.BracketOpenNum = 2
                                    oCondition.Alias = l_alias_nev
                                    oCondition.Operation = SAPbouiCOM.BoConditionOperation.co_GRATER_EQUAL
                                    oCondition.CondVal = l_ertek.Substring(0, l_ertek.Length - 1)
                                    oCondition.BracketCloseNum = 1
                                    oCondition.Relationship = SAPbouiCOM.BoConditionRelationship.cr_AND

                                    oCondition = oConditions.Add
                                    oCondition.BracketOpenNum = 1
                                    oCondition.Alias = l_alias_nev
                                    oCondition.Operation = SAPbouiCOM.BoConditionOperation.co_LESS_EQUAL
                                    oCondition.CondVal = l_ertek.Substring(0, l_ertek.Length - 1) & "zzz"
                                    oCondition.BracketCloseNum = 2
                                Else
                                    oCondition.Relationship = SAPbouiCOM.BoConditionRelationship.cr_AND
                                    oCondition.BracketOpenNum = 1
                                    oCondition.Alias = l_alias_nev
                                    oCondition.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL
                                    oCondition.CondVal = l_ertek
                                    oCondition.BracketCloseNum = 1
                                End If
                            End If

                        ElseIf l_szamlal = 1 Then
                            If l_alias_nev <> "Code" And l_alias_nev <> "Name" Then
                                If utdTable.UserFields.Fields.Item(l_alias_nev).Type = SAPbobsCOM.BoFieldTypes.db_Alpha Then
                                    If l_ertek.Substring(l_ertek.Length - 1, 1) = "*" Then
                                        oCondition.BracketOpenNum = 2
                                        oCondition.Alias = l_alias_nev
                                        oCondition.Operation = SAPbouiCOM.BoConditionOperation.co_GRATER_EQUAL
                                        oCondition.CondVal = l_ertek.Substring(0, l_ertek.Length - 1)
                                        oCondition.BracketCloseNum = 1
                                        oCondition.Relationship = SAPbouiCOM.BoConditionRelationship.cr_AND

                                        oCondition = oConditions.Add
                                        oCondition.BracketOpenNum = 1
                                        oCondition.Alias = l_alias_nev
                                        oCondition.Operation = SAPbouiCOM.BoConditionOperation.co_LESS_EQUAL
                                        oCondition.CondVal = l_ertek.Substring(0, l_ertek.Length - 1) & "zzz"
                                        oCondition.BracketCloseNum = 2
                                    Else
                                        oCondition.BracketOpenNum = 1
                                        oCondition.Alias = l_alias_nev
                                        oCondition.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL
                                        oCondition.CondVal = l_ertek
                                        oCondition.BracketCloseNum = 1
                                    End If
                                ElseIf utdTable.UserFields.Fields.Item(l_alias_nev).Type = SAPbobsCOM.BoFieldTypes.db_Date Then
                                    oCondition.BracketOpenNum = 1
                                    oCondition.Alias = l_alias_nev
                                    oCondition.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL
                                    oCondition.CondVal = l_ertek
                                    oCondition.BracketCloseNum = 1
                                ElseIf utdTable.UserFields.Fields.Item(l_alias_nev).Type = SAPbobsCOM.BoFieldTypes.db_Numeric Or utdTable.UserFields.Fields.Item(l_alias_nev).Type = SAPbobsCOM.BoFieldTypes.db_Float Then
                                    oCondition.BracketOpenNum = 1
                                    oCondition.Alias = l_alias_nev
                                    oCondition.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL
                                    oCondition.CondVal = CDbl(Replace(l_ertek, Me.p_EzresEvt, ""))
                                    oCondition.BracketCloseNum = 1
                                End If
                            Else
                                If l_ertek.Substring(l_ertek.Length - 1, 1) = "*" Then
                                    oCondition.BracketOpenNum = 2
                                    oCondition.Alias = l_alias_nev
                                    oCondition.Operation = SAPbouiCOM.BoConditionOperation.co_GRATER_EQUAL
                                    oCondition.CondVal = l_ertek.Substring(0, l_ertek.Length - 1)
                                    oCondition.BracketCloseNum = 1
                                    oCondition.Relationship = SAPbouiCOM.BoConditionRelationship.cr_AND

                                    oCondition = oConditions.Add
                                    oCondition.BracketOpenNum = 1
                                    oCondition.Alias = l_alias_nev
                                    oCondition.Operation = SAPbouiCOM.BoConditionOperation.co_LESS_EQUAL
                                    oCondition.CondVal = l_ertek.Substring(0, l_ertek.Length - 1) & "zzz"
                                    oCondition.BracketCloseNum = 2
                                Else
                                    oCondition.BracketOpenNum = 1
                                    oCondition.Alias = l_alias_nev
                                    oCondition.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL
                                    oCondition.CondVal = l_ertek
                                    oCondition.BracketCloseNum = 1
                                End If
                            End If

                        ElseIf l_szamlal > 1 Then
                            If l_alias_nev <> "Code" And l_alias_nev <> "Name" Then
                                If utdTable.UserFields.Fields.Item(l_alias_nev).Type = SAPbobsCOM.BoFieldTypes.db_Alpha Then
                                    If l_ertek.Substring(l_ertek.Length - 1, 1) = "*" Then
                                        oCondition.Relationship = SAPbouiCOM.BoConditionRelationship.cr_AND
                                        oCondition = oConditions.Add
                                        oCondition.BracketOpenNum = 2
                                        oCondition.Alias = l_alias_nev
                                        oCondition.Operation = SAPbouiCOM.BoConditionOperation.co_GRATER_EQUAL
                                        oCondition.CondVal = l_ertek.Substring(0, l_ertek.Length - 1)
                                        oCondition.BracketCloseNum = 1
                                        oCondition.Relationship = SAPbouiCOM.BoConditionRelationship.cr_AND

                                        oCondition = oConditions.Add
                                        oCondition.BracketOpenNum = 1
                                        oCondition.Alias = l_alias_nev
                                        oCondition.Operation = SAPbouiCOM.BoConditionOperation.co_LESS_EQUAL
                                        oCondition.CondVal = l_ertek.Substring(0, l_ertek.Length - 1) & "zzz"
                                        oCondition.BracketCloseNum = 2
                                    Else
                                        oCondition.Relationship = SAPbouiCOM.BoConditionRelationship.cr_AND
                                        oCondition = oConditions.Add
                                        oCondition.BracketOpenNum = 1
                                        oCondition.Alias = l_alias_nev
                                        oCondition.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL
                                        oCondition.CondVal = l_ertek
                                        oCondition.BracketCloseNum = 1
                                    End If
                                ElseIf utdTable.UserFields.Fields.Item(l_alias_nev).Type = SAPbobsCOM.BoFieldTypes.db_Date Then
                                    oCondition.Relationship = SAPbouiCOM.BoConditionRelationship.cr_AND
                                    oCondition = oConditions.Add
                                    oCondition.BracketOpenNum = 1
                                    oCondition.Alias = l_alias_nev
                                    oCondition.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL
                                    oCondition.CondVal = l_ertek
                                    oCondition.BracketCloseNum = 1
                                ElseIf utdTable.UserFields.Fields.Item(l_alias_nev).Type = SAPbobsCOM.BoFieldTypes.db_Numeric Or utdTable.UserFields.Fields.Item(l_alias_nev).Type = SAPbobsCOM.BoFieldTypes.db_Float Then
                                    oCondition.Relationship = SAPbouiCOM.BoConditionRelationship.cr_AND
                                    oCondition = oConditions.Add
                                    oCondition.BracketOpenNum = 1
                                    oCondition.Alias = l_alias_nev
                                    oCondition.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL
                                    oCondition.CondVal = CDbl(Replace(l_ertek, Me.p_EzresEvt, ""))
                                    oCondition.BracketCloseNum = 1
                                    'Replace(Replace(l_ertek, Me.p_EzresEvt, ""), Me.p_TizedesEvt, ".")
                                End If
                            Else
                                If l_ertek.Substring(l_ertek.Length - 1, 1) = "*" Then
                                    oCondition.Relationship = SAPbouiCOM.BoConditionRelationship.cr_AND
                                    oCondition = oConditions.Add
                                    oCondition.BracketOpenNum = 2
                                    oCondition.Alias = l_alias_nev
                                    oCondition.Operation = SAPbouiCOM.BoConditionOperation.co_GRATER_EQUAL
                                    oCondition.CondVal = l_ertek.Substring(0, l_ertek.Length - 1)
                                    oCondition.BracketCloseNum = 1
                                    oCondition.Relationship = SAPbouiCOM.BoConditionRelationship.cr_AND

                                    oCondition = oConditions.Add
                                    oCondition.BracketOpenNum = 1
                                    oCondition.Alias = l_alias_nev
                                    oCondition.Operation = SAPbouiCOM.BoConditionOperation.co_LESS_EQUAL
                                    oCondition.CondVal = l_ertek.Substring(0, l_ertek.Length - 1) & "zzz"
                                    oCondition.BracketCloseNum = 2
                                Else
                                    oCondition.Relationship = SAPbouiCOM.BoConditionRelationship.cr_AND
                                    oCondition = oConditions.Add
                                    oCondition.BracketOpenNum = 1
                                    oCondition.Alias = l_alias_nev
                                    oCondition.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL
                                    oCondition.CondVal = l_ertek
                                    oCondition.BracketCloseNum = 1
                                End If
                            End If
                        End If
                    End If
                End If
            Next


            oMatrix.Clear()

            Try

                oDBDataSource.Query(oConditions)

                For i = 0 To oDBDataSource.Size - 1
                    oDBDataSource.Offset = i
                    oMatrix.AddRow()
                    Me.post_query(i + 1)
                Next i

            Catch ex As Exception

            End Try

            'm_sboform.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE
        Catch ex As Exception
            m_ParentAddon.SboApplication.MessageBox(ex.ToString)
            m_ParentAddon.BlockEvents = False
        End Try
    End Sub
    Public Function parameter_ertek(ByVal pnr_kod As String)
        Dim oRecordSet As SAPbobsCOM.Recordset
        Dim p_select As String
        Try
            oRecordSet = m_parentaddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

            p_select = QueryResource.GetQuery("Base_IFSZ_AddOn_SBO", "sel_value_from_parameters_by_code", pnr_kod)
            oRecordSet.DoQuery(p_select)
            If oRecordSet.RecordCount <> 1 Then
                Exit Function
            End If

            If oRecordSet.RecordCount = 1 Then
                oRecordSet.MoveFirst()
                Return oRecordSet.Fields.Item(0).Value
            End If
        Catch ex As Exception
            Return ""
        Finally
            If (Not oRecordSet Is Nothing) Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oRecordSet)
                oRecordSet = Nothing
            End If
        End Try
    End Function

    Public Sub set_parameter_ertek(ByVal pnr_kod As String, ByVal pValue As String)
        Dim oRecordSet As SAPbobsCOM.Recordset
        Dim p_select As String
        Try
            oRecordSet = m_parentaddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

            p_select = QueryResource.GetQuery("Base_IFSZ_AddOn_SBO", "sel_value_from_parameters_by_code", pnr_kod)
            oRecordSet.DoQuery(p_select)
            oRecordSet.MoveLast()
            oRecordSet.MoveFirst()
            If oRecordSet.RecordCount <> 1 Then
                oRecordSet.DoQuery(QueryResource.GetQuery("Base_IFSZ_AddOn_SBO", "ins_parameters", pnr_kod, pnr_kod, pValue, "Automatikusan besz�rva"))
                Exit Sub
            End If

            If oRecordSet.RecordCount = 1 Then
                oRecordSet.DoQuery(QueryResource.GetQuery("Base_IFSZ_AddOn_SBO", "upd_parameter", pValue, pnr_kod))
            End If
        Catch ex As Exception
            Exit Sub
        Finally
            If (Not oRecordSet Is Nothing) Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oRecordSet)
                oRecordSet = Nothing
            End If
        End Try
    End Sub


#End Region

#Region "Overrides"
    Public Overrides Sub HANDLE_FORM_EVENTS(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)

        Try

            'Me.m_esemenyek = ""

            'Me.m_esemenyek += pVal.EventType.ToString() + "(" + pVal.ItemUID + "." + pVal.ColUID + ")" + ": " + DateTime.Now().ToString("HH:mm:ss") + Environment.NewLine

            Dim l_kilepni As Boolean = False
            '''''''''''''''''
            'Lovform eset�n semmit nem enged�nk csin�lni a h�v� formon
            If Me.p_ModalFormUID IsNot Nothing AndAlso Me.m_LovVisszairas = False Then
#If SBOVER > "9000" Then
                If pVal.EventType <> SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE AndAlso pVal.EventType <> SAPbouiCOM.BoEventTypes.et_FORM_DEACTIVATE AndAlso pVal.EventType <> SAPbouiCOM.BoEventTypes.et_FORM_RESIZE AndAlso pVal.EventType <> SAPbouiCOM.BoEventTypes.et_FORM_DRAW AndAlso pVal.EventType <> SAPbouiCOM.BoEventTypes.et_VALIDATE Then
#Else
                If pVal.EventType <> SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE AndAlso pVal.EventType <> SAPbouiCOM.BoEventTypes.et_FORM_DEACTIVATE AndAlso pVal.EventType <> SAPbouiCOM.BoEventTypes.et_FORM_RESIZE AndAlso pVal.EventType <> SAPbouiCOM.BoEventTypes.et_VALIDATE Then
#End If
                    BubbleEvent = False
                    l_kilepni = True
                ElseIf pVal.EventType = SAPbouiCOM.BoEventTypes.et_VALIDATE AndAlso Me.m_LovAlattValidateEnged = False Then
                    BubbleEvent = False
                    l_kilepni = True
                End If
            End If

            If (Not Me.p_ModalFormUID Is Nothing AndAlso Me.m_LovVisszairas = False) AndAlso pVal.EventType <> SAPbouiCOM.BoEventTypes.et_FORM_DEACTIVATE AndAlso Me.m_SboForm.Selected = True Then ' pVal.EventType <> SAPbouiCOM.BoEventTypes.et_FORM_DEACTIVATE And (pVal.BeforeAction = False Or pVal.EventType = SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE Or pVal.EventType = SAPbouiCOM.BoEventTypes.et_CLICK) Then
                Dim oForm As SboForm
                Dim oFormSBO As SAPbouiCOM.Form
                For Each oForm In Me.m_ParentAddon.SBOForms
                    If oForm.UniqueID = Me.p_ModalFormUID Then
                        oFormSBO = Me.m_ParentAddon.SboApplication.Forms.Item(oForm.UniqueID)
                        If (Not oFormSBO Is Nothing) And oFormSBO.Visible = True Then
                            'Me.m_esemenyek += "�tv�ltott" + Environment.NewLine
                            oFormSBO.Select()
                        End If
                        If pVal.ItemUID = "1" Or pVal.ItemUID = "2" Then
                            BubbleEvent = False
                        End If
                        Exit Sub
                    End If
                Next
                Me.p_ModalFormUID = Nothing
            End If
            If l_kilepni Then
                Exit Sub
            End If
            If Me.p_validal_e = False Then
                Exit Sub
            End If
            Me.pre_event(FormUID, pVal, BubbleEvent)
            'If Me.p_validal_e = False Then
            '    Exit Sub
            'End If
            If BubbleEvent Then
                Me.esemeny_kezelo(FormUID, pVal, BubbleEvent)
                If Me.p_uj_sor_e = True Then
                    Me.p_uj_sor_e = False
                End If
                If BubbleEvent Then
                    Me.post_event(FormUID, pVal, BubbleEvent)
                End If
            End If
        Catch ex As Exception
            m_ParentAddon.SboApplication.MessageBox(ex.ToString)
            m_ParentAddon.BlockEvents = False
        End Try

    End Sub

    Public Overrides Sub HANDLE_MENU_EVENTS(ByRef pVal As SAPbouiCOM.MenuEvent, ByRef BubbleEvent As Boolean)
        Dim oMatrix As SAPbouiCOM.Matrix
        Dim l_matrix_nev As String
        Try
            Select Case pVal.MenuUID
                Case 1292
                    If Me.m_SboForm.Selected And pVal.BeforeAction = True Then
                        Me.sorrend_ujraszamolas(l_kivalasztott_sor, 1)
                        Me.uj_sor_letrehozas()
                    End If
                Case 1293
                    If Me.m_SboForm.Selected Then
                        If pVal.BeforeAction = True Then
                            If Me.l_matrix Is Nothing Then
                                Exit Sub
                            End If
                            oMatrix = Me.m_SboForm.Items.Item(Me.l_matrix).Specific
                            Me.key_delete(Me.l_matrix, Me.l_kivalasztott_sor, Me.l_kivalasztott_kod, BubbleEvent)
                            If BubbleEvent = False Then
                                Exit Sub
                            End If
                            Me.l_torlse_e = True
                            Me.sorrend_ujraszamolas(l_kivalasztott_sor, -1)
                            Me.sor_tarolas(Me.l_matrix, Me.l_kivalasztott_sor, Me.l_kivalasztott_kod)
                            Me.l_torlse_e = False
                            oMatrix.DeleteRow(Me.l_kivalasztott_sor)
                        Else

                            oMatrix = Me.m_SboForm.Items.Item(Me.l_matrix).Specific
                            If oMatrix.RowCount >= Me.l_kivalasztott_sor Then
                                For Each oColumn As SAPbouiCOM.Column In oMatrix.Columns
                                    If oColumn.Visible And oColumn.Editable Then
                                        oColumn.Cells.Item(Me.l_kivalasztott_sor).Click() 'HG !!!!
                                        Exit For
                                    End If
                                Next
                                'oMatrix.DeleteRow(1)
                            ElseIf oMatrix.RowCount > 1 Then
                                For Each oColumn As SAPbouiCOM.Column In oMatrix.Columns
                                    If oColumn.Visible And oColumn.Editable Then
                                        oColumn.Cells.Item(Me.l_kivalasztott_sor - 1).Click() 'HG !!!!
                                        Exit For
                                    End If
                                Next
                            ElseIf oMatrix.RowCount = 1 Then
                                For Each oColumn As SAPbouiCOM.Column In oMatrix.Columns
                                    If oColumn.Visible And oColumn.Editable Then
                                        oColumn.Cells.Item(1).Click() 'HG !!!!
                                        Exit For
                                    End If
                                Next
                            Else
                                Me.l_matrix = Nothing
                                Me.l_kivalasztott_sor = Nothing
                                Me.l_kivalasztott_kod = Nothing
                            End If
                        End If
                    End If
                Case 1281
                    Dim i As Integer
                    If pVal.BeforeAction = False And Me.m_SboForm.Selected Then
                        l_matrix_nev = Me.l_matrix
                        If l_matrix_nev = "" Then
                            For i = 0 To Me.m_SboForm.Items.Count - 1
                                If Me.m_SboForm.Items.Item(i).Type = SAPbouiCOM.BoFormItemTypes.it_MATRIX Then
                                    l_matrix_nev = Me.m_SboForm.Items.Item(i).UniqueID
                                End If
                            Next
                        End If
                        oMatrix = Me.m_SboForm.Items.Item(l_matrix_nev).Specific
                        oMatrix.Clear()

                        Me.uj_sor_letrehozas(1)
                        Me.m_SboForm.Mode = SAPbouiCOM.BoFormMode.fm_FIND_MODE
                    End If

                Case 1289
                    If Me.m_SboForm.Selected And pVal.BeforeAction = True Then
                        Me.Leptet(-1)
                    End If

                Case 1288
                    If Me.m_SboForm.Selected And pVal.BeforeAction = True Then
                        Me.Leptet(1)
                    End If
                Case 519

                    If Me.m_SboForm.Selected And pVal.BeforeAction = True Then
                        nyomtat()
                        BubbleEvent = False
                    Else
                        Exit Sub
                    End If

            End Select

        Catch ex As Exception
            m_ParentAddon.SboApplication.MessageBox(ex.ToString)
            m_ParentAddon.BlockEvents = False
        End Try

    End Sub
#End Region

#Region "EsemenyKezelo"

    Public Overridable Sub esemeny_kezelo(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Dim p_hiba As String = "00"
        Dim p_oszlop As String = ""
        Try
            'If Me.p_validal_e = False Then
            '    Exit Sub
            'End If
            If pVal.Before_Action = True Then
                p_hiba = "01"
                Select Case pVal.EventType
                    Case SAPbouiCOM.BoEventTypes.et_CLICK
                        Dim oMatrix As SAPbouiCOM.Matrix
                        Dim i As Integer
                        Dim index As Integer
                        Dim lng_errCode As Long
                        Dim str_errMsg As String
                        Dim l_matrix_nev As String
                        Dim l_tabla_nev As String
                        Dim l_eredeti_tabla_nev As String
                        Dim oColumn As SAPbouiCOM.Column
                        Dim l_alias_nev As String
                        Dim l_ertek As String
                        Dim l_lookup_ertek As String
                        p_hiba = "02"
                        Select Case pVal.ItemUID

                            Case "1"
                                'Ha le van tiltva az insert/update/delete akkor kil�p
                                p_hiba = "03"
                                If Me.m_SboForm.Mode = SAPbouiCOM.BoFormMode.fm_FIND_MODE Then
                                    Me.kereses()
                                    BubbleEvent = False
                                    m_SboForm.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE
                                    Exit Sub
                                End If

                                If Me.p_modosithat_e = False Then
                                    Exit Sub
                                End If

                                Dim utdTable As SAPbobsCOM.UserTable
                                Dim p_BubbleEvent As Boolean = True

                                Try
                                    p_hiba = "04"
                                    If Me.l_utolso_matrix_nev Is Nothing Then
                                        Exit Sub
                                    End If
                                    'TODOm_ParentAddon.SboCompany.StartTransaction()
                                    If Me.l_kivalasztott_sor > 0 Then
                                        l_ertek = Me.get_item_value(Me.l_utolso_matrix_nev, Me.l_utolso_oszlop, Me.l_utolso_sor, False)
                                        l_lookup_ertek = Me.get_item_value(Me.l_utolso_matrix_nev, Me.l_utolso_oszlop, Me.l_utolso_sor, True)
                                        Me.item_validate(True, Me.l_utolso_matrix_nev, Me.l_utolso_oszlop, Me.l_utolso_sor, l_ertek, l_lookup_ertek, BubbleEvent)
                                    End If
                                    'Me.p_validal_e = False

                                    'Megvizsg�ljuk, hogy az OK gomb megnyom�sa el�tti item el lett-e m�r t�rolva
                                    'Ha nem akkor a m�dos�tand� t�mb�t m�dos�tjuk
                                    If Me.l_utolso_matrix_nev <> "" And Me.l_kivalasztott_sor > 0 Then
                                        If Me.ItemInList(Me.l_utolso_matrix_nev, Me.l_utolso_sor) = False Then
                                            Me.sor_tarolas(Me.l_utolso_matrix_nev, Me.l_utolso_sor)
                                        End If
                                    End If

                                    For i = 0 To Me.l_sor_tomb.GetLength(0) - 2

                                        index = Me.l_sor_tomb(i).sor
                                        l_matrix_nev = Me.get_matrix(l_sor_tomb(i).nev)
                                        l_eredeti_tabla_nev = Me.get_tabla(l_sor_tomb(i).nev)
                                        'Minden sor m�dso�t�s el�tt megh�vunk egy pre_dml elj�r�st
                                        'p_BubbleEvent = BubbleEvent
                                        If Me.get_matrix(l_sor_tomb(i).torles_e) = False Then
                                            pre_dml(l_matrix_nev, index, l_sor_tomb(i).kod, l_sor_tomb(i).torles_e, p_BubbleEvent)
                                            BubbleEvent = p_BubbleEvent
                                            If BubbleEvent = False Then
                                                'TODOm_ParentAddon.SboCompany.EndTransaction(SAPbobsCOM.BoWfTransOpt.wf_RollBack)
                                                Exit Sub
                                            End If
                                        End If
                                        l_tabla_nev = Replace(l_eredeti_tabla_nev, "@", "")
                                        oMatrix = m_SboForm.Items.Item(l_matrix_nev).Specific
                                        utdTable = m_ParentAddon.SboCompany.UserTables.Item(l_tabla_nev)

                                        If Me.l_sor_tomb(i).torles_e = False Then
                                            If Me.ItemDelInList(Me.l_sor_tomb(i).nev, i, Me.l_sor_tomb(i).kod) = False Then
                                                With utdTable.UserFields.Fields
                                                    l_ertek = Me.get_item_value(l_matrix_nev, "Code", index)
                                                    'Ha a sor �s a hozz� tartoz� k�d nem egyezik meg hib�t k�ld�nk

                                                    'If l_ertek <> Me.l_sor_tomb(i).kod Then
                                                    '    m_ParentAddon.SboApplication.MessageBox("A sorsz�moz�s hib�s")
                                                    '    m_ParentAddon.BlockEvents = False
                                                    '    Exit Sub
                                                    'End If

                                                    If utdTable.GetByKey(l_ertek) = True Then

                                                        utdTable.Name = Me.get_item_value(l_matrix_nev, "Name", index)

                                                        Dim l_a As Double
                                                        For Each oColumn In oMatrix.Columns
                                                            l_alias_nev = oColumn.DataBind.Alias
                                                            l_alias_nev = Replace(l_alias_nev, " ", "")
                                                            p_oszlop = l_alias_nev
                                                            Dim p_ertek As Object
                                                            If l_alias_nev <> "" And l_alias_nev <> "Code" And oColumn.DataBind.TableName = l_eredeti_tabla_nev And l_alias_nev <> "Name" Then
                                                                If .Item(l_alias_nev).Type = SAPbobsCOM.BoFieldTypes.db_Numeric Or .Item(l_alias_nev).Type = SAPbobsCOM.BoFieldTypes.db_Float Then

                                                                    If .Item(l_alias_nev).Type = SAPbobsCOM.BoFieldTypes.db_Float Then
                                                                        l_a = IFSZ_Globals_SBO.KonvertSBOSzam(Me.get_item_value(l_matrix_nev, oColumn.UniqueID, index))
                                                                        .Item(l_alias_nev).Value = l_a 'Replace(Me.get_item_value(l_matrix_nev, oColumn.UniqueID, index), Me.p_EzresEvt, "")
                                                                        p_ertek = l_a
                                                                    Else
                                                                        If Me.get_item_value(l_matrix_nev, oColumn.UniqueID, index) <> "" Then
                                                                            'Dim l_i As Integer = IFSZ_Globals_SBO.KonvertSBOSzam(Me.get_item_value(l_matrix_nev, oColumn.UniqueID, index))
                                                                            '.Item(l_alias_nev).Value = l_i
                                                                            .Item(l_alias_nev).Value = Replace(Me.get_item_value(l_matrix_nev, oColumn.UniqueID, index), Me.p_EzresEvt, "")
                                                                            p_ertek = Replace(Me.get_item_value(l_matrix_nev, oColumn.UniqueID, index), Me.p_EzresEvt, "")
                                                                        Else
                                                                            .Item(l_alias_nev).Value = 0
                                                                            p_ertek = 0
                                                                        End If

                                                                    End If
                                                                ElseIf .Item(l_alias_nev).Type = SAPbobsCOM.BoFieldTypes.db_Date Then
                                                                    p_ertek = Me.get_item_value(l_matrix_nev, oColumn.UniqueID, index)
                                                                    Dim p_date_ertek As Date
                                                                    p_date_ertek = IFSZ_Globals_SBO.KonvertSBODate(p_ertek)
                                                                    .Item(l_alias_nev).Value = p_date_ertek
                                                                Else
                                                                    .Item(l_alias_nev).Value = Me.get_item_value(l_matrix_nev, oColumn.UniqueID, index)
                                                                    p_ertek = Me.get_item_value(l_matrix_nev, oColumn.UniqueID, index)
                                                                End If
                                                            End If
                                                        Next
                                                        If utdTable.Update <> 0 Then
                                                            m_ParentAddon.SboCompany.GetLastError(lng_errCode, str_errMsg)
                                                            m_ParentAddon.SboApplication.MessageBox(str_errMsg & Chr(10) & _
                                                              " hibak�d = " & lng_errCode.ToString())
                                                        End If
                                                    Else
                                                        utdTable.Code = Me.get_item_value(l_matrix_nev, "Code", index)
                                                        utdTable.Name = Me.get_item_value(l_matrix_nev, "Name", index)

                                                        Dim l_a As Double
                                                        Dim p_ertek As Object
                                                        For Each oColumn In oMatrix.Columns
                                                            l_alias_nev = oColumn.DataBind.Alias
                                                            l_alias_nev = Replace(l_alias_nev, " ", "")
                                                            If l_alias_nev <> "" And l_alias_nev <> "Code" And oColumn.DataBind.TableName = l_eredeti_tabla_nev And l_alias_nev <> "Name" Then
                                                                If .Item(l_alias_nev).Type = SAPbobsCOM.BoFieldTypes.db_Numeric Or .Item(l_alias_nev).Type = SAPbobsCOM.BoFieldTypes.db_Float Then
                                                                    If .Item(l_alias_nev).Type = SAPbobsCOM.BoFieldTypes.db_Float Then
                                                                        l_a = IFSZ_Globals_SBO.KonvertSBOSzam(Me.get_item_value(l_matrix_nev, oColumn.UniqueID, index))
                                                                        .Item(l_alias_nev).Value = l_a
                                                                    Else
                                                                        If Me.get_item_value(l_matrix_nev, oColumn.UniqueID, index) <> "" Then
                                                                            .Item(l_alias_nev).Value = CType(IFSZ_Globals_SBO.KonvertSBOSzam(Me.get_item_value(l_matrix_nev, oColumn.UniqueID, index)), Integer)
                                                                        End If
                                                                    End If
                                                                ElseIf .Item(l_alias_nev).Type = SAPbobsCOM.BoFieldTypes.db_Date Then
                                                                    p_ertek = Me.get_item_value(l_matrix_nev, oColumn.UniqueID, index)
                                                                    Dim p_date_ertek As Date
                                                                    p_date_ertek = IFSZ_Globals_SBO.KonvertSBODate(p_ertek)
                                                                    .Item(l_alias_nev).Value = p_date_ertek
                                                                Else
                                                                    .Item(l_alias_nev).Value = Me.get_item_value(l_matrix_nev, oColumn.UniqueID, index)
                                                                End If
                                                            End If
                                                        Next
                                                        If utdTable.Add <> 0 Then
                                                            m_ParentAddon.SboCompany.GetLastError(lng_errCode, str_errMsg)
                                                            m_ParentAddon.SboApplication.MessageBox(str_errMsg & Chr(10) & _
                                                              " hibak�d = " & lng_errCode.ToString())
                                                        End If

                                                    End If

                                                End With
                                            End If
                                        Else
                                            utdTable.GetByKey(l_sor_tomb(i).kod)
                                            If utdTable.Remove <> 0 And Me.l_sor_tomb(i).volt_e_torles = False Then
                                                m_ParentAddon.SboCompany.GetLastError(lng_errCode, str_errMsg)
                                                m_ParentAddon.SboApplication.MessageBox(str_errMsg & Chr(10) & _
                                                  " hibak�d = " & lng_errCode.ToString())
                                            End If

                                        End If

                                    Next
                                    p_hiba = "05"
                                    Try
                                        'TODO If m_ParentAddon.SboCompany.InTransaction Then
                                        'm_ParentAddon.SboCompany.EndTransaction(SAPbobsCOM.BoWfTransOpt.wf_Commit)
                                        'End If
                                    Catch ex As Exception
                                        m_ParentAddon.SboApplication.MessageBox("p_hiba commit " + p_hiba + p_oszlop + ex.ToString)
                                    End Try

                                    ReDim Me.l_sor_tomb(0)
                                Catch ex As Exception
                                    'TODOm_ParentAddon.SboCompany.EndTransaction(SAPbobsCOM.BoWfTransOpt.wf_RollBack)
                                    m_ParentAddon.SboApplication.MessageBox("p_hiba " + p_hiba + p_oszlop + ex.ToString)
                                    m_ParentAddon.BlockEvents = False
                                    Exit Sub
                                End Try
                            Case "2"
                                p_hiba = "1"
                                Me.p_validal_e = False
                                If Me.l_utolso_matrix_nev = "" Or Me.l_utolso_oszlop = "" Or Me.l_utolso_sor = "" Then
                                    m_SboForm.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE
                                    m_SboForm.Close()
                                    Exit Sub
                                End If

                                m_SboForm.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE
                                m_SboForm.Close()
                                p_hiba = "2"
                        End Select
                    Case SAPbouiCOM.BoEventTypes.et_DOUBLE_CLICK
                        Dim p_tabla As String
                        Dim oMatrix As SAPbouiCOM.Matrix
                        Dim oColumn As SAPbouiCOM.Column

                        If Me.m_SboForm.Items.Item(pVal.ItemUID).Type = SAPbouiCOM.BoFormItemTypes.it_MATRIX And pVal.Row = 0 And pVal.ColUID <> "" Then

                            p_tabla = Me.get_tabla(pVal.ItemUID)
                            oMatrix = Me.m_SboForm.Items.Item(pVal.ItemUID).Specific
                            oColumn = oMatrix.Columns.Item(pVal.ColUID)
                            If oColumn.DataBind.TableName <> "" Then
                                Me.fejlec_aktival(pVal, BubbleEvent)
                            End If

                        End If
                End Select

            ElseIf pVal.Before_Action = False Then
                p_hiba = "3"
                Dim oMatrix As SAPbouiCOM.Matrix
                Dim oColumn As SAPbouiCOM.Column
                Dim oEditText As SAPbouiCOM.EditText
                Dim oComboBox As SAPbouiCOM.ComboBox
                Dim oCheckBox As SAPbouiCOM.CheckBox
                Dim l_ertek As String
                Dim l_lookup_ertek As String

                Select Case pVal.EventType

                    Case SAPbouiCOM.BoEventTypes.et_MATRIX_LINK_PRESSED
                        p_hiba = "4"
                        link_pressed(pVal.ItemUID, pVal.ColUID, pVal.Row)
                        p_hiba = "5"
                    Case SAPbouiCOM.BoEventTypes.et_VALIDATE
                        p_hiba = "6"
                        If m_SboForm.Items.Item(pVal.ItemUID).Type = SAPbouiCOM.BoFormItemTypes.it_MATRIX Then
                            oMatrix = m_SboForm.Items.Item(pVal.ItemUID).Specific
                            oColumn = oMatrix.Columns.Item(pVal.ColUID)

                            If oColumn.Type = SAPbouiCOM.BoFormItemTypes.it_EDIT Or oColumn.Type = SAPbouiCOM.BoFormItemTypes.it_LINKED_BUTTON Then
                                p_hiba = "7"
                                oEditText = oColumn.Cells.Item(pVal.Row).Specific
                                l_ertek = oEditText.String
                                l_lookup_ertek = ""
                                If Me.p_validal_e = True And Me.p_uj_sor_e = False Then
                                    Me.item_validate(pVal.ItemChanged, pVal.ItemUID, pVal.ColUID, pVal.Row, l_ertek, l_lookup_ertek, BubbleEvent)
                                End If
                                'Me.p_validal_e = True

                                If Me.ItemInList(pVal.ItemUID, pVal.Row) = False And pVal.ItemChanged = True Then
                                    Me.sor_tarolas(pVal.ItemUID, pVal.Row)
                                End If

                                oMatrix = m_SboForm.Items.Item(pVal.ItemUID).Specific
                                oEditText = oMatrix.Columns.Item("Code").Cells.Item(pVal.Row).Specific
                                Me.item_kod = oEditText.String
                                Me.l_torlse_e = False

                            End If
                        End If
                        p_hiba = "8"
                    Case SAPbouiCOM.BoEventTypes.et_CLICK And pVal.ItemUID <> ""
                        p_hiba = "9"
                        'm_ParentAddon.SboApplication.MessageBox(m_SboForm.Items.Item(pVal.ItemUID).Type)
                        If pVal.ItemUID = "pb_runrep" Then
                            Exit Sub
                        End If
                        'm_ParentAddon.SboApplication.MessageBox(l_str)
                        If m_SboForm.Items.Item(pVal.ItemUID).Type = SAPbouiCOM.BoFormItemTypes.it_MATRIX Then
                            p_hiba = "10"
                            oMatrix = m_SboForm.Items.Item(pVal.ItemUID).Specific
                            oColumn = oMatrix.Columns.Item(pVal.ColUID)

                            If oColumn.Type = SAPbouiCOM.BoFormItemTypes.it_CHECK_BOX And pVal.Row > 0 Then
                                oCheckBox = oColumn.Cells.Item(pVal.Row).Specific
                                l_ertek = oCheckBox.Checked.ToString
                                l_lookup_ertek = ""
                                If Me.p_validal_e = True And Me.p_uj_sor_e = False Then
                                    Me.item_validate(pVal.ItemChanged, pVal.ItemUID, pVal.ColUID, pVal.Row, l_ertek, l_lookup_ertek, BubbleEvent)
                                End If
                                'Me.p_validal_e = True

                                If Me.ItemInList(pVal.ItemUID, pVal.Row) = False Then
                                    Me.sor_tarolas(pVal.ItemUID, pVal.Row)
                                End If
                                p_hiba = "11"
                                oMatrix = m_SboForm.Items.Item(pVal.ItemUID).Specific
                                oEditText = oMatrix.Columns.Item("Code").Cells.Item(pVal.Row).Specific
                                Me.item_kod = oEditText.String
                                Me.l_torlse_e = False

                                Me.l_utolso_sor = pVal.Row
                                Me.l_utolso_matrix_nev = pVal.ItemUID
                                Me.l_utolso_oszlop = pVal.ColUID


                            End If

                            Me.l_kivalasztott_sor = pVal.Row
                            Me.l_matrix = pVal.ItemUID

                        End If
                        p_hiba = "12"
                    Case SAPbouiCOM.BoEventTypes.et_COMBO_SELECT
                        p_hiba = "13"
                        If m_SboForm.Items.Item(pVal.ItemUID).Type = SAPbouiCOM.BoFormItemTypes.it_MATRIX Then

                            oMatrix = m_SboForm.Items.Item(pVal.ItemUID).Specific
                            oColumn = oMatrix.Columns.Item(pVal.ColUID)
                            p_hiba = "14"
                            If oColumn.Type = SAPbouiCOM.BoFormItemTypes.it_COMBO_BOX Then
                                oComboBox = oColumn.Cells.Item(pVal.Row).Specific
                                l_ertek = oComboBox.Selected.Value
                                l_lookup_ertek = oComboBox.Selected.Description
                                If Me.p_validal_e = True And Me.p_uj_sor_e = False Then
                                    Me.item_validate(pVal.ItemChanged, pVal.ItemUID, pVal.ColUID, pVal.Row, l_ertek, l_lookup_ertek, BubbleEvent)
                                End If
                                'Me.p_validal_e = True

                                If Me.ItemInList(pVal.ItemUID, pVal.Row) = False Then
                                    Me.sor_tarolas(pVal.ItemUID, pVal.Row)
                                End If

                                oMatrix = m_SboForm.Items.Item(pVal.ItemUID).Specific
                                oEditText = oMatrix.Columns.Item("Code").Cells.Item(pVal.Row).Specific
                                Me.item_kod = oEditText.String
                                Me.l_torlse_e = False

                                Me.l_utolso_sor = pVal.Row
                                Me.l_utolso_matrix_nev = pVal.ItemUID
                                Me.l_utolso_oszlop = pVal.ColUID


                            End If
                        End If
                        p_hiba = "15"
                    Case SAPbouiCOM.BoEventTypes.et_GOT_FOCUS
                        p_hiba = "16"
                        'Meg kell n�zni, hogy t�nleg m�trix t�pus�
                        If m_SboForm.Items.Item(pVal.ItemUID).Type() = SAPbouiCOM.BoFormItemTypes.it_MATRIX Then
                            Me.l_kivalasztott_sor = pVal.Row
                            Me.l_matrix = pVal.ItemUID
                            Me.l_kivalasztott_kod = get_item_value(l_matrix, "Code", l_kivalasztott_sor)
                        End If

                        If m_SboForm.Items.Item(pVal.ItemUID).Type() = SAPbouiCOM.BoFormItemTypes.it_MATRIX Then
                            Me.l_utolso_sor = pVal.Row
                            Me.l_utolso_matrix_nev = pVal.ItemUID
                            Me.l_utolso_oszlop = pVal.ColUID

                        End If
                        p_hiba = "17"
                    Case SAPbouiCOM.BoEventTypes.et_LOST_FOCUS

                End Select
            End If

        Catch ex As Exception
            m_ParentAddon.SboApplication.MessageBox("p_hiba_vege" + p_hiba + p_oszlop + ex.ToString)
            m_ParentAddon.BlockEvents = False
        End Try
    End Sub

#End Region

#Region "Private"

    Public Function ItemInList(ByVal l_nev As String, ByVal l_sor As Integer) As Boolean
        Dim i As MatrixTomb
        For Each i In Me.l_sor_tomb
            If i.nev = l_nev And i.sor = l_sor Then
                Return True
            End If
        Next i
        Return False
    End Function

    Public Sub sor_tarolas(ByVal l_matrix_nev As String, ByVal l_sor_index As Integer, Optional ByVal l_kod As String = "")
        Static l_tomb_index As Integer = 0
        Dim l_ertek As String

        'oMatrix = m_SboForm.Items.Item(l_matrix_nev).Specific
        'oEditText = oMatrix.Columns.Item("Code").Cells.Item(l_sor_index).Specific
        l_ertek = Me.get_item_value(l_matrix_nev, "Code", l_sor_index)
        If l_sor_tomb.GetUpperBound(0) = 0 Then
            l_tomb_index = 0
        End If
        Me.l_sor_tomb(l_tomb_index).nev = l_matrix_nev
        If l_kod = "" Then
            Me.l_sor_tomb(l_tomb_index).kod = l_ertek
        Else
            Me.l_sor_tomb(l_tomb_index).kod = l_kod
        End If
        Me.l_sor_tomb(l_tomb_index).sor = l_sor_index
        Me.l_sor_tomb(l_tomb_index).torles_e = Me.l_torlse_e
        ReDim Preserve Me.l_sor_tomb(l_tomb_index + 1)
        l_tomb_index += 1
        Me.l_torlse_e = False
    End Sub

    Public Sub sortar_urites()
        ReDim Me.l_sor_tomb(0)
    End Sub

    Private Function ItemDelInList(ByVal l_nev As String, ByVal l_index As Integer, ByVal l_kod As String) As Boolean
        Dim i As Integer
        For i = l_index + 1 To Me.l_sor_tomb.GetUpperBound(0) - 1
            If l_sor_tomb(i).nev = l_nev And l_sor_tomb(i).kod = l_kod And l_sor_tomb(i).torles_e = True Then
                l_sor_tomb(i).volt_e_torles = True
                Return True
            End If
        Next i
        Return False
    End Function


    Private Function get_matrix(ByVal l_nev As String) As String
        If Me.matrix_nev <> "" Then
            Return Me.matrix_nev
        Else
            Return l_nev
        End If
    End Function

    Private Function get_tabla(ByVal l_nev As String) As String
        Dim oMatrix As SAPbouiCOM.Matrix
        Dim oColumn As SAPbouiCOM.Column
        Dim l_matrix_nev As String

        If Me.DBTable_nev <> "" Then
            Return Me.DBTable_nev
        Else
            l_matrix_nev = Me.get_matrix(l_nev)
            oMatrix = Me.m_SboForm.Items.Item(l_matrix_nev).Specific
            For Each oColumn In oMatrix.Columns
                If oColumn.DataBind.TableName <> "" Then
                    Return oColumn.DataBind.TableName
                    Exit For
                End If
            Next
        End If
    End Function

    Private Sub sorrend_ujraszamolas(ByVal l_index As Integer, ByVal irany As Integer)
        Dim i As Integer
        If irany = 1 Then
            For i = 0 To Me.l_sor_tomb.GetUpperBound(0) - 1
                If Me.l_sor_tomb(i).sor > l_index Then
                    Me.l_sor_tomb(i).sor += 1
                End If
            Next
        Else
            For i = 0 To Me.l_sor_tomb.GetUpperBound(0) - 1
                If Me.l_sor_tomb(i).sor > l_index Then
                    Me.l_sor_tomb(i).sor -= 1
                End If
            Next
        End If
    End Sub

    Private Function index_sort(ByVal oRSet As SAPbobsCOM.Recordset, ByVal p_kod As String) As Integer
        Dim l_count As Integer
        If oRSet.RecordCount > 0 Then
            oRSet.MoveFirst()
            For l_count = 1 To oRSet.RecordCount
                If oRSet.Fields.Item(0).Value = p_kod Then
                    Return l_count
                Else
                    oRSet.MoveNext()
                End If
            Next
        End If
    End Function

    Private Sub sorbarendezes(ByRef oDBDataSource As SAPbouiCOM.DBDataSource, ByVal p_item As String, ByVal p_oszlop As String, ByVal p_irany As String, Optional ByVal p_select As String = "")
        Dim oMatrix As SAPbouiCOM.Matrix
        Dim oColumn As SAPbouiCOM.Column
        Dim oRecordSet_sort As SAPbobsCOM.Recordset
        Dim oRecordSet As SAPbobsCOM.Recordset
        Dim l_count As Integer
        Dim l_kod, l_oszlop As String
        Dim l_max As Integer
        Dim l_select_sort As String
        Dim l_select As String
        Dim p_index As Integer
        Dim l_alias_nev As String
        Dim l_tabla As String

        If m_sboform.Items.Item(p_item).Type = SAPbouiCOM.BoFormItemTypes.it_MATRIX Then
            Try
                oMatrix = m_sboform.Items.Item(p_item).Specific
                l_tabla = Me.get_tabla(p_item)
                'l_tabla = Replace(l_tabla, "@", "")
                l_oszlop = Replace(oMatrix.Columns.Item(p_oszlop).DataBind.Alias, " ", "")
                oMatrix.Clear()

                oRecordSet = Me.SBO_Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                oRecordSet_sort = Me.SBO_Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

#If HANADB Then
                l_select_sort = "Select ""Code"" from """ & oDBDataSource.TableName & """ " & p_select & " order by """ & l_oszlop & """ " & p_irany & ""
#Else
                l_select_sort = "Select Code from [" & oDBDataSource.TableName & "] " & p_select & " order by " & l_oszlop & " " & p_irany & ""
#End If
                'l_select = "Select Code, Name, U_Descr from [" & oDBDataSource.TableName & "]"

                l_select = "Select "
                For Each oColumn In oMatrix.Columns
                    l_alias_nev = oColumn.DataBind.Alias
                    l_alias_nev = Replace(l_alias_nev, " ", "")
                    If l_alias_nev <> "" And oColumn.DataBind.TableName = l_tabla Then
#If HANADB Then                        l_select = l_select & """" & l_alias_nev & ""","#Else                        l_select = l_select & l_alias_nev & ","#End If                    End If                Next                l_select = l_select & "1 "#If HANADB Then                l_select = l_select & " from """ & oDBDataSource.TableName & """ " & p_select & " order by ""Code"""#Else                l_select = l_select & " from [" & oDBDataSource.TableName & "] " & p_select & " order by Code"#End If
                oRecordSet.DoQuery(l_select)
                oRecordSet_sort.DoQuery(l_select_sort)

                If oRecordSet.RecordCount <= 0 Then
                    Exit Sub
                End If

                If oRecordSet_sort.RecordCount > 0 Then
                    oRecordSet_sort.MoveFirst()
                    l_max = oRecordSet_sort.RecordCount
                    For l_count = 1 To oRecordSet_sort.RecordCount
                        l_kod = oRecordSet_sort.Fields.Item(0).Value
                        p_index = Me.index_sort(oRecordSet, l_kod)
                        oDBDataSource.Offset = p_index - 1
                        oMatrix.AddRow()
                        Me.post_query(l_count)
                        oRecordSet_sort.MoveNext()
                    Next
                End If
            Catch
                Exit Sub
            Finally
                If (Not oRecordSet_sort Is Nothing) Then
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRecordSet_sort)
                    oRecordSet_sort = Nothing
                End If

                If (Not oRecordSet Is Nothing) Then
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRecordSet)
                    oRecordSet = Nothing
                End If
            End Try
        End If

    End Sub

    Private Sub matrix_sort(ByVal p_item As String, ByVal p_oszlop As String, ByVal p_irany As String)
        Dim p_tabla As String
        Dim l_DataSource As SAPbouiCOM.DBDataSource
        Dim p_select As String
        p_tabla = Me.get_tabla(p_item)
        l_DataSource = Me.m_SboForm.DataSources.DBDataSources.Item(p_tabla)
        Me.matrix_query(l_DataSource, p_select)
        Me.sorbarendezes(l_DataSource, p_item, p_oszlop, p_irany, Me.p_where_sort)
    End Sub
#End Region

End Class