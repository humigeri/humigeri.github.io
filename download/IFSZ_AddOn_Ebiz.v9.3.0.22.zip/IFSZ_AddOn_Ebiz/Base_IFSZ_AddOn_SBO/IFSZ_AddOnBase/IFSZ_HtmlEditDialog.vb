Option Explicit On
Imports SboAddOnBase
Imports System.Reflection

'IFSZ_HtmlEditDialog: HTML Editor dial�gusablak k�l�n threadben t�rt�n� megnyit�s�ra
'  Ahonnan megh�vjuk, ott p�ld�nyos�tani kell, �s kell deleg�lni egy k�l�n elj�r�st
'  ennek a p�ld�nynak a megfelel� elj�r�s�ra (OpenFileDialog)
'  pl.:
'    Public Sub HTMLEdit()
'        Me.plOpenFileDialog.OpenFileDialog(Me)
'    End Sub
'
'  Thread-es�teni kell ezt az elj�r�st, �s az adott helyen ezt a sz�lat elind�tani
'  pl:
'    Public ShowFileDialogThread As New Threading.Thread(AddressOf ShowFileDialog)
'
'    ShowFileDialogThread.Start()
'
'  A kiv�lasztott f�jl visszajelz�se az IIFSZ_HtmlEditDialogResult interf�sz seg�ts�g�vel t�rt�nik
'  Legjobb a h�v� formra be�ll�tani, hogy implement�lja ezt az interf�szt, �s ott tudjuk
'  defini�lni azt a k�dot, ami lefut


Public Class IFSZ_HtmlEditDialog





#Region "Variables"    Protected m_Company As Object 'As SAPbobsCOM.Company
    Protected m_ParentAddon As Object 'As SBOAddOn
    Public Enum enEditorType
        HTML
        RTF
    End Enum

    Public Shared m_EditorType As enEditorType = enEditorType.HTML





#End Region












#Region "Constructor"    Public Sub New(ByRef ParentAddon As Object)        m_ParentAddon = ParentAddon        If Not m_ParentAddon Is Nothing Then            If m_ParentAddon.GetType.Name = "IFSZ_Addon" Then                m_Company = ParentAddon.SboCompany            End If        End If    End Sub    Public Sub New()
    End Sub


































#End Region
#Region "Properties"
#End Region
#Region "public"    Public Sub OpenHTMLEditDialog(ByRef p_addon As IFSZ_Addon_Keret, ByVal p_html_ertek As String, ByVal p_html_hossz As Integer, ByVal p_html_default As String, Optional ByVal pMyProc As Process = Nothing)

        'Dim lDlg As IFSZ_DNET_HTMLEditor = New IFSZ_DNET_HTMLEditor(p_html_ertek, p_html_hossz)
        Dim lDlg As Object
        Dim l_MyProc As Process

        Try
            If IFSZ_HtmlEditDialog.m_EditorType = enEditorType.HTML Then
                lDlg = Assembly.GetExecutingAssembly.CreateInstance("IFSZ_AddOnBase.IFSZ_DNET_HTMLEditor", True, BindingFlags.Public Or BindingFlags.Instance Or BindingFlags.CreateInstance, Nothing, New Object() {p_html_ertek, p_html_hossz, p_html_default}, Nothing, Nothing)
            Else
                lDlg = Assembly.GetExecutingAssembly.CreateInstance("IFSZ_AddOnBase.IFSZ_DNET_RTFProc", True, BindingFlags.Public Or BindingFlags.Instance Or BindingFlags.CreateInstance, Nothing, New Object() {p_html_ertek, p_html_hossz, p_html_default}, Nothing, Nothing)
            End If

            If pMyProc Is Nothing Then
                If Not m_ParentAddon Is Nothing Then
                    If m_ParentAddon.GetType.Name = "IFSZ_Addon" Then
                        l_MyProc = IFSZ_Globals.GetSBOProc()
                        If l_MyProc Is Nothing Then
                            m_ParentAddon.SboApplication.MessageBox("No SBO instances found.")
                        End If
                    End If
                Else
                    l_MyProc = IFSZ_Globals.GetMyProc()
                    If l_MyProc Is Nothing Then
                        '"No SBO instances found."
                        MessageBox.Show("No ParentAddon Found!")
                        Exit Sub
                    End If
                End If
            Else
                l_MyProc = pMyProc
            End If

            Dim MyWindow As New WindowWrapper(l_MyProc.MainWindowHandle)

            If lDlg.ShowDialog(MyWindow) = DialogResult.OK Then
                p_addon.SetHTMLCode(lDlg.m_html_code)
                Return
                'End If
            End If

        Finally
            'Me.m_ParentAddon.SboApplication.Desktop.Title = strOriginalTitle
        End Try

    End Sub



#End Region
End Class