﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class IFSZ_DNET_HTMLEditor
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(IFSZ_DNET_HTMLEditor))
        Me.AxWebBrowser1 = New AxSHDocVw.AxWebBrowser()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OKToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CancelToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewSourceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UndoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RedoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PasteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InsertToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PictureToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UnorderedListToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OrderedListToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FormatToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BoldToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ItalicToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UnderLineToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.IndentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OutdentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator8 = New System.Windows.Forms.ToolStripSeparator()
        Me.FontNameToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FontSizeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AlignToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LeftToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CenterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RightToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.JustifyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator()
        Me.ForeColorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FCBlackToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FCSilverToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FCGrayToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FCWhiteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FCMaroonToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FCRedToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FCPurpleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FCFuchsiaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FCGreenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FCLimeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FCOliveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FCYellowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FCNavyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FCBlueToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FCTealToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FCAquaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BackColorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BCBlackToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BCSilverToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BCGrayToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BCWhiteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BCMaroonToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BCRedToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BCPurpleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BCFuchsiaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BCGreenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BCLimeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BCOliveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BCYellowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BCNavyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BCBlueToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BCTealToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BCAquaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.OKToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.UndoToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.RedoToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.BoldToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.ItalicToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.UnderlineToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.FontNameToolStripComboBox = New System.Windows.Forms.ToolStripComboBox()
        Me.FontSizeToolStripComboBox = New System.Windows.Forms.ToolStripComboBox()
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.JustifyLeftToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.JustifyCenterToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.JustifyRightToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.JustifyFillToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator()
        Me.PictureToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.UnorderedListToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.OrderedListToolStripButton = New System.Windows.Forms.ToolStripButton()
        CType(Me.AxWebBrowser1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'AxWebBrowser1
        '
        Me.AxWebBrowser1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.AxWebBrowser1.Enabled = True
        Me.AxWebBrowser1.Location = New System.Drawing.Point(12, 52)
        Me.AxWebBrowser1.OcxState = CType(resources.GetObject("AxWebBrowser1.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxWebBrowser1.Size = New System.Drawing.Size(801, 419)
        Me.AxWebBrowser1.TabIndex = 0
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.EditToolStripMenuItem, Me.InsertToolStripMenuItem, Me.FormatToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(825, 24)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OKToolStripMenuItem, Me.CancelToolStripMenuItem, Me.ViewSourceToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "Fájl"
        '
        'OKToolStripMenuItem
        '
        Me.OKToolStripMenuItem.Name = "OKToolStripMenuItem"
        Me.OKToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.OKToolStripMenuItem.Text = "OK"
        '
        'CancelToolStripMenuItem
        '
        Me.CancelToolStripMenuItem.Name = "CancelToolStripMenuItem"
        Me.CancelToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.CancelToolStripMenuItem.Text = "Mégsem"
        '
        'ViewSourceToolStripMenuItem
        '
        Me.ViewSourceToolStripMenuItem.Name = "ViewSourceToolStripMenuItem"
        Me.ViewSourceToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.ViewSourceToolStripMenuItem.Text = "Forrás megtekintése"
        '
        'EditToolStripMenuItem
        '
        Me.EditToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.UndoToolStripMenuItem, Me.RedoToolStripMenuItem, Me.CutToolStripMenuItem, Me.CopyToolStripMenuItem, Me.PasteToolStripMenuItem})
        Me.EditToolStripMenuItem.Name = "EditToolStripMenuItem"
        Me.EditToolStripMenuItem.Size = New System.Drawing.Size(77, 20)
        Me.EditToolStripMenuItem.Text = "Szerkesztés"
        '
        'UndoToolStripMenuItem
        '
        Me.UndoToolStripMenuItem.Name = "UndoToolStripMenuItem"
        Me.UndoToolStripMenuItem.Size = New System.Drawing.Size(127, 22)
        Me.UndoToolStripMenuItem.Text = "Visszavon"
        '
        'RedoToolStripMenuItem
        '
        Me.RedoToolStripMenuItem.Name = "RedoToolStripMenuItem"
        Me.RedoToolStripMenuItem.Size = New System.Drawing.Size(127, 22)
        Me.RedoToolStripMenuItem.Text = "Újra"
        '
        'CutToolStripMenuItem
        '
        Me.CutToolStripMenuItem.Name = "CutToolStripMenuItem"
        Me.CutToolStripMenuItem.Size = New System.Drawing.Size(127, 22)
        Me.CutToolStripMenuItem.Text = "Kivágás"
        '
        'CopyToolStripMenuItem
        '
        Me.CopyToolStripMenuItem.Name = "CopyToolStripMenuItem"
        Me.CopyToolStripMenuItem.Size = New System.Drawing.Size(127, 22)
        Me.CopyToolStripMenuItem.Text = "Másolás"
        '
        'PasteToolStripMenuItem
        '
        Me.PasteToolStripMenuItem.Name = "PasteToolStripMenuItem"
        Me.PasteToolStripMenuItem.Size = New System.Drawing.Size(127, 22)
        Me.PasteToolStripMenuItem.Text = "Beillesztés"
        '
        'InsertToolStripMenuItem
        '
        Me.InsertToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PictureToolStripMenuItem, Me.UnorderedListToolStripMenuItem, Me.OrderedListToolStripMenuItem})
        Me.InsertToolStripMenuItem.Name = "InsertToolStripMenuItem"
        Me.InsertToolStripMenuItem.Size = New System.Drawing.Size(64, 20)
        Me.InsertToolStripMenuItem.Text = "Beszúrás"
        '
        'PictureToolStripMenuItem
        '
        Me.PictureToolStripMenuItem.Name = "PictureToolStripMenuItem"
        Me.PictureToolStripMenuItem.Size = New System.Drawing.Size(153, 22)
        Me.PictureToolStripMenuItem.Text = "Kép"
        '
        'UnorderedListToolStripMenuItem
        '
        Me.UnorderedListToolStripMenuItem.Name = "UnorderedListToolStripMenuItem"
        Me.UnorderedListToolStripMenuItem.Size = New System.Drawing.Size(153, 22)
        Me.UnorderedListToolStripMenuItem.Text = "Lista"
        '
        'OrderedListToolStripMenuItem
        '
        Me.OrderedListToolStripMenuItem.Name = "OrderedListToolStripMenuItem"
        Me.OrderedListToolStripMenuItem.Size = New System.Drawing.Size(153, 22)
        Me.OrderedListToolStripMenuItem.Text = "Számozott lista"
        '
        'FormatToolStripMenuItem
        '
        Me.FormatToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BoldToolStripMenuItem, Me.ItalicToolStripMenuItem, Me.UnderLineToolStripMenuItem, Me.ToolStripSeparator3, Me.IndentToolStripMenuItem, Me.OutdentToolStripMenuItem, Me.ToolStripSeparator8, Me.FontNameToolStripMenuItem, Me.FontSizeToolStripMenuItem, Me.AlignToolStripMenuItem, Me.ToolStripSeparator7, Me.ForeColorToolStripMenuItem, Me.BackColorToolStripMenuItem})
        Me.FormatToolStripMenuItem.Name = "FormatToolStripMenuItem"
        Me.FormatToolStripMenuItem.Size = New System.Drawing.Size(69, 20)
        Me.FormatToolStripMenuItem.Text = "Formázás"
        '
        'BoldToolStripMenuItem
        '
        Me.BoldToolStripMenuItem.Name = "BoldToolStripMenuItem"
        Me.BoldToolStripMenuItem.Size = New System.Drawing.Size(184, 22)
        Me.BoldToolStripMenuItem.Text = "Félkövér"
        '
        'ItalicToolStripMenuItem
        '
        Me.ItalicToolStripMenuItem.Name = "ItalicToolStripMenuItem"
        Me.ItalicToolStripMenuItem.Size = New System.Drawing.Size(184, 22)
        Me.ItalicToolStripMenuItem.Text = "Dőlt"
        '
        'UnderLineToolStripMenuItem
        '
        Me.UnderLineToolStripMenuItem.Name = "UnderLineToolStripMenuItem"
        Me.UnderLineToolStripMenuItem.Size = New System.Drawing.Size(184, 22)
        Me.UnderLineToolStripMenuItem.Text = "Aláhúzott"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(181, 6)
        '
        'IndentToolStripMenuItem
        '
        Me.IndentToolStripMenuItem.Name = "IndentToolStripMenuItem"
        Me.IndentToolStripMenuItem.Size = New System.Drawing.Size(184, 22)
        Me.IndentToolStripMenuItem.Text = "Behúzás növelése"
        '
        'OutdentToolStripMenuItem
        '
        Me.OutdentToolStripMenuItem.Name = "OutdentToolStripMenuItem"
        Me.OutdentToolStripMenuItem.Size = New System.Drawing.Size(184, 22)
        Me.OutdentToolStripMenuItem.Text = "Behúzás csökkentése"
        '
        'ToolStripSeparator8
        '
        Me.ToolStripSeparator8.Name = "ToolStripSeparator8"
        Me.ToolStripSeparator8.Size = New System.Drawing.Size(181, 6)
        '
        'FontNameToolStripMenuItem
        '
        Me.FontNameToolStripMenuItem.Name = "FontNameToolStripMenuItem"
        Me.FontNameToolStripMenuItem.Size = New System.Drawing.Size(184, 22)
        Me.FontNameToolStripMenuItem.Text = "Betűtípus"
        '
        'FontSizeToolStripMenuItem
        '
        Me.FontSizeToolStripMenuItem.Name = "FontSizeToolStripMenuItem"
        Me.FontSizeToolStripMenuItem.Size = New System.Drawing.Size(184, 22)
        Me.FontSizeToolStripMenuItem.Text = "Betűméret"
        '
        'AlignToolStripMenuItem
        '
        Me.AlignToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LeftToolStripMenuItem, Me.CenterToolStripMenuItem, Me.RightToolStripMenuItem, Me.JustifyToolStripMenuItem})
        Me.AlignToolStripMenuItem.Name = "AlignToolStripMenuItem"
        Me.AlignToolStripMenuItem.Size = New System.Drawing.Size(184, 22)
        Me.AlignToolStripMenuItem.Text = "Igazítás"
        '
        'LeftToolStripMenuItem
        '
        Me.LeftToolStripMenuItem.Name = "LeftToolStripMenuItem"
        Me.LeftToolStripMenuItem.Size = New System.Drawing.Size(126, 22)
        Me.LeftToolStripMenuItem.Text = "Balra"
        '
        'CenterToolStripMenuItem
        '
        Me.CenterToolStripMenuItem.Name = "CenterToolStripMenuItem"
        Me.CenterToolStripMenuItem.Size = New System.Drawing.Size(126, 22)
        Me.CenterToolStripMenuItem.Text = "Középre"
        '
        'RightToolStripMenuItem
        '
        Me.RightToolStripMenuItem.Name = "RightToolStripMenuItem"
        Me.RightToolStripMenuItem.Size = New System.Drawing.Size(126, 22)
        Me.RightToolStripMenuItem.Text = "Jobbra"
        '
        'JustifyToolStripMenuItem
        '
        Me.JustifyToolStripMenuItem.Name = "JustifyToolStripMenuItem"
        Me.JustifyToolStripMenuItem.Size = New System.Drawing.Size(126, 22)
        Me.JustifyToolStripMenuItem.Text = "Sorkizárás"
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(181, 6)
        '
        'ForeColorToolStripMenuItem
        '
        Me.ForeColorToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FCBlackToolStripMenuItem, Me.FCSilverToolStripMenuItem, Me.FCGrayToolStripMenuItem, Me.FCWhiteToolStripMenuItem, Me.FCMaroonToolStripMenuItem, Me.FCRedToolStripMenuItem, Me.FCPurpleToolStripMenuItem, Me.FCFuchsiaToolStripMenuItem, Me.FCGreenToolStripMenuItem, Me.FCLimeToolStripMenuItem, Me.FCOliveToolStripMenuItem, Me.FCYellowToolStripMenuItem, Me.FCNavyToolStripMenuItem, Me.FCBlueToolStripMenuItem, Me.FCTealToolStripMenuItem, Me.FCAquaToolStripMenuItem})
        Me.ForeColorToolStripMenuItem.Name = "ForeColorToolStripMenuItem"
        Me.ForeColorToolStripMenuItem.Size = New System.Drawing.Size(184, 22)
        Me.ForeColorToolStripMenuItem.Text = "Szín"
        '
        'FCBlackToolStripMenuItem
        '
        Me.FCBlackToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.FCBlackToolStripMenuItem.Name = "FCBlackToolStripMenuItem"
        Me.FCBlackToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.FCBlackToolStripMenuItem.Text = "Fekete"
        '
        'FCSilverToolStripMenuItem
        '
        Me.FCSilverToolStripMenuItem.ForeColor = System.Drawing.Color.Silver
        Me.FCSilverToolStripMenuItem.Name = "FCSilverToolStripMenuItem"
        Me.FCSilverToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.FCSilverToolStripMenuItem.Text = "Ezüst"
        '
        'FCGrayToolStripMenuItem
        '
        Me.FCGrayToolStripMenuItem.ForeColor = System.Drawing.Color.Gray
        Me.FCGrayToolStripMenuItem.Name = "FCGrayToolStripMenuItem"
        Me.FCGrayToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.FCGrayToolStripMenuItem.Text = "Szürke"
        '
        'FCWhiteToolStripMenuItem
        '
        Me.FCWhiteToolStripMenuItem.BackColor = System.Drawing.Color.DarkGray
        Me.FCWhiteToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.FCWhiteToolStripMenuItem.Name = "FCWhiteToolStripMenuItem"
        Me.FCWhiteToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.FCWhiteToolStripMenuItem.Text = "Fehér"
        '
        'FCMaroonToolStripMenuItem
        '
        Me.FCMaroonToolStripMenuItem.ForeColor = System.Drawing.Color.Maroon
        Me.FCMaroonToolStripMenuItem.Name = "FCMaroonToolStripMenuItem"
        Me.FCMaroonToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.FCMaroonToolStripMenuItem.Text = "Gesztenyebarna"
        '
        'FCRedToolStripMenuItem
        '
        Me.FCRedToolStripMenuItem.ForeColor = System.Drawing.Color.Red
        Me.FCRedToolStripMenuItem.Name = "FCRedToolStripMenuItem"
        Me.FCRedToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.FCRedToolStripMenuItem.Text = "Piros"
        '
        'FCPurpleToolStripMenuItem
        '
        Me.FCPurpleToolStripMenuItem.ForeColor = System.Drawing.Color.Purple
        Me.FCPurpleToolStripMenuItem.Name = "FCPurpleToolStripMenuItem"
        Me.FCPurpleToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.FCPurpleToolStripMenuItem.Text = "Lila"
        '
        'FCFuchsiaToolStripMenuItem
        '
        Me.FCFuchsiaToolStripMenuItem.ForeColor = System.Drawing.Color.Fuchsia
        Me.FCFuchsiaToolStripMenuItem.Name = "FCFuchsiaToolStripMenuItem"
        Me.FCFuchsiaToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.FCFuchsiaToolStripMenuItem.Text = "Fukszia"
        '
        'FCGreenToolStripMenuItem
        '
        Me.FCGreenToolStripMenuItem.ForeColor = System.Drawing.Color.Green
        Me.FCGreenToolStripMenuItem.Name = "FCGreenToolStripMenuItem"
        Me.FCGreenToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.FCGreenToolStripMenuItem.Text = "Zöld"
        '
        'FCLimeToolStripMenuItem
        '
        Me.FCLimeToolStripMenuItem.ForeColor = System.Drawing.Color.Lime
        Me.FCLimeToolStripMenuItem.Name = "FCLimeToolStripMenuItem"
        Me.FCLimeToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.FCLimeToolStripMenuItem.Text = "Lime"
        '
        'FCOliveToolStripMenuItem
        '
        Me.FCOliveToolStripMenuItem.ForeColor = System.Drawing.Color.Olive
        Me.FCOliveToolStripMenuItem.Name = "FCOliveToolStripMenuItem"
        Me.FCOliveToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.FCOliveToolStripMenuItem.Text = "Oliva"
        '
        'FCYellowToolStripMenuItem
        '
        Me.FCYellowToolStripMenuItem.ForeColor = System.Drawing.Color.Yellow
        Me.FCYellowToolStripMenuItem.Name = "FCYellowToolStripMenuItem"
        Me.FCYellowToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.FCYellowToolStripMenuItem.Text = "Sárga"
        '
        'FCNavyToolStripMenuItem
        '
        Me.FCNavyToolStripMenuItem.ForeColor = System.Drawing.Color.Navy
        Me.FCNavyToolStripMenuItem.Name = "FCNavyToolStripMenuItem"
        Me.FCNavyToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.FCNavyToolStripMenuItem.Text = "Tengerészkék"
        '
        'FCBlueToolStripMenuItem
        '
        Me.FCBlueToolStripMenuItem.ForeColor = System.Drawing.Color.Blue
        Me.FCBlueToolStripMenuItem.Name = "FCBlueToolStripMenuItem"
        Me.FCBlueToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.FCBlueToolStripMenuItem.Text = "Kék"
        '
        'FCTealToolStripMenuItem
        '
        Me.FCTealToolStripMenuItem.ForeColor = System.Drawing.Color.Teal
        Me.FCTealToolStripMenuItem.Name = "FCTealToolStripMenuItem"
        Me.FCTealToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.FCTealToolStripMenuItem.Text = "Zöldeskék"
        '
        'FCAquaToolStripMenuItem
        '
        Me.FCAquaToolStripMenuItem.ForeColor = System.Drawing.Color.Aqua
        Me.FCAquaToolStripMenuItem.Name = "FCAquaToolStripMenuItem"
        Me.FCAquaToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.FCAquaToolStripMenuItem.Text = "Aqua"
        '
        'BackColorToolStripMenuItem
        '
        Me.BackColorToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BCBlackToolStripMenuItem, Me.BCSilverToolStripMenuItem, Me.BCGrayToolStripMenuItem, Me.BCWhiteToolStripMenuItem, Me.BCMaroonToolStripMenuItem, Me.BCRedToolStripMenuItem, Me.BCPurpleToolStripMenuItem, Me.BCFuchsiaToolStripMenuItem, Me.BCGreenToolStripMenuItem, Me.BCLimeToolStripMenuItem, Me.BCOliveToolStripMenuItem, Me.BCYellowToolStripMenuItem, Me.BCNavyToolStripMenuItem, Me.BCBlueToolStripMenuItem, Me.BCTealToolStripMenuItem, Me.BCAquaToolStripMenuItem})
        Me.BackColorToolStripMenuItem.Name = "BackColorToolStripMenuItem"
        Me.BackColorToolStripMenuItem.Size = New System.Drawing.Size(184, 22)
        Me.BackColorToolStripMenuItem.Text = "Háttérszín"
        '
        'BCBlackToolStripMenuItem
        '
        Me.BCBlackToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.BCBlackToolStripMenuItem.Name = "BCBlackToolStripMenuItem"
        Me.BCBlackToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.BCBlackToolStripMenuItem.Text = "Fekete"
        '
        'BCSilverToolStripMenuItem
        '
        Me.BCSilverToolStripMenuItem.ForeColor = System.Drawing.Color.Silver
        Me.BCSilverToolStripMenuItem.Name = "BCSilverToolStripMenuItem"
        Me.BCSilverToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.BCSilverToolStripMenuItem.Text = "Ezüst"
        '
        'BCGrayToolStripMenuItem
        '
        Me.BCGrayToolStripMenuItem.ForeColor = System.Drawing.Color.Gray
        Me.BCGrayToolStripMenuItem.Name = "BCGrayToolStripMenuItem"
        Me.BCGrayToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.BCGrayToolStripMenuItem.Text = "Szürke"
        '
        'BCWhiteToolStripMenuItem
        '
        Me.BCWhiteToolStripMenuItem.BackColor = System.Drawing.Color.DarkGray
        Me.BCWhiteToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.BCWhiteToolStripMenuItem.Name = "BCWhiteToolStripMenuItem"
        Me.BCWhiteToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.BCWhiteToolStripMenuItem.Text = "Fehér"
        '
        'BCMaroonToolStripMenuItem
        '
        Me.BCMaroonToolStripMenuItem.ForeColor = System.Drawing.Color.Maroon
        Me.BCMaroonToolStripMenuItem.Name = "BCMaroonToolStripMenuItem"
        Me.BCMaroonToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.BCMaroonToolStripMenuItem.Text = "Gesztenyebarna"
        '
        'BCRedToolStripMenuItem
        '
        Me.BCRedToolStripMenuItem.ForeColor = System.Drawing.Color.Red
        Me.BCRedToolStripMenuItem.Name = "BCRedToolStripMenuItem"
        Me.BCRedToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.BCRedToolStripMenuItem.Text = "Piros"
        '
        'BCPurpleToolStripMenuItem
        '
        Me.BCPurpleToolStripMenuItem.ForeColor = System.Drawing.Color.Purple
        Me.BCPurpleToolStripMenuItem.Name = "BCPurpleToolStripMenuItem"
        Me.BCPurpleToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.BCPurpleToolStripMenuItem.Text = "Lila"
        '
        'BCFuchsiaToolStripMenuItem
        '
        Me.BCFuchsiaToolStripMenuItem.ForeColor = System.Drawing.Color.Fuchsia
        Me.BCFuchsiaToolStripMenuItem.Name = "BCFuchsiaToolStripMenuItem"
        Me.BCFuchsiaToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.BCFuchsiaToolStripMenuItem.Text = "Fukszia"
        '
        'BCGreenToolStripMenuItem
        '
        Me.BCGreenToolStripMenuItem.ForeColor = System.Drawing.Color.Green
        Me.BCGreenToolStripMenuItem.Name = "BCGreenToolStripMenuItem"
        Me.BCGreenToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.BCGreenToolStripMenuItem.Text = "Zöld"
        '
        'BCLimeToolStripMenuItem
        '
        Me.BCLimeToolStripMenuItem.ForeColor = System.Drawing.Color.Lime
        Me.BCLimeToolStripMenuItem.Name = "BCLimeToolStripMenuItem"
        Me.BCLimeToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.BCLimeToolStripMenuItem.Text = "Lime"
        '
        'BCOliveToolStripMenuItem
        '
        Me.BCOliveToolStripMenuItem.ForeColor = System.Drawing.Color.Olive
        Me.BCOliveToolStripMenuItem.Name = "BCOliveToolStripMenuItem"
        Me.BCOliveToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.BCOliveToolStripMenuItem.Text = "Oliva"
        '
        'BCYellowToolStripMenuItem
        '
        Me.BCYellowToolStripMenuItem.ForeColor = System.Drawing.Color.Yellow
        Me.BCYellowToolStripMenuItem.Name = "BCYellowToolStripMenuItem"
        Me.BCYellowToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.BCYellowToolStripMenuItem.Text = "Sárga"
        '
        'BCNavyToolStripMenuItem
        '
        Me.BCNavyToolStripMenuItem.ForeColor = System.Drawing.Color.Navy
        Me.BCNavyToolStripMenuItem.Name = "BCNavyToolStripMenuItem"
        Me.BCNavyToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.BCNavyToolStripMenuItem.Text = "Tengerészkék"
        '
        'BCBlueToolStripMenuItem
        '
        Me.BCBlueToolStripMenuItem.ForeColor = System.Drawing.Color.Blue
        Me.BCBlueToolStripMenuItem.Name = "BCBlueToolStripMenuItem"
        Me.BCBlueToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.BCBlueToolStripMenuItem.Text = "Kék"
        '
        'BCTealToolStripMenuItem
        '
        Me.BCTealToolStripMenuItem.ForeColor = System.Drawing.Color.Teal
        Me.BCTealToolStripMenuItem.Name = "BCTealToolStripMenuItem"
        Me.BCTealToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.BCTealToolStripMenuItem.Text = "Zöldeskék"
        '
        'BCAquaToolStripMenuItem
        '
        Me.BCAquaToolStripMenuItem.ForeColor = System.Drawing.Color.Aqua
        Me.BCAquaToolStripMenuItem.Name = "BCAquaToolStripMenuItem"
        Me.BCAquaToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.BCAquaToolStripMenuItem.Text = "Aqua"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OKToolStripButton, Me.ToolStripSeparator1, Me.UndoToolStripButton, Me.RedoToolStripButton, Me.ToolStripSeparator2, Me.BoldToolStripButton, Me.ItalicToolStripButton, Me.UnderlineToolStripButton, Me.ToolStripSeparator4, Me.FontNameToolStripComboBox, Me.FontSizeToolStripComboBox, Me.ToolStripSeparator5, Me.JustifyLeftToolStripButton, Me.JustifyCenterToolStripButton, Me.JustifyRightToolStripButton, Me.JustifyFillToolStripButton, Me.ToolStripSeparator6, Me.PictureToolStripButton, Me.UnorderedListToolStripButton, Me.OrderedListToolStripButton})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 24)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(825, 25)
        Me.ToolStrip1.TabIndex = 2
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'OKToolStripButton
        '
        Me.OKToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.OKToolStripButton.Image = Global.IFSZ_AddOnBase.My.Resources.Resources.icon_accept
        Me.OKToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.OKToolStripButton.Name = "OKToolStripButton"
        Me.OKToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.OKToolStripButton.Text = "OKToolStripButton"
        Me.OKToolStripButton.ToolTipText = "OK"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'UndoToolStripButton
        '
        Me.UndoToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.UndoToolStripButton.Image = CType(resources.GetObject("UndoToolStripButton.Image"), System.Drawing.Image)
        Me.UndoToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.UndoToolStripButton.Name = "UndoToolStripButton"
        Me.UndoToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.UndoToolStripButton.Text = "UndoToolStripButton"
        Me.UndoToolStripButton.ToolTipText = "Visszavonás"
        '
        'RedoToolStripButton
        '
        Me.RedoToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.RedoToolStripButton.Image = CType(resources.GetObject("RedoToolStripButton.Image"), System.Drawing.Image)
        Me.RedoToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.RedoToolStripButton.Name = "RedoToolStripButton"
        Me.RedoToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.RedoToolStripButton.Text = "RedoToolStripButton"
        Me.RedoToolStripButton.ToolTipText = "Újra"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'BoldToolStripButton
        '
        Me.BoldToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BoldToolStripButton.Image = CType(resources.GetObject("BoldToolStripButton.Image"), System.Drawing.Image)
        Me.BoldToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.BoldToolStripButton.Name = "BoldToolStripButton"
        Me.BoldToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.BoldToolStripButton.Text = "BoldToolStripButton"
        Me.BoldToolStripButton.ToolTipText = "Félkövér"
        '
        'ItalicToolStripButton
        '
        Me.ItalicToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ItalicToolStripButton.Image = CType(resources.GetObject("ItalicToolStripButton.Image"), System.Drawing.Image)
        Me.ItalicToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ItalicToolStripButton.Name = "ItalicToolStripButton"
        Me.ItalicToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.ItalicToolStripButton.Text = "ItalicToolStripButton"
        Me.ItalicToolStripButton.ToolTipText = "Dőlt"
        '
        'UnderlineToolStripButton
        '
        Me.UnderlineToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.UnderlineToolStripButton.Image = CType(resources.GetObject("UnderlineToolStripButton.Image"), System.Drawing.Image)
        Me.UnderlineToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.UnderlineToolStripButton.Name = "UnderlineToolStripButton"
        Me.UnderlineToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.UnderlineToolStripButton.Text = "UnderlineToolStripButton"
        Me.UnderlineToolStripButton.ToolTipText = "Aláhúzott"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(6, 25)
        '
        'FontNameToolStripComboBox
        '
        Me.FontNameToolStripComboBox.Name = "FontNameToolStripComboBox"
        Me.FontNameToolStripComboBox.Size = New System.Drawing.Size(121, 25)
        Me.FontNameToolStripComboBox.ToolTipText = "Betűtípus"
        '
        'FontSizeToolStripComboBox
        '
        Me.FontSizeToolStripComboBox.Name = "FontSizeToolStripComboBox"
        Me.FontSizeToolStripComboBox.Size = New System.Drawing.Size(75, 25)
        Me.FontSizeToolStripComboBox.ToolTipText = "Betűméret"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(6, 25)
        '
        'JustifyLeftToolStripButton
        '
        Me.JustifyLeftToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.JustifyLeftToolStripButton.Image = CType(resources.GetObject("JustifyLeftToolStripButton.Image"), System.Drawing.Image)
        Me.JustifyLeftToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.JustifyLeftToolStripButton.Name = "JustifyLeftToolStripButton"
        Me.JustifyLeftToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.JustifyLeftToolStripButton.Text = "ToolStripButton1"
        Me.JustifyLeftToolStripButton.ToolTipText = "Balra igazítás"
        '
        'JustifyCenterToolStripButton
        '
        Me.JustifyCenterToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.JustifyCenterToolStripButton.Image = CType(resources.GetObject("JustifyCenterToolStripButton.Image"), System.Drawing.Image)
        Me.JustifyCenterToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.JustifyCenterToolStripButton.Name = "JustifyCenterToolStripButton"
        Me.JustifyCenterToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.JustifyCenterToolStripButton.Text = "ToolStripButton2"
        Me.JustifyCenterToolStripButton.ToolTipText = "Középre igazítás"
        '
        'JustifyRightToolStripButton
        '
        Me.JustifyRightToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.JustifyRightToolStripButton.Image = CType(resources.GetObject("JustifyRightToolStripButton.Image"), System.Drawing.Image)
        Me.JustifyRightToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.JustifyRightToolStripButton.Name = "JustifyRightToolStripButton"
        Me.JustifyRightToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.JustifyRightToolStripButton.Text = "ToolStripButton3"
        Me.JustifyRightToolStripButton.ToolTipText = "Jobbra igazít"
        '
        'JustifyFillToolStripButton
        '
        Me.JustifyFillToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.JustifyFillToolStripButton.Image = CType(resources.GetObject("JustifyFillToolStripButton.Image"), System.Drawing.Image)
        Me.JustifyFillToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.JustifyFillToolStripButton.Name = "JustifyFillToolStripButton"
        Me.JustifyFillToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.JustifyFillToolStripButton.Text = "ToolStripButton4"
        Me.JustifyFillToolStripButton.ToolTipText = "Jobbra igazít"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(6, 25)
        '
        'PictureToolStripButton
        '
        Me.PictureToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.PictureToolStripButton.Image = CType(resources.GetObject("PictureToolStripButton.Image"), System.Drawing.Image)
        Me.PictureToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.PictureToolStripButton.Name = "PictureToolStripButton"
        Me.PictureToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.PictureToolStripButton.Text = "Kép beszúrása"
        '
        'UnorderedListToolStripButton
        '
        Me.UnorderedListToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.UnorderedListToolStripButton.Image = CType(resources.GetObject("UnorderedListToolStripButton.Image"), System.Drawing.Image)
        Me.UnorderedListToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.UnorderedListToolStripButton.Name = "UnorderedListToolStripButton"
        Me.UnorderedListToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.UnorderedListToolStripButton.Text = "UnorderedListToolStripButton"
        Me.UnorderedListToolStripButton.ToolTipText = "Lista"
        '
        'OrderedListToolStripButton
        '
        Me.OrderedListToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.OrderedListToolStripButton.Image = CType(resources.GetObject("OrderedListToolStripButton.Image"), System.Drawing.Image)
        Me.OrderedListToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.OrderedListToolStripButton.Name = "OrderedListToolStripButton"
        Me.OrderedListToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.OrderedListToolStripButton.Text = "ToolStripButton2"
        Me.OrderedListToolStripButton.ToolTipText = "Számozott lista"
        '
        'IFSZ_DNET_HTMLEditor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(825, 483)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.AxWebBrowser1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "IFSZ_DNET_HTMLEditor"
        Me.Text = "HTML szerkesztő"
        CType(Me.AxWebBrowser1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents AxWebBrowser1 As AxSHDocVw.AxWebBrowser
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OKToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CancelToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EditToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CopyToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents OKToolStripButton As ToolStripButton
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents UndoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RedoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ViewSourceToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PasteToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents InsertToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FormatToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BoldToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ItalicToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents UnderLineToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As ToolStripSeparator
    Friend WithEvents FontNameToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FontSizeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AlignToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LeftToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CenterToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RightToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents JustifyToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents UndoToolStripButton As ToolStripButton
    Friend WithEvents RedoToolStripButton As ToolStripButton
    Friend WithEvents ToolStripSeparator2 As ToolStripSeparator
    Friend WithEvents BoldToolStripButton As ToolStripButton
    Friend WithEvents ItalicToolStripButton As ToolStripButton
    Friend WithEvents UnderlineToolStripButton As ToolStripButton
    Friend WithEvents ToolStripSeparator4 As ToolStripSeparator
    Friend WithEvents FontNameToolStripComboBox As ToolStripComboBox
    Friend WithEvents FontSizeToolStripComboBox As ToolStripComboBox
    Friend WithEvents ToolStripSeparator5 As ToolStripSeparator
    Friend WithEvents JustifyLeftToolStripButton As ToolStripButton
    Friend WithEvents JustifyCenterToolStripButton As ToolStripButton
    Friend WithEvents JustifyRightToolStripButton As ToolStripButton
    Friend WithEvents JustifyFillToolStripButton As ToolStripButton
    Friend WithEvents PictureToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator6 As ToolStripSeparator
    Friend WithEvents PictureToolStripButton As ToolStripButton
    Friend WithEvents UnorderedListToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OrderedListToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents UnorderedListToolStripButton As ToolStripButton
    Friend WithEvents OrderedListToolStripButton As ToolStripButton
    Friend WithEvents ToolStripSeparator7 As ToolStripSeparator
    Friend WithEvents ForeColorToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FCBlackToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FCSilverToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FCGrayToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FCWhiteToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FCMaroonToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FCRedToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FCPurpleToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FCFuchsiaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FCGreenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FCLimeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FCOliveToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FCYellowToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FCNavyToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FCBlueToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FCTealToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FCAquaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BCBlackToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BCSilverToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BCGrayToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BCWhiteToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BCMaroonToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BCRedToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BCPurpleToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BCFuchsiaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BCGreenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BCLimeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BCOliveToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BCYellowToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BCNavyToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BCBlueToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BCTealToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BCAquaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BackColorToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents IndentToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OutdentToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator8 As ToolStripSeparator
End Class
