﻿Public Class IFSZ_DNET_RTFProc

    Public Shared m_rtf_editor As String = ""
    Public Shared m_rtf_argument As String = ""

    Public m_html_code As String = ""
    Public m_html_hossz As Integer = 0
    Public m_html_default As String = ""

    Private m_torlendo_fajl As String = ""

    Public Sub New(ByVal p_html As String, ByVal p_html_hossz As Integer, ByVal p_html_default As String)

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        m_html_code = p_html
        m_html_hossz = p_html_hossz
        m_html_default = p_html_default

    End Sub

    Private Sub IFSZ_DNET_RTFProc_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Show()
        Dim l_fajl As String
        Try
            Me.GetNextRTFFileName(l_fajl)
        Catch ex As Exception
            MsgBox(ex.Message)
            Me.Close()
            Exit Sub
        End Try

        m_torlendo_fajl = l_fajl

        If String.IsNullOrEmpty(m_html_code) Then
            If String.IsNullOrEmpty(m_html_default) Then
                Using sw As New System.IO.StreamWriter(System.IO.File.Open(l_fajl, System.IO.FileMode.OpenOrCreate), New System.Text.UTF8Encoding(False))
                    sw.Write("{\rtf1\ansi\ansicpg1250\deff0\nouicompat\deflang1038{\fonttbl{\f0\fnil\fcharset0 Calibri;}}" + Environment.NewLine +
                           "{\*\generator Riched20 10.0.17763}\viewkind4\uc1  " + Environment.NewLine +
                           "\pard\sa200\sl276\slmult1\f0\fs22\lang14\par" + Environment.NewLine +
                           "}" + Environment.NewLine +
                           " ")
                End Using
            Else
                Using sw As New System.IO.StreamWriter(System.IO.File.Open(l_fajl, System.IO.FileMode.OpenOrCreate), New System.Text.UTF8Encoding(False))
                    sw.Write(m_html_default)
                End Using
            End If
        Else
            Using sw As New System.IO.StreamWriter(System.IO.File.Open(l_fajl, System.IO.FileMode.OpenOrCreate), New System.Text.UTF8Encoding(False))
                sw.Write(m_html_code)
            End Using
        End If

        Me.OpenWordpad()

        Dim TorlesThread As New Threading.Thread(AddressOf KesletetettTorles)
        TorlesThread.ApartmentState = Threading.ApartmentState.STA
        TorlesThread.Start()

        Me.Close()

    End Sub

    Private Sub OpenWordpad()
        Try
            If String.IsNullOrEmpty(IFSZ_DNET_RTFProc.m_rtf_editor) Then
                IFSZ_DNET_RTFProc.m_rtf_editor = IFSZ_Globals.GetParameter("RTFEDITOR")
                If String.IsNullOrEmpty(IFSZ_DNET_RTFProc.m_rtf_editor) Then
                    IFSZ_DNET_RTFProc.m_rtf_editor = "wordpad.exe"
                End If
            End If
            If String.IsNullOrEmpty(IFSZ_DNET_RTFProc.m_rtf_argument) Then
                IFSZ_DNET_RTFProc.m_rtf_argument = IFSZ_Globals.GetParameter("RTFARG")
                If String.IsNullOrEmpty(IFSZ_DNET_RTFProc.m_rtf_argument) Then
                    IFSZ_DNET_RTFProc.m_rtf_argument = "<fname>"
                End If
            End If
            Dim p As New Process
            p.StartInfo.FileName = IFSZ_DNET_RTFProc.m_rtf_editor
            p.StartInfo.Arguments = IFSZ_DNET_RTFProc.m_rtf_argument.Replace("<fname>", """" + m_torlendo_fajl.Replace("""", """""") + """").Replace("<fshortname>", m_torlendo_fajl)
            p.Start()
            Dim handle As IntPtr = p.MainWindowHandle
            Win32Helper.SetForegroundWindow(handle)
            p.WaitForExit()

            Dim l_content As String
            Using sr As New System.IO.StreamReader(m_torlendo_fajl)
                l_content = sr.ReadToEnd()
            End Using

            If l_content.Length > m_html_hossz Then
                Me.Show()
                If MsgBox("Túl nagy lett az rtf kód, nem fér bele a mezőbe. (" + l_content.Length.ToString() + " - " + m_html_hossz.ToString() + ") Újra megnyitja a wordpad-et?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                    OpenWordpad()
                Else
                    Me.DialogResult = DialogResult.Cancel
                End If
            Else
                m_html_code = l_content
                Me.DialogResult = DialogResult.OK
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub GetNextRTFFileName(ByRef p_filename As String)
        Dim i As Integer
        Dim l_path As String = System.IO.Path.GetTempPath()
        Dim l_name As String
        Dim l_fs As System.IO.FileStream

        For i = 0 To 100
            l_name = l_path + "IFSZ_AddOn_RTFEdit" + i.ToString() + ".rtf"
            If Not System.IO.File.Exists(l_name) Then
                l_fs = System.IO.File.Create(l_name)
                l_fs.Close()
                p_filename = l_name
                Exit Sub
            End If
        Next
        'Ha betelt a 100 hely, az gyanús, megpróbáljuk kitörölni őket
        For i = 0 To 100
            l_name = l_path + "IFSZ_AddOn_RTFEdit" + i.ToString() + ".xls"
            Try                Dim l_fajl As String = l_name
                System.IO.File.Delete(l_fajl)
            Catch            End Try        Next
        'Majd újra az első lépés
        For i = 0 To 100
            l_name = l_path + "IFSZ_AddOn_RTFEdit" + i.ToString() + ".xls"
            If Not System.IO.File.Exists(l_name) Then
                l_fs = System.IO.File.Create(l_name)
                l_fs.Close()
                p_filename = l_name
                Exit Sub
            End If
        Next

        Throw New Exception("Nem generálható átmeneti RTF állomány")
    End Sub

    Private Sub KesletetettTorles()
        Try            If String.IsNullOrEmpty(m_torlendo_fajl) Then
                Exit Sub
            End If            Dim l_fajl As String = Me.m_torlendo_fajl
            System.Threading.Thread.Sleep(5000)
            System.IO.File.Delete(l_fajl)
        Catch        End Try    End Sub

End Class