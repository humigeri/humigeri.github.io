Option Explicit On 
Imports SboAddOnBase
Imports IFSZ_AddOnBase

Public Class IFSZ_CashPointClose

    Protected m_ParentAddOn As SBOAddOn
    Protected m_Company As SAPbobsCOM.Company

    Public Sub New(ByVal ParentAddOn As SBOAddOn)
        m_ParentAddOn = ParentAddOn
        m_Company = ParentAddOn.SboCompany
    End Sub

    Public Function HasRole(ByVal CashPoint As String)
        Dim l_role As IFSZ_CashPoint = New IFSZ_CashPoint(m_ParentAddOn)
        Return l_role.HasRole("IFSZ_CASH_CLOSE", CashPoint)
    End Function

    Public Sub CashPointClose( _
                 ByVal p_CashPoint As String _
             , ByVal p_stand As String _
             , Optional ByVal p_Comment As String = Nothing _
    )
        Dim RecSet As SAPbobsCOM.Recordset
        Dim RecSet2 As SAPbobsCOM.Recordset
        Dim oCommand As SAPbobsCOM.Command
        Dim l_chartofaccounts As SAPbobsCOM.ChartOfAccounts
        Dim l_seq As IFSZ_Sequence
        Dim l_udt As SAPbobsCOM.UserTable
        Dim l_udt_fields As SAPbobsCOM.Fields
        Dim l_code As String
        Dim l_cls_code As String
        Dim l_inDNCat As String
        Dim l_outDNCat As String
        Dim lng_errCode As Long
        Dim str_errMsg As String
        Dim a As String
        Dim l_timestamp As DateTime
        Dim l_sbobob As SAPbobsCOM.SBObob
        Dim l_local_curr As String

        If (Not HasRole(p_CashPoint)) Then
            'A felhaszn�l�nak nincs joga a p�nzt�r z�r�s�hoz
            m_ParentAddOn.SboApplication.MessageBox(m_ParentAddOn.LocRM.GetString("ifsz-10001"))
            Exit Sub
        End If

        'Local currency megkeres�se
        Try
            RecSet = m_Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            l_sbobob = m_ParentAddOn.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoBridge)
            RecSet = l_sbobob.GetLocalCurrency()
            l_local_curr = RecSet.Fields.Item(0).Value
        Catch

        Finally
            If (Not RecSet Is Nothing) Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(RecSet)
                RecSet = Nothing
            End If
            If (Not RecSet2 Is Nothing) Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(RecSet2)
                RecSet2 = Nothing
            End If
            If (Not l_chartofaccounts Is Nothing) Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(l_chartofaccounts)
                l_chartofaccounts = Nothing
            End If
            If (Not oCommand Is Nothing) Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oCommand)
                oCommand = Nothing
            End If
        End Try

        Try

            RecSet = m_Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            RecSet2 = m_Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

            m_Company.StartTransaction()

            'Leellen�rizz�k, hogy van-e nem lez�rt bizonylat
            RecSet.DoQuery("select code from [@ifsz_cash_txns] where u_cashcode = '" & p_CashPoint & "' and u_txnsts in (0,1)")
            If RecSet.RecordCount > 0 Then
                'A p�nzt�r z�r�sa el�tt le kell z�rni az �sszes bizonylatot
                m_ParentAddOn.SboApplication.MessageBox(m_ParentAddOn.LocRM.GetString("ifsz-10006"))
                m_Company.EndTransaction(SAPbobsCOM.BoWfTransOpt.wf_RollBack)
                Exit Sub
            Else

                'Azt is ellen�rizz�k, hogy egy�ltal�n sz�letett-e bizonylat
                RecSet.DoQuery("select code from [@ifsz_cash_txns] where u_cashcode = '" & p_CashPoint & "' and u_cashcls is null")
                If RecSet.RecordCount = 0 Then
                    'Nem volt forgalom az utols� p�nzt�rz�r�s �ta
                    m_ParentAddOn.SboApplication.MessageBox(m_ParentAddOn.LocRM.GetString("ifsz-10007"))
                    m_Company.EndTransaction(SAPbobsCOM.BoWfTransOpt.wf_RollBack)
                    Exit Sub
                Else
                    'Leellen�rizz�k, hogy a p�nzt�r p�nznemenk�nt vezetett egyenlege a hozz� tartoz� f�k�nyvi sz�mla egyenleg�vel megegyezik-e
                    'valamint a standol�sokkal megegyezik-e (param�tert�l f�gg)
                    RecSet.DoQuery("select u_currcode, u_balance, code from [@ifsz_cashpnt_blncs] where u_cashcode = '" & p_CashPoint & "'")
                    RecSet.MoveFirst()
                    Dim l_nincs_tetel As Boolean = True
                    While (Not RecSet.EoF)
                        l_nincs_tetel = False
                        'balance = account balance ?
                        RecSet2.DoQuery("select acctcode from oact where u_ifszcash = '" & p_CashPoint & "' and actcurr = '" & RecSet.Fields.Item(0).Value & "'")
                        l_chartofaccounts = m_ParentAddOn.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oChartOfAccounts)
                        l_chartofaccounts.GetByKey(RecSet2.Fields.Item(0).Value)
                        If Me.m_ParentAddOn.parameter_ertek("ENG_ELL") = "I" Then
                            If ((l_local_curr = RecSet.Fields.Item(0).Value And l_chartofaccounts.Balance <> RecSet.Fields.Item(1).Value) Or (l_local_curr <> RecSet.Fields.Item(0).Value And l_chartofaccounts.Balance_FrgnCurr <> RecSet.Fields.Item(1).Value)) Then
                                'A p�nzt�r <1> p�nznembeli egyenlege nem egyezik meg a f�k�nyvi sz�mla egyenleg�vel
                                m_ParentAddOn.SboApplication.MessageBox(m_ParentAddOn.LocRM.GetString("ifsz-10004").Replace("<1>", RecSet.Fields.Item(0).Value))
                                m_Company.EndTransaction(SAPbobsCOM.BoWfTransOpt.wf_RollBack)
                                Exit Sub
                            End If
                        End If

                        ' balance = sum( c�mletek ) ?
                        If p_stand = "I" Then
                            Dim l_teszt As String
                            l_teszt = RecSet.Fields.Item(2).Value
                            RecSet2.DoQuery("select sum( u_ertek ) from [@ifsz_cls_stand] where u_cashblnc = '" & RecSet.Fields.Item(2).Value & "'")
                            If RecSet2.Fields.Item(0).Value <> RecSet.Fields.Item(1).Value Then
                                'A p�nzt�r <1> p�nznembeli egyenlege nem egyezik meg a hozz� tartoz� c�mletek �sszes �rt�k�vel
                                'm_ParentAddOn.SboApplication.MessageBox(m_ParentAddOn.LocRM.GetString("ifsz-10013").Replace("<1>", RecSet.Fields.Item(0).Value))
                                m_ParentAddOn.SboApplication.MessageBox(m_ParentAddOn.LocRM.GetString("ifsz-18033")) '"A p�nzt�r egyenlege nem egyezik meg a hozz� tartoz� c�mletek �sszes �rt�k�vel")
                                m_Company.EndTransaction(SAPbobsCOM.BoWfTransOpt.wf_RollBack)
                                Exit Sub
                            End If
                        End If
                        RecSet.MoveNext()
                    End While

                    If l_nincs_tetel Then
                        'Nem t�rt�nt forgalom a p�nzt�rban
                        'm_ParentAddOn.SboApplication.MessageBox(m_ParentAddOn.LocRM.GetString("ifsz-10005"))
                        m_ParentAddOn.SboApplication.MessageBox(m_ParentAddOn.LocRM.GetString("ifsz-18034")) '"Nem t�rt�nt forgalom a p�nzt�rban")
                        m_Company.EndTransaction(SAPbobsCOM.BoWfTransOpt.wf_RollBack)
                        Exit Sub
                    End If

                    l_udt = m_ParentAddOn.SboCompany.UserTables.Item("IFSZ_CASH_CLS")
                    l_udt_fields = l_udt.UserFields.Fields

                    'Code, Name
                    l_seq = New IFSZ_Sequence(m_ParentAddOn)
                    l_cls_code = l_seq.get_next_seq("DEFAULT")
                    l_udt.Code = l_cls_code
                    l_udt.Name = l_cls_code
                    'U_Seq
                    RecSet.DoQuery("select max(u_seq)+1 from [@ifsz_cash_cls] where u_cashcode = '" & p_CashPoint & "'")
                    If RecSet.RecordCount = 0 Then
                        l_udt_fields.Item("U_Seq").Value = 1
                    Else
                        If (RecSet.Fields.Item(0).Value Is Nothing Or RecSet.Fields.Item(0).Value = 0) Then
                            l_udt_fields.Item("U_Seq").Value = 1
                        Else
                            l_udt_fields.Item("U_Seq").Value = RecSet.Fields.Item(0).Value
                        End If
                    End If
                    'U_inDN
                    'get_DNCats(p_CashPoint, l_inDNCat, l_outDNCat)
                    'If (l_inDNCat Is Nothing Or l_outDNCat Is Nothing Or l_inDNCat = "" Or l_outDNCat = "") Then
                    '    Exit Sub
                    'End If
                    'RecSet.DoQuery("select u_next, code from [@ifsz_docnum_assigns] with(updlock) where U_DNCateg = '" & l_inDNCat & "' and convert(varchar, getdate(), 112) between convert(varchar, u_datefrom, 112) and convert(varchar, u_dateto, 112)")
                    'If RecSet.RecordCount = 0 Then
                    '    l_udt_fields.Item("U_inDN").Value = Nothing
                    'Else
                    '    l_udt_fields.Item("U_inDN").Value = RecSet.Fields.Item(0).Value
                    'End If
                    'RecSet.DoQuery("select u_next, code from [@ifsz_docnum_assigns] with(updlock) where U_DNCateg = '" & l_outDNCat & "' and convert(varchar, getdate(), 112) between convert(varchar, u_datefrom, 112) and convert(varchar, u_dateto, 112)")
                    'If RecSet.RecordCount = 0 Then
                    '    l_udt_fields.Item("U_outDN").Value = Nothing
                    'Else
                    '    l_udt_fields.Item("U_outDN").Value = RecSet.Fields.Item(0).Value
                    'End If
                    Dim l_lastclose As DateTime
                    Dim l_no_lastclose As Boolean
                    Dim l_inDN As String
                    Dim l_outDN As String
                    LastDNs(p_CashPoint, l_lastclose, l_no_lastclose, l_inDN, l_outDN, Nothing, False)
                    l_udt_fields.Item("U_InDN").Value = l_inDN
                    l_udt_fields.Item("U_OutDN").Value = l_outDN
                    'T�bbi oszlop
                    l_udt_fields.Item("U_CashCode").Value = p_CashPoint
                    l_udt_fields.Item("U_TimeStmp").Value = Me.m_ParentAddOn.SboApplication.Company.ServerDate
                    l_udt_fields.Item("U_UserCode").Value = m_Company.UserName
                    l_udt_fields.Item("U_Comment").Value = p_Comment

                    'fej INSERT
                    If l_udt.Add <> 0 Then
                        m_ParentAddOn.SboCompany.GetLastError(lng_errCode, str_errMsg)
                        m_ParentAddOn.SboApplication.MessageBox(str_errMsg & Chr(10) & _
                          " hibak�d = " & lng_errCode.ToString())
                        Exit Sub
                    End If

                    'T�telek INSERT
                    l_udt = m_ParentAddOn.SboCompany.UserTables.Item("IFSZ_CASH_CLS_LINES")
                    l_udt_fields = l_udt.UserFields.Fields

                    RecSet.DoQuery("select u_currcode, u_balance, code from [@ifsz_cashpnt_blncs] where u_cashcode = '" & p_CashPoint & "'")
                    RecSet.MoveFirst()
                    While (Not RecSet.EoF)
                        'Code, Name
                        l_seq = New IFSZ_Sequence(m_ParentAddOn)
                        l_code = l_seq.get_next_seq("DEFAULT")
                        l_udt.Code = l_code
                        l_udt.Name = l_code
                        l_udt_fields.Item("U_CashCls").Value = l_cls_code
                        l_udt_fields.Item("U_CurrCode").Value = RecSet.Fields.Item(0).Value
                        l_udt_fields.Item("U_Balance").Value = RecSet.Fields.Item(1).Value
                        If l_udt.Add <> 0 Then
                            m_ParentAddOn.SboCompany.GetLastError(lng_errCode, str_errMsg)
                            m_ParentAddOn.SboApplication.MessageBox(str_errMsg & Chr(10) & _
                              " hibak�d = " & lng_errCode.ToString())
                            Exit Sub
                        End If
                        If p_stand = "I" Then
                            'Update-elj�k a standol�st
                            RecSet2.DoQuery("update [@ifsz_cls_stand] set u_cashblnc = null, u_clslns = '" & l_code & "' where u_cashblnc = '" & RecSet.Fields.Item(2).Value & "'")
                        End If
                        RecSet.MoveNext()
                    End While

                    'P�nzt�ri mozg�sok update-je
                    RecSet.DoQuery("update [@ifsz_cash_txns] set u_cashcls = '" & l_cls_code & "' where u_cashcode = '" & p_CashPoint & "' and u_cashcls is null")
                End If
            End If

        Catch exc As Exception
            'V�ratlan kiv�tel
            'm_ParentAddOn.SboApplication.MessageBox(m_ParentAddOn.LocRM.GetString("ifsz-00002") & " (" & exc.ToString & ")")
            m_ParentAddOn.SboApplication.MessageBox(exc.ToString)
            m_ParentAddOn.SboApplication.MessageBox(exc.ToString.Substring(100, 100))
            m_Company.EndTransaction(SAPbobsCOM.BoWfTransOpt.wf_RollBack)
            Exit Sub
        Finally
            If (Not RecSet Is Nothing) Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(RecSet)
                RecSet = Nothing
            End If
            If (Not RecSet2 Is Nothing) Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(RecSet2)
                RecSet2 = Nothing
            End If
            If (Not l_chartofaccounts Is Nothing) Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(l_chartofaccounts)
                l_chartofaccounts = Nothing
            End If
            If (Not oCommand Is Nothing) Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oCommand)
                oCommand = Nothing
            End If
        End Try

        'A p�nzt�rz�r�s sikeresen megt�rt�nt
        m_ParentAddOn.SboApplication.MessageBox(m_ParentAddOn.LocRM.GetString("ifsz-10008"))
        m_Company.EndTransaction(SAPbobsCOM.BoWfTransOpt.wf_Commit)

    End Sub

    Public Sub LastDNs( _
        ByVal p_cashpoint As String _
      , ByRef p_lastclose As DateTime _
      , ByRef p_no_lastclose As Boolean _
      , ByRef p_inDN As String _
      , ByRef p_outDN As String _
      , Optional ByRef p_cashcls As String = Nothing _
      , Optional ByRef p_raise_failure As Boolean = True _
    )
        Dim RecSet As SAPbobsCOM.Recordset
        Dim l_docnum As IFSZ_AddOnBase.IFSZ_DocNumAssignment = New IFSZ_AddOnBase.IFSZ_DocNumAssignment(m_ParentAddOn)
        Dim l_inDocNum As String
        Dim l_outDocNum As String
        Dim l_inDNCat As String
        Dim l_outDNCat As String
        Dim l_lastdate As Date
        Dim l_code As String
        Dim MyCultureInfo As System.Globalization.CultureInfo = New System.Globalization.CultureInfo("en-gb")
        Dim l_additional_where As String

        If p_cashcls Is Nothing Then
            l_additional_where = ""
        Else
            l_additional_where = " and u_cashcls = '" & p_cashcls & "'"
        End If

        p_no_lastclose = True

        Try
            RecSet = m_Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            get_DNCats(p_cashpoint, l_inDNCat, l_outDNCat)
            If (l_inDNCat Is Nothing Or l_outDNCat Is Nothing Or l_inDNCat = "" Or l_outDNCat = "") Then
                p_inDN = Nothing
                p_outDN = Nothing
                Exit Sub
            End If
            'In
            RecSet.DoQuery("select max(code) from [@ifsz_cash_txns] where u_cashcode = '" & p_cashpoint & "' and u_direct = 'I'" & l_additional_where)
            l_code = RecSet.Fields.Item(0).Value
            RecSet.DoQuery("select u_docnum from [@ifsz_cash_txns] where code = '" & l_code & "'")
            If (RecSet.RecordCount = 0) Then
                If p_raise_failure Then
                    'A(z) "<1>" k�d� p�nzt�rnak nem tal�lhat� az utols� bev�telez�si bizonylata!
                    m_ParentAddOn.SboApplication.MessageBox(m_ParentAddOn.LocRM.GetString("ifsz-10011").Replace("<1>", p_cashpoint))
                End If
                p_inDN = Nothing
            End If
            p_inDN = RecSet.Fields.Item(0).Value
            'Out
            RecSet.DoQuery("select max(code) from [@ifsz_cash_txns] where u_cashcode = '" & p_cashpoint & "' and u_direct = 'O'" & l_additional_where)
            l_code = RecSet.Fields.Item(0).Value
            RecSet.DoQuery("select u_docnum from [@ifsz_cash_txns] where code = '" & l_code & "'")
            If (RecSet.RecordCount = 0) Then
                If p_raise_failure Then
                    'A(z) "<1>" k�d� p�nzt�rnak nem tal�lhat� az utols� kiad�si bizonylata!
                    m_ParentAddOn.SboApplication.MessageBox(m_ParentAddOn.LocRM.GetString("ifsz-10012").Replace("<1>", p_cashpoint))
                End If
                p_outDN = Nothing
            End If
            p_outDN = RecSet.Fields.Item(0).Value
            'last close date
            RecSet.DoQuery("select max(convert(varchar, u_timestmp, 120)) from [@ifsz_cash_cls] where u_cashcode = '" & p_cashpoint & "'")
            If (RecSet.Fields.Item(0).Value Is Nothing Or RecSet.Fields.Item(0).Value = "") Then
                p_no_lastclose = True
            Else
                p_no_lastclose = False
                p_lastclose = DateTime.ParseExact(RecSet.Fields.Item(0).Value, "yyyy-MM-dd HH:mm:ss", MyCultureInfo)
            End If
        Catch exc As Exception
            'V�ratlan kiv�tel
            m_ParentAddOn.SboApplication.MessageBox(m_ParentAddOn.LocRM.GetString("ifsz-00002") & " (" & exc.ToString & ")")
            p_inDN = Nothing
            p_outDN = Nothing
            Exit Sub
        Finally
            If (Not RecSet Is Nothing) Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(RecSet)
                RecSet = Nothing
            End If
        End Try
    End Sub

    Public Function GetCode( _
      ByVal p_cashcode As String _
    , ByVal p_seq As Integer _
    ) As String
        Dim RecSet As SAPbobsCOM.Recordset

        Try
            RecSet = m_Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            RecSet.DoQuery("select code from [@ifsz_cash_cls] where u_cashcode = '" & p_cashcode & "' and u_seq = " & p_seq)
            If RecSet.RecordCount = 0 Then
                Return Nothing
            Else
                Return RecSet.Fields.Item(0).Value
            End If
        Catch exc As Exception
            'V�ratlan kiv�tel
            m_ParentAddOn.SboApplication.MessageBox(m_ParentAddOn.LocRM.GetString("ifsz-00002") & " (" & exc.ToString & ")")
            Return Nothing
        Finally
            If (Not RecSet Is Nothing) Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(RecSet)
                RecSet = Nothing
            End If
        End Try
    End Function

    Public Sub get_DNCats( _
      ByVal p_cashpoint As String, _
      ByRef p_inDNCat As String, _
      ByRef p_outDNCat As String _
    )
        Dim RecSet As SAPbobsCOM.Recordset

        Try

            RecSet = m_Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            RecSet.DoQuery("select u_indncat, u_outdncat from [@ifsz_cashpoints] where code = '" & p_cashpoint & "'")
            If (RecSet.RecordCount = 0) Then
                'A(z) "<1>" k�dhoz nem l�tezik p�nzt�r!
                m_ParentAddOn.SboApplication.MessageBox(m_ParentAddOn.LocRM.GetString("ifsz-08005").Replace("<1>", p_cashpoint))
                p_inDNCat = Nothing
                p_outDNCat = Nothing
                Exit Sub
            End If
            p_inDNCat = RecSet.Fields.Item(0).Value
            p_outDNCat = RecSet.Fields.Item(1).Value

        Catch exc As Exception
            'V�ratlan kiv�tel
            m_ParentAddOn.SboApplication.MessageBox(m_ParentAddOn.LocRM.GetString("ifsz-00002") & " (" & exc.ToString & ")")
            p_inDNCat = Nothing
            p_outDNCat = Nothing
            Exit Sub
        Finally
            If (Not RecSet Is Nothing) Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(RecSet)
                RecSet = Nothing
            End If
        End Try
    End Sub

#Region "Private"

#End Region

End Class
