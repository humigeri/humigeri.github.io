Imports SboAddOnBaseImports IFSZ_AddOnBasePublic Class IFSZ_KimenoFizetes    Inherits SboForm    Public Sub New(
        ByVal ParentAddOn As SBOAddOn,
        ByRef oEredetiForm As IFSZ_CashTxn_Matrix,
        ByVal FunctionCode As String,
        ByVal FormUID As String,
        ByVal l_CshTxn As String,
        ByVal l_pnr_kod As String,
        ByVal l_szamla_tipus As String,
        ByVal l_pnm_kod As String,
        ByVal l_konyvelesi_datum As String,
        ByVal l_osszeg As Double,
        ByVal l_osszegFC As Double,
        ByVal l_fokonyvi_szam As String,
        ByVal l_fokonyvi_szamMGS As String,
        ByVal l_dlgID As String,
        ByVal l_RefNum As String,
        ByVal l_PrcCode As String,
        ByVal l_OcrCode2 As String,
        ByVal l_OcrCode3 As String,
        ByVal l_OcrCode4 As String,
        ByVal l_OcrCode5 As String,
        ByVal l_TxnCode As String,
        ByVal l_ref2 As String,
        ByVal l_code As String,
        ByVal l_bizonylat_szam As String,
        ByVal l_ado_kod As String,
        ByVal l_megjegyzes As String,
        ByVal l_hiv_szam As String,
        ByVal l_penztar_kod As String,
        ByVal l_arfolyam As Double,
        ByVal l_PrjCode As String
        )        MyBase.New(ParentAddOn, enSboFormTypes.LogicOnly, enSAPFormTypes.IFSZ_Function_UDF, FunctionCode, FormUID)        oForm_Eredeti = oEredetiForm        p_konyvelesi_datum = l_konyvelesi_datum        p_osszeg = CDbl(Replace(l_osszeg, ".", ""))        p_osszegFC = CDbl(Replace(l_osszegFC, ".", ""))        p_pnr_kod = l_pnr_kod        p_szamla_tipus = l_szamla_tipus        p_pnm_kod = l_pnm_kod        p_fokonyvi_szam = l_fokonyvi_szam        p_dlgID = l_dlgID        p_RefNum = l_RefNum        p_PrcCode = l_PrcCode        p_OcrCode2 = l_OcrCode2
        p_OcrCode3 = l_OcrCode3
        p_OcrCode4 = l_OcrCode4
        p_OcrCode5 = l_OcrCode5
        p_PrjCode = l_PrjCode        p_CshTxn = l_CshTxn        p_fokonyvi_szamMGS = l_fokonyvi_szamMGS        p_TxnCode = l_TxnCode        p_ref2 = l_ref2        p_code = l_code        p_bizonylat_szam = l_bizonylat_szam        p_ado_kod = l_ado_kod        p_megjegyzes = l_megjegyzes        p_hiv_szam = l_hiv_szam        p_penztar_kod = l_penztar_kod        p_arfolyam = l_arfolyam    End Sub    Private oForm_Eredeti As IFSZ_CashTxn_Matrix    Private p_konyvelesi_datum As String    Private p_pnr_kod, p_CshTxn As String    Private p_pnm_kod, l_tzo_kod As String    Private p_osszeg, p_osszegFC, p_arfolyam As Double    Private p_Seq As Integer    Private p_szamla_tipus, p_ref2, p_penztar_kod As String    Private p_ModalFormUID, p_megjegyzes, p_hiv_szam As String    Private p_fokonyvi_szam, p_bizonylat_szam, p_ado_kod As String    Private p_fokonyvi_szamMGS As String    Private p_code, p_name, p_TxnCode, p_LineSts, p_dlgID, p_RefNum, p_PrcCode, p_PrjCode, p_OcrCode2, p_OcrCode3, p_OcrCode4, p_OcrCode5 As String    Private p_DocNum As String    Private p_irany As Integer    Private p_kilepes As Boolean = False    Private p_elso As Boolean = True
    Private m_ablaknyit As Boolean = False    Private m_penzeszsak_ok As Boolean = True    Private m_megnyitva As System.Nullable(Of DateTime) = Nothing    Private m_adatok_kitoltve As Boolean = False    Public Overrides Sub HANDLE_FORM_EVENTS(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)        Static l_Event_Count As Integer = 1        Dim newThread As Threading.Thread        Dim oOption As SAPbouiCOM.OptionBtn        Dim oMatrix As SAPbouiCOM.Matrix        If m_adatok_kitoltve AndAlso Not m_penzeszsak_ok AndAlso pVal.InnerEvent = False Then
            If m_megnyitva.HasValue Then
                If DateTime.Now().Subtract(m_megnyitva.Value).TotalSeconds > 12 Then
                    'Nehogy valami beragadjon
                    m_penzeszsak_ok = True
                End If
            Else
                m_megnyitva = DateTime.Now()
            End If
            BubbleEvent = False
            Exit Sub
        End If        If Me.m_ablaknyit Then
            If pVal.EventType = SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE Then
                Me.m_ablaknyit = False
                Me.m_ParentAddon.SboApplication.ActivateMenuItem(5892)
            End If
        End If        If IFSZ_CashTxn_Matrix.KimenoFizetes = True Or IFSZ_CashTxn_Matrix.BejovoFizetes = True Then            If pVal.FormType = 426 Or pVal.FormType = 170 Then                If pVal.ActionSuccess And pVal.Before_Action = False Then                    Dim i As Integer                    i = 0                End If

                'If (Not Me.p_ModalFormUID Is Nothing) Then
                '    Dim oForm As SboForm
                '    Dim oFormSBO As SAPbouiCOM.Form
                '    For Each oForm In Me.m_ParentAddon.SBOForms
                '        If oForm.UniqueID = Me.p_ModalFormUID Then
                '            oFormSBO = Me.m_ParentAddon.SboApplication.Forms.Item(oForm.UniqueID)
                '            oFormSBO.Select()
                '            If pVal.ItemUID = "1" Or pVal.ItemUID = "2" Then
                '                BubbleEvent = False
                '            End If
                '            Exit Sub
                '        End If
                '    Next
                '    Me.p_ModalFormUID = Nothing
                'End If

                If pVal.Before_Action = True And SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED Then                    If CStr(pVal.ItemUID) = "2" Then                        Me.p_kilepes = True                    End If                End If                If pVal.Before_Action = True And pVal.EventType = SAPbouiCOM.BoEventTypes.et_CLICK Then                    Dim i As Integer                    i = 0                End If                If pVal.EventType = SAPbouiCOM.BoEventTypes.et_FORM_LOAD Then                    Dim oForm As SboForm                    Dim oFormSBO As SAPbouiCOM.Form                    Dim i As Integer                    i = 1
                    'oForm = New IFSZ_Fizetesi_modok(Me.m_ParentAddon, "F_FSM", FormUID, Me.p_fokonyvi_szam, Me.p_osszeg, Me.p_pnm_kod)
                    'Me.m_ParentAddon.SBOForms.Add(oForm, oForm.UniqueID)
                    'Me.p_ModalFormUID = oForm.UniqueID
                End If                If pVal.EventType = SAPbouiCOM.BoEventTypes.et_FORM_LOAD And l_Event_Count = 1 And pVal.Before_Action = False Then                    m_megnyitva = DateTime.Now()                    Dim l_megjegyzes As String                    Try                        Me.m_SboForm.Select()                        l_Event_Count += 1
                        'Me.m_SboForm.Items.Item("22").Enabled = False
                        If Me.p_szamla_tipus = "V" And pVal.FormType = 426 Then                            oOption = Me.m_SboForm.Items.Item("56").Specific                            oOption.Selected = True                            Me.set_item_value("5", "", 0, p_pnr_kod)                            Me.m_SboForm.Items.Item("32").Click()                            Me.m_SboForm.Items.Item("5").Enabled = False                            Me.m_SboForm.Items.Item("56").Enabled = False                            Me.m_SboForm.Items.Item("57").Enabled = False                            Me.m_SboForm.Items.Item("58").Enabled = False
                            'Me.set_item_value("13", "", 0, p_osszeg)
                            'Me.m_SboForm.Items.Item("13").Enabled = False
                        ElseIf Me.p_szamla_tipus = "S" And pVal.FormType = 426 Then                            oOption = Me.m_SboForm.Items.Item("57").Specific                            oOption.Selected = True                            Me.set_item_value("5", "", 0, p_pnr_kod)                            Me.m_SboForm.Items.Item("32").Click()                            Me.m_SboForm.Items.Item("56").Enabled = False                            Me.m_SboForm.Items.Item("57").Enabled = False                            Me.m_SboForm.Items.Item("58").Enabled = False                            Me.m_SboForm.Items.Item("5").Enabled = False
                            'Me.set_item_value("13", "", 0, p_osszeg)
                            'Me.m_SboForm.Items.Item("13").Enabled = False
                        ElseIf Me.p_szamla_tipus = "S" And pVal.FormType = 170 Then                            oOption = Me.m_SboForm.Items.Item("57").Specific                            oOption.Selected = True                            Me.set_item_value("5", "", 0, p_pnr_kod)                            Me.m_SboForm.Items.Item("32").Click()                            Me.m_SboForm.Items.Item("5").Enabled = False                            Me.m_SboForm.Items.Item("56").Enabled = False                            Me.m_SboForm.Items.Item("57").Enabled = False                            Me.m_SboForm.Items.Item("58").Enabled = False
                            'Me.set_item_value("13", "", 0, p_osszeg)
                            'Me.m_SboForm.Items.Item("13").Enabled = False
                        ElseIf Me.p_szamla_tipus = "V" And pVal.FormType = 170 Then                            oOption = Me.m_SboForm.Items.Item("56").Specific                            oOption.Selected = True                            Me.set_item_value("5", "", 0, p_pnr_kod)                            Me.m_SboForm.Items.Item("32").Click()                            Me.m_SboForm.Items.Item("56").Enabled = False                            Me.m_SboForm.Items.Item("57").Enabled = False                            Me.m_SboForm.Items.Item("58").Enabled = False                            Me.m_SboForm.Items.Item("5").Enabled = False
                            'Me.set_item_value("13", "", 0, p_osszeg)
                            'Me.m_SboForm.Items.Item("13").Enabled = False
                        ElseIf Me.p_szamla_tipus = "F" Then                            Dim oRecordSet As SAPbobsCOM.Recordset                            Dim p_select As String                            Dim l_rate As Double                            Try                                oRecordSet = Me.SBO_Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)                                p_select = "select Rate from OVTG where code = '" & Me.p_ado_kod & "'"                                oRecordSet.DoQuery(p_select)                                oRecordSet.MoveFirst()                                oOption = Me.m_SboForm.Items.Item("58").Specific                                oOption.Selected = True                                Me.m_SboForm.Items.Item("56").Enabled = False                                Me.m_SboForm.Items.Item("57").Enabled = False                                Me.m_SboForm.Items.Item("58").Enabled = False                                Me.m_SboForm.Items.Item("5").Enabled = False                                If Me.p_pnm_kod <> "Ft" Then                                    Me.set_item_value("74", "", 0, Me.p_pnm_kod)                                End If                                Me.set_item_value("71", "8", 1, Me.p_fokonyvi_szamMGS)                                Me.set_item_value("71", "4", 1, Me.p_ado_kod)                                Me.set_item_value("71", "3", 1, Me.p_megjegyzes)

                                'If Me.p_arfolyam = 1 Then
                                '    Me.set_item_value("71", "5", 1, (Me.p_osszeg / (1 + (oRecordSet.Fields.Item(0).Value / 100))) * Me.p_arfolyam)
                                'Else
                                '    If pVal.FormType = 426 Then
                                '        Me.set_item_value("71", "5", 1, (Me.p_osszeg / (1 + (oRecordSet.Fields.Item(0).Value / 100))) * Me.p_arfolyam)
                                '    Else
                                '        Me.set_item_value("71", "5", 1, (Me.p_osszeg / (1 + (oRecordSet.Fields.Item(0).Value / 100))))
                                '    End If
                                'End If

                                If Me.p_arfolyam = 1 Then                                    Me.set_item_value("71", "5", 1, (Me.p_osszeg / (1 + (oRecordSet.Fields.Item(0).Value / 100))) * Me.p_arfolyam)                                Else                                    If pVal.FormType = 426 Then
                                        'Me.set_item_value("71", "5", 1, (Me.p_osszeg / (1 + (oRecordSet.Fields.Item(0).Value / 100))) * Me.p_arfolyam)
                                        Me.set_item_value("71", "10000024", 1, (Me.p_osszeg / (1 + (oRecordSet.Fields.Item(0).Value / 100))))                                    Else
                                        'Me.set_item_value("71", "5", 1, (Me.p_osszeg / (1 + (oRecordSet.Fields.Item(0).Value / 100))))
                                        Me.set_item_value("71", "10000024", 1, (Me.p_osszeg / (1 + (oRecordSet.Fields.Item(0).Value / 100))))                                    End If                                End If                                Try
                                    If Not String.IsNullOrEmpty(Me.p_PrcCode) Then Me.set_item_value("71", "10000012", 1, Me.p_PrcCode)
                                Catch ex As Exception

                                End Try
                                Try
                                    If Not String.IsNullOrEmpty(Me.p_OcrCode2) Then Me.set_item_value("71", "10000036", 1, Me.p_OcrCode2)
                                Catch ex As Exception

                                End Try
                                Try
                                    If Not String.IsNullOrEmpty(Me.p_OcrCode3) Then Me.set_item_value("71", "10000038", 1, Me.p_OcrCode3)
                                Catch ex As Exception

                                End Try
                                Try
                                    If Not String.IsNullOrEmpty(Me.p_OcrCode4) Then Me.set_item_value("71", "10000040", 1, Me.p_OcrCode4)
                                Catch ex As Exception

                                End Try
                                Try
                                    If Not String.IsNullOrEmpty(Me.p_OcrCode5) Then Me.set_item_value("71", "10000042", 1, Me.p_OcrCode5)
                                Catch ex As Exception

                                End Try

                                oMatrix = Me.m_SboForm.Items.Item("71").Specific()                                oMatrix.Columns.Item("3").Cells.Item(1).Click()
                                'oMatrix.Columns.Item("8").Editable = False
                                'oMatrix.Columns.Item("2").Editable = False
                                'Me.m_SboForm.Items.Item("74").Enabled = False
                            Finally                                If (Not oRecordSet Is Nothing) Then                                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRecordSet)                                    oRecordSet = Nothing                                End If                            End Try                        End If                        Me.set_item_value("22", "", 0, p_ref2)                        Me.set_item_value("10", "", 0, Replace(p_konyvelesi_datum, " ", ""))                        Me.l_tzo_kod = Me.m_ParentAddon.parameter_ertek("TZO_KOD")                        If Me.l_tzo_kod <> "" Then                            Me.set_item_value("1002", "", 0, Me.l_tzo_kod)                        End If
                        'Me.set_item_value("13", "", 0, p_osszeg)
                        l_megjegyzes = m_ParentAddon.LocRM.GetString("ifsz-18194") & ": " & p_osszeg.ToString & " " & m_ParentAddon.LocRM.GetString("ifsz-18195") & " : " & Me.p_bizonylat_szam & " " & m_ParentAddon.LocRM.GetString("ifsz-18196") & " : " & Me.p_hiv_szam
                        'l_megjegyzes = "A p�nzt�r �rt�ke: " & p_osszeg.ToString & " Bizonylatsz�m : " & Me.p_bizonylat_szam & " Hivatkoz�si sz�m : " & Me.p_hiv_szam
                        Me.set_item_value("26", "", 0, l_megjegyzes)
                        'Me.m_SboForm.Items.Item("13").Enabled = False
                        Me.m_SboForm.Items.Item("10").Enabled = False                        Me.m_SboForm.Items.Item("22").Enabled = False
                        'm_SboForm.EnableMenu("5892", False)
                        'Me.m_ParentAddon.SboApplication.ActivateMenuItem(5892)
                    Catch ex As Exception                        m_ParentAddon.SboApplication.SetStatusBarMessage(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, True)
                    Finally                        m_adatok_kitoltve = True                    End Try                ElseIf pVal.EventType = SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE And pVal.Before_Action = False And l_Event_Count = 1 Then                    l_Event_Count += 1                End If            End If            If pVal.EventType = SAPbouiCOM.BoEventTypes.et_FORM_LOAD Then                Dim oForm As SboForm                Dim oFormSBO As SAPbouiCOM.Form                Dim i As Integer                i = 1
                'oForm = New IFSZ_Fizetesi_modok(Me.m_ParentAddon, "F_FSM", FormUID, Me.p_fokonyvi_szam, Me.p_osszeg, Me.p_pnm_kod)
                'Me.m_ParentAddon.SBOForms.Add(oForm, oForm.UniqueID)
                'Me.p_ModalFormUID = oForm.UniqueID
            End If            If pVal.Before_Action = False Then                Select Case pVal.EventType                    Case SAPbouiCOM.BoEventTypes.et_CLICK                        If pVal.ItemUID = "1" Then                            Dim oRcdSet As SAPbobsCOM.Recordset                            Dim oCurrRate As SAPbobsCOM.SBObob                            Dim l_ossz As Double                            Dim l_osszIP As Double                            Dim l_osszSP As Double                            Dim l_pr As String                            Try                                If Me.m_SboForm.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE Then                                    Exit Sub                                End If                                If pVal.Before_Action = True Then                                    oRcdSet = Me.SBO_Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)                                    oCurrRate = Me.m_ParentAddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoBridge)                                    oRcdSet = oCurrRate.GetLocalCurrency                                    If pVal.FormType = 170 Then                                        If Me.p_szamla_tipus = "V" Then                                            l_pr = Me.get_item_value("12", "", 0)
                                            'l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))
                                            'l_ossz = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))
                                            'l_pr = Me.get_item_value("44", "", 0)
                                            'l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))
                                            If IsNumeric(l_pr.Substring(0, 1)) = False Then                                                l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))                                                l_ossz = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))                                                l_pr = Me.get_item_value("44", "", 0)                                                l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))                                            Else                                                l_pr = l_pr.Remove(l_pr.IndexOf(" "), (l_pr.Length - l_pr.IndexOf(" ")))                                                l_ossz = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))                                                l_pr = Me.get_item_value("44", "", 0)                                                l_pr = l_pr.Remove(l_pr.IndexOf(" "), (l_pr.Length - l_pr.IndexOf(" ")))                                            End If                                            l_osszIP = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))
                                            'l_osszSP = CDbl(Replace(Me.get_item_value("45", "", 0), oForm_Eredeti.p_EzresEvt, ""))
                                            If l_osszIP = 0 Then                                                l_osszIP = l_ossz                                            End If                                            If l_osszIP <> p_osszeg Then                                                m_ParentAddon.SboApplication.MessageBox(m_ParentAddon.LocRM.GetString("ifsz-12013"))                                                BubbleEvent = False                                                Exit Sub                                            End If                                        ElseIf Me.p_szamla_tipus = "S" Then                                            l_pr = Me.get_item_value("12", "", 0)
                                            'l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))
                                            'l_ossz = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))
                                            'l_pr = Me.get_item_value("44", "", 0)
                                            'l_pr = l_pr.Remove(1, l_pr.IndexOf(" "))
                                            If IsNumeric(l_pr.Substring(0, 1)) = False Then                                                l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))                                                l_ossz = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))                                                l_pr = Me.get_item_value("44", "", 0)                                                l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))                                            Else                                                l_pr = l_pr.Remove(l_pr.IndexOf(" "), (l_pr.Length - l_pr.IndexOf(" ")))                                                l_ossz = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))                                                l_pr = Me.get_item_value("44", "", 0)                                                l_pr = l_pr.Remove(l_pr.IndexOf(" "), (l_pr.Length - l_pr.IndexOf(" ")))                                            End If                                            l_osszIP = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))
                                            'l_osszSP = CDbl(Replace(Me.get_item_value("45", "", 0), oForm_Eredeti.p_EzresEvt, ""))
                                            If l_osszIP = 0 Then                                                l_osszIP = l_ossz                                            End If                                            If l_osszIP <> p_osszeg Then                                                m_ParentAddon.SboApplication.MessageBox(m_ParentAddon.LocRM.GetString("ifsz-12013"))                                                BubbleEvent = False                                                Exit Sub                                            End If                                        ElseIf Me.p_szamla_tipus = "F" Then                                            l_pr = Me.get_item_value("77", "", 0)
                                            'l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))
                                            'l_ossz = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))
                                            'l_pr = Me.get_item_value("82", "", 0)
                                            'l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))
                                            If IsNumeric(l_pr.Substring(0, 1)) = False Then                                                l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))                                                l_ossz = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))                                                l_pr = Me.get_item_value("82", "", 0)                                                l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))                                            Else                                                l_pr = l_pr.Remove(l_pr.IndexOf(" "), (l_pr.Length - l_pr.IndexOf(" ")))                                                l_ossz = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))                                                l_pr = Me.get_item_value("82", "", 0)                                                l_pr = l_pr.Remove(l_pr.IndexOf(" "), (l_pr.Length - l_pr.IndexOf(" ")))                                            End If                                            l_osszIP = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))
                                            'l_osszSP = CDbl(Replace(Me.get_item_value("83", "", 0), oForm_Eredeti.p_EzresEvt, ""))
                                            If Me.p_pnm_kod <> oRcdSet.Fields.Item(0).Value Then                                                l_ossz = l_osszIP                                            Else                                                l_osszIP = l_ossz                                            End If                                            If l_osszIP <> p_osszeg Then                                                m_ParentAddon.SboApplication.MessageBox(m_ParentAddon.LocRM.GetString("ifsz-12013"))                                                BubbleEvent = False                                                Exit Sub                                            End If                                        End If                                    Else                                        If Me.p_szamla_tipus = "V" Then                                            l_pr = Me.get_item_value("12", "", 0)
                                            'l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))
                                            'l_ossz = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))
                                            'l_pr = Me.get_item_value("44", "", 0)
                                            'l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))
                                            If IsNumeric(l_pr.Substring(0, 1)) = False Then                                                l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))                                                l_ossz = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))                                                l_pr = Me.get_item_value("44", "", 0)                                                l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))                                            Else                                                l_pr = l_pr.Remove(l_pr.IndexOf(" "), (l_pr.Length - l_pr.IndexOf(" ")))                                                l_ossz = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))                                                l_pr = Me.get_item_value("44", "", 0)                                                l_pr = l_pr.Remove(l_pr.IndexOf(" "), (l_pr.Length - l_pr.IndexOf(" ")))                                            End If                                            l_osszIP = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))
                                            'l_osszSP = CDbl(Replace(Me.get_item_value("45", "", 0), oForm_Eredeti.p_EzresEvt, ""))
                                            If l_osszIP = 0 Then                                                l_osszIP = l_ossz                                            End If                                            If l_osszIP <> p_osszeg Then                                                m_ParentAddon.SboApplication.MessageBox(m_ParentAddon.LocRM.GetString("ifsz-12013"))                                                BubbleEvent = False                                                Exit Sub                                            End If                                        ElseIf Me.p_szamla_tipus = "S" Then                                            l_pr = Me.get_item_value("12", "", 0)
                                            'l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))
                                            'l_ossz = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))
                                            'l_pr = Me.get_item_value("44", "", 0)
                                            'l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))
                                            If IsNumeric(l_pr.Substring(0, 1)) = False Then                                                l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))                                                l_ossz = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))                                                l_pr = Me.get_item_value("44", "", 0)                                                l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))                                            Else                                                l_pr = l_pr.Remove(l_pr.IndexOf(" "), (l_pr.Length - l_pr.IndexOf(" ")))                                                l_ossz = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))                                                l_pr = Me.get_item_value("44", "", 0)                                                l_pr = l_pr.Remove(l_pr.IndexOf(" "), (l_pr.Length - l_pr.IndexOf(" ")))                                            End If                                            l_osszIP = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))
                                            'l_osszSP = CDbl(Replace(Me.get_item_value("45", "", 0), oForm_Eredeti.p_EzresEvt, ""))
                                            If l_osszIP = 0 Then                                                l_osszIP = l_ossz                                            End If                                            If l_osszIP <> p_osszeg Then                                                m_ParentAddon.SboApplication.MessageBox(m_ParentAddon.LocRM.GetString("ifsz-12013"))                                                BubbleEvent = False                                                Exit Sub                                            End If                                        ElseIf Me.p_szamla_tipus = "F" Then                                            l_pr = Me.get_item_value("77", "", 0)                                            If IsNumeric(l_pr.Substring(0, 1)) = False Then                                                l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))                                                l_ossz = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))                                                l_pr = Me.get_item_value("82", "", 0)                                                l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))                                            Else                                                l_pr = l_pr.Remove(l_pr.IndexOf(" "), (l_pr.Length - l_pr.IndexOf(" ")))                                                l_ossz = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))                                                l_pr = Me.get_item_value("82", "", 0)                                                l_pr = l_pr.Remove(l_pr.IndexOf(" "), (l_pr.Length - l_pr.IndexOf(" ")))                                            End If                                            l_osszIP = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))
                                            'l_osszSP = CDbl(Replace(Me.get_item_value("83", "", 0), oForm_Eredeti.p_EzresEvt, ""))
                                            If l_osszIP = 0 Then                                                l_osszIP = l_ossz                                            End If                                            If l_osszIP <> p_osszeg Then                                                m_ParentAddon.SboApplication.MessageBox(m_ParentAddon.LocRM.GetString("ifsz-12013"))                                                BubbleEvent = False                                                Exit Sub                                            End If                                        End If                                    End If                                    Me.p_DocNum = Me.get_item_value("3", "", 0)                                Else                                End If                            Finally                                If (Not oRcdSet Is Nothing) Then                                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRcdSet)                                    oRcdSet = Nothing                                End If                                If (Not oCurrRate Is Nothing) Then                                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oCurrRate)                                    oCurrRate = Nothing                                End If                            End Try                        End If                    Case SAPbouiCOM.BoEventTypes.et_FORM_LOAD                        If pVal.FormType = "196" Or pVal.FormType = "146" Then                            Dim oForm As SboForm                            Dim oFormSBO As SAPbouiCOM.Form                            If p_elso Then                                oForm = New IFSZ_Fizetesi_modok(Me.m_ParentAddon, "F_FSM", FormUID, Me.p_fokonyvi_szam, Me.p_osszeg, Me.p_pnm_kod)                            Else                                oForm = New IFSZ_Fizetesi_modok(Me.m_ParentAddon, "F_FSM", FormUID, Me.p_fokonyvi_szam, Me.p_osszeg, Me.p_pnm_kod, False)                            End If                            Me.m_ParentAddon.SBOForms.Add(oForm, oForm.UniqueID)                            Me.p_ModalFormUID = oForm.UniqueID                            Me.p_elso = False                        End If                    Case SAPbouiCOM.BoEventTypes.et_FORM_CLOSE
                        'If SBO_Application.Forms.Item(pVal.FormUID).Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE And p_kilepes = False Then
                        '    m_ParentAddon.SboApplication.MessageBox("A Form elmentetlen v�ltoz�sokat tartalmaz! A form bez�r�s�hoz haszn�lja a M�gse nyom�gombot.")
                        '    BubbleEvent = False
                        '    Exit Sub
                        'End If
                        Dim i, j As Integer
                        i = 0                    Case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED
                        If CStr(pVal.ItemUID) = "1" And pVal.ActionSuccess And SBO_Application.Forms.Item(pVal.FormUID).Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Then
                            'Dim oMatrix As SAPbouiCOM.Matrix
                            Dim oDBsource As SAPbouiCOM.DBDataSource
                            Dim oEditText As SAPbouiCOM.EditText
                            Dim i, j As Integer
                            Dim index As Integer
                            Dim lng_errCode As Long
                            Dim str_errMsg As String
                            Dim l_matrix_nev As String
                            Dim l_tabla_nev As String
                            Dim l_eredeti_tabla_nev As String
                            Dim oColumn As SAPbouiCOM.Column
                            Dim l_alias_nev As String
                            Dim l_ertek, l_code, p_select, l_string, p_selectB As String
                            Dim l_lookup_ertek As String
                            Dim utdTable As SAPbobsCOM.UserTable
                            Dim oRecordSet As SAPbobsCOM.Recordset
                            Dim utdTableB As SAPbobsCOM.UserTable
                            Dim oRecordSetB As SAPbobsCOM.Recordset
                            Dim l_datetime As DateTime
                            Dim l_ref2 As String
                            Dim BlnCode As String
                            Dim l_blnc As Double
                            Dim l_ossz_ertek, l_ossz_ertekFC As Double
                            Dim oForm As SAPbouiCOM.Form
                            Dim Journal As SAPbobsCOM.JournalEntries
                            Dim JournalLines As SAPbobsCOM.JournalEntries_Lines
                            Dim l_num As Integer
                            Dim a As Integer
                            Dim b As String
                            Dim utdTableBl As SAPbobsCOM.ChartOfAccounts
                            Dim oRcdSet As SAPbobsCOM.Recordset
                            Dim oCurrRate As SAPbobsCOM.SBObob


                            Try
                                Dim l_irany As Integer
                                If pVal.FormType = 170 Then
                                    l_irany = 1
                                Else
                                    l_irany = -1
                                End If
                                If BubbleEvent = True Then                                    Try                                        oRecordSet = Me.SBO_Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)                                        oRecordSetB = Me.SBO_Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)                                        p_select = "select BaseRef from OJDT where TransType in (24, 46) and Ref2 = '" & Me.p_ref2 & "' order by BaseRef desc"                                        p_selectB = "select Code, Name, U_CashCode, U_CurrCode, U_Balance from [@IFSZ_CASHPNT_BLNCS] where U_CashCode = '" & Me.p_penztar_kod & "' and U_CurrCode = '" & Me.p_pnm_kod & "'"                                        oRecordSet.DoQuery(p_select)                                        If oRecordSet.RecordCount = 0 Then
                                            'oForm_Eredeti.TetelFeltolt()
                                            Me.m_ParentAddon.SboApplication.MessageBox("Hiba t�rt�nt a fizet�s azonos�t�j�nak visszajelz�se k�zben, a kivonatt�tel nem lett �rv�nyes. Javasoljuk, hogy l�pjen kapcsolatba az IFSZ Kft-vel.")
                                            BubbleEvent = False
                                            Exit Sub                                        End If                                        oRecordSet.MoveFirst()                                        Me.p_DocNum = oRecordSet.Fields.Item(0).Value                                        m_ParentAddon.SboCompany.StartTransaction()                                        p_select = "select max(U_Seq) from [@IFSZ_CASH_TXN_LINES] (updlock) where U_CshTxn = '" & Me.p_CshTxn & "'"                                        oRecordSet.DoQuery(p_select)                                        If oRecordSet.RecordCount > 1 Then                                            Me.m_ParentAddon.SboApplication.MessageBox("Hiba t�rt�nt a fizet�s azonos�t�j�nak visszajelz�se k�zben, a kivonatt�tel nem lett �rv�nyes. Javasoljuk, hogy l�pjen kapcsolatba az IFSZ Kft-vel.")
                                            BubbleEvent = False
                                            Exit Sub                                        End If                                        oRecordSet.MoveFirst()                                        Me.p_Seq = oRecordSet.Fields.Item(0).Value + 1                                        l_matrix_nev = "Item26"                                        l_eredeti_tabla_nev = "@IFSZ_CASH_TXN_LINES"                                        l_tabla_nev = "IFSZ_CASH_TXN_LINES"                                        utdTable = m_ParentAddon.SboCompany.UserTables.Item(l_tabla_nev)


                                        'oRecordSet = Me.SBO_Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                                        'oRecordSetB = Me.SBO_Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

                                        'p_select = "select 1 from OJDT where Ref2 = '" & Me.p_ref2 & "'"

                                        'p_selectB = "select Code, Name, U_CashCode, U_CurrCode, U_Balance from [@IFSZ_CASHPNT_BLNCS] where U_CashCode = '" & Me.p_penztar_kod & "' and U_CurrCode = '" & Me.p_pnm_kod & "'"

                                        'oRecordSet.DoQuery(p_select)
                                        'If oRecordSet.RecordCount <> 1 Then
                                        '    'oForm_Eredeti.TetelFeltolt()
                                        '    Exit Sub
                                        'End If

                                        'm_ParentAddOn.SboCompany.StartTransaction()
                                        'p_select = "select max(U_Seq) from [@IFSZ_CASH_TXN_LINES] where U_CshTxn = '" & Me.p_CshTxn & "'"

                                        'oRecordSet.DoQuery(p_select)
                                        'If oRecordSet.RecordCount > 1 Then
                                        '    Exit Sub
                                        'End If


                                        'oRecordSet.MoveFirst()
                                        'Me.p_Seq = oRecordSet.Fields.Item(0).Value + 1

                                        'l_matrix_nev = "Item26"
                                        'l_eredeti_tabla_nev = "@IFSZ_CASH_TXN_LINES"
                                        'l_tabla_nev = "IFSZ_CASH_TXN_LINES"
                                        'utdTable = m_ParentAddon.SboCompany.UserTables.Item(l_tabla_nev)

                                        'l_code = Me.get_code_from_sequence()
                                        With utdTable.UserFields.Fields                                            If utdTable.GetByKey(p_code) = False Then                                                utdTable.Code = p_code.ToString                                                utdTable.Name = p_code.ToString                                                .Item("U_CshTxn").Value = p_CshTxn                                                .Item("U_Seq").Value = p_Seq                                                .Item("U_TxnCode").Value = p_TxnCode                                                .Item("U_LineSts").Value = "2"                                                .Item("U_Amount").Value = p_osszeg
                                                '.Item("U_AmountFC").Value = p_osszegFC
                                                .Item("U_AmountSP").Value = p_osszegFC                                                .Item("U_Account").Value = Me.p_fokonyvi_szamMGS                                                .Item("U_CardCode").Value = Me.p_pnr_kod                                                .Item("U_EmpId").Value = Me.p_dlgID                                                .Item("U_RefNum").Value = Me.p_RefNum                                                .Item("U_PrcCode").Value = Me.p_PrcCode                                                .Item("U_PrjCode").Value = Me.p_PrjCode                                                .Item("U_OcrCode2").Value = Me.p_OcrCode2                                                .Item("U_OcrCode3").Value = Me.p_OcrCode3                                                .Item("U_OcrCode4").Value = Me.p_OcrCode4                                                .Item("U_OcrCode5").Value = Me.p_OcrCode5                                                l_datetime = Me.SBO_Application.Company.ServerDate                                                .Item("U_CreDate").Value = l_datetime                                                .Item("U_CreUser").Value = Me.SBO_Company.UserName                                                .Item("U_DocNum").Value = Me.p_DocNum                                                .Item("U_Comment").Value = Me.p_megjegyzes                                                If utdTable.Add <> 0 Then                                                    m_ParentAddon.SboCompany.GetLastError(lng_errCode, str_errMsg)                                                    m_ParentAddon.SboApplication.MessageBox(str_errMsg & Chr(10) &
                                                    " " & m_ParentAddon.LocRM.GetString("ifsz-18197") & " = " & lng_errCode.ToString())
                                                    ' hibak�d = 
                                                End If                                            End If                                        End With

                                        'A BLNCS t�bla t�lt�se

                                        oRecordSetB.DoQuery(p_selectB)                                        oRecordSetB.MoveFirst()                                        BlnCode = oRecordSetB.Fields.Item("Code").Value                                        l_blnc = oRecordSetB.Fields.Item("U_Balance").Value                                        utdTableB = m_ParentAddon.SboCompany.UserTables.Item("IFSZ_CASHPNT_BLNCS")                                        With utdTableB.UserFields.Fields                                            If utdTableB.GetByKey(BlnCode) = True Then                                                .Item("U_Balance").Value = l_blnc + l_irany * Me.p_osszeg                                                If utdTableB.Update <> 0 Then                                                    m_ParentAddon.SboCompany.GetLastError(lng_errCode, str_errMsg)                                                    m_ParentAddon.SboApplication.MessageBox(str_errMsg & Chr(10) &
                                                    " " & m_ParentAddon.LocRM.GetString("ifsz-18198") & " = " & lng_errCode.ToString())
                                                    '" hibak�d = "
                                                End If                                            Else                                                BlnCode = Me.get_code_from_sequence()                                                utdTableB.Code = BlnCode                                                utdTableB.Name = BlnCode                                                .Item("U_CashCode").Value = Me.p_penztar_kod                                                .Item("U_CurrCode").Value = Me.p_pnm_kod                                                .Item("U_Balance").Value = l_irany * Me.p_osszeg                                                If utdTableB.Add <> 0 Then                                                    m_ParentAddon.SboCompany.GetLastError(lng_errCode, str_errMsg)                                                    m_ParentAddon.SboApplication.MessageBox(str_errMsg & Chr(10) &
                                                    " " & m_ParentAddon.LocRM.GetString("ifsz-18199") & " = " & lng_errCode.ToString())
                                                    '" hibak�d = "
                                                End If                                            End If                                        End With                                        Me.CommitTransaction()                                        oForm = Me.m_ParentAddon.SboApplication.Forms.Item(oForm_Eredeti.UniqueID)                                        l_ossz_ertek = CDbl(Replace(oForm.Items.Item("Item12").Specific.string, oForm_Eredeti.p_EzresEvt, "")) + l_irany * p_osszeg                                        oForm.Items.Item("Item12").Specific.string = l_ossz_ertek                                        Dim l_balance As Double                                        utdTableBl = Me.m_ParentAddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oChartOfAccounts)                                        utdTableBl.GetByKey(p_fokonyvi_szam)                                        oRcdSet = Me.SBO_Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)                                        oCurrRate = Me.m_ParentAddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoBridge)                                        oRcdSet = oCurrRate.GetLocalCurrency                                        If oRcdSet.Fields.Item(0).Value <> Me.p_pnm_kod Then                                            l_balance = utdTableBl.Balance_FrgnCurr                                        Else                                            l_balance = utdTableBl.Balance                                        End If                                        oForm.Items.Item("Item14").Specific.string = l_balance                                        oForm_Eredeti.TetelFeltolt()                                    Catch ex As Exception                                        m_ParentAddon.SboApplication.MessageBox(ex.ToString)                                        Me.RollbackTransaction()                                        m_ParentAddon.SboApplication.MessageBox(m_ParentAddon.LocRM.GetString("ifsz-18200"))
                                        '"A p�nzt�r t�tel besz�r�sa nem siker�lt. L�pjen kapcsolatba a rendszer adminisztr�torral!"
                                        m_ParentAddon.BlockEvents = False                                        BubbleEvent = False                                        Exit Sub                                    End Try


                                    Try
                                        'A bizonylatsz�m besz�r�sa a napl�k�nyvel�sbe

                                        m_ParentAddon.SboCompany.StartTransaction()
                                        Journal = Me.m_ParentAddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oJournalEntries)

                                        If pVal.FormType = "170" Then
                                            p_select = "select TransId from [ORCT] where DocNum = '" & Me.p_DocNum & "'"
                                        Else
                                            p_select = "select TransId from [OVPM] where DocNum = '" & Me.p_DocNum & "'"
                                        End If
                                        oRecordSet.DoQuery(p_select)

                                        oRecordSet.MoveFirst()
                                        l_num = oRecordSet.Fields.Item(0).Value
                                        Journal.GetByKey(l_num)
                                        JournalLines = Journal.Lines
                                        a = JournalLines.Count

                                        b = JournalLines.AccountCode

                                        JournalLines.SetCurrentLine(1)

                                        For j = 0 To a - 1
                                            JournalLines.SetCurrentLine(j)
                                            b = JournalLines.AccountCode

                                            If b = Me.p_fokonyvi_szam Then
                                                'JournalLines.ReferenceDate2 = Me.p_bizonylat_szam
                                                'Journal.Update()
                                                p_select = "select Ref3Line from JDT1 where transid = '" & l_num & "' and Line_Id = '" & JournalLines.Line_ID & "'"
                                                oRecordSet.DoQuery(p_select)
                                                If oRecordSet.Fields.Item(0).Value = "" Then
                                                    p_select = "Update JDT1 set Ref3Line = '" & Me.p_bizonylat_szam & "' where transid = '" & l_num & "' and Line_Id = '" & JournalLines.Line_ID & "'"
                                                    oRecordSet.DoQuery(p_select)
                                                End If
                                                Exit For
                                            End If
                                            'b = JournalLines.ShortName
                                        Next j

                                        'A bizonylatsz�m besz�r�sa a napl�k�nyvel�sbe: V�ge!

                                    Finally
                                        If (Not Journal Is Nothing) Then
                                            System.Runtime.InteropServices.Marshal.ReleaseComObject(Journal)
                                            Journal = Nothing
                                        End If

                                    End Try

                                    'A ProfitCenter besz�r�sa a napl�k�nyvel�sbe
                                    If Me.p_PrcCode <> "" Or Me.p_PrjCode <> "" Then

                                        Journal = Me.m_ParentAddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oJournalEntries)

                                        If pVal.FormType = "170" Then
                                            p_select = "select TransId from [ORCT] where DocNum = '" & Me.p_DocNum & "'"
                                        Else
                                            p_select = "select TransId from [OVPM] where DocNum = '" & Me.p_DocNum & "'"
                                        End If
                                        oRecordSet.DoQuery(p_select)

                                        oRecordSet.MoveFirst()
                                        l_num = oRecordSet.Fields.Item(0).Value
                                        Journal.GetByKey(l_num)
                                        JournalLines = Journal.Lines
                                        a = JournalLines.Count

                                        b = JournalLines.AccountCode

                                        JournalLines.SetCurrentLine(1)

                                        For j = 0 To a - 1
                                            JournalLines.SetCurrentLine(j)
                                            b = JournalLines.AccountCode

                                            If Me.p_szamla_tipus = "F" Then
                                                If b = Me.p_fokonyvi_szamMGS Then
                                                    JournalLines.CostingCode = Me.p_PrcCode
                                                    JournalLines.CostingCode2 = Me.p_OcrCode2
                                                    JournalLines.CostingCode3 = Me.p_OcrCode3
                                                    JournalLines.CostingCode4 = Me.p_OcrCode4
                                                    JournalLines.CostingCode5 = Me.p_OcrCode5
                                                    JournalLines.ProjectCode = Me.p_PrjCode
                                                    Journal.Update()
                                                    Exit For
                                                End If
                                            Else
                                                If JournalLines.ShortName = Me.p_pnr_kod Then
                                                    JournalLines.CostingCode = Me.p_PrcCode
                                                    JournalLines.CostingCode2 = Me.p_OcrCode2
                                                    JournalLines.CostingCode3 = Me.p_OcrCode3
                                                    JournalLines.CostingCode4 = Me.p_OcrCode4
                                                    JournalLines.CostingCode5 = Me.p_OcrCode5
                                                    JournalLines.ProjectCode = Me.p_PrjCode
                                                    Journal.Update()
                                                    Exit For
                                                End If
                                                'b = JournalLines.ShortName
                                            End If
                                        Next j

                                    End If
                                    'A ProfitCenter besz�r�sa a napl�k�nyvel�sbe: V�ge!

                                End If                                Me.CommitTransaction()
                                Me.m_SboForm.Close()


                            Catch ex As Exception
                                m_ParentAddon.SboApplication.MessageBox(ex.ToString)                                Me.RollbackTransaction()
                                m_ParentAddon.SboApplication.MessageBox(ex.ToString)
                                m_ParentAddon.BlockEvents = False
                                BubbleEvent = False

                            Finally
                                If (Not oRecordSet Is Nothing) Then
                                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRecordSet)
                                    oRecordSet = Nothing
                                End If
                                If (Not oRecordSetB Is Nothing) Then
                                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRecordSetB)
                                    oRecordSet = Nothing
                                End If
                                If (Not Journal Is Nothing) Then
                                    System.Runtime.InteropServices.Marshal.ReleaseComObject(Journal)
                                    Journal = Nothing
                                End If
                                If (Not utdTableBl Is Nothing) Then
                                    System.Runtime.InteropServices.Marshal.ReleaseComObject(utdTableBl)
                                    utdTableBl = Nothing
                                End If
                                If (Not oRcdSet Is Nothing) Then
                                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRcdSet)
                                    oRcdSet = Nothing
                                End If
                                If (Not oCurrRate Is Nothing) Then
                                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oCurrRate)
                                    oCurrRate = Nothing
                                End If
                                If IFSZ_CashTxn_Matrix.KimenoFizetes = True Then
                                    IFSZ_CashTxn_Matrix.KimenoFizetes = False
                                ElseIf IFSZ_CashTxn_Matrix.BejovoFizetes = True Then
                                    IFSZ_CashTxn_Matrix.BejovoFizetes = False
                                End If

                            End Try

                        End If                End Select            End If        End If    End Sub    Public Overrides Sub HANDLE_MENU_EVENTS(ByRef pVal As SAPbouiCOM.MenuEvent, ByRef BubbleEvent As Boolean)
        If pVal.MenuUID = "2818" And Me.p_elso AndAlso pVal.BeforeAction = False Then
            If CType(IFSZ_Globals.m_ParentAddOn, IFSZ_Addon).SboCompany.Version >= 910000 Then
                Dim l_menuactivatethread As New System.Threading.Thread(AddressOf Me.threadmenuactivate)
                l_menuactivatethread.Start()
            Else
                Me.m_ParentAddon.SboApplication.ActivateMenuItem(5892)
            End If
        End If

        If pVal.MenuUID = "2817" And Me.p_elso Then
            If CType(IFSZ_Globals.m_ParentAddOn, IFSZ_Addon).SboCompany.Version >= 910000 Then
                Dim l_menuactivatethread As New System.Threading.Thread(AddressOf Me.threadmenuactivate)
                l_menuactivatethread.Start()
            Else
                Me.m_ParentAddon.SboApplication.ActivateMenuItem(5892)
            End If
        End If

        If IFSZ_CashTxn_Matrix.KimenoFizetes = True Then        End If    End Sub





#Region "Public"    Public Overridable Sub set_item_value(ByVal p_item As String, ByVal p_oszlop As String, ByVal p_sor As Integer, ByVal p_ertek As String, Optional ByVal p_combo_index As Integer = 0)        Dim oMatrix As SAPbouiCOM.Matrix        Dim oColumn As SAPbouiCOM.Column        Dim oEditText As SAPbouiCOM.EditText        Dim oComboBox As SAPbouiCOM.ComboBox        Dim oCheckBox As SAPbouiCOM.CheckBox        Dim l_ertek As String        If m_SboForm.Items.Item(p_item).Type = SAPbouiCOM.BoFormItemTypes.it_MATRIX Then            oMatrix = m_SboForm.Items.Item(p_item).Specific            oColumn = oMatrix.Columns.Item(p_oszlop)            Select Case oColumn.Type                Case SAPbouiCOM.BoFormItemTypes.it_EDIT                    oEditText = oColumn.Cells.Item(p_sor).Specific                    oEditText.String = p_ertek                Case SAPbouiCOM.BoFormItemTypes.it_COMBO_BOX                    oComboBox = oColumn.Cells.Item(p_sor).Specific                    oComboBox.Select(p_ertek, p_combo_index)                Case SAPbouiCOM.BoFormItemTypes.it_CHECK_BOX                    oCheckBox = oColumn.Cells.Item(p_sor).Specific                    If oCheckBox.Checked() <> p_ertek Then
                        'oCheckBox.Checked = True
                        oMatrix.Columns.Item(p_oszlop).Cells.Item(p_sor).Click()                    End If                Case SAPbouiCOM.BoFormItemTypes.it_LINKED_BUTTON                    oEditText = oColumn.Cells.Item(p_sor).Specific
                    'oLink = oColumn.Cells.Item(p_sor).Specific
                    'oColumn.Editable = True
                    If p_ertek = "" Then
                        'oLink.String = Nothing
                        oEditText.String = Nothing                    Else
                        'oLink.String = p_ertek
                        oEditText.String = p_ertek                    End If            End Select        ElseIf m_SboForm.Items.Item(p_item).Type = SAPbouiCOM.BoFormItemTypes.it_EDIT Then            oEditText = m_SboForm.Items.Item(p_item).Specific            oEditText.String = p_ertek        ElseIf m_SboForm.Items.Item(p_item).Type = SAPbouiCOM.BoFormItemTypes.it_COMBO_BOX Then            oComboBox = m_SboForm.Items.Item(p_item).Specific            oComboBox.Select(p_ertek, p_combo_index)        ElseIf m_SboForm.Items.Item(p_item).Type = SAPbouiCOM.BoFormItemTypes.it_CHECK_BOX Then            oCheckBox = m_SboForm.Items.Item(p_item).Specific            If oCheckBox.Checked() <> p_ertek Then                m_SboForm.Items.Item(p_item).Click()            End If        ElseIf m_SboForm.Items.Item(p_item).Type = SAPbouiCOM.BoFormItemTypes.it_EXTEDIT Then            oEditText = m_SboForm.Items.Item(p_item).Specific            oEditText.String = p_ertek        End If    End Sub    Public Function get_item_value(ByVal p_item As String, ByVal p_oszlop As String, ByVal p_sor As Integer, Optional ByVal lookup_e As Boolean = False)        Dim oMatrix As SAPbouiCOM.Matrix        Dim oColumn As SAPbouiCOM.Column        Dim oEditText As SAPbouiCOM.EditText        Dim oComboBox As SAPbouiCOM.ComboBox        Dim oCheckBox As SAPbouiCOM.CheckBox        Dim l_ertek As String        If m_SboForm.Items.Item(p_item).Type = SAPbouiCOM.BoFormItemTypes.it_MATRIX Then            oMatrix = m_SboForm.Items.Item(p_item).Specific            oColumn = oMatrix.Columns.Item(p_oszlop)            Select Case oColumn.Type                Case SAPbouiCOM.BoFormItemTypes.it_EDIT                    oEditText = oColumn.Cells.Item(p_sor).Specific                    l_ertek = oEditText.String                    Return l_ertek                Case SAPbouiCOM.BoFormItemTypes.it_LINKED_BUTTON                    oEditText = oColumn.Cells.Item(p_sor).Specific                    l_ertek = oEditText.String                    Return l_ertek                Case SAPbouiCOM.BoFormItemTypes.it_COMBO_BOX                    oComboBox = oColumn.Cells.Item(p_sor).Specific                    If lookup_e = True Then                        Return oComboBox.Selected.Description                    Else                        Return oComboBox.Selected.Value                    End If                Case SAPbouiCOM.BoFormItemTypes.it_CHECK_BOX                    oCheckBox = oColumn.Cells.Item(p_sor).Specific                    If oCheckBox.Checked Then                        Return oCheckBox.ValOn                    Else                        Return oCheckBox.ValOff                    End If            End Select        ElseIf m_SboForm.Items.Item(p_item).Type = SAPbouiCOM.BoFormItemTypes.it_EDIT Then            oEditText = m_SboForm.Items.Item(p_item).Specific            l_ertek = oEditText.String            Return l_ertek        ElseIf m_SboForm.Items.Item(p_item).Type = SAPbouiCOM.BoFormItemTypes.it_COMBO_BOX Then            oComboBox = m_SboForm.Items.Item(p_item).Specific            If (Not oComboBox.Selected Is Nothing) Then                If lookup_e = True Then                    Return oComboBox.Selected.Description                Else                    Return oComboBox.Selected.Value                End If            Else                Return ""            End If        ElseIf m_SboForm.Items.Item(p_item).Type = SAPbouiCOM.BoFormItemTypes.it_CHECK_BOX Then            oCheckBox = m_SboForm.Items.Item(p_item).Specific            If oCheckBox.Checked Then                Return oCheckBox.ValOn            Else                Return oCheckBox.ValOff            End If        End If        Return ""    End Function



#End Region
    Private Function get_code_from_sequence() As String        Dim l_seq As New IFSZ_Sequence(m_ParentAddon)        Return l_seq.get_next_seq("DEFAULT")    End Function    Private Function get_osszeg(ByVal formtype As Integer) As Double        Dim oMatrix As SAPbouiCOM.Matrix        Dim oColumn As SAPbouiCOM.Column        If Me.p_szamla_tipus = "S" And formtype = 426 Then            oMatrix = Me.m_SboForm.Items.Item("20").Specific        End If    End Function    Private Sub CommitTransaction()
        If m_ParentAddon.SboCompany.InTransaction Then
            m_ParentAddon.SboCompany.EndTransaction(SAPbobsCOM.BoWfTransOpt.wf_Commit)
        End If
    End Sub

    Private Sub RollbackTransaction()
        If m_ParentAddon.SboCompany.InTransaction Then
            m_ParentAddon.SboCompany.EndTransaction(SAPbobsCOM.BoWfTransOpt.wf_RollBack)
        End If
    End Sub

    Public Sub threadmenuactivate()        Dim m_oProgBar As SAPbouiCOM.ProgressBar        m_oProgBar = Me.m_ParentAddon.SboApplication.StatusBar.CreateProgressBar("Fizet�s form adatainak kit�lt�se", 10, False)        Dim i As Integer = 0
        While i < 20
            i += 1
            System.Threading.Thread.Sleep(200)
            If m_adatok_kitoltve Then
                Exit While
            End If
        End While
        For i = 0 To 10
            'If Me.m_ParentAddon.SboApplication.Menus.Item("5892").Enabled Then
            '    Exit For
            'End If
            'If i > 5 Then
            '    m_oProgBar.Value = 5
            'Else
            m_oProgBar.Value = i            'End If
            System.Threading.Thread.Sleep(200)
            If Me.m_ParentAddon.SboApplication.Menus.Item("5892").Enabled Then
                Exit For
            End If
        Next
        m_oProgBar.Stop()        m_oProgBar = Nothing        Me.m_ParentAddon.SboApplication.ActivateMenuItem(5892)
        Me.m_penzeszsak_ok = True
    End SubEnd Class