Option Strict Off
Option Explicit On 
Imports SboAddOnBase
Imports IFSZ_AddOnBase
Public Class Penztar_torzs
    Inherits IFSZ_OACT

    Private p_EzresEvt As String
    Private p_TizedesEvt As String

    Public Sub New(ByRef ParentAddon As SBOAddOn, ByVal FunctionCode As String)
        MyBase.New(ParentAddon, enSboFormTypes.XmlFile, enSAPFormTypes.Penztar_torzs, FunctionCode)

        Dim oRecordSet As SAPbobsCOM.Recordset
        Dim p_select As String

        Try
            oRecordSet = Me.SBO_Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            p_select = "select DecSep, ThousSep from [OADM]"
            oRecordSet.DoQuery(p_select)

            oRecordSet.MoveFirst()
            Me.p_TizedesEvt = oRecordSet.Fields.Item(0).Value
            Me.p_EzresEvt = oRecordSet.Fields.Item(1).Value
        Finally
            If (Not oRecordSet Is Nothing) Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oRecordSet)
                oRecordSet = Nothing
            End If
        End Try

        initialize()
    End Sub




    Private Sub initialize()
        '//*************************************************************
        '// set SBO_Application with an initialized application object
        '//*************************************************************
        SetApplication()
        '//*************************************************************
        '// Create a simple Form with matrix
        '// Don't forget: once you've created the form
        '// save it as an XML and load it from XML the next
        '// time you wish to use this form
        '//*************************************************************

        CreateFormWithMatrix()

        '// Add Data Sources to the Form
        AddDataSourceToForm()

        '// Bind the Form's items with the desired data source
        BindDataToForm()

        '// Fill the matrix with data
        GetDataFromDataSource()

        '// Show my Simple Form
        m_SboForm.Visible = True

        '//*************************************************************
        '// Enable the desired tool bar items
        '//*************************************************************

        SetToolBarEnabled()

    End Sub

    Private Sub SetApplication()

    End Sub

    Private Sub CreateFormWithMatrix()
        '//*******************************************************
        '// Don't Forget:
        '// it is much more efficient to load a form from xml.
        '// use code only to create your form.
        '// once you have created it save it as XML.
        '// see "WorkingWithXML" sample project
        '//*******************************************************

        Dim oItem As SAPbouiCOM.Item

        '// *******************************************
        '// we will use the following objects to set
        '// the specific values of every item
        '// we add.
        '// this is the best way to do so
        '//*********************************************

        Dim oButton As SAPbouiCOM.Button
        Dim oMatrix As SAPbouiCOM.Matrix
        Dim oColumns As SAPbouiCOM.Columns
        Dim oColumn As SAPbouiCOM.Column

        '// add a new form
        'oForm = m_SboForm



        '// set the form properties
        m_SboForm.Title = m_ParentAddon.LocRM.GetString("ifsz-18217") '"P�nzt�r t�rzs"
        m_SboForm.Left = 336
        m_SboForm.ClientWidth = 576
        m_SboForm.Width = 576
        m_SboForm.Top = 44
        m_SboForm.ClientHeight = 325
        m_SboForm.Height = 325

        '//*****************************************
        '// Adding Items to the form
        '// and setting their properties
        '//*****************************************


        '/**********************
        '// Adding an Ok button
        '//*********************

        '// We get automatic event handling for
        '// the Ok and Cancel Buttons by setting
        '// their UIDs to 1 and 2 respectively

        oItem = m_SboForm.Items.Add("1", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
        oItem.Left = 5
        oItem.Width = 65
        oItem.Top = 273
        oItem.Height = 19

        oButton = oItem.Specific

        oButton.Caption = "Ok"

        '//************************
        '// Adding a Cancel button
        '//***********************

        oItem = m_SboForm.Items.Add("2", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
        oItem.Left = 75
        oItem.Width = 65
        oItem.Top = 273
        oItem.Height = 19

        oButton = oItem.Specific

        oButton.Caption = "Cancel"


        oItem = m_SboForm.Items.Add("Aktualizal", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
        oItem.Left = 145
        oItem.Width = 65
        oItem.Top = 273
        oItem.Height = 19

        oButton = oItem.Specific

        oButton.Caption = m_ParentAddon.LocRM.GetString("ifsz-18218") '"Szinkroniz�l"

        '//***************************
        '// Adding a Matrix item
        '//***************************

        oItem = m_SboForm.Items.Add("OACTMatrix", SAPbouiCOM.BoFormItemTypes.it_MATRIX)
        oItem.Left = 5
        oItem.Width = 550
        oItem.Top = 5
        oItem.Height = 260

        oMatrix = oItem.Specific
        oColumns = oMatrix.Columns

        '//***********************************
        '// Adding Culomn items to the matrix
        '//***********************************

        oColumn = oColumns.Add("Ssz", SAPbouiCOM.BoFormItemTypes.it_EDIT)
        oColumn.TitleObject.Caption = m_ParentAddon.LocRM.GetString("ifsz-18219") '"Ssz"
        oColumn.Width = 30
        oColumn.Editable = False
        oColumn.RightJustified = True

        oColumn = oColumns.Add("AcctCode", SAPbouiCOM.BoFormItemTypes.it_EDIT)
        oColumn.TitleObject.Caption = m_ParentAddon.LocRM.GetString("ifsz-18220") '"F�k�nyvi sz�m"
        oColumn.Width = 100
        oColumn.Editable = True
        oColumn.Visible = True

        oColumn = oColumns.Add("AcctName", SAPbouiCOM.BoFormItemTypes.it_EDIT)
        oColumn.TitleObject.Caption = m_ParentAddon.LocRM.GetString("ifsz-18221") '"P�nzt�r n�v"
        oColumn.Width = 200
        oColumn.Editable = True

        oColumn = oColumns.Add("Currency", SAPbouiCOM.BoFormItemTypes.it_EDIT)
        oColumn.TitleObject.Caption = m_ParentAddon.LocRM.GetString("ifsz-18222") '"P�nznem"
        oColumn.Width = 100
        oColumn.Editable = False

        oColumn = oColumns.Add("U_IFSZCASH", SAPbouiCOM.BoFormItemTypes.it_COMBO_BOX)
        oColumn.TitleObject.Caption = m_ParentAddon.LocRM.GetString("ifsz-18223") '"P�nzt�rk�d"
        oColumn.Width = 100
        oColumn.Editable = True
        oColumn.DisplayDesc = True

        'oColumn = oColumns.Add("U_PBT_STAND", SAPbouiCOM.BoFormItemTypes.it_CHECK_BOX)
        'oColumn.TitleObject.Caption = "Bizonylat stand"
        'oColumn.Width = 100
        'oColumn.Editable = True
        'oColumn.DisplayDesc = True

        'oColumn = oColumns.Add("U_PZT_STAND", SAPbouiCOM.BoFormItemTypes.it_CHECK_BOX)
        'oColumn.TitleObject.Caption = "P�nzt�r stand"
        'oColumn.Width = 100
        'oColumn.Editable = True
        'oColumn.DisplayDesc = True


        oColumn = oColumns.Add("AmountIfsz", SAPbouiCOM.BoFormItemTypes.it_EDIT)
        oColumn.TitleObject.Caption = m_ParentAddon.LocRM.GetString("ifsz-18224") '"P�nzt�regyenleg"
        oColumn.Width = 100
        oColumn.Editable = False
        oColumn.DisplayDesc = True

        oColumn = oColumns.Add("AmountCash", SAPbouiCOM.BoFormItemTypes.it_EDIT)
        oColumn.TitleObject.Caption = m_ParentAddon.LocRM.GetString("ifsz-18225") '"Sz�mlaegyenleg"
        oColumn.Width = 100
        oColumn.Editable = False
        oColumn.DisplayDesc = True


    End Sub

    Public Sub AddDataSourceToForm()
        '//****************************************************************
        '// every item must be binded to a Data Source
        '// prior of binding the data we must add Data sources to the form
        '//****************************************************************

        '// Add a DBDataSource to Users table
        m_SboForm.DataSources.DBDataSources.Add("OACT")

        '// Add a user data source
        m_SboForm.DataSources.UserDataSources.Add("Ssz", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 30)
        m_SboForm.DataSources.UserDataSources.Add("Ifsz", SAPbouiCOM.BoDataType.dt_SUM, 30)
        m_SboForm.DataSources.UserDataSources.Add("Cash", SAPbouiCOM.BoDataType.dt_SUM, 30)

        '// you add many data sources

    End Sub

    Public Sub BindDataToForm()

        '//********************************************************
        '// binding data to the Form items will set the connection
        '// between the requested DB table field and the item
        '//********************************************************

        Dim oMatrix As SAPbouiCOM.Matrix
        Dim oColumns As SAPbouiCOM.Columns
        Dim oColumn As SAPbouiCOM.Column

        '// getting the form's matrix object
        oMatrix = m_SboForm.Items.Item("OACTMatrix").Specific

        oColumns = oMatrix.Columns

        oColumn = oColumns.Item("Ssz")
        oColumn.DataBind.SetBound(True, "", "Ssz")

        '// getting the matrix columns by the UID
        oColumn = oColumns.Item("AcctCode")

        '// bindidng the data
        oColumn.DataBind.SetBound(True, "OACT", "AcctCode")
        'oColumn.DataBind.SetBound(True, "", "Code")

        oColumn = oColumns.Item("AcctName")

        oColumn.DataBind.SetBound(True, "OACT", "AcctName")
        'oColumn.DataBind.SetBound(True, "", "Name")

        oColumn = oColumns.Item("Currency")

        oColumn.DataBind.SetBound(True, "OACT", "ActCurr")
        'oColumn.DataBind.SetBound(True, "", "U_Descr")



        oColumn = oColumns.Item("U_IFSZCASH")

        Dim utdTable As SAPbobsCOM.ChartOfAccounts
        Dim l_name As String
        Try
            utdTable = Me.m_ParentAddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oChartOfAccounts)
            l_name = utdTable.UserFields.Fields.Item("U_IFSZCASH").Name()
        Finally
            If (Not utdTable Is Nothing) Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(utdTable)
                utdTable = Nothing
            End If
        End Try


        oColumn.DataBind.SetBound(True, "OACT", "U_IFSZCASH")

        oColumn = oColumns.Item("AmountIfsz")
        oColumn.DataBind.SetBound(True, "", "Ifsz")

        oColumn = oColumns.Item("AmountCash")
        oColumn.DataBind.SetBound(True, "", "Cash")

    End Sub

    Public Sub GetDataFromDataSource()

        Dim oDBDataSource As SAPbouiCOM.DBDataSource
        Dim oUserDataSource As SAPbouiCOM.UserDataSource
        Dim oMatrix As SAPbouiCOM.Matrix
        Dim oColumn As SAPbouiCOM.Column
        Dim oCombo As SAPbouiCOM.ComboBox
        Dim oValues As SAPbouiCOM.ValidValues
        Dim oConditions = New SAPbouiCOM.Conditions
        Dim oCondition = oConditions.Add
        Dim p_select As String
        Dim l_ertek As String
        Dim oColumns As SAPbouiCOM.Columns
        Dim oItem As SAPbouiCOM.Item


        Dim i As Integer '// to be used as counter

        '// getting the data sources from the form

        oDBDataSource = m_SboForm.DataSources.DBDataSources.Item("OACT")

        '// setting the user data source data
        oUserDataSource = m_SboForm.DataSources.UserDataSources.Item("Ssz")

        '// getting the matrix from the form
        oMatrix = m_SboForm.Items.Item("OACTMatrix").Specific
        oColumn = oMatrix.Columns.Item("Ssz")

        Try
            oCombo = oMatrix.Columns.Item("U_IFSZCASH").Cells.Item(1).Specific
            oValues = oCombo.ValidValues
            For i = 0 To oValues.Count - 1
                oValues.Remove(0, SAPbouiCOM.BoSearchKey.psk_Index)
            Next
        Catch ex As Exception

        End Try

        oMatrix.Clear()

        '// Querying the DB Data source
        oCondition.BracketOpenNum = 2
        oCondition.Alias = "ActCurr"
        oCondition.Operation = SAPbouiCOM.BoConditionOperation.co_NOT_EQUAL
        oCondition.CondVal = "##"
        oCondition.BracketCloseNum = 1
        oCondition.Relationship = SAPbouiCOM.BoConditionRelationship.cr_AND

        oCondition = oConditions.Add
        oCondition.BracketOpenNum = 1
        oCondition.Alias = "U_IFSZCASH"
        oCondition.Operation = SAPbouiCOM.BoConditionOperation.co_GRATER_THAN
        oCondition.CondVal = " "
        oCondition.BracketCloseNum = 1
        oCondition.Relationship = SAPbouiCOM.BoConditionRelationship.cr_AND

        oCondition = oConditions.Add
        oCondition.BracketOpenNum = 1
        oCondition.Alias = "Finanse"
        oCondition.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL
        oCondition.CondVal = "Y"
        oCondition.BracketCloseNum = 2

        oDBDataSource.Query(oConditions)

        l_ertek = "Y"
        p_select = "select Code, Name from [@ifsz_cashpoints]"  ' where U_IsValid = '" & l_ertek & "'
        For i = 0 To oDBDataSource.size - 1
            oUserDataSource.Value = i + 1
            oDBDataSource.Offset = i
            oMatrix.AddRow()
            If i = 0 Then
                load_combo("OACTMatrix", "U_IFSZCASH", p_select)
            End If

            Dim l_szamla_kod, l_szamla_nev As String
            Dim utdTable As SAPbobsCOM.ChartOfAccounts
            Dim oRecordSet As SAPbobsCOM.Recordset
            Dim oRcdSet As SAPbobsCOM.Recordset
            Dim oCurrRate As SAPbobsCOM.SBObob
            Dim l_penztar, l_penznem, p_select2 As String
            Dim l_balance, l_penztar_egyenleg As Double

            Try

                l_szamla_kod = Me.get_item_value("OACTMatrix", "AcctCode", i + 1)
                l_penznem = Me.get_item_value("OACTMatrix", "Currency", i + 1)
                l_penztar = Me.get_item_value("OACTMatrix", "U_IFSZCASH", i + 1)

                utdTable = Me.m_ParentAddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oChartOfAccounts)
                utdTable.GetByKey(l_szamla_kod)

                oCurrRate = Me.m_ParentAddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoBridge)
                oRcdSet = oCurrRate.GetLocalCurrency
                If oRcdSet.Fields.Item(0).Value <> l_penznem Then
                    l_balance = utdTable.Balance_FrgnCurr
                Else
                    l_balance = utdTable.Balance
                End If


                p_select2 = "select U_Balance from [@IFSZ_CASHPNT_BLNCS] where U_CurrCode = '" & l_penznem & "' and U_CashCode = '" & l_penztar & "'"
                oRcdSet.DoQuery(p_select2)
                If oRcdSet.RecordCount <> 1 Then
                    l_penztar_egyenleg = 0
                End If

                If oRcdSet.RecordCount = 1 Then
                    oRcdSet.MoveFirst()
                    l_penztar_egyenleg = oRcdSet.Fields.Item(0).Value
                End If

                'oItem = m_SboForm.Items.Add("OACTMatrix", SAPbouiCOM.BoFormItemTypes.it_MATRIX)

                oColumn = oMatrix.Columns.Item("AmountIfsz")
                'oColumn.Editable = True

                oColumn = oMatrix.Columns.Item("AmountCash")
                'oColumn.Editable = True


                Me.set_item_value("OACTMatrix", "AmountIfsz", i + 1, l_penztar_egyenleg)
                Me.set_item_value("OACTMatrix", "AmountCash", i + 1, l_balance)


                oColumn = oMatrix.Columns.Item("AmountIfsz")
                'oColumn.Editable = False

                oColumn = oMatrix.Columns.Item("AmountCash")
                'oColumn.Editable = False

            Finally
                If (Not oRecordSet Is Nothing) Then
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRecordSet)
                    oRecordSet = Nothing
                End If
                If (Not oRcdSet Is Nothing) Then
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRcdSet)
                    oRcdSet = Nothing
                End If
                If (Not utdTable Is Nothing) Then
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(utdTable)
                    utdTable = Nothing
                End If
                If (Not oCurrRate Is Nothing) Then
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oCurrRate)
                    oCurrRate = Nothing
                End If
            End Try


        Next i
        If oDBDataSource.Size = 0 Then
            oUserDataSource.Value = 1
            oDBDataSource.Offset = 0
            oMatrix.AddRow()
            load_combo("OACTMatrix", "U_IFSZCASH", p_select)
        End If


        oMatrix.AutoResizeColumns()

    End Sub

    Private Sub SetToolBarEnabled()
        '// the form controlls the Menu Items
        '// the list of MenuUIDs should apear in the SDK help file
        '// otherwise look at the SBO_Aplication_MenuEvent method

        '// enable 'Next Record', 'Previous Record', 'First Data Record'
        '// and 'Last Data Record' Menu Items

        m_SboForm.EnableMenu("1288", True) 'next record 
        m_SboForm.EnableMenu("1289", True) 'previous record
        'm_SboForm.EnableMenu("1290", True) 'first record
        'm_SboForm.EnableMenu("1291", True) 'last record
        m_SboForm.EnableMenu("1281", True) 'find record ; keres�s
        m_SboForm.EnableMenu("1282", True) 'add new record ; hozz�ad�s
        m_SboForm.EnableMenu("1292", True) 'Add Matrix row ; sor l�trehoz�s
        'm_SboForm.EnableMenu("1293", True) 'Delete Matrix row ; sor t�rl�se
    End Sub


    Private Sub Connect2Company()
        Try
            'Ensure that the company object is connected
            If Not m_ParentAddon.SboCompany.Connected Then
                Dim result As Int16
                'If the company object is not connected, try to connect again
                result = m_ParentAddon.SboCompany.Connect()
                'If still doesn�t connect, throw an error.
                If result <> 0 Then
                    Dim ErrorText As String
                    m_ParentAddon.SboCompany.GetLastError(result, ErrorText)
                    Throw New Exception("Error N:" + result.ToString() + " ." + ErrorText)
                End If
            End If
        Catch excE As Exception
            m_ParentAddon.SboApplication.MessageBox(excE.ToString)
            m_ParentAddon.BlockEvents = False
        End Try
    End Sub


    Private Sub SaveAsXML()
        Dim oXmlDoc As New Xml.XmlDocument
        Dim sXmlString As String
        sXmlString = Me.m_SboForm.GetAsXML
        oXmlDoc.LoadXml(sXmlString)
        oXmlDoc.Save("C:\BT_1_tablas_form.xml")
    End Sub



    Public Overrides Sub after_event(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        If pVal.EventType = SAPbouiCOM.BoEventTypes.et_CLICK And pVal.ItemUID = "1" And pVal.Before_Action = False Then
            'Me.GetDataFromDataSource()
        End If
    End Sub

    Public Overrides Sub befor_event(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Dim l_sor, l_eredmeny As Integer
        Dim l_szamla_kod, l_penznem, l_penztar, p_selectB As String
        Dim l_penztar_egyenleg, l_balance As Double
        Dim oRecordSetB As SAPbobsCOM.Recordset
        Dim utdTableB As SAPbobsCOM.UserTable
        Dim BlnCode As String
        Dim l_blnc As Double
        Dim lng_errCode As Long
        Dim str_errMsg As String

        Try

            If pVal.Before_Action = True Then
                If pVal.ItemUID = "Aktualizal" Then
                    l_sor = Me.KivalasztottSor
                    If l_sor = 0 Then
                        Me.m_ParentAddon.SboApplication.MessageBox(m_ParentAddon.LocRM.GetString("ifsz-18226")) '"Az aktualiz�l�s el�tt v�lasszon sz�ml�t!")
                        Exit Sub
                    End If

                    l_szamla_kod = Me.get_item_value("OACTMatrix", "AcctCode", l_sor)
                    l_penznem = Me.get_item_value("OACTMatrix", "Currency", l_sor)
                    l_penztar = Me.get_item_value("OACTMatrix", "U_IFSZCASH", l_sor)

                    l_penztar_egyenleg = IFSZ_Globals.StringToDouble(Me.get_FormattedString(Me.get_item_value("OACTMatrix", "AmountIfsz", l_sor)))
                    l_balance = IFSZ_Globals.StringToDouble(Me.get_FormattedString(Me.get_item_value("OACTMatrix", "AmountCash", l_sor)))

                    If l_penztar_egyenleg <> l_balance Then
                        l_eredmeny = Me.m_ParentAddon.SboApplication.MessageBox(Replace(m_ParentAddon.LocRM.GetString("ifsz-18227"), "<p1>", l_szamla_kod), 2, m_ParentAddon.LocRM.GetString("ifsz-18228"), m_ParentAddon.LocRM.GetString("ifsz-18229"))
                        'l_eredmeny = Me.m_ParentAddon.SboApplication.MessageBox(Replace("Biztosan aktualiz�lni akarja a <p1> sz�ml�t?", "<p1>", l_szamla_kod), 2, "Igen", "Nem")
                        If l_eredmeny = 1 Then
                            oRecordSetB = Me.SBO_Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                            p_selectB = "select Code, Name, U_CashCode, U_CurrCode, U_Balance from [@IFSZ_CASHPNT_BLNCS] where U_CashCode = '" & l_penztar & "' and U_CurrCode = '" & l_penznem & "'"


                            oRecordSetB.DoQuery(p_selectB)
                            oRecordSetB.MoveFirst()
                            BlnCode = oRecordSetB.Fields.Item("Code").Value
                            l_blnc = oRecordSetB.Fields.Item("U_Balance").Value
                            utdTableB = m_ParentAddon.SboCompany.UserTables.Item("IFSZ_CASHPNT_BLNCS")
                            With utdTableB.UserFields.Fields
                                If utdTableB.GetByKey(BlnCode) = True Then
                                    .Item("U_Balance").Value = l_balance
                                    If utdTableB.Update <> 0 Then
                                        m_ParentAddon.SboCompany.GetLastError(lng_errCode, str_errMsg)
                                        m_ParentAddon.SboApplication.MessageBox(str_errMsg & Chr(10) & _
                                        " " & m_ParentAddon.LocRM.GetString("ifsz-18230") & " = " & lng_errCode.ToString())
                                        '" hibak�d = "
                                    End If
                                Else
                                    BlnCode = Me.get_code_from_sequence()
                                    utdTableB.Code = BlnCode
                                    utdTableB.Name = BlnCode
                                    .Item("U_CashCode").Value = l_penztar
                                    .Item("U_CurrCode").Value = l_penznem
                                    .Item("U_Balance").Value = l_balance

                                    If utdTableB.Add <> 0 Then
                                        m_ParentAddon.SboCompany.GetLastError(lng_errCode, str_errMsg)
                                        m_ParentAddon.SboApplication.MessageBox(str_errMsg & Chr(10) & _
                                        " " & m_ParentAddon.LocRM.GetString("ifsz-18231") & " = " & lng_errCode.ToString())
                                        '" hibak�d = "
                                    End If
                                End If

                            End With

                        Else
                            Exit Sub
                        End If


                    End If
                End If
            Else
                Select Case pVal.EventType
                    Case SAPbouiCOM.BoEventTypes.et_GOT_FOCUS
                        m_SboForm.EnableMenu("1293", False)
                End Select
            End If

        Finally
            If (Not oRecordSetB Is Nothing) Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oRecordSetB)
                oRecordSetB = Nothing
            End If
            If (Not utdTableB Is Nothing) Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(utdTableB)
                utdTableB = Nothing
            End If
        End Try

    End Sub

    Public Overrides Sub after_menu_event(ByRef pVal As SAPbouiCOM.MenuEvent, ByRef BubbleEvent As Boolean)

    End Sub

    Public Overrides Sub before_menu_event(ByRef pVal As SAPbouiCOM.MenuEvent, ByRef BubbleEvent As Boolean)

    End Sub

    Public Overrides Sub item_validate(ByVal p_ItemChanged As Boolean, ByVal p_matrix As String, ByVal p_oszlop As String, ByVal p_sor As Integer, ByVal p_ertek As String, ByVal p_lookup_ertek As String, ByRef BubbleEvent As Boolean)
        Dim oRecordSet As SAPbobsCOM.Recordset
        Dim l_string, p_select As String
        Dim l_kod As String
        Dim l_ifszcash As String
        Dim l_acctcode As String
        Dim retval As String
        Dim oMatrix As SAPbouiCOM.Matrix
        Dim oEditText As SAPbouiCOM.EditText
        Dim l_ertek As String = "Y"
        Dim l_kell_lov As Boolean = False
        Static fut_e As Boolean = False

        oMatrix = Me.m_SboForm.Items.Item(p_matrix).Specific
        l_ifszcash = Me.get_item_value(p_matrix, "U_IFSZCASH", p_sor)

        If p_oszlop = "AcctCode" And fut_e = False And l_ifszcash = "" Then 'And p_ItemChanged = True
            oEditText = oMatrix.Columns.Item(p_oszlop).Cells.Item(p_sor).Specific
            l_kod = oEditText.String

            If p_ertek.Length > 0 Then
                If p_ertek.Substring(p_ertek.Length - 1, 1) = "*" Then
                    Me.FszamLov(p_ertek.Substring(0, p_ertek.Length - 1))
                Else
                    Try
                        oRecordSet = Me.SBO_Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                        l_string = "Select AcctCode, AcctName, ActCurr " _
                                 & "  from [OACT] " _
                                 & " where AcctCode like '" & l_kod & "%'" _
                                 & "   and U_IFSZCASH is null " _
                                 & "   and Finanse = 'Y' " _
                                 & "   and ActCurr <> '##'"
                        oRecordSet.DoQuery(l_string)

                        If oRecordSet.RecordCount <= 0 Then
                            l_kell_lov = True
                            m_ParentAddon.SboApplication.MessageBox(m_ParentAddon.LocRM.GetString("ifsz-18232")) '"Nincs ilyen p�nzt�r, haszn�ljon �rt�klist�t")
                            m_ParentAddon.BlockEvents = False
                            BubbleEvent = False
                            oEditText.String = ""
                            oMatrix.Columns.Item(p_oszlop).Cells.Item(p_sor).Click()
                            fut_e = False
                            Exit Sub
                        End If

                        oEditText = oMatrix.Columns.Item("AcctCode").Cells.Item(p_sor).Specific
                        If oEditText.String <> oRecordSet.Fields.Item("AcctCode").Value Then
                            oEditText.String = oRecordSet.Fields.Item("AcctCode").Value
                        End If

                        oEditText = oMatrix.Columns.Item("AcctName").Cells.Item(p_sor).Specific
                        If oEditText.String <> oRecordSet.Fields.Item("AcctName").Value Then
                            Me.p_validal_e = False
                            oEditText.String = oRecordSet.Fields.Item("AcctName").Value
                        End If

                        oEditText = oMatrix.Columns.Item("Currency").Cells.Item(p_sor).Specific
                        If oEditText.String <> oRecordSet.Fields.Item("ActCurr").Value Then
                            Dim l_curr As String
                            l_curr = oRecordSet.Fields.Item("ActCurr").Value
                            'oMatrix.Columns.Item("Currency").Editable = True
                            oEditText.String = l_curr
                            'oMatrix.Columns.Item("Currency").Editable = False
                        End If
                        'Me.m_SboForm.Freeze(False)
                        oMatrix.Columns.Item("AcctName").Cells.Item(p_sor).Click()
                        fut_e = False

                        Me.p_validal_e = True
                    Finally
                        If (Not oRecordSet Is Nothing) Then
                            System.Runtime.InteropServices.Marshal.ReleaseComObject(oRecordSet)
                            oRecordSet = Nothing
                        End If

                    End Try

                End If
            Else
                m_ParentAddon.SboApplication.MessageBox(m_ParentAddon.LocRM.GetString("ifsz-18233")) '"A p�nzt�rat k�telez� megadni")
                BubbleEvent = False
                Exit Sub
            End If
        End If



        'If oEditText.String = "" Then
        '    m_ParentAddon.SboApplication.MessageBox("A p�nzt�rat k�telez� megadni")
        '    m_ParentAddon.BlockEvents = False
        '    BubbleEvent = False
        '    Exit Sub
        'End If

        'If p_oszlop = "AcctCode" And fut_e = False And l_ifszcash = "" And p_ItemChanged = True Then 'fut_e = False And

        '    Try
        '        fut_e = True

        '        oEditText = oMatrix.Columns.Item(p_oszlop).Cells.Item(p_sor).Specific
        '        l_kod = oEditText.String
        '        If l_kod.Substring(l_kod.Length - 1, 1) = "*" Then
        '            l_kod = l_kod.Substring(1, l_kod.Length - 1)
        '            l_kell_lov = True
        '        End If
        '        If Not l_kell_lov Then
        '            oRecordSet = Me.SBO_Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        '            l_string = "Select AcctCode, AcctName, ActCurr " _
        '                     & "  from [OACT] " _
        '                     & " where AcctCode like '" & l_kod & "%'" _
        '                     & "   and U_IFSZCASH is null " _
        '                     & "   and Finanse = 'Y' " _
        '                     & "   and ActCurr <> '##'"
        '            oRecordSet.DoQuery(l_string)
        '            If oRecordSet.RecordCount <= 0 Then
        '                l_kell_lov = True
        '                m_ParentAddon.SboApplication.MessageBox("Nincs ilyen p�nzt�r, haszn�ljon �rt�klist�t")
        '                m_ParentAddon.BlockEvents = False
        '                BubbleEvent = False
        '                oEditText.String = ""
        '                oMatrix.Columns.Item(p_oszlop).Cells.Item(p_sor).Click()
        '                fut_e = False
        '                Exit Sub
        '            End If
        '            'Me.m_SboForm.Freeze(True)
        '            oEditText = oMatrix.Columns.Item("AcctCode").Cells.Item(p_sor).Specific
        '            If oEditText.String <> oRecordSet.Fields.Item("AcctCode").Value Then
        '                oEditText.String = oRecordSet.Fields.Item("AcctCode").Value
        '            End If

        '            oEditText = oMatrix.Columns.Item("AcctName").Cells.Item(p_sor).Specific
        '            If oEditText.String <> oRecordSet.Fields.Item("AcctName").Value Then
        '                oEditText.String = oRecordSet.Fields.Item("AcctName").Value
        '            End If

        '            oEditText = oMatrix.Columns.Item("Currency").Cells.Item(p_sor).Specific
        '            If oEditText.String <> oRecordSet.Fields.Item("ActCurr").Value Then
        '                Dim l_curr As String
        '                l_curr = oRecordSet.Fields.Item("ActCurr").Value
        '                'oMatrix.Columns.Item("Currency").Editable = True
        '                oEditText.String = l_curr
        '                'oMatrix.Columns.Item("Currency").Editable = False
        '            End If
        '            'Me.m_SboForm.Freeze(False)
        '            oMatrix.Columns.Item("AcctName").Cells.Item(p_sor).Click()
        '            fut_e = False
        '        End If

        '    Catch
        '        fut_e = False
        '        Exit Sub
        '    Finally
        '        If (Not oRecordSet Is Nothing) Then
        '            System.Runtime.InteropServices.Marshal.ReleaseComObject(oRecordSet)
        '            oRecordSet = Nothing
        '        End If
        '    End Try

        'End If

        If p_oszlop = "U_IFSZCASH" And fut_e = False Then
            l_ertek = Me.get_item_value(p_matrix, p_oszlop, p_sor)
            If l_ertek = "" Then
                Try
                    l_acctcode = Me.get_item_value(p_matrix, "AcctCode", p_sor)
                    oRecordSet = Me.SBO_Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                    l_string = "Select oact.U_IFSZCASH from [OACT], [@IFSZ_CASH_TXNS] ctxs where AcctCode = '" & l_acctcode & "' and oact.U_IFSZCASH = ctxs.u_cashcode"
                    oRecordSet.DoQuery(l_string)
                    oRecordSet.MoveFirst()
                    If oRecordSet.RecordCount > 0 Then
                        l_ertek = oRecordSet.Fields.Item(0).Value
                        m_ParentAddon.SboApplication.MessageBox(m_ParentAddon.LocRM.GetString("ifsz-18234")) '"Ezt a p�nzt�rat nem t�r�lheti, hivatkozik r� p�nzt�r bizonylat")
                        m_ParentAddon.BlockEvents = False
                        BubbleEvent = False
                        set_item_value(p_matrix, p_oszlop, p_sor, l_ertek)
                        fut_e = False
                        Exit Sub
                    End If
                Finally
                    If (Not oRecordSet Is Nothing) Then
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(oRecordSet)
                        oRecordSet = Nothing
                    End If
                End Try
            End If
        End If

    End Sub

    Public Overrides Sub pre_dml(ByVal p_matrix_nev As String, ByVal p_sor_index As Integer, ByVal p_kod As String, ByVal p_torles_e As Boolean, ByRef BubbleEvent As Boolean)
        Dim oRecordSet As SAPbobsCOM.Recordset
        Dim l_string As String
        Dim l_kod As String
        Dim l_ifszcash As String
        Dim retval As String
        Dim oMatrix As SAPbouiCOM.Matrix
        Dim oEditText As SAPbouiCOM.EditText
        Dim l_curr As String
        Dim l_cash As String

        Try

            l_curr = Me.get_item_value(p_matrix_nev, "Currency", p_sor_index)
            l_cash = Me.get_item_value(p_matrix_nev, "U_IFSZCASH", p_sor_index)

            oRecordSet = Me.SBO_Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            l_string = "Select AcctName from [OACT] where ActCurr = '" & l_curr & "' and U_IFSZCASH = '" & l_cash & "'"
            oRecordSet.DoQuery(l_string)
            If oRecordSet.RecordCount > 1 Then
                m_ParentAddon.SboApplication.MessageBox(m_ParentAddon.LocRM.GetString("ifsz-18235")) '"M�r van ilyen p�nzt�r")
                m_ParentAddon.BlockEvents = False
                BubbleEvent = False
                Exit Sub
            End If


        Catch
            Exit Sub
        Finally
            If (Not oRecordSet Is Nothing) Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oRecordSet)
                oRecordSet = Nothing
            End If
        End Try

    End Sub

    Private Sub FszamLov(ByVal l_ertek As String)
        Dim p_oszlop_tipus(2) As OszlopTipus
        Dim oConditions = New SAPbouiCOM.Conditions
        Dim oRecordSet As SAPbobsCOM.Recordset
        Dim l_code, p_select, l_tipus, l_where As String

        Try
            p_oszlop_tipus(0).Title = m_ParentAddon.LocRM.GetString("ifsz-18236") '"F�k�nyvi sz�m"
            p_oszlop_tipus(0).DbNev = "AcctCode"
            p_oszlop_tipus(0).Description = m_ParentAddon.LocRM.GetString("ifsz-18237") '"A f�k�nyvi sz�m"
            p_oszlop_tipus(0).Visible = True

            p_oszlop_tipus(1).Title = m_ParentAddon.LocRM.GetString("ifsz-18238") '"Sz�mla neve"
            p_oszlop_tipus(1).DbNev = "AcctName"
            p_oszlop_tipus(1).Description = m_ParentAddon.LocRM.GetString("ifsz-18239") '"A sz�mla megnevez�s"
            p_oszlop_tipus(1).Visible = True

            p_oszlop_tipus(2).Title = m_ParentAddon.LocRM.GetString("ifsz-18240") '"P�nznem"
            p_oszlop_tipus(2).DbNev = "ActCurr"
            p_oszlop_tipus(2).Description = m_ParentAddon.LocRM.GetString("ifsz-18241") '"A p�nznem"
            p_oszlop_tipus(2).Visible = True
            p_oszlop_tipus(2).RightJustified = True

            oRecordSet = Me.SBO_Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

            l_where = "Select AcctCode, AcctName, ActCurr " _
                     & "  from [OACT] " _
                     & " where AcctCode like '" & l_ertek & "%'" _
                     & "   and U_IFSZCASH is null " _
                     & "   and Finanse = 'Y' " _
                     & "   and ActCurr <> '##'"

            If l_ertek <> "" Then
                l_where = "Select AcctCode, AcctName, ActCurr " _
                         & "  from [OACT] " _
                         & " where AcctCode like '" & l_ertek & "%'" _
                         & "   and U_IFSZCASH is null " _
                         & "   and Finanse = 'Y' " _
                         & "   and ActCurr <> '##'"
                erteklista(p_oszlop_tipus, "AcctCode", "AcctName", "OACT", l_where, _
                               "F�k�nyvi sz�ml�k", l_where, l_ertek)
            Else
                l_where = "Select AcctCode, AcctName, ActCurr " _
                         & "  from [OACT] " _
                         & " where U_IFSZCASH is null " _
                         & "   and Finanse = 'Y' " _
                         & "   and ActCurr <> '##'"
                erteklista(p_oszlop_tipus, "AcctCode", "AcctName", "OACT", l_where, "F�k�nyvi sz�ml�k", l_where)
            End If

        Catch ex As Exception

        Finally
            If (Not oRecordSet Is Nothing) Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oRecordSet)
                oRecordSet = Nothing
            End If
        End Try


    End Sub

    Private Function get_code_from_sequence() As String
        Dim l_seq As New IFSZ_Sequence(m_parentaddon)
        Return l_seq.get_next_seq("DEFAULT")
    End Function

    Private Function get_FormattedString(ByVal p_string As String) As String
        If p_string Is Nothing Or p_string = "" Then
            Return p_string
        End If
        Return Replace(p_string, Me.p_EzresEvt, "")
    End Function

End Class
