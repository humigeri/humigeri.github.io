Option Explicit On 

Imports System.IO
Imports SboAddOnBase
Imports System.Windows.Forms
Imports IFSZ_AddOnBase
Imports System.Threading

Public Class IFSZ_CashPointClose_Matrix
    Inherits IFSZ_AddOnBase.IFSZ_MatrixControl

#Region "Konstruktor"
    Public Sub New(ByVal ParentAddOn As SBOAddOn, ByVal FunctionCode As String)
        MyBase.New(ParentAddOn, enSboFormTypes.XmlFile, enSAPFormTypes.IFSZ_CashPointClose_Matrix, FunctionCode)
        Me.Riport_Nev_Penztar_Zaras = "IFSZ_Penztarzaras"
        Me.Riport_Nev_Cimlet = "IFSZ_ZARAS_CIMLET"
        Me.form_kod = FunctionCode
        initialize()
    End Sub
#End Region

#Region "Variables"
    Dim lRdoc As IFSZ_Rdoc 'BA
    Private pl_blnc_code As String
    Private pl_balance As Double
    Private pl_opening_balance As Double
    Private pl_sum_out As Double
    Private pl_sum_in As Double
    Private l_lastcls_old As String
    Private Riport_Nev As String
    Private Riport_Nev_Penztar_Zaras As String
    Private Riport_Nev_Cimlet As String
    Private form_kod As String
    Private l_nyomtat As Boolean = False
    Private l_combo_populalas As Boolean = False
    Private m_zarothread As Thread
    Private m_zaras_alatt As Boolean = False
    Private m_fut_cashcode As String = ""
    Private m_fut_stand As String = ""
    Private m_fut_comment As String = ""
    Private m_last_select As String = ""
#End Region

#Region "Form initialize"

    Private Sub initialize()
        '//*************************************************************
        '// set SBO_Application with an initialized application object
        '//*************************************************************
        m_sboForm.Freeze(True)
        SetApplication()

        If Me.m_ParentAddon.parameter_ertek("PZT_STND") <> "I" Then
            m_SboForm.Items.Item("pb_stand").Visible = False
        End If

        '// Add Data Sources to the Form
        AddDataSourceToForm()

        '// Bind the Form's items with the desired data source
        BindDataToForm()

        '// Fill the matrix with data
        GetDataFromDataSource()

        CashpointPopulate()

        '// Show my Simple Form
        m_SboForm.Visible = True

        '//*************************************************************
        '// Enable the desired tool bar items
        '//*************************************************************

        SetToolBarEnabled()
        m_sboForm.Freeze(False)

    End Sub

    Private Sub SetApplication()

        '*******************************************************************
        '// Use an SboGuiApi object to establish connection
        '// with the SAP Business One application and return an
        '// initialized appliction object
        '*******************************************************************
        'Dim SboGuiApi As SAPbouiCOM.SboGuiApi
        'Dim sConnectionString As String
        'SboGuiApi = New SAPbouiCOM.SboGuiApi
        '// by following the steps specified above, the following
        '// statment should be suficient for either development or run mode

        'most nem kell sConnectionString = Environment.GetCommandLineArgs.GetValue(1)
        '// connect to a running SBO Application

        'most nem kell SboGuiApi.Connect(sConnectionString)

    End Sub

    Public Sub AddDataSourceToForm()
        '//****************************************************************
        '// every item must be binded to a Data Source
        '// prior of binding the data we must add Data sources to the form
        '//****************************************************************

        '// Add a DBDataSource to Users table
        'Nincs DB datasource

        '// Add user data source
        'm_SboForm.DataSources.UserDataSources.Add("BlncCode", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 8)
        'm_SboForm.DataSources.UserDataSources.Add("c_penznem", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 3)
        'm_SboForm.DataSources.UserDataSources.Add("c_egy1", SAPbouiCOM.BoDataType.dt_PRICE, 30)
        'm_SboForm.DataSources.UserDataSources.Add("c_egy2", SAPbouiCOM.BoDataType.dt_PRICE, 30)
        m_SboForm.DataSources.UserDataSources.Add("Penztar", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 254)      'ICT_Penztarkod + ICT_Penztarnev
        m_SboForm.DataSources.UserDataSources.Add("Penznem", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 254)      'ICT_Penznem
        m_SboForm.DataSources.UserDataSources.Add("Fokszam", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 254)      'ICT_Fokonyviszamla
        m_SboForm.DataSources.UserDataSources.Add("Bizszam", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 254)      'ICT_Bizonylatszam
        m_SboForm.DataSources.UserDataSources.Add("Sorszam", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 254)      'ICTL_Sorszam
        m_SboForm.DataSources.UserDataSources.Add("Bizdatum", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 254)     'ICT_Mozgasdatum
        m_SboForm.DataSources.UserDataSources.Add("Zarasdatum", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 254)   'Zarasdatum
        m_SboForm.DataSources.UserDataSources.Add("Zarasszam", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 254)    'Zarassorszam
        m_SboForm.DataSources.UserDataSources.Add("Ellszamla", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 254)    'Ellenszamla_vagy_UPartner
        m_SboForm.DataSources.UserDataSources.Add("BevetelIP", SAPbouiCOM.BoDataType.dt_PRICE, 254)    'Idegenbevetel
        m_SboForm.DataSources.UserDataSources.Add("KiadasIP", SAPbouiCOM.BoDataType.dt_PRICE, 254)     'Idegenkiadas
        m_SboForm.DataSources.UserDataSources.Add("BevetelSP", SAPbouiCOM.BoDataType.dt_PRICE, 254)    'Sajatbevetel
        m_SboForm.DataSources.UserDataSources.Add("KiadasSP", SAPbouiCOM.BoDataType.dt_PRICE, 254)     'Sajatkiadas
        m_SboForm.DataSources.UserDataSources.Add("Penzmozgas", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 254)   'Mozgaskodnev
        m_SboForm.DataSources.UserDataSources.Add("Dolgozo", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 254)      'Dolgozo
        m_SboForm.DataSources.UserDataSources.Add("Hivszam", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 254)      'ICTL_Hivatkozasiszam
        m_SboForm.DataSources.UserDataSources.Add("Ktshely", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 254)      'Koltseghelykod
        m_SboForm.DataSources.UserDataSources.Add("Megjegyzes", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 254)   'ICT_Megjegyzes
        m_SboForm.DataSources.UserDataSources.Add("U_Direct", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 254)   'ICT_Direct
        m_SboForm.DataSources.UserDataSources.Add("U_EllenFok", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 254)   'ICT_Direct
        m_SboForm.DataSources.UserDataSources.Add("U_EllenPnr", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 254)   'ICT_Direct
        m_SboForm.DataSources.UserDataSources.Add("PrjCode", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 254)      'Projektk�d

        m_SboForm.DataSources.UserDataSources.Add("Ssz", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 30)

        m_SboForm.DataSources.UserDataSources.Add("SumOut", SAPbouiCOM.BoDataType.dt_SUM, 30)
        m_SboForm.DataSources.UserDataSources.Add("SumIn", SAPbouiCOM.BoDataType.dt_SUM, 30)
        m_SboForm.DataSources.UserDataSources.Add("OpenBlnc", SAPbouiCOM.BoDataType.dt_SUM, 30)
        m_SboForm.DataSources.UserDataSources.Add("CloseBlnc", SAPbouiCOM.BoDataType.dt_SUM, 30)
        m_SboForm.DataSources.UserDataSources.Add("Balance", SAPbouiCOM.BoDataType.dt_SUM, 30)

    End Sub

    Public Sub BindDataToForm()

        '//********************************************************
        '// binding data to the Form items will set the connection
        '// between the requested DB table field and the item
        '//********************************************************

        Dim oMatrix As SAPbouiCOM.Matrix
        Dim oColumns As SAPbouiCOM.Columns
        Dim oColumn As SAPbouiCOM.Column
        Dim oEditText As SAPbouiCOM.EditText

        '// getting the form's matrix object
        oMatrix = m_SboForm.Items.Item("Matrix1").Specific

        oColumns = oMatrix.Columns

        '// getting the matrix columns by the UID
        'oColumn = oColumns.Item("c_penznem")

        '// binding the data
        'oColumn.DataBind.SetBound(True, "", "c_penznem")

        'oColumn = oColumns.Item("Code")

        'oColumn.DataBind.SetBound(True, "", "BlncCode")

        'oColumn = oColumns.Item("c_egy1")

        'oColumn.DataBind.SetBound(True, "", "c_egy1")

        'oColumn = oColumns.Item("c_egy2")

        'oColumn.DataBind.SetBound(True, "", "c_egy2")

        oColumn = oColumns.Add("U_Direct", SAPbouiCOM.BoFormItemTypes.it_EDIT)
        oColumn.Editable = True
        oColumn.Visible = False
        oColumn.DataBind.SetBound(True, "", "U_Direct")

        oColumn = oColumns.Add("U_EllenFok", SAPbouiCOM.BoFormItemTypes.it_EDIT)
        oColumn.Editable = True
        oColumn.Visible = False
        oColumn.DataBind.SetBound(True, "", "U_EllenFok")

        oColumn = oColumns.Add("U_EllenPnr", SAPbouiCOM.BoFormItemTypes.it_EDIT)
        oColumn.Editable = True
        oColumn.Visible = False
        oColumn.DataBind.SetBound(True, "", "U_EllenPnr")

        oColumn = oColumns.Item("Penztar")
        oColumn.DataBind.SetBound(True, "", "Penztar")

        oColumn = oColumns.Item("Penznem")
        oColumn.DataBind.SetBound(True, "", "Penznem")

        oColumn = oColumns.Item("Fokszam")
        oColumn.DataBind.SetBound(True, "", "Fokszam")

        oColumn = oColumns.Item("Bizszam")
        oColumn.DataBind.SetBound(True, "", "Bizszam")

        oColumn = oColumns.Item("Sorszam")
        oColumn.DataBind.SetBound(True, "", "Sorszam")

        oColumn = oColumns.Item("Bizdatum")
        oColumn.DataBind.SetBound(True, "", "Bizdatum")

        oColumn = oColumns.Item("Zarasdatum")
        oColumn.DataBind.SetBound(True, "", "Zarasdatum")

        oColumn = oColumns.Item("Zarasszam")
        oColumn.DataBind.SetBound(True, "", "Zarasszam")

        oColumn = oColumns.Item("Ellszamla")
        oColumn.DataBind.SetBound(True, "", "Ellszamla")

        oColumn = oColumns.Item("BevetelIP")
        oColumn.DataBind.SetBound(True, "", "BevetelIP")

        oColumn = oColumns.Item("KiadasIP")
        oColumn.DataBind.SetBound(True, "", "KiadasIP")

        oColumn = oColumns.Item("BevetelSP")
        oColumn.DataBind.SetBound(True, "", "BevetelSP")

        oColumn = oColumns.Item("KiadasSP")
        oColumn.DataBind.SetBound(True, "", "KiadasSP")

        oColumn = oColumns.Item("Penzmozgas")
        oColumn.DataBind.SetBound(True, "", "Penzmozgas")

        oColumn = oColumns.Item("Dolgozo")
        oColumn.DataBind.SetBound(True, "", "Dolgozo")

        oColumn = oColumns.Item("Hivszam")
        oColumn.DataBind.SetBound(True, "", "Hivszam")

        oColumn = oColumns.Item("Ktshely")
        oColumn.DataBind.SetBound(True, "", "Ktshely")

        oColumn = oColumns.Item("PrjCode")
        oColumn.DataBind.SetBound(True, "", "PrjCode")

        oColumn = oColumns.Item("Megjegyzes")
        oColumn.DataBind.SetBound(True, "", "Megjegyzes")

        oColumn = oColumns.Item("Col0")
        oColumn.DataBind.SetBound(True, "", "Ssz")

        oEditText = m_SboForm.Items.Item("SumOut").Specific
        oEditText.DataBind.SetBound(True, "", "SumOut")

        oEditText = m_SboForm.Items.Item("SumIn").Specific
        oEditText.DataBind.SetBound(True, "", "SumIn")

        oEditText = m_SboForm.Items.Item("OpenBlnc").Specific
        oEditText.DataBind.SetBound(True, "", "OpenBlnc")

        oEditText = m_SboForm.Items.Item("CloseBlnc").Specific
        oEditText.DataBind.SetBound(True, "", "CloseBlnc")

        oEditText = m_SboForm.Items.Item("Balance").Specific
        oEditText.DataBind.SetBound(True, "", "Balance")

    End Sub

    Public Sub GetDataFromDataSource()

        'Dim oUserDataSource_penznem As SAPbouiCOM.UserDataSource
        'Dim oUserDataSource_egy1 As SAPbouiCOM.UserDataSource
        'Dim oUserDataSource_egy2 As SAPbouiCOM.UserDataSource
        'Dim oUserDataSource_BlncCode As SAPbouiCOM.UserDataSource
        'Dim oMatrix As SAPbouiCOM.Matrix
        'Dim RecSet As SAPbobsCOM.Recordset
        'Dim l_cashpoint As String
        'Dim l_chartofaccounts As SAPbobsCOM.ChartOfAccounts
        'Dim l_sbobob As SAPbobsCOM.SBObob
        'Dim l_local_curr As String

        'Dim i As Integer '// to be used as counter

        ''// getting the data sources from the form

        'oUserDataSource_penznem = m_SboForm.DataSources.UserDataSources.Item("c_penznem")
        'oUserDataSource_egy1 = m_SboForm.DataSources.UserDataSources.Item("c_egy1")
        'oUserDataSource_egy2 = m_SboForm.DataSources.UserDataSources.Item("c_egy2")
        'oUserDataSource_BlncCode = m_SboForm.DataSources.UserDataSources.Item("BlncCode")

        ''// getting the matrix from the form
        'oMatrix = m_SboForm.Items.Item("Matrix1").Specific

        ''Me.m_SboForm.Freeze(True)

        'oMatrix.Clear()

        'RecSet = m_ParentAddOn.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        'Try
        '    l_sbobob = m_parentaddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoBridge)
        '    RecSet = l_sbobob.GetLocalCurrency()
        '    l_local_curr = RecSet.Fields.Item(0).Value
        '    l_chartofaccounts = m_ParentAddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oChartOfAccounts)
        '    l_cashpoint = get_item_value("cashpoint", "", 0) 'm_SboForm.Items.Item("cashpoint").Specific.Selected.Value
        '    RecSet.DoQuery("select  cbl.u_currcode, cbl.u_balance, oact.acctcode, cbl.code " _
        '                 & "from    [@ifsz_cashpnt_blncs] cbl, oact " _
        '                 & "where   cbl.u_cashcode = '" & l_cashpoint & "' " _
        '                 & "and     cbl.u_cashcode = oact.u_ifszcash " _
        '                 & "and     cbl.u_currcode = oact.actcurr" _
        '    )
        '    RecSet.MoveFirst()
        '    For i = 1 To RecSet.RecordCount
        '        oUserDataSource_penznem.Value = RecSet.Fields.Item(0).Value
        '        oUserDataSource_egy1.Value = RecSet.Fields.Item(1).Value
        '        oUserDataSource_BlncCode.Value = RecSet.Fields.Item(3).Value
        '        l_chartofaccounts.GetByKey(RecSet.Fields.Item(2).Value)
        '        If l_local_curr = RecSet.Fields.Item(0).Value Then
        '            oUserDataSource_egy2.Value = l_chartofaccounts.Balance
        '        Else
        '            oUserDataSource_egy2.Value = l_chartofaccounts.Balance_FrgnCurr
        '        End If
        '        oMatrix.AddRow()
        '        RecSet.MoveNext()
        '    Next i
        'Catch ex As Exception
        '    'V�ratlan kiv�tel
        '    m_ParentAddon.SboApplication.MessageBox(Me.LocRM.GetString("ifsz-00002") & " (" & ex.ToString & ")")
        'Finally
        '    If (Not RecSet Is Nothing) Then
        '        System.Runtime.InteropServices.Marshal.ReleaseComObject(RecSet)
        '        RecSet = Nothing
        '    End If
        'End Try

        ''Me.m_SboForm.Freeze(False)
        'm_sboform.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE

        Dim RecSet As SAPbobsCOM.Recordset
        Dim oUserDataSource0 As SAPbouiCOM.UserDataSource
        Dim oUserDataSource1 As SAPbouiCOM.UserDataSource
        Dim oUserDataSource2 As SAPbouiCOM.UserDataSource
        Dim oUserDataSource3 As SAPbouiCOM.UserDataSource
        Dim oUserDataSource4 As SAPbouiCOM.UserDataSource
        Dim oUserDataSource5 As SAPbouiCOM.UserDataSource
        Dim oUserDataSource6 As SAPbouiCOM.UserDataSource
        Dim oUserDataSource7 As SAPbouiCOM.UserDataSource
        Dim oUserDataSource8 As SAPbouiCOM.UserDataSource
        Dim oUserDataSource9 As SAPbouiCOM.UserDataSource
        Dim oUserDataSource10 As SAPbouiCOM.UserDataSource
        Dim oUserDataSource11 As SAPbouiCOM.UserDataSource
        Dim oUserDataSource12 As SAPbouiCOM.UserDataSource
        Dim oUserDataSource13 As SAPbouiCOM.UserDataSource
        Dim oUserDataSource14 As SAPbouiCOM.UserDataSource
        Dim oUserDataSource15 As SAPbouiCOM.UserDataSource
        Dim oUserDataSource16 As SAPbouiCOM.UserDataSource
        Dim oUserDataSource17 As SAPbouiCOM.UserDataSource
        Dim oUserDataSource18 As SAPbouiCOM.UserDataSource
        Dim oUserDataSource19 As SAPbouiCOM.UserDataSource
        Dim oUserDataSource20 As SAPbouiCOM.UserDataSource
        Dim oUserDataSource21 As SAPbouiCOM.UserDataSource
        Dim oMatrix As SAPbouiCOM.Matrix
        Dim oCombo As SAPbouiCOM.ComboBox
        Dim l_select As String
        Dim l_cashpoint As String
        Dim l_penznem As String
        Dim l_cls_where As String
        Dim l_cls_seq As String

        Dim i As Integer '// to be used as counter

        '// getting the data sources from the form

        'm_SboForm.Freeze(True)

        oUserDataSource0 = m_SboForm.DataSources.UserDataSources.Item("Penztar")
        oUserDataSource1 = m_SboForm.DataSources.UserDataSources.Item("Penznem")
        oUserDataSource2 = m_SboForm.DataSources.UserDataSources.Item("Fokszam")
        oUserDataSource3 = m_SboForm.DataSources.UserDataSources.Item("Bizszam")
        oUserDataSource4 = m_SboForm.DataSources.UserDataSources.Item("Sorszam")
        oUserDataSource5 = m_SboForm.DataSources.UserDataSources.Item("Bizdatum")
        oUserDataSource6 = m_SboForm.DataSources.UserDataSources.Item("Zarasdatum")
        oUserDataSource7 = m_SboForm.DataSources.UserDataSources.Item("Zarasszam")
        oUserDataSource8 = m_SboForm.DataSources.UserDataSources.Item("Ellszamla")
        oUserDataSource9 = m_SboForm.DataSources.UserDataSources.Item("BevetelIP")
        oUserDataSource10 = m_SboForm.DataSources.UserDataSources.Item("KiadasIP")
        oUserDataSource11 = m_SboForm.DataSources.UserDataSources.Item("BevetelSP")
        oUserDataSource12 = m_SboForm.DataSources.UserDataSources.Item("KiadasSP")
        oUserDataSource13 = m_SboForm.DataSources.UserDataSources.Item("Penzmozgas")
        oUserDataSource14 = m_SboForm.DataSources.UserDataSources.Item("Dolgozo")
        oUserDataSource15 = m_SboForm.DataSources.UserDataSources.Item("Hivszam")
        oUserDataSource16 = m_SboForm.DataSources.UserDataSources.Item("Ktshely")
        oUserDataSource17 = m_SboForm.DataSources.UserDataSources.Item("Megjegyzes")
        oUserDataSource18 = m_SboForm.DataSources.UserDataSources.Item("U_Direct")
        oUserDataSource19 = m_SboForm.DataSources.UserDataSources.Item("U_EllenFok")
        oUserDataSource20 = m_SboForm.DataSources.UserDataSources.Item("U_EllenPnr")
        oUserDataSource21 = m_SboForm.DataSources.UserDataSources.Item("PrjCode")

        oCombo = m_SboForm.Items.Item("cashpoint").Specific
        If oCombo.ValidValues.Count > 0 Then
            l_cashpoint = oCombo.Selected.Value
            If l_cashpoint Is Nothing Then
                l_cashpoint = ""
            End If
        Else
            l_cashpoint = ""
        End If

        oCombo = m_SboForm.Items.Item("penznem").Specific
        If oCombo.ValidValues.Count > 0 Then
            l_penznem = oCombo.Selected.Value
            If l_penznem Is Nothing Then
                l_penznem = ""
            End If
        Else
            l_penznem = ""
        End If

        l_cls_seq = get_item_value("clsseq", "", 0)
        If l_cls_seq Is Nothing Or l_cls_seq = "" Then
            l_cls_where = "and     Zarassorszam is null "
        Else
            l_cls_where = "and     Zarassorszam = " & l_cls_seq
        End If
        l_select = "select  ICT_Penztarkod + Penztarnev " & _
                                   "      , ICT_Penznem " & _
                                   "      , ICT_Fokonyviszamla " & _
                                   "      , ICT_Bizonylatszam " & _
                                   "      , ICTL_Sorszam " & _
                                   "      , convert(varchar, ICT_Mozgasdatum, 102) " & _
                                   "      , convert(varchar, Zarasdatum, 120) " & _
                                   "      , Zarassorszam " & _
                                   "      , Ellenszamla_vagy_UPartner " & _
                                   "      , Idegenbevetel " & _
                                   "      , Idegenkiadas " & _
                                   "      , Sajatbevetel " & _
                                   "      , Sajatkiadas " & _
                                   "      , Mozgaskodesnev " & _
                                   "      , Dolgozo " & _
                                   "      , ICTL_Hivatkozasiszam " & _
                                   "      , ICTL_Koltseghelykod " & _
                                   "      , ICT_Megjegyzes " & _
                                   "      , ICT_Irany " & _
                                   "      , ICTL_Fokonyviszamla " & _
                                   "      , ICTL_UPartner " & _
                                   "      , ICTL_PrjCode " & _
                                   "      , nyito_egyenleg " & _
                                   "from    ifsz_penztarforgalom_v " & _
                                   "where   Upper(ICT_Penztarkod) = '" & l_cashpoint.ToUpper & "' " & _
                                   "and     Upper(ICT_Penznem) = '" & l_penznem.ToUpper & "' " & _
                                   l_cls_where

        If l_select <> Me.m_last_select Then
            Me.m_last_select = l_select
            '// getting the matrix from the form
            oMatrix = m_SboForm.Items.Item("Matrix1").Specific

            oMatrix.Clear()

            Try
                RecSet = m_ParentAddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                RecSet.DoQuery(l_select)
                RecSet.MoveFirst()
                pl_sum_out = 0
                pl_sum_in = 0
                Me.p_validal_e = False
                For i = 1 To RecSet.RecordCount
                    oUserDataSource0.Value = RecSet.Fields.Item(0).Value
                    oUserDataSource1.Value = RecSet.Fields.Item(1).Value
                    oUserDataSource2.Value = RecSet.Fields.Item(2).Value
                    oUserDataSource3.Value = RecSet.Fields.Item(3).Value
                    oUserDataSource4.Value = RecSet.Fields.Item(4).Value
                    oUserDataSource5.Value = RecSet.Fields.Item(5).Value
                    oUserDataSource6.Value = RecSet.Fields.Item(6).Value
                    oUserDataSource7.Value = RecSet.Fields.Item(7).Value
                    oUserDataSource8.Value = RecSet.Fields.Item(8).Value
                    oUserDataSource9.Value = RecSet.Fields.Item(9).Value
                    oUserDataSource10.Value = RecSet.Fields.Item(10).Value
                    oUserDataSource11.Value = RecSet.Fields.Item(11).Value
                    oUserDataSource12.Value = RecSet.Fields.Item(12).Value
                    oUserDataSource13.Value = RecSet.Fields.Item(13).Value
                    oUserDataSource14.Value = RecSet.Fields.Item(14).Value
                    oUserDataSource15.Value = RecSet.Fields.Item(15).Value
                    oUserDataSource16.Value = RecSet.Fields.Item(16).Value
                    oUserDataSource17.Value = RecSet.Fields.Item(17).Value
                    oUserDataSource18.Value = RecSet.Fields.Item(18).Value
                    oUserDataSource19.Value = RecSet.Fields.Item(19).Value
                    oUserDataSource20.Value = RecSet.Fields.Item(20).Value
                    oUserDataSource21.Value = RecSet.Fields.Item(21).Value
                    pl_opening_balance = RecSet.Fields.Item(22).Value
                    pl_sum_out = pl_sum_out + RecSet.Fields.Item(10).Value
                    pl_sum_in = pl_sum_in + RecSet.Fields.Item(9).Value
                    oMatrix.AddRow()
                    Me.p_validal_e = False
                    Me.set_item_value("Matrix1", "Col0", i, i)
                    Me.p_validal_e = True
                    'post_query(i)
                    RecSet.MoveNext()
                Next i
                'A pl_opening_balance t�rolja a nyit� egyenleget, ami egy esetben nem j�
                'Ha a legels� z�r�sr�l van sz�. Ebben az esetben fel�l�rjuk a visszafel� sz�molt �rt�kkel
                If l_cls_seq = "1" Then
                    'Fel�l�rjuk, mert m�r t�rt�nt z�r�s, de mi pont a legels� z�r�st k�rdezz�k le
                    pl_opening_balance = pl_balance - pl_sum_in + pl_sum_out
                ElseIf l_cls_seq Is Nothing Or l_cls_seq = "" Then
                    RecSet.DoQuery("select [@ifsz_cash_cls].code from [@ifsz_cash_cls] where [@ifsz_cash_cls].u_cashcode = '" & l_cashpoint & "'")
                    If RecSet.RecordCount = 0 Then
                        'Fel�l�rjuk, mert m�g egy�ltal�n nem z�rtak erre a p�nzt�rra
                        pl_opening_balance = pl_balance - pl_sum_in + pl_sum_out
                    Else
                        RecSet.MoveLast()
                    End If
                End If
                set_item_value("SumOut", "", 0, pl_sum_out)
                set_item_value("SumIn", "", 0, pl_sum_in)
                If pl_opening_balance < 0.0001 And pl_opening_balance > -1 * 0.0001 Then
                    pl_opening_balance = 0
                End If
                set_item_value("OpenBlnc", "", 0, pl_opening_balance)
                set_item_value("CloseBlnc", "", 0, pl_balance)
                set_item_value("Balance", "", 0, pl_opening_balance - pl_sum_out + pl_sum_in)

                Me.p_validal_e = True
            Catch ex As Exception
                'V�ratlan kiv�tel
                m_ParentAddon.SboApplication.MessageBox(Me.LocRM.GetString("ifsz-00002") & " (" & ex.ToString & ")")
            Finally
                If (Not RecSet Is Nothing) Then
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(RecSet)
                    RecSet = Nothing
                End If
            End Try

        End If

        m_SboForm.Freeze(False)
        set_item_value("Balance", "", 0, pl_opening_balance - pl_sum_out + pl_sum_in)
        m_SboForm.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE


    End Sub

    Private Sub SetToolBarEnabled()
        '// the form controlls the Menu Items
        '// the list of MenuUIDs should apear in the SDK help file
        '// otherwise look at the SBO_Aplication_MenuEvent method

        '// enable 'Next Record', 'Previous Record', 'First Data Record'
        '// and 'Last Data Record' Menu Items

        m_SboForm.EnableMenu("1292", False) 'Add Matrix row ; sor l�trehoz�s
        m_SboForm.EnableMenu("1293", False) 'Delete Matrix row ; sor t�rl�se
    End Sub

#End Region

#Region "Variables"
    Private l_link_kimeno As Boolean = False
    Private l_link_bejovo As Boolean = False
    Private l_link_penztar_forgalom As Boolean = False
    Private l_link_szamlakeret As Boolean = False
    Private l_link_fokszam As String = ""
    Private l_link_partner As Boolean = False
    Private l_link_pnr_kod As String = ""
    Private l_link_kod As Integer = -1
#End Region

#Region "Overrides"

    Protected Overrides Sub Finalize()
        'clean up class
        ' m_ParentAddon = Nothing
        'oForms = Nothing
        'GC.WaitForPendingFinalizers()
        'GC.Collect()
        MyBase.Finalize()
    End Sub

    Public Overrides Sub pre_event(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Dim oForm As SboForm

        If Me.m_zaras_alatt Then
            BubbleEvent = False
            'Me.m_ParentAddon.SboApplication.SetStatusBarMessage("M�g tart a z�r�s, k�rem, v�rjon!")
            Exit Sub
        End If

        'If pVal.Before_Action = False _
        '  And pVal.EventType = SAPbouiCOM.BoEventTypes.et_VALIDATE _
        '  And Me.p_validal_e = True _
        'Then
        '    Me.p_validal_e = False
        '    LOVValidate(pVal.ItemUID)
        '    Me.p_validal_e = True
        'End If

        'Dim l_ertek As String
        'l_ertek = Me.get_item_value("Balance", "", 1)
        'l_ertek = m_SboForm.DataSources.UserDataSources.Item("Balance").Value

        If pVal.Before_Action = False Then

            Select Case pVal.EventType

                Case SAPbouiCOM.BoEventTypes.et_COMBO_SELECT
                    If Me.l_combo_populalas = False Then
                        Select Case pVal.ItemUID
                            Case "cashpoint"
                                'cashpoint_change()
                                cashpoint_change(True)
                            Case "penznem"
                                penznem_change(True)
                            Case "lastcls"
                                cls_change()
                        End Select
                    End If

            End Select
        End If

        If pVal.Before_Action = False Then
            If pVal.EventType = SAPbouiCOM.BoEventTypes.et_FORM_LOAD And pVal.FormType = "426" And Me.l_link_kimeno = True Then
                oForm = New IFSZ_Fizetes(Me.m_ParentAddon, Me, "F_KFS", FormUID, Me.l_link_kod)
                Me.m_ParentAddon.SBOForms.Add(oForm, oForm.UniqueID)
                Me.ModalFormUID = oForm.UniqueID
                Me.l_link_kimeno = False
                Me.l_link_bejovo = False
                Exit Sub
            ElseIf pVal.EventType = SAPbouiCOM.BoEventTypes.et_FORM_LOAD And pVal.FormType = "170" And Me.l_link_bejovo = True Then
                oForm = New IFSZ_Fizetes(Me.m_ParentAddon, Me, "F_KFS", FormUID, Me.l_link_kod)
                Me.m_ParentAddon.SBOForms.Add(oForm, oForm.UniqueID)
                Me.ModalFormUID = oForm.UniqueID
                Me.l_link_kimeno = False
                Me.l_link_bejovo = False
                Exit Sub
            ElseIf pVal.EventType = SAPbouiCOM.BoEventTypes.et_FORM_LOAD And pVal.FormType = "804" And Me.l_link_szamlakeret = True Then
                oForm = New IFSZ_AddOnBase.IFSZ_Szamlakeret(Me.m_ParentAddon, Me, "F_SZK", FormUID, Me.l_link_fokszam)
                Me.m_ParentAddon.SBOForms.Add(oForm, oForm.UniqueID)
                Me.ModalFormUID = oForm.UniqueID
                Me.l_link_szamlakeret = False
                Exit Sub
            ElseIf pVal.EventType = SAPbouiCOM.BoEventTypes.et_FORM_LOAD And pVal.FormType = "134" And Me.l_link_partner = True Then
                oForm = New IFSZ_Partner(Me.m_ParentAddon, Me, "F_PNR", FormUID, Me.l_link_pnr_kod)
                Me.m_ParentAddon.SBOForms.Add(oForm, oForm.UniqueID)
                Me.ModalFormUID = oForm.UniqueID
                Me.l_link_partner = False
                Exit Sub
            End If
        End If

    End Sub

    Public Overrides Sub post_event(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)

        If pVal.Before_Action = True Then

            Select Case pVal.EventType

                Case SAPbouiCOM.BoEventTypes.et_CLICK
                    Select Case pVal.ItemUID
                        Case "pb_friss"
                            'cashpoint_change() 'A r�gi cashpoint change �jrapopul�lta a deviz�t �s a cls list�t is, �gy mindig a lista els? elem�re ugrott
                            cashpoint_change(False)
                            penznem_change(False)
                            cls_change()
                        Case "pb_zaras"
                            CashPointClose()
                        Case "pb_stand"
                            Cimletezes(FormUID)
                        Case "pb_megsem"
                            m_sboform.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE
                            m_sboform.Close()
                            Exit Sub
                    End Select

            End Select
        End If


        Dim l_ertek As String
        'l_ertek = Me.get_item_value("Balance", "", 1)
        'l_ertek = m_SboForm.DataSources.UserDataSources.Item("Balance").Value

        If pVal.Before_Action = False Then

            'If (IFSZ_RunReportControl.RiportIndit And pVal.FormType = enSAPFormTypes.sapUserReports And pVal.EventType = SAPbouiCOM.BoEventTypes.et_FORM_LOAD And ((Me.l_nyomtat = True And Me.form_kod = "F_R_TXN") Or (Me.form_kod <> "F_R_TXN"))) Then
            If (IFSZ_RunReportControl.RiportIndit And IFSZ_RunReportControl.RiportInditoForm = Me.UniqueID And pVal.FormType = enSAPFormTypes.sapUserReports And pVal.EventType = SAPbouiCOM.BoEventTypes.et_FORM_LOAD And ((Me.l_nyomtat = True And Me.form_kod <> "F_R_TXN") Or (Me.form_kod = "F_R_TXN"))) Then
                Dim oForm1 As SboForm
                oForm1 = New IFSZ_RunRep_Logical(m_ParentAddon, Me.Riport_Nev, pVal.FormUID)
                Me.m_ParentAddon.SBOForms.Add(oForm1, oForm1.UniqueID)
                Me.l_nyomtat = False

            End If
        End If

        If pVal.Before_Action = False _
           And pVal.EventType = SAPbouiCOM.BoEventTypes.et_CLICK _
           And pVal.ItemUID = "pb_runform" _
           And Me.p_validal_e = True _
        Then
            pb_runform_pressed()
        End If

        If pVal.Before_Action = False And pVal.ItemUID = "pb_runrep" And pVal.EventType = SAPbouiCOM.BoEventTypes.et_CLICK Then
            If (Not IFSZ_RunReportControl.RiportIndit) Then
                If Set_Report_Where(Me.Riport_Nev_Penztar_Zaras) Then
                    IFSZ_RunReportControl.RiportIndit = True
                    IFSZ_RunReportControl.RiportInditoForm = Me.UniqueID
                    Me.Riport_Nev = Me.Riport_Nev_Penztar_Zaras
                    Me.l_nyomtat = True
                    m_ParentAddon.SboApplication.ActivateMenuItem(enSAPMenuUIDs.UserReports)
                End If
            End If
        End If

        If pVal.Before_Action = False And pVal.ItemUID = "pb_standpr" And pVal.EventType = SAPbouiCOM.BoEventTypes.et_CLICK Then
            If (Not IFSZ_RunReportControl.RiportIndit) Then
                If Set_Report_Where(Me.Riport_Nev_Cimlet) Then
                    IFSZ_RunReportControl.RiportIndit = True
                    IFSZ_RunReportControl.RiportInditoForm = Me.UniqueID
                    Me.Riport_Nev = Me.Riport_Nev_Cimlet
                    Me.l_nyomtat = True
                    m_ParentAddon.SboApplication.ActivateMenuItem(enSAPMenuUIDs.UserReports)
                End If
            End If
        End If

        'l_ertek = Me.get_item_value("Balance", "", 1)
        'l_ertek = m_SboForm.DataSources.UserDataSources.Item("Balance").Value

    End Sub

    Public Overrides Sub item_validate(ByVal p_ItemChanged As Boolean, ByVal p_matrix As String, ByVal p_oszlop As String, ByVal p_sor As Integer, ByVal p_ertek As String, ByVal p_lookup_ertek As String, ByRef BubbleEvent As Boolean)

    End Sub

    Public Overrides Sub link_pressed(ByVal l_ItemUID As String, ByVal l_ColUID As String, ByVal l_Row As Integer)
        Dim l_U_CashTxn As String
        Dim l_code As String
        Dim l_docnum As String
        Dim l_irany As String
        Dim l_biz_kod As String
        Dim p_select As String
        Dim l_fok, l_pnr As String
        Dim oForm As SboForm
        Dim oRecordSet As SAPbobsCOM.Recordset

        Try
            oRecordSet = Me.SBO_Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

            If l_ColUID = "Sorszam" Then
                p_select = "select [@IFSZ_CASH_TXN_LINES].U_DocNum, [@IFSZ_CASH_TXNS].U_Direct from [@IFSZ_CASH_TXN_LINES], [@IFSZ_CASH_TXNS] where [@IFSZ_CASH_TXN_LINES].U_CshTxn = [@IFSZ_CASH_TXNS].Code and [@IFSZ_CASH_TXNS].U_DocNum = '" & Me.get_item_value("Matrix1", "Bizszam", l_Row) & "' and [@IFSZ_CASH_TXNS].U_Direct = '" & Me.get_item_value("Matrix1", "U_Direct", l_Row) & "' and [@IFSZ_CASH_TXN_LINES].U_Seq = '" & Me.get_item_value("Matrix1", "Sorszam", l_Row) & "'"
                oRecordSet.DoQuery(p_select)

                If oRecordSet.RecordCount = 1 Then
                    oRecordSet.MoveFirst()
                    Me.l_link_kod = oRecordSet.Fields.Item(0).Value
                    l_irany = oRecordSet.Fields.Item(1).Value
                Else
                    Exit Sub
                End If

                System.Runtime.InteropServices.Marshal.ReleaseComObject(oRecordSet)
                oRecordSet = Nothing

                If l_irany = "I" Then
                    'Bejovo
                    Me.l_link_bejovo = True
                    Me.m_ParentAddon.SboApplication.ActivateMenuItem(enSAPMenuUIDs.Receipts)
                Else
                    'Kimeno
                    Me.l_link_kimeno = True
                    Me.m_ParentAddon.SboApplication.ActivateMenuItem(enSAPMenuUIDs.VendorPayment)
                End If
            ElseIf l_ColUID = "Bizszam" Then
                p_select = "select [@IFSZ_CASH_TXNS].Code from [@IFSZ_CASH_TXNS] where [@IFSZ_CASH_TXNS].U_DocNum = '" & Me.get_item_value("Matrix1", "Bizszam", l_Row) & "' and [@IFSZ_CASH_TXNS].U_Direct = '" & Me.get_item_value("Matrix1", "U_Direct", l_Row) & "'"
                oRecordSet.DoQuery(p_select)

                If oRecordSet.RecordCount = 1 Then
                    oRecordSet.MoveFirst()
                    l_biz_kod = oRecordSet.Fields.Item(0).Value

                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRecordSet)
                    oRecordSet = Nothing

                    IFSZ_CashTxn_Matrix.KeresIndit = l_biz_kod
                    oForm = New IFSZ_CashTxn_Matrix(Me.m_ParentAddon, "F_KFS")
                    Me.m_ParentAddon.SBOForms.Add(oForm, oForm.UniqueID)
                    Me.ModalFormUID = oForm.UniqueID
                    Exit Sub
                Else
                    Exit Sub
                End If

            ElseIf l_ColUID = "Fokszam" Then
                l_biz_kod = Me.get_item_value("Matrix1", "Fokszam", l_Row)
                If l_biz_kod <> "" Then
                    Me.l_link_fokszam = l_biz_kod
                    Me.l_link_szamlakeret = True
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRecordSet)
                    oRecordSet = Nothing

                    Me.m_ParentAddon.SboApplication.ActivateMenuItem(1537)
                Else
                    Exit Sub
                End If

            ElseIf l_ColUID = "Ellszamla" Then
                l_fok = Me.get_item_value("Matrix1", "U_EllenFok", l_Row)
                l_pnr = Me.get_item_value("Matrix1", "U_EllenPnr", l_Row)
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oRecordSet)
                oRecordSet = Nothing

                If l_fok = "" Then
                    Me.l_link_pnr_kod = l_pnr
                    Me.l_link_partner = True
                    Me.m_ParentAddon.SboApplication.ActivateMenuItem(2561)
                Else
                    Me.l_link_fokszam = l_fok
                    Me.l_link_szamlakeret = True
                    Me.m_ParentAddon.SboApplication.ActivateMenuItem(1537)
                End If

            End If
        Finally
            If (Not oRecordSet Is Nothing) Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oRecordSet)
                oRecordSet = Nothing
            End If

        End Try

    End Sub

#End Region

#Region "Private"

    Private Sub CashPointClose()
        Dim l_cashpointclose = New IFSZ_CashPointClose(m_ParentAddOn)
        'Dim oCombo As SAPbouiCOM.ComboBox

        If (get_item_value("cashpoint", "", 0) = "") Then
            'A "p�nzt�r" �rt�k�t k�telez� megadni
            m_ParentAddOn.SboApplication.MessageBox(m_ParentAddOn.LocRM.GetString("ifsz-10009"))
            Exit Sub
        End If
        'cashpoint_change() 'A r�gi cashpoint_change �jrapopul�lt mindent, mint a friss�t�sn�l
        cashpoint_change(False) 'Param�ter = false: Nem user v�ltoztatta, teh�t nem fogja a t�bbit �jrapopul�lni
        penznem_change(False)   'Param�ter = false: Nem kell a m�trix tartalm�t �jrak�rdezni (mert a k�vetkez? sor meg fogja tenni)
        m_SboForm.Items.Item("lastcls").Specific.Select("", SAPbouiCOM.BoSearchKey.psk_ByValue)
        cls_change()
        'oCombo = m_SboForm.Items.Item("cashpoint").Specific


        Me.m_fut_cashcode = get_item_value("cashpoint", "", 0)
        Me.m_fut_stand = Me.m_ParentAddon.parameter_ertek("PZT_STND")
        Me.m_fut_comment = get_item_value("comment", "", 0)

        Me.m_zarothread = New Thread(AddressOf CashPointCloseThread)
        Me.m_zarothread.IsBackground = True
        Me.m_zarothread.Start()

        '�jrafriss�tj�k az adatokat
        'cashpoint_change(False)
        'penznem_change(False)
        'cls_change()
    End Sub

    Public Sub CashPointCloseThread()
        Try
            Me.m_zaras_alatt = True
            Dim l_cashpointclose = New IFSZ_CashPointClose(m_ParentAddon)
            l_cashpointclose.CashPointClose(Me.m_fut_cashcode, Me.m_fut_stand, Me.m_fut_comment)

            Me.m_last_select = ""

            Me.m_zaras_alatt = False

            '�jrafriss�tj�k az adatokat
            cashpoint_change(False)
            penznem_change(False)
            cls_change()

        Catch ex As ThreadAbortException

        Catch ex As Exception
            Me.m_ParentAddon.SboApplication.MessageBox("V�ratlan hiba:" + ex.ToString)
        Finally
            Me.m_zaras_alatt = False
        End Try
    End Sub

    Private Sub CashpointPopulate()
        Dim oCombo As SAPbouiCOM.ComboBox
        Dim RecSet As SAPbobsCOM.Recordset
        Dim l_cashpointclose As IFSZ_CashPointClose = New IFSZ_CashPointClose(m_ParentAddon)
        Dim l_code As String

        Try
            RecSet = m_ParentAddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            oCombo = m_SboForm.Items.Item("cashpoint").Specific

            l_combo_populalas = True
            RecSet.DoQuery("select code, name from [@ifsz_cashpoints]")
            RecSet.MoveFirst()
            While (Not RecSet.EoF)
                l_code = RecSet.Fields.Item(0).Value
                If (l_cashpointclose.HasRole(l_code)) Then
                    oCombo.ValidValues.Add(l_code, RecSet.Fields.Item(1).Value)
                End If
                RecSet.MoveNext()
            End While
        Catch ex As Exception
            'V�ratlan kiv�tel
            m_ParentAddon.SboApplication.MessageBox(Me.LocRM.GetString("ifsz-00002") & " (" & ex.ToString & ")")
        Finally
            If (Not RecSet Is Nothing) Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(RecSet)
                RecSet = Nothing
            End If
            l_combo_populalas = False
        End Try

    End Sub

    Private Sub PenznemPopulate(Optional ByVal p_getdata As Boolean = True)
        Dim oCombo As SAPbouiCOM.ComboBox
        Dim RecSet As SAPbobsCOM.Recordset
        Dim RecSet2 As SAPbobsCOM.Recordset
        Dim l_code As String
        Dim i As Integer
        Dim l_selected As Boolean = False

        Try
            RecSet = m_ParentAddOn.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            RecSet2 = m_ParentAddOn.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

            l_combo_populalas = True
            oCombo = m_SboForm.Items.Item("penznem").Specific
            Try
                oCombo.ValidValues.Add("", "")
            Catch ex As Exception

            End Try
            oCombo.Select("", SAPbouiCOM.BoSearchKey.psk_ByValue)
            If oCombo.ValidValues.Count > 1 Then
                For i = 0 To oCombo.ValidValues.Count - 2
                    oCombo.ValidValues.Remove(0, SAPbouiCOM.BoSearchKey.psk_Index)
                Next
            End If

            RecSet.DoQuery("select u_currcode from [@ifsz_cashpnt_blncs] where u_cashcode = '" & get_item_value("cashpoint", "", 0) & "'")
            RecSet.MoveFirst()
            While (Not RecSet.EoF)
                l_code = RecSet.Fields.Item(0).Value
                RecSet2.DoQuery("select currcode, currname from ocrn where currcode = '" & l_code & "'")
                If RecSet2.RecordCount > 0 Then
                    RecSet2.MoveFirst()
                    oCombo.ValidValues.Add(l_code, RecSet2.Fields.Item(1).Value)
                    If Not l_selected Then
                        oCombo.Select(l_code, SAPbouiCOM.BoSearchKey.psk_ByValue)
                        oCombo.ValidValues.Remove("", SAPbouiCOM.BoSearchKey.psk_ByValue)
                        l_selected = True
                    End If
                End If
                RecSet.MoveNext()
            End While
            penznem_change(p_getdata)
        Catch ex As Exception
            'V�ratlan kiv�tel
            m_ParentAddon.SboApplication.MessageBox(Me.LocRM.GetString("ifsz-00002") & " (" & ex.ToString & ")")
        Finally
            If (Not RecSet Is Nothing) Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(RecSet)
                RecSet = Nothing
            End If
            If (Not RecSet2 Is Nothing) Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(RecSet2)
                RecSet2 = Nothing
            End If
            l_combo_populalas = False
        End Try

    End Sub

    Private Sub ClsPopulate()
        Dim oCombo As SAPbouiCOM.ComboBox
        Dim RecSet As SAPbobsCOM.Recordset
        Dim l_code As String
        Dim i As Integer
        Dim l_selected As Boolean = False

        Try
            RecSet = m_ParentAddOn.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

            l_combo_populalas = True
            oCombo = m_SboForm.Items.Item("lastcls").Specific

            If oCombo.ValidValues.Count = 0 Then
                oCombo.ValidValues.Add("", "-")
            End If
            oCombo.Select("", SAPbouiCOM.BoSearchKey.psk_ByValue)

            Dim a As String
            'Elvileg ez kit�rli az �sszest kiv�ve a ""-t
            If oCombo.ValidValues.Count > 1 Then
                For i = 1 To oCombo.ValidValues.Count - 1
                    'a = Me.get_item_value("lastcls", "", "")
                    'If oCombo.ValidValues.Item(i).Value <> "" Then
                    '    oCombo.ValidValues.Remove(i, SAPbouiCOM.BoSearchKey.psk_Index)
                    'End If
                    oCombo.ValidValues.Remove(1, SAPbouiCOM.BoSearchKey.psk_Index)
                Next
            End If

            RecSet.DoQuery("select u_seq, convert(varchar, u_timestmp, 120) from [@ifsz_cash_cls] where u_cashcode = '" & get_item_value("cashpoint", "", 0) & "' order by u_seq desc")
            RecSet.MoveFirst()
            While (Not RecSet.EoF)
                oCombo.ValidValues.Add(RecSet.Fields.Item(0).Value, RecSet.Fields.Item(1).Value)
                'If Not l_selected Then
                '    oCombo.Select(RecSet.Fields.Item(0).Value, SAPbouiCOM.BoSearchKey.psk_ByValue)
                '    oCombo.ValidValues.Remove("", SAPbouiCOM.BoSearchKey.psk_ByValue)
                '    l_selected = True
                'End If
                RecSet.MoveNext()
            End While
            cls_change()
        Catch ex As Exception
            'V�ratlan kiv�tel
            m_ParentAddon.SboApplication.MessageBox(Me.LocRM.GetString("ifsz-00002") & " (" & ex.ToString & ")")
        Finally
            If (Not RecSet Is Nothing) Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(RecSet)
                RecSet = Nothing
            End If
            l_combo_populalas = False
        End Try

    End Sub

    Private Sub cashpoint_change(Optional ByVal p_user_changed As Boolean = True)
        Dim l_cashpointclose As IFSZ_CashPointClose = New IFSZ_CashPointClose(m_ParentAddon)
        Dim l_cashpoint As String = get_item_value("cashpoint", "", 0) 'm_SboForm.Items.Item("cashpoint").Specific.Selected.Value
        Dim l_lastclose As DateTime
        Dim l_no_lastclose As Boolean
        Dim l_lastclose_string As String
        Dim l_inDN As String
        Dim l_outDN As String
        Dim vObj As SAPbobsCOM.SBObob
        Dim rs As SAPbobsCOM.Recordset
        Dim oCol As SAPbouiCOM.Item
        Dim l_raise_failure As Boolean

        If (l_cashpoint Is Nothing Or l_cashpoint = "") Then
            Exit Sub
        End If

        If p_user_changed Then
            l_raise_failure = True
        Else
            l_raise_failure = False
        End If
        l_cashpointclose.LastDNs(l_cashpoint, l_lastclose, l_no_lastclose, l_inDN, l_outDN, Nothing, l_raise_failure)

        Me.p_validal_e = False
        'oCol = m_SBOform.Items.Item("lastcls")
        'oCol.Enabled = True
        'If l_no_lastclose Then
        '    set_item_value("lastcls", "", 0, Nothing)
        'Else
        '    l_lastclose_string = l_lastclose.ToString("G")
        '    set_item_value("lastcls", "", 0, l_lastclose_string)
        'End If
        'oCol.Enabled = False

        set_item_value("inDN", "", 0, l_inDN)
        set_item_value("outDN", "", 0, l_outDN)
        Me.p_validal_e = True

        If p_user_changed Then
            PenznemPopulate(False)

            'Z�r�si d�tum, combo-s megold�s
            ClsPopulate()

            'GetDataFromDataSource()
        End If
    End Sub

    Private Sub penznem_change(Optional ByVal p_getdata As Boolean = True)
        Dim RecSet As SAPbobsCOM.Recordset
        Dim oCombo As SAPbouiCOM.ComboBox

        Try
            RecSet = m_ParentAddOn.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

            oCombo = m_SboForm.Items.Item("penznem").Specific

            If oCombo.ValidValues.Count > 0 Then
                RefreshBalance()
            End If

            If p_getdata = True Then
                GetDataFromDataSource()
            End If

        Catch ex As Exception
            'V�ratlan kiv�tel
            m_ParentAddon.SboApplication.MessageBox(Me.LocRM.GetString("ifsz-00002") & " (" & ex.ToString & ")")
        Finally
            If (Not RecSet Is Nothing) Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(RecSet)
                RecSet = Nothing
            End If
        End Try


    End Sub

    Private Sub cls_change()
        Dim RecSet As SAPbobsCOM.Recordset
        Dim oCombo As SAPbouiCOM.ComboBox

        Try
            RecSet = m_ParentAddOn.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

            oCombo = m_SboForm.Items.Item("lastcls").Specific

            If oCombo.ValidValues.Count > 0 Then
                'Igaz�b�l nem kellene, de a lov-os megold�sban a clsseq t�roln� a z�r�s sorsz�m�t, ez�rt odam�soljuk
                set_item_value("clsseq", "", 0, oCombo.Selected.Value)

                RefreshBalance()

            End If

            GetDataFromDataSource()

        Catch ex As Exception
            'V�ratlan kiv�tel
            m_ParentAddon.SboApplication.MessageBox(Me.LocRM.GetString("ifsz-00002") & " (" & ex.ToString & ")")
        Finally
            If (Not RecSet Is Nothing) Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(RecSet)
                RecSet = Nothing
            End If
        End Try

    End Sub

    Private Sub RefreshBalance()
        Dim RecSet As SAPbobsCOM.Recordset
        Dim oCombo As SAPbouiCOM.ComboBox
        Dim lCashCls As String

        Try
            RecSet = m_ParentAddOn.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

            oCombo = m_SboForm.Items.Item("lastcls").Specific

            If oCombo.ValidValues.Count > 0 Then

                lCashCls = get_item_value("clsseq", "", 0)
                If lCashCls Is Nothing Or lCashCls = "" Then
                    RecSet.DoQuery("select code, u_balance from [@ifsz_cashpnt_blncs] where u_cashcode = '" & get_item_value("cashpoint", "", 0) & "' and u_currcode = '" & get_item_value("penznem", "", 0) & "'")
                    If RecSet.RecordCount > 0 Then
                        RecSet.MoveFirst()
                        pl_blnc_code = RecSet.Fields.Item(0).Value
                        pl_balance = RecSet.Fields.Item(1).Value
                    End If
                Else
                    RecSet.DoQuery("select [@ifsz_cash_cls_lines].u_balance " & _
                                   "from [@ifsz_cash_cls] join [@ifsz_cash_cls_lines] on [@ifsz_cash_cls].code = [@ifsz_cash_cls_lines].u_cashcls " & _
                                   "where [@ifsz_cash_cls].u_cashcode = '" & get_item_value("cashpoint", "", 0) & "' " & _
                                   "and   [@ifsz_cash_cls].u_seq = " & lCashCls & _
                                   "and   [@ifsz_cash_cls_lines].u_currcode = '" & get_item_value("penznem", "", 0) & "'" _
                    )
                    If RecSet.RecordCount > 0 Then
                        RecSet.MoveFirst()
                        pl_blnc_code = Nothing
                        pl_balance = RecSet.Fields.Item(0).Value
                    End If
                End If

            End If

        Catch ex As Exception
            'V�ratlan kiv�tel
            m_ParentAddon.SboApplication.MessageBox(Me.LocRM.GetString("ifsz-00002") & " (" & ex.ToString & ")")
        Finally
            If (Not RecSet Is Nothing) Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(RecSet)
                RecSet = Nothing
            End If
        End Try

    End Sub

    Private Sub Cimletezes(ByVal FormUID As String)

        Dim l_statusz As String
        Dim l_pnm As String
        Dim oForm As SboForm
        Dim oCombo As SAPbouiCOM.ComboBox
        Dim l_clslines As String
        Dim l_blnc_code As String
        Dim RecSet As SAPbobsCOM.Recordset

        Try
            RecSet = m_ParentAddOn.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

            oCombo = m_SboForm.Items.Item("penznem").Specific
            If oCombo.ValidValues.Count > 0 Then

                l_pnm = oCombo.Selected.Value

                l_clslines = get_item_value("lastcls", "", 0)
                If l_clslines = "" Then
                    l_clslines = Nothing
                    l_blnc_code = Me.pl_blnc_code
                    l_statusz = "-"
                Else
                    l_blnc_code = Nothing
                    RecSet.DoQuery("select [@ifsz_cash_cls_lines].code from [@ifsz_cash_cls] join [@ifsz_cash_cls_lines] on [@ifsz_cash_cls].code = [@ifsz_cash_cls_lines].u_cashcls where [@ifsz_cash_cls].u_cashcode = '" & get_item_value("cashpoint", "", 0) & "' and [@ifsz_cash_cls].u_seq = " & get_item_value("clsseq", "", 0) & " and [@ifsz_cash_cls_lines].u_currcode = '" & l_pnm & "'")
                    RecSet.MoveFirst()
                    l_clslines = RecSet.Fields.Item(0).Value
                    l_statusz = "3"
                End If

                oForm = New IFSZ_CLS_Stand(Me.m_ParentAddon, FormUID, l_pnm, l_pnm, pl_balance, l_blnc_code, l_clslines, l_statusz)
                Me.m_ParentAddon.SBOForms.Add(oForm, oForm.UniqueID)
            Else
                m_ParentAddon.SboApplication.MessageBox(m_ParentAddon.LocRM.GetString("ifsz-18035")) '"V�lasszon el�bb p�nzt�rat!")
            End If

        Catch ex As Exception
            'V�ratlan kiv�tel
            m_ParentAddon.SboApplication.MessageBox(Me.LocRM.GetString("ifsz-00002") & " (" & ex.ToString & ")")
        Finally
            If (Not RecSet Is Nothing) Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(RecSet)
                RecSet = Nothing
            End If
        End Try

    End Sub

    Private Function Validate_Lookup_Ertek(ByVal P_Item As String, _
                                         ByVal P_Sor As Integer, _
                                         ByVal P_Oszlop As String) As Integer
        Dim oRecordset As SAPbobsCOM.Recordset
        Dim l_lookup_reszlet As String = get_item_value(P_Item, P_Oszlop, P_Sor)
        Dim l_datetime As DateTime
        Dim MyCultureInfo As System.Globalization.CultureInfo = New System.Globalization.CultureInfo("en-gb")
        Try
            oRecordset = m_ParentAddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            Select Case P_Item
                Case "lastcls"
                    If (l_lookup_reszlet Is Nothing Or l_lookup_reszlet = "") Then
                        Me.p_validal_e = False
                        set_item_value("lastcls", "", P_Sor, Nothing)
                        set_item_value("clsseq", "", P_Sor, Nothing)
                        Me.p_validal_e = True
                        Return -11
                    Else
                        l_lookup_reszlet = get_item_value("clsseq", P_Oszlop, P_Sor)
                        oRecordset.DoQuery("select u_seq, convert(varchar, u_timestmp, 120) from [@ifsz_cash_cls] where (u_cashcode = '" & get_item_value("cashpoint", "", 0) & "') and " _
                                           & "(u_seq = " & l_lookup_reszlet & ")")
                        If oRecordset.RecordCount > 0 Then
                            Me.p_validal_e = False
                            l_datetime = DateTime.ParseExact(oRecordset.Fields.Item(1).Value, "yyyy-MM-dd HH:mm:ss", MyCultureInfo)
                            set_item_value("lastcls", "", P_Sor, l_datetime)
                            'set_item_value("clsseq", "", P_Sor, oRecordset.Fields.Item(1).Value)
                            Me.p_validal_e = True
                        End If
                        Return oRecordset.RecordCount
                    End If
            End Select
        Catch
            Return 0
        Finally
            If (Not oRecordset Is Nothing) Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oRecordset)
                oRecordset = Nothing
            End If
        End Try
    End Function 'Validate_Lookup_Ertek

    Private Sub Go_LOV(ByVal P_Item As String, _
                         ByVal P_Oszlop As String, _
                         ByVal P_SzuresiErtek As String)
        Dim oConditions = New SAPbouiCOM.Conditions

        If P_Item = "lastcls" Then
            Dim p_oszlop_tipus(1) As OszlopTipus
            p_oszlop_tipus(0).Title = Me.LocRM.GetString("ifsz-01255")
            p_oszlop_tipus(0).DbNev = "U_TimeStmp"
            p_oszlop_tipus(0).Description = Me.LocRM.GetString("ifsz-01255")
            p_oszlop_tipus(0).Visible = True
            p_oszlop_tipus(1).Title = Me.LocRM.GetString("ifsz-01247")
            p_oszlop_tipus(1).DbNev = "U_Seq"
            p_oszlop_tipus(1).Description = Me.LocRM.GetString("ifsz-01247")
            p_oszlop_tipus(1).Visible = True

            Dim oCondition = oConditions.Add
            oCondition.BracketOpenNum = 1
            oCondition.Alias = "U_CashCode"
            oCondition.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL
            oCondition.CondVal = get_item_value("cashpoint", "", 0)
            oCondition.BracketCloseNum = 1

            If P_SzuresiErtek = Nothing Then
                erteklista_ctrl(p_oszlop_tipus, "lastcls", "clsseq", "@IFSZ_CASH_CLS", oConditions, _
                           Me.LocRM.GetString("ifsz-01118"))
            Else ' ha sz�rni kell  - Nem tudom, hogy lehet form�zni d�tumot
                'oCondition.Relationship = SAPbouiCOM.BoConditionRelationship.cr_AND
                'oCondition = oConditions.Add

                'oCondition.BracketOpenNum = 1
                'oCondition.Alias = "U_Seq"
                'oCondition.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL
                'oCondition.CondVal = P_SzuresiErtek
                'oCondition.BracketCloseNum = 1

                erteklista_ctrl(p_oszlop_tipus, "lastcls", "clsseq", "@IFSZ_CASH_CLS", oConditions, _
                           Me.LocRM.GetString("ifsz-01118"))
            End If
        End If
    End Sub

    Private Sub LOVValidate(ByVal p_item As String)
        Dim l_ertek As String
        Dim l_LOV_count As Integer
        Dim l_old_ertek As String

        Select Case p_item
            Case "lastcls"

                Select Case p_item
                    Case "lastcls"
                        l_old_ertek = l_lastcls_old
                End Select
                l_ertek = get_item_value(p_item, "", 0)
                'If l_old_ertek <> l_ertek Then
                If ((Not l_ertek Is Nothing) And l_ertek <> "") Then
                    If l_ertek.Substring(l_ertek.Length - 1, 1) = "*" Then
                        Go_LOV(p_item, "", l_ertek.Substring(0, l_ertek.Length - 1))
                    Else
                        l_LOV_count = Validate_Lookup_Ertek(p_item, 0, "")
                        If l_LOV_count = 0 Then
                            Go_LOV(p_item, "", l_ertek)
                        End If
                    End If
                Else ' ha a felhaszn�l� t�rli a mez� tartalm�t, akkor a visszat�r� �rt�keket is �r�teni kell
                    Validate_Lookup_Ertek(p_item, 0, "")
                End If
                l_ertek = get_item_value(p_item, "", 0)
                Select Case p_item
                    Case "lastcls"
                        l_lastcls_old = l_ertek
                End Select
                'End If
        End Select

    End Sub

    Private Function Get_Report_Query_Where( _
      ByVal p_riport_nev As String, _
      ByVal p_cashcode As String, _
      ByVal p_currcode As String, _
      ByVal p_clsseq As Integer _
    ) As String

        Dim v_str As String
        Dim v_flt As Boolean = False 'van-e sz�r� felt�tel
        Dim v_fltstr As String

        'p�nzt�r (ICT.U_CashCode)
        If Len(p_cashcode) > 0 Then
            v_flt = True
            If p_riport_nev = Me.Riport_Nev_Penztar_Zaras Then
                v_str = "Upper(ICT_Penztarkod) = " & IFSZ_Globals.SQLConstantPrepare(p_cashcode.ToUpper)
            Else
                v_str = "Upper(U_CashCode) = " & IFSZ_Globals.SQLConstantPrepare(p_cashcode.ToUpper)
            End If
        End If

        'p�nznem (ICT.U_CurrCode)
        If Len(p_currcode) > 0 Then
            If v_flt Then
                v_str = v_str & " and "
            End If
            v_flt = True
            If p_riport_nev = Me.Riport_Nev_Penztar_Zaras Then
                v_str = v_str & "Upper(ICT_Penznem) = " & IFSZ_Globals.SQLConstantPrepare(p_currcode.ToUpper)
            Else
                v_str = v_str & "Upper(penznem) = " & IFSZ_Globals.SQLConstantPrepare(p_currcode.ToUpper)
            End If
        End If

        'z�r�s (ICC.U_Seq)
        If (p_clsseq > 0) Then
            If v_flt Then
                v_str = v_str & " and "
            End If
            If p_riport_nev = Me.Riport_Nev_Penztar_Zaras Then
                v_str = v_str & "Zarassorszam = " & p_clsseq
            Else
                v_str = v_str & "sorszam = " & p_clsseq
            End If
            v_flt = True
        Else
            If v_flt Then
                v_str = v_str & " and "
            End If
            If p_riport_nev = Me.Riport_Nev_Penztar_Zaras Then
                v_str = v_str & "Zarassorszam is not null"
            Else
                v_str = v_str & "sorszam is not null"
            End If
            v_flt = True
        End If

        If v_flt Then 'volt sz�r� felt�tel
            v_fltstr = " WHERE " & v_str
        End If

        Return v_fltstr

    End Function

    Private Function Get_Report_Query( _
      ByVal p_riport_nev As String, _
      ByVal p_cashcode As String, _
      ByVal p_currcode As String, _
      ByVal p_clsseq As Integer _
    ) As String
        Dim v_fltstr As String

        If p_riport_nev = Me.Riport_Nev_Penztar_Zaras Then
            v_fltstr = "SELECT * FROM IFSZ_PENZTARFORGALOM_V" & _
              Get_Report_Query_Where( _
                  p_riport_nev _
                , p_cashcode _
                , p_currcode _
                , p_clsseq _
              )
        Else
            v_fltstr = "SELECT * FROM IFSZ_CLS_CIMLET_V" & _
              Get_Report_Query_Where( _
                  p_riport_nev _
                , p_cashcode _
                , p_currcode _
                , p_clsseq _
              )
        End If

        Return v_fltstr

    End Function

#End Region


#Region "Protected"

    Protected Function Set_Report_Where(ByVal p_riport_nev As String) As Boolean
        Dim v_sel As String
        Dim l_cashcode As String
        Dim l_currcode As String
        Dim l_clsseq As Integer

        Get_Parameters( _
          l_cashcode, _
          l_currcode, _
          l_clsseq _
        )

        v_sel = Get_Report_Query( _
          p_riport_nev, _
          l_cashcode, _
          l_currcode, _
          l_clsseq _
        )

        lRdoc = New IFSZ_Rdoc(Me.m_ParentAddon)

        Try
            m_ParentAddOn.SboCompany.StartTransaction()
            lRdoc.SetReportQueryStr(p_riport_nev, v_sel)
            m_ParentAddOn.SboCompany.EndTransaction(SAPbobsCOM.BoWfTransOpt.wf_Commit)
        Catch e As NoRowsOwnException
            MsgBox(e.Message)
            Return False
        Catch f As TooManyRowsOwnException
            MsgBox(f.Message)
            Return False
        Catch g As System.Exception
            'ifsz-00002: V�ratlan kiv�tel
            MsgBox(LocRM.GetString("ifsz-00002") & ":" & Chr(10) & g.ToString)
            Return False
        Finally
            lRdoc = Nothing
        End Try
        Return True
    End Function

    Protected Sub Get_Parameters( _
         ByRef p_cashcode As String, _
         ByRef p_currcode As String, _
         ByRef p_clsseq As Integer _
    )
        Dim l_cashcode As String = get_item_value("cashpoint", "", 0)
        Dim l_currcode As String = get_item_value("penznem", "", 0)
        Dim l_clsseq As Integer
        Dim l_cls As String = get_item_value("clsseq", "", 0)

        If l_cashcode = "" Then
            p_cashcode = Nothing
        Else
            p_cashcode = l_cashcode
        End If
        If l_currcode = "" Then
            p_currcode = Nothing
        Else
            p_currcode = l_currcode
        End If
        If l_cls Is Nothing Or l_cls = "" Then
            p_clsseq = 0
        Else
            p_clsseq = CInt(l_cls)
        End If

    End Sub

    Protected Overridable Sub pb_runform_pressed()
        Dim l_cashcode As String
        Dim l_currcode As String
        Dim l_clsseq As Integer
        Dim v_sel As String
        Dim oForm As SboForm

        Get_Parameters( _
          l_cashcode, _
          l_currcode, _
          l_clsseq _
        )

        v_sel = Get_Report_Query_Where( _
          Me.Riport_Nev_Penztar_Zaras, _
          l_cashcode, _
          l_currcode, _
          l_clsseq _
        )

        If Not v_sel Is Nothing And v_sel <> "" Then
            v_sel = v_sel.Replace("''", "'")
        End If

        oForm = New IFSZ_CashTxn_Browse_Matrix( _
                      m_ParentAddon _
                    , Nothing _
                    , v_sel _
        )
        Me.m_ParentAddon.SBOForms.Add(oForm, oForm.UniqueID)
        Me.ModalFormUID = oForm.UniqueID

    End Sub

#End Region


End Class
