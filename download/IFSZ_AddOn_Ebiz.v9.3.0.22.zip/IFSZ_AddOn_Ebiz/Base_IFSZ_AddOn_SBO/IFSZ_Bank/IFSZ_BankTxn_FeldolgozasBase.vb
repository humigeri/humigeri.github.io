﻿Public Class IFSZ_BankTxn_FeldolgozasBase

    Public m_uzenet As String = ""
    Public m_uzenet_p1 As String = ""
    Public m_uzenet_p2 As String = ""
    Public m_uzenet_p3 As String = ""
    Public m_uzenet_p4 As String = ""

    Private m_ParentAddon As SBOAddOn
    Private m_hivo_form As IFSZ_BankTxn_Matrix

    Public m_BranchID As String
    Public m_kimeno_atlag_arfolyam As Boolean = False
    Public l_sajat_pnm As String

    Public m_SeriesParamKI As String
    Public m_SeriesParamBE As String

    Public m_fokszam_for_series As String

    Public m_sajat_currcode As String = IFSZ_Globals_SBO.MainCurrency

    Sub New(ByRef p_hivo_form As IFSZ_BankTxn_Matrix, ByRef p_parentaddon As SBOAddOn)
        m_hivo_form = p_hivo_form
        m_ParentAddon = p_parentaddon
    End Sub

    Public Overridable Function GetSeries(ByVal pDatum As Date, ByVal pFizetesTip As String, ByVal pMit As String, ByRef l_vissza As String) As Boolean
        Dim l_datum_s As String = pDatum.ToString("yyyyMMdd")
        Dim l_SeriesName, l_fokszamser As String
        Dim l_Series As Integer = 0

        If String.IsNullOrEmpty(l_vissza) Then
            l_vissza = "0"
        End If

        l_fokszamser = Me.m_ParentAddon.parameter_ertek("BANKFOKSZAMSER")
        If String.IsNullOrEmpty(l_fokszamser) Then
            l_fokszamser = "N"
        End If

        If Not String.IsNullOrEmpty(m_fokszam_for_series) AndAlso l_fokszamser.ToUpper() <> "N" Then
            m_SeriesParamBE = IFSZ_Globals_SBO.DIExecScalar("select oact.U_SeriesIn from oact where acctcode = " & IFSZ_Globals.SQLConstantPrepare(m_fokszam_for_series))
            m_SeriesParamKI = IFSZ_Globals_SBO.DIExecScalar("select oact.U_SeriesOut from oact where acctcode = " & IFSZ_Globals.SQLConstantPrepare(m_fokszam_for_series))
        End If

        Try
            If String.IsNullOrEmpty(Me.m_SeriesParamKI) Or String.IsNullOrEmpty(Me.m_SeriesParamBE) Then
                l_vissza = "0"
                Return True
            End If
            If pFizetesTip = "B" Then
                If Me.m_SeriesParamBE.IndexOf("<EEEE>") >= 0 Then
                    l_SeriesName = l_datum_s.Substring(0, 4)
                    l_SeriesName = Me.m_SeriesParamBE.Replace("<EEEE>", l_SeriesName)
                ElseIf Me.m_SeriesParamBE.IndexOf("<EE>") >= 0 Then
                    l_SeriesName = l_datum_s.ToString.Substring(2, 2)
                    l_SeriesName = Me.m_SeriesParamBE.Replace("<EE>", l_SeriesName)
                ElseIf Me.m_SeriesParamBE.IndexOf("<ÉÉÉÉ>") >= 0 Then
                    l_SeriesName = l_datum_s.Substring(0, 4)
                    l_SeriesName = Me.m_SeriesParamBE.Replace("<ÉÉÉÉ>", l_SeriesName)
                ElseIf Me.m_SeriesParamBE.IndexOf("<ÉÉ>") >= 0 Then
                    l_SeriesName = l_datum_s.ToString.Substring(2, 2)
                    l_SeriesName = Me.m_SeriesParamBE.Replace("<ÉÉ>", l_SeriesName)
                ElseIf Me.m_SeriesParamBE.IndexOf("<YYYY>") >= 0 Then
                    l_SeriesName = l_datum_s.Substring(0, 4)
                    l_SeriesName = Me.m_SeriesParamBE.Replace("<YYYY>", l_SeriesName)
                ElseIf Me.m_SeriesParamBE.IndexOf("<YY>") >= 0 Then
                    l_SeriesName = l_datum_s.ToString.Substring(2, 2)
                    l_SeriesName = Me.m_SeriesParamBE.Replace("<YY>", l_SeriesName)
                Else
                    l_SeriesName = Me.m_SeriesParamBE
                End If
                If Not String.IsNullOrEmpty(l_SeriesName) Then
                    l_Series = DataProvider.ExecuteScalar("select ""Series"" from NNM1 where ""ObjectCode""='24' and ""SeriesName"" = '" & l_SeriesName & "'")
                End If
            Else
                If Me.m_SeriesParamKI.IndexOf("<EEEE>") >= 0 Then
                    l_SeriesName = l_datum_s.Substring(0, 4)
                    l_SeriesName = Me.m_SeriesParamKI.Replace("<EEEE>", l_SeriesName)
                ElseIf Me.m_SeriesParamKI.IndexOf("<EE>") >= 0 Then
                    l_SeriesName = l_datum_s.Substring(2, 2)
                    l_SeriesName = Me.m_SeriesParamKI.Replace("<EE>", l_SeriesName)
                Else
                    l_SeriesName = Me.m_SeriesParamKI
                End If
                If Not String.IsNullOrEmpty(l_SeriesName) Then
                    l_Series = DataProvider.ExecuteScalar("select ""Series"" from NNM1 where ""ObjectCode""='46' and ""SeriesName"" = '" & l_SeriesName & "'")
                End If
            End If
            If pMit = "NAME" Then
                l_vissza = l_SeriesName
            Else
                l_vissza = l_Series.ToString
            End If
            Return True
        Catch ex As Exception
            l_vissza = "0"
            m_uzenet = "Hiba történt a bizonylatszám meghatározása közben!"
            m_uzenet_p1 = ex.Message.ToString
        End Try
    End Function

    Public Overridable Function FizetesKeszites(ByVal l_code As String) As Boolean
        Dim l_temp As String = IFSZ_Globals.GetParameter("BANKTXN_KONYVEL_A_MODSZER")
        If String.IsNullOrEmpty(l_temp) OrElse l_temp.ToUpper() <> "AUT" Then
            FizetesKeszitesRegiModszer(l_code)
        Else
            FizetesKeszitesAutModszer(l_code)
        End If
    End Function

    ''' <summary>
    ''' Az eredeti módszer a Könyvel A-ra. Ha nem adjuk meg a BANKTXN_KONYVEL_A_MODSZER paramétert, akkor alapból ez fog működni
    ''' - A főkönyvi fizetéseket, ha meg van adva a főkönyv, simán könyveli
    ''' - A partneri fizetéseket akkor könyveli, ha ki van tölte az U_Szamhiv mező és azt, mint donum megtalálja az oinv/opch táblákban ugyanolyan nyitott összeggel
    ''' </summary>
    ''' <param name="l_code"></param>
    ''' <returns></returns>
    Public Overridable Function FizetesKeszitesRegiModszer(ByVal l_code As String) As Boolean
        Dim l_sql As String
        Dim l_tabla, l_fizcode, l_fizdocnum As String
        Dim l_fokszam, l_docentry, p_select As String
        Dim l_fej_rows, l_rows As DataRowCollection
        Dim l_fej_row, l_row As DataRow
        Dim l_tetel_rows As DataRowCollection
        Dim l_tetel_row As DataRow
        Dim l_payment As SAPbobsCOM.Payments
        Dim l_szamla_osszeg As Double
        Dim l_sajat_currcode As String = IFSZ_Globals_SBO.MainCurrency
        Dim l_Series As Integer = 0
        Dim l_rate As Decimal
        Dim l_tech_fok As String = Me.m_ParentAddon.parameter_ertek("TECH_FOK")

        l_sql = "select * from ""@IFSZ_BANK_TXNS"" where ""Code""='" & l_code & "'"

        l_fej_rows = DataProvider.GetDataRecord(l_sql)
        If l_fej_rows.Count = 1 Then
            l_fej_row = l_fej_rows.Item(0)
            l_fokszam = l_fej_row.Item("U_Account").ToString
        Else
            m_uzenet = "nemtalal_bizonylat"
            Return False
        End If

        l_sql = "select case when ""U_AmountS"" = 0 then ""U_Amount"" else ""U_AmountS"" end fizetendo_osszeg, case when ""U_AmountS"" = 0 then a.""U_CurrCode"" else ""U_CashS"" end fizetendo_pnm, " _
            & "a.""U_CurrCode"",b.* from ""@IFSZ_BANK_TXNS"" a inner join ""@IFSZ_BANK_TXN_LINES"" b on a.""Code""=b.""U_BankTxn"" where ""U_BankTxn"" = '" & l_code & "' and ""U_LineSts""='0' "
        l_tetel_rows = DataProvider.GetDataRecord(l_sql)
        For Each l_tetel_row In l_tetel_rows
            Dim l_arfolyam As Decimal
            If l_fej_row("U_CurrCode").ToString = m_sajat_currcode Then
                l_arfolyam = 1
            Else
                If IsDBNull(l_tetel_row("U_Arfolyam")) Then
                    l_arfolyam = 1
                Else
                    l_arfolyam = l_tetel_row("U_Arfolyam")
                End If

                If Me.m_kimeno_atlag_arfolyam And l_tetel_row.Item("U_Amount") < 0 Then
                    'Kimenő átlag árfolyam használata esetén
                    l_arfolyam = Math.Round(IFSZ_Globals_SBO.GetAcctAtlagArfolyam(l_fokszam), IFSZ_Globals_SBO.RateDec)
                    If l_arfolyam = 0 Then
                        'Nem határozható meg az árfolyam
                        Continue For
                    End If
                    l_sql = "update ""@IFSZ_BANK_TXN_LINES"" set ""U_Arfolyam"" = " + IFSZ_Globals.SQLConstantPrepare(l_arfolyam) + " where ""Code"" = " + IFSZ_Globals.SQLConstantPrepare(l_tetel_row("Code"))
                    DataProvider.EExecuteNonQuery(l_sql)
                End If
            End If
            If (Not l_payment Is Nothing) Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(l_payment)
                l_payment = Nothing
            End If


            If l_tetel_row.Item("U_Amount") > 0 Then
                l_payment = m_ParentAddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oIncomingPayments)
                l_tabla = "OINV"
            Else
                l_payment = m_ParentAddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oVendorPayments)
                l_tabla = "OPCH"
            End If

            l_Series = 0
            If Not String.IsNullOrEmpty(l_tetel_row.Item("U_ErtNap").ToString) Then
                If l_tabla = "OINV" Then
                    If Not GetSeries(l_tetel_row.Item("U_ErtNap"), "B", "SZAM", l_Series) Then
                        Return False
                    End If
                Else
                    If Not GetSeries(l_tetel_row.Item("U_ErtNap"), "K", "SZAM", l_Series) Then
                        Return False
                    End If
                End If
            End If

            l_payment.GetByKey(-1)
            If l_tetel_row.Item("U_Jelleg").ToString = "F" Then
                l_payment.ApplyVAT = SAPbobsCOM.BoYesNoEnum.tNO
                'l_payment.CardCode = m_ParentAddon.parameter_ertek("TECH_FOK")

                l_payment.CashSum = 0
                If l_Series > 0 Then
                    l_payment.Series = l_Series
                End If
                l_payment.DocCurrency = l_tetel_row.Item("fizetendo_pnm").ToString
                l_payment.DocDate = l_tetel_row.Item("U_ErtNap").ToString
                l_payment.TaxDate = l_tetel_row.Item("U_ErtNap").ToString
                l_payment.VatDate = l_tetel_row.Item("U_ErtNap").ToString
                l_payment.DocRate = l_arfolyam
                l_payment.Reference2 = l_tetel_row.Item("Code").ToString
                l_payment.CounterReference = l_tetel_row.Item("Code").ToString
                l_payment.DocTypte = SAPbobsCOM.BoRcptTypes.rAccount
                l_payment.HandWritten = SAPbobsCOM.BoYesNoEnum.tNO
                'l_payment.JournalRemarks = "Incoming - D10004"
                'VenTable.LocalCurrency = SAPbobsCOM.BoYesNoEnum.tNO
                'VenTable.Reference1 = 8
                l_payment.Remarks = l_fej_row.Item("U_KntKod").ToString
                If Not String.IsNullOrEmpty(m_BranchID) Then l_payment.BPLID = m_BranchID

                l_payment.TaxDate = l_tetel_row.Item("U_ErtNap").ToString
                l_payment.VatDate = l_tetel_row.Item("U_ErtNap").ToString
                l_payment.TransferAccount = l_fej_row.Item("U_Account").ToString
                l_payment.TransferDate = l_tetel_row.Item("U_ErtNap").ToString
                l_payment.TransferSum = Math.Abs(l_tetel_row.Item("fizetendo_osszeg"))

                l_payment.AccountPayments.ProfitCenter = l_tetel_row.Item("U_PrcCode").ToString
                l_payment.AccountPayments.ProfitCenter2 = l_tetel_row.Item("U_OcrCode2").ToString
                l_payment.AccountPayments.ProfitCenter3 = l_tetel_row.Item("U_OcrCode3").ToString
                l_payment.AccountPayments.ProfitCenter4 = l_tetel_row.Item("U_OcrCode4").ToString
                l_payment.AccountPayments.ProfitCenter5 = l_tetel_row.Item("U_OcrCode5").ToString
                l_payment.AccountPayments.ProjectCode = l_tetel_row.Item("U_PrjCode").ToString

                l_payment.AccountPayments.AccountCode = l_tetel_row.Item("U_Account").ToString()
                l_payment.AccountPayments.SumPaid = Math.Abs(l_tetel_row.Item("fizetendo_osszeg"))
                'l_payment.AccountPayments.Add()

                If (l_payment.Add() <> 0) Then
                    Dim lng_errCode, str_errMsg As String
                    m_ParentAddon.SboCompany.GetLastError(lng_errCode, str_errMsg)
                    m_hivo_form.show_error("sorszam_hiba_hibakod", l_tetel_row.Item("U_FbSeq").ToString, str_errMsg & Chr(10), lng_errCode.ToString())
                    Continue For
                Else
                    m_ParentAddon.SboCompany.GetNewObjectCode(l_fizcode)
                    If l_tabla = "OINV" Then
                        l_fizdocnum = DataProvider.ExecuteScalar("SELECT ""DocNum"" FROM ""ORCT"" WHERE ""DocEntry"" = " & l_fizcode)
                    Else
                        l_fizdocnum = DataProvider.ExecuteScalar("SELECT ""DocNum"" FROM ""OVPM"" WHERE ""DocEntry"" = " & l_fizcode)
                    End If

                    Dim p_message, l_sql2 As String
                    l_sql2 = "update ""@IFSZ_BANK_TXN_LINES"" set ""U_LineSts"" = '2', ""U_DocNum"" = " & IFSZ_Globals.SQLConstantPrepare(l_fizdocnum) & " where ""Code"" = '" & l_tetel_row.Item("Code").ToString & "' "
                    DataProvider.ExecuteNonQuery(l_sql2, p_message)

                End If

            Else
                l_sql = "select " & QueryResource.SQL_dbopont & "IS_NUMBERS_ONLY(" & IFSZ_Globals.SQLConstantPrepare(l_tetel_row.Item("U_SzamHiv").ToString) & ")" & QueryResource.SQL_FromDummy
                If l_tetel_row.Item("U_SzamHiv").ToString = "" OrElse DataProvider.GetDataRecord(l_sql).Item(0).Item(0) = 0 Then
                    Continue For
                End If
                l_sql = "select case when ""DocTotalFC"" > 0 then  ""DocTotalFC"" - ""PaidSumFc"" else ""DocTotal"" - ""PaidSum"" end, ""DocEntry"", ""ObjType"", ""CardCode"", ""DocCur"" from " + l_tabla + " where ""DocNum"" = " + IFSZ_Globals.SQLConstantPrepare(l_tetel_row.Item("U_SzamHiv").ToString)
                l_rows = DataProvider.GetDataRecord(l_sql)
                If l_rows.Count = 1 Then
                    l_szamla_osszeg = l_rows.Item(0).Item(0)
                    If Math.Abs(l_szamla_osszeg) <> Math.Abs(l_tetel_row.Item("fizetendo_osszeg")) Then
                        If Math.Abs(l_szamla_osszeg) = Math.Abs(l_tetel_row.Item("U_AmountSP")) And l_tetel_row.Item("fizetendo_pnm").ToString <> l_rows.Item(0).Item("DocCur") Then

                        Else
                            Continue For
                        End If

                    End If
                    l_docentry = l_rows.Item(0).Item(1)

                    If l_Series > 0 Then
                        l_payment.Series = l_Series
                    End If
                    l_payment.CardCode = l_rows.Item(0).Item("CardCode")
                    If l_tetel_row.Item("fizetendo_pnm").ToString <> l_fej_row.Item("U_CurrCode").ToString AndAlso Not String.IsNullOrEmpty(l_tech_fok) Then
                        l_payment.TransferAccount = l_tech_fok
                    Else
                        l_payment.TransferAccount = l_fej_row.Item("U_Account").ToString
                    End If

                    If l_tetel_row.Item("fizetendo_pnm").ToString = l_rows.Item(0).Item("DocCur") Then
                        l_payment.DocCurrency = l_tetel_row.Item("fizetendo_pnm").ToString
                    Else
                        'l_payment.DocCurrency = l_rows.Item(0).Item("DocCur")
                        l_payment.DocCurrency = l_tetel_row.Item("fizetendo_pnm").ToString
                    End If


                    If Not String.IsNullOrEmpty(m_BranchID) Then l_payment.BPLID = m_BranchID
                    l_payment.DocDate = l_tetel_row.Item("U_ErtNap").ToString
                    l_payment.VatDate = l_tetel_row.Item("U_ErtNap").ToString
                    l_payment.DocRate = l_arfolyam
                    l_payment.Reference2 = l_tetel_row.Item("Code").ToString
                    l_payment.CounterReference = l_tetel_row.Item("Code").ToString
                    If l_tetel_row.Item("U_Jelleg").ToString = "V" Then
                        l_payment.DocTypte = SAPbobsCOM.BoRcptTypes.rCustomer
                    Else
                        l_payment.DocTypte = SAPbobsCOM.BoRcptTypes.rSupplier
                    End If
                    l_payment.Remarks = l_fej_row.Item("U_KntKod").ToString
                    l_payment.HandWritten = SAPbobsCOM.BoYesNoEnum.tNO
                    l_payment.TaxDate = l_tetel_row.Item("U_ErtNap").ToString
                    l_payment.VatDate = l_tetel_row.Item("U_ErtNap").ToString
                    If l_tetel_row.Item("fizetendo_pnm").ToString = l_rows.Item(0).Item("DocCur") Then
                        l_payment.TransferSum = Math.Abs(l_tetel_row.Item("fizetendo_osszeg"))
                    Else
                        l_payment.TransferSum = Math.Abs(l_tetel_row.Item("fizetendo_osszeg"))
                    End If


                    l_payment.Invoices.DocEntry = l_docentry
                    l_payment.Invoices.InvoiceType = l_rows.Item(0).Item("OBJTYPE")
                    If l_tetel_row.Item("fizetendo_pnm").ToString = l_rows.Item(0).Item("DocCur") OrElse String.IsNullOrEmpty(l_tech_fok) Then
                        If l_tetel_row.Item("fizetendo_pnm").ToString.ToUpper() = l_sajat_currcode.ToUpper() Then
                            l_payment.Invoices.SumApplied = Math.Abs(l_tetel_row.Item("fizetendo_osszeg"))
                        Else
                            l_payment.Invoices.AppliedFC = Math.Abs(l_tetel_row.Item("fizetendo_osszeg"))
                        End If
                    Else
                        l_payment.Invoices.SumApplied = Math.Abs(l_tetel_row.Item("U_AmountSP"))
                    End If

                    If (l_payment.Add() <> 0) Then
                        Dim lng_errCode, str_errMsg As String
                        m_ParentAddon.SboCompany.GetLastError(lng_errCode, str_errMsg)
                        m_hivo_form.show_error("sorszam_hiba_hibakod", l_tetel_row.Item("U_FbSeq").ToString, str_errMsg & Chr(10), lng_errCode.ToString())
                        Continue For
                    Else
                        m_ParentAddon.SboCompany.GetNewObjectCode(l_fizcode)
                        If l_tabla = "OINV" Then
                            l_fizdocnum = DataProvider.ExecuteScalar("SELECT ""DocNum"" FROM ""ORCT"" WHERE ""DocEntry"" = " & l_fizcode)
                        Else
                            l_fizdocnum = DataProvider.ExecuteScalar("SELECT ""DocNum"" FROM ""OVPM"" WHERE ""DocEntry"" = " & l_fizcode)
                        End If

                        Dim p_message, l_sql2 As String
                        l_sql2 = "update ""@IFSZ_BANK_TXN_LINES"" set ""U_LineSts"" = '2', ""U_DocNum"" = " & IFSZ_Globals.SQLConstantPrepare(l_fizdocnum) & " where ""Code"" = '" & l_tetel_row.Item("Code").ToString & "' "
                        DataProvider.ExecuteNonQuery(l_sql2, p_message)

                    End If

                Else
                    Continue For
                End If
            End If
            If l_tetel_row.Item("fizetendo_pnm").ToString <> l_fej_row.Item("U_CurrCode").ToString AndAlso Not String.IsNullOrEmpty(l_tech_fok) Then
                Dim oRcdSet As SAPbobsCOM.Recordset
                Dim oCurrRate As SAPbobsCOM.SBObob

                If (Not l_payment Is Nothing) Then
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(l_payment)
                    l_payment = Nothing
                End If

                If l_tetel_row.Item("fizetendo_osszeg") > 0 Then
                    l_payment = m_ParentAddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oIncomingPayments)
                Else
                    l_payment = m_ParentAddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oVendorPayments)
                End If

                l_Series = 0
                If Not String.IsNullOrEmpty(l_tetel_row.Item("U_ErtNap").ToString) Then
                    If l_tetel_row.Item("fizetendo_osszeg") > 0 Then
                        If Not GetSeries(l_tetel_row.Item("U_ErtNap"), "B", "SZAM", l_Series) Then
                            Return False
                        End If
                    Else
                        If Not GetSeries(l_tetel_row.Item("U_ErtNap"), "K", "SZAM", l_Series) Then
                            Return False
                        End If
                    End If
                End If

                oCurrRate = m_ParentAddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoBridge)
                oRcdSet = oCurrRate.GetLocalCurrency

                Dim l_hiba As String
                l_sajat_pnm = oRcdSet.Fields.Item(0).Value
                If l_fej_row.Item("U_CurrCode").ToString <> l_sajat_pnm Then
                    l_rate = IFSZ_Globals_SBO.GetCurrencyRate(l_fej_row.Item("U_CurrCode").ToString, l_tetel_row.Item("U_ErtNap"), m_ParentAddon, l_hiba)
                Else
                    l_rate = 1
                End If
                If Not String.IsNullOrEmpty(l_hiba) Then
                    m_hivo_form.show_error("erteknap_arfolyam_nincs")
                    Continue For
                End If

                l_payment.ApplyVAT = SAPbobsCOM.BoYesNoEnum.tNO
                l_payment.CardCode = l_tech_fok

                If l_Series > 0 Then
                    l_payment.Series = l_Series
                End If
                l_payment.CashSum = 0
                l_payment.DocCurrency = l_fej_row.Item("U_CurrCode").ToString
                l_payment.DocDate = l_tetel_row.Item("U_ErtNap").ToString
                l_payment.VatDate = l_tetel_row.Item("U_ErtNap").ToString
                l_payment.DocRate = l_rate
                l_payment.Reference2 = l_tetel_row.Item("Code").ToString
                l_payment.CounterReference = l_tetel_row.Item("Code").ToString
                l_payment.DocTypte = SAPbobsCOM.BoRcptTypes.rAccount
                l_payment.HandWritten = SAPbobsCOM.BoYesNoEnum.tNO
                l_payment.TaxDate = l_tetel_row.Item("U_ErtNap").ToString
                l_payment.VatDate = l_tetel_row.Item("U_ErtNap").ToString
                l_payment.TransferAccount = l_fej_row.Item("U_Account").ToString
                l_payment.TransferDate = l_tetel_row.Item("U_ErtNap").ToString
                l_payment.TransferSum = Math.Abs(l_tetel_row.Item("U_Amount"))
                If Not String.IsNullOrEmpty(m_BranchID) Then l_payment.BPLID = m_BranchID

                l_payment.AccountPayments.AccountCode = l_tech_fok
                l_payment.AccountPayments.SumPaid = Math.Abs(l_tetel_row.Item("U_Amount"))
                l_payment.AccountPayments.Add()


                If (l_payment.Add() <> 0) Then
                    Dim lng_errCode, str_errMsg As String
                    m_ParentAddon.SboCompany.GetLastError(lng_errCode, str_errMsg)
                    m_hivo_form.show_error("hiba_hibakod", str_errMsg & Chr(10), lng_errCode.ToString())
                    Continue For
                End If

            End If
            'Dim p_message As String
            'l_sql = "update ""@IFSZ_BANK_TXN_LINES"" set ""U_LineSts"" = '2', ""U_DocNum"" = " & IFSZ_Globals.SqlConstantPrepare(l_fizdocnum) & " where ""Code"" = '" & l_tetel_row.Item("Code").ToString & "' "
            'DataProvider.ExecuteNonQuery(l_sql, p_message)
            'p_select = QueryResource.GetQuery("Base_IFSZ_AddOn_SBO", "exists_banktxnlines_open_by_bantxn", l_fej_row.Item("Code").ToString)
        Next
        l_sql = "SELECT 1 FROM ""@IFSZ_BANK_TXN_LINES"" WHERE ""U_LineSts"" = '0' and ""U_BankTxn"" = '" & l_code & "'"
        If DataProvider.GetDataRecord(l_sql).Count = 0 Then
            l_sql = "update ""@IFSZ_BANK_TXNS"" set ""U_TxnSts"" = '2' WHERE ""Code"" = '" & l_code & "'"
            Dim l_message As String
            DataProvider.ExecuteNonQuery(l_sql, l_message)
        End If

        Return True

    End Function

    ''' <summary>
    ''' Könyvel A - fejlettebb módszer indotekes elképzelés alapján
    ''' Külön eljárás van, ami megpróbálja visszaadni, hogy mely számlákat jelölte be az ügyfél -overrideolható
    ''' Külön eljárás van, ami megmondja, hogy mely számlákat fogjuk kiegyenlíteni milyen összeggel -overrideolható
    ''' Külön eljárás a konkrét fizetés létrehozására -overrideolható
    ''' </summary>
    ''' <param name="l_code"></param>
    ''' <returns></returns>
    Public Overridable Function FizetesKeszitesAutModszer(ByVal l_code As String) As Boolean
        Dim l_sql As String
        Dim l_tabla, l_fizcode, l_fizdocnum As String
        Dim l_fokszam, l_docentry, p_select As String
        Dim l_fej_rows, l_rows As DataRowCollection
        Dim l_fej_row, l_row As DataRow
        Dim l_tetel_rows As DataRowCollection
        Dim l_tetel_row As DataRow
        Dim l_payment As SAPbobsCOM.Payments
        Dim l_szamla_osszeg As Double
        Dim l_Series As Integer = 0
        Dim l_rate As Decimal
        Dim l_tech_fok As String = Me.m_ParentAddon.parameter_ertek("TECH_FOK")

        l_sql = "select * from ""@IFSZ_BANK_TXNS"" where ""Code""='" & l_code & "'"

        l_fej_rows = DataProvider.GetDataRecord(l_sql)
        If l_fej_rows.Count = 1 Then
            l_fej_row = l_fej_rows.Item(0)
            l_fokszam = l_fej_row.Item("U_Account").ToString
        Else
            m_uzenet = "nemtalal_bizonylat"
            Return False
        End If

        l_sql = "select case when ""U_AmountS"" = 0 then ""U_Amount"" else ""U_AmountS"" end fizetendo_osszeg, case when ""U_AmountS"" = 0 then a.""U_CurrCode"" else ""U_CashS"" end fizetendo_pnm, " _
            & "a.""U_CurrCode"",b.* from ""@IFSZ_BANK_TXNS"" a inner join ""@IFSZ_BANK_TXN_LINES"" b on a.""Code""=b.""U_BankTxn"" where ""U_BankTxn"" = '" & l_code & "' and ""U_LineSts""='0' "
        l_tetel_rows = DataProvider.GetDataRecord(l_sql)
        For Each l_tetel_row In l_tetel_rows

            If l_tetel_row.Item("U_Jelleg").ToString = "F" Then
                Dim lng_errCode, str_errMsg As String
                l_fizcode = CreateFokonyviFizetes(l_fej_row, l_tetel_row, lng_errCode, str_errMsg)
                If String.IsNullOrEmpty(l_fizcode) Then
                    If Not String.IsNullOrEmpty(lng_errCode) Then
                        m_hivo_form.show_error("sorszam_hiba_hibakod", l_tetel_row.Item("U_FbSeq").ToString, str_errMsg & Chr(10), lng_errCode.ToString())
                    End If
                    Continue For
                Else
                    If l_tetel_row("Amount") > 0 Then
                        l_fizdocnum = DataProvider.ExecuteScalar("SELECT ""DocNum"" FROM ""ORCT"" WHERE ""DocEntry"" = " & l_fizcode)
                    Else
                        l_fizdocnum = DataProvider.ExecuteScalar("SELECT ""DocNum"" FROM ""OVPM"" WHERE ""DocEntry"" = " & l_fizcode)
                    End If

                    Dim p_message, l_sql2 As String
                    l_sql2 = "update ""@IFSZ_BANK_TXN_LINES"" set ""U_LineSts"" = '2', ""U_DocNum"" = " & IFSZ_Globals.SQLConstantPrepare(l_fizdocnum) & " where ""Code"" = '" & l_tetel_row.Item("Code").ToString & "' "
                    DataProvider.ExecuteNonQuery(l_sql2, p_message)

                End If

            Else
                Dim l_kiegytab As DataTable
                'Ez mondja meg, hogy mely számlákat egyenlítjük ki. Ha üreset ad vissza, akkor nem hozunk létre fizetést
                l_kiegytab = GetKiegyenlitettSzamlak(l_fej_row, l_tetel_row)
                If l_kiegytab Is Nothing OrElse l_kiegytab.Rows.Count = 0 Then
                    Continue For
                End If

                Dim lng_errCode, str_errMsg As String
                l_fizcode = CreatePartneriFizetes(l_fej_row, l_tetel_row, l_kiegytab, lng_errCode, str_errMsg)
                If String.IsNullOrEmpty(l_fizcode) Then
                    If Not String.IsNullOrEmpty(lng_errCode) Then
                        m_hivo_form.show_error("sorszam_hiba_hibakod", l_tetel_row.Item("U_FbSeq").ToString, str_errMsg & Chr(10), lng_errCode.ToString())
                    End If
                    Continue For
                Else
                    If l_tetel_row("Amount") > 0 Then
                        l_fizdocnum = DataProvider.ExecuteScalar("SELECT ""DocNum"" FROM ""ORCT"" WHERE ""DocEntry"" = " & l_fizcode)
                    Else
                        l_fizdocnum = DataProvider.ExecuteScalar("SELECT ""DocNum"" FROM ""OVPM"" WHERE ""DocEntry"" = " & l_fizcode)
                    End If

                    Dim p_message, l_sql2 As String
                    l_sql2 = "update ""@IFSZ_BANK_TXN_LINES"" set ""U_LineSts"" = '2', ""U_DocNum"" = " & IFSZ_Globals.SQLConstantPrepare(l_fizdocnum) & " where ""Code"" = '" & l_tetel_row.Item("Code").ToString & "' "
                    DataProvider.ExecuteNonQuery(l_sql2, p_message)

                End If

            End If

            If l_tetel_row.Item("fizetendo_pnm").ToString <> l_fej_row.Item("U_CurrCode").ToString AndAlso Not String.IsNullOrEmpty(l_tech_fok) Then
                Dim oRcdSet As SAPbobsCOM.Recordset
                Dim oCurrRate As SAPbobsCOM.SBObob

                If (Not l_payment Is Nothing) Then
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(l_payment)
                    l_payment = Nothing
                End If

                If l_tetel_row.Item("fizetendo_osszeg") > 0 Then
                    l_payment = m_ParentAddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oIncomingPayments)
                Else
                    l_payment = m_ParentAddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oVendorPayments)
                End If

                l_Series = 0
                If Not String.IsNullOrEmpty(l_tetel_row.Item("U_ErtNap").ToString) Then
                    If l_tetel_row.Item("fizetendo_osszeg") > 0 Then
                        If Not GetSeries(l_tetel_row.Item("U_ErtNap"), "B", "SZAM", l_Series) Then
                            Return False
                        End If
                    Else
                        If Not GetSeries(l_tetel_row.Item("U_ErtNap"), "K", "SZAM", l_Series) Then
                            Return False
                        End If
                    End If
                End If

                oCurrRate = m_ParentAddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoBridge)
                oRcdSet = oCurrRate.GetLocalCurrency

                Dim l_hiba As String
                l_sajat_pnm = oRcdSet.Fields.Item(0).Value
                If l_fej_row.Item("U_CurrCode").ToString <> l_sajat_pnm Then
                    l_rate = IFSZ_Globals_SBO.GetCurrencyRate(l_fej_row.Item("U_CurrCode").ToString, l_tetel_row.Item("U_ErtNap"), m_ParentAddon, l_hiba)
                Else
                    l_rate = 1
                End If
                If Not String.IsNullOrEmpty(l_hiba) Then
                    m_hivo_form.show_error("erteknap_arfolyam_nincs")
                    Continue For
                End If

                l_payment.ApplyVAT = SAPbobsCOM.BoYesNoEnum.tNO
                l_payment.CardCode = l_tech_fok

                If l_Series > 0 Then
                    l_payment.Series = l_Series
                End If
                l_payment.CashSum = 0
                l_payment.DocCurrency = l_fej_row.Item("U_CurrCode").ToString
                l_payment.DocDate = l_tetel_row.Item("U_ErtNap").ToString
                l_payment.VatDate = l_tetel_row.Item("U_ErtNap").ToString
                l_payment.DocRate = l_rate
                l_payment.Reference2 = l_tetel_row.Item("Code").ToString
                l_payment.CounterReference = l_tetel_row.Item("Code").ToString
                l_payment.DocTypte = SAPbobsCOM.BoRcptTypes.rAccount
                l_payment.HandWritten = SAPbobsCOM.BoYesNoEnum.tNO
                l_payment.TaxDate = l_tetel_row.Item("U_ErtNap").ToString
                l_payment.VatDate = l_tetel_row.Item("U_ErtNap").ToString
                l_payment.TransferAccount = l_fej_row.Item("U_Account").ToString
                l_payment.TransferDate = l_tetel_row.Item("U_ErtNap").ToString
                l_payment.TransferSum = Math.Abs(l_tetel_row.Item("U_Amount"))
                If Not String.IsNullOrEmpty(m_BranchID) Then l_payment.BPLID = m_BranchID

                l_payment.AccountPayments.AccountCode = l_tech_fok
                l_payment.AccountPayments.SumPaid = Math.Abs(l_tetel_row.Item("U_Amount"))
                l_payment.AccountPayments.Add()


                If (l_payment.Add() <> 0) Then
                    Dim lng_errCode, str_errMsg As String
                    m_ParentAddon.SboCompany.GetLastError(lng_errCode, str_errMsg)
                    m_hivo_form.show_error("hiba_hibakod", str_errMsg & Chr(10), lng_errCode.ToString())
                    Continue For
                End If

            End If
            'Dim p_message As String
            'l_sql = "update ""@IFSZ_BANK_TXN_LINES"" set ""U_LineSts"" = '2', ""U_DocNum"" = " & IFSZ_Globals.SqlConstantPrepare(l_fizdocnum) & " where ""Code"" = '" & l_tetel_row.Item("Code").ToString & "' "
            'DataProvider.ExecuteNonQuery(l_sql, p_message)
            'p_select = QueryResource.GetQuery("Base_IFSZ_AddOn_SBO", "exists_banktxnlines_open_by_bantxn", l_fej_row.Item("Code").ToString)
        Next
        l_sql = "SELECT 1 FROM ""@IFSZ_BANK_TXN_LINES"" WHERE ""U_LineSts"" = '0' and ""U_BankTxn"" = '" & l_code & "'"
        If DataProvider.GetDataRecord(l_sql).Count = 0 Then
            l_sql = "update ""@IFSZ_BANK_TXNS"" set ""U_TxnSts"" = '2' WHERE ""Code"" = '" & l_code & "'"
            Dim l_message As String
            DataProvider.ExecuteNonQuery(l_sql, l_message)
        End If

        Return True

    End Function

    ''' <summary>
    ''' Visszaadja a tételsor árfolyamát. Ha változott, akkor be is update-eli
    ''' </summary>
    ''' <param name="p_fej_row"></param>
    ''' <param name="p_tet_row"></param>
    ''' <returns></returns>
    Protected Overridable Function GetTxnLineArfolyam(ByVal p_fej_row As DataRow, ByVal p_tet_row As DataRow) As Decimal
        Dim l_arfolyam As Decimal
        Dim l_sql As String

        If p_fej_row("U_CurrCode").ToString = m_sajat_currcode Then
            l_arfolyam = 1
        Else
            If IsDBNull(p_tet_row("U_Arfolyam")) Then
                l_arfolyam = 1
            Else
                l_arfolyam = p_tet_row("U_Arfolyam")
            End If

            If Me.m_kimeno_atlag_arfolyam And p_tet_row.Item("U_Amount") < 0 Then
                'Kimenő átlag árfolyam használata esetén
                l_arfolyam = Math.Round(IFSZ_Globals_SBO.GetAcctAtlagArfolyam(p_fej_row.Item("U_Account").ToString), IFSZ_Globals_SBO.RateDec)
                If l_arfolyam > 0 Then
                    l_sql = "update ""@IFSZ_BANK_TXN_LINES"" set ""U_Arfolyam"" = " + IFSZ_Globals.SQLConstantPrepare(l_arfolyam) + " where ""Code"" = " + IFSZ_Globals.SQLConstantPrepare(p_tet_row("Code"))
                    DataProvider.EExecuteNonQuery(l_sql)
                End If
            End If
        End If

        Return l_arfolyam

    End Function

    ''' <summary>
    ''' Ez bányászná ki, hog az ügyfél mely számlákat jelölte meg kiegyenlítésre
    ''' Egyelőre még csak az u_szamhiv-et adja vissza, de fel kell okosítani. Használhatná simán a közleményeket
    ''' </summary>
    ''' <param name="p_fej_row"></param>
    ''' <param name="p_tet_row"></param>
    ''' <returns></returns>
    Protected Overridable Function GetMegjeloltSzamlak(ByVal p_fej_row As DataRow, ByVal p_tet_row As DataRow) As DataTable
        Dim l_tab, l_tab2 As DataTable
        Dim l_szamhiv As String = p_tet_row("U_SzamHiv").ToString()
        Dim l_docnum As Long

        l_tab = New DataTable()
        l_tab.Columns.Add("DOCENTRY", GetType(Integer))
        l_tab.Columns.Add("OBJTYPE", GetType(Integer))

        If p_tet_row("Amount") > 0 Then
            If Long.TryParse(l_szamhiv, l_docnum) Then
                l_tab2 = DataProvider.GetDataTable("select ""DocEntry"" DOCENTRY, ""ObjType"" OBJTYPE from oinv where ""DocNum"" = " + l_szamhiv)
                l_tab.Merge(l_tab2)
            End If
        Else
            If Long.TryParse(l_szamhiv, l_docnum) Then
                l_tab2 = DataProvider.GetDataTable("select ""DocEntry"" DOCENTRY, ""ObjType"" OBJTYPE from opch where ""DocNum"" = " + l_szamhiv)
                l_tab.Merge(l_tab2)
            End If
        End If

        Return l_tab

    End Function

    ''' <summary>
    ''' Visszaadja a kiegyenlített számlákat
    ''' </summary>
    ''' <param name="p_fej_row"></param>
    ''' <param name="p_tet_row"></param>
    ''' <returns></returns>
    Protected Overridable Function GetKiegyenlitettSzamlak(ByVal p_fej_row As DataRow, ByVal p_tet_row As DataRow) As DataTable
        Dim l_sql, l_sql1 As String
        Dim l_tab, l_megjelolttab As DataTable
        Dim l_view As DataView
        Dim l_amount, l_arfolyaminv, l_arfolyambank, l_allpaidamount, l_invpaidamount, l_invpaidmain, l_sumapplied As Decimal
        Dim l_kerekites As Integer = IFSZ_Globals_SBO.GetCurrDecimals(m_sajat_currcode)

        If p_tet_row("Amount") > 0 Then
            'Meg kell keresni a nyitott kimenő bizonylatokat
            l_sql1 = "select ""DocEntry"" as DOCENTRY, ""ObjType"" as OBJTYPE, ""CardCode"" as CARDCODE, ""DocDate"" as DOCDATE, ""DocCur"" as DOCCUR "
            l_sql1 += ", case when ""DocCur"" = " + IFSZ_Globals.SQLConstantPrepare(m_sajat_currcode) + " then ""DocTotal"" - ""PaidToDate"" else ""DocTotalfc"" - ""PaidFC"" end as INVAMOUNT"
            l_sql1 += ", cast(0 as decimal(19,6)) as ALLPAIDAMOUNT, cast(0 as decimal(19,6)) as INVPAIDAMOUNT, cast(0 as decimal(19,6)) as SUMAPPLIED "

            l_sql = "select *, ROW_NUMBER() OVER (ORDER BY DOCDATE, OBJTYPE, DOCENTRY) + 100000 as SORREND from ( "
            l_sql += l_sql1
            l_sql += " from oinv where ""DocTotal"" > 0 and ""DocStatus"" = 'O' "
            l_sql += " union all "
            l_sql += l_sql1
            l_sql += " from ocsi where ""DocTotal"" > 0 and ""DocStatus"" = 'O' "
            l_sql += " union all "
            l_sql += l_sql1
            l_sql += " from odpi where ""DocTotal"" > 0 and ""DocStatus"" = 'O' and ""Posted"" = 'N' "
            l_sql += ") a"
        Else
            'Meg kell keresni a nyitott bejövő bizonylatokat
            l_sql1 = "select ""DocEntry"" as DOCENTRY, ""ObjType"" as OBJTYPE, ""CardCode"" as CARDCODE, ""DocDate"" as DOCDATE, ""DocCur"" as DOCCUR "
            l_sql1 += ", case when ""DocCur"" = " + IFSZ_Globals.SQLConstantPrepare(m_sajat_currcode) + " then ""DocTotal"" - ""PaidToDate"" else ""DocTotalfc"" - ""PaidFC"" end as SUMAPPLIED"

            l_sql = "select *, ROW_NUMBER() OVER (ORDER BY DOCDATE, OBJTYPE, DOCENTRY) + 100000 as SORREND from ( "
            l_sql += l_sql1
            l_sql += " from oinv where ""DocTotal"" > 0 and ""DocStatus"" = 'O' "
            l_sql += " union all "
            l_sql += l_sql1
            l_sql += " from ocsi where ""DocTotal"" > 0 and ""DocStatus"" = 'O' "
            l_sql += " union all "
            l_sql += l_sql1
            l_sql += " from odpi where ""DocTotal"" > 0 and ""DocStatus"" = 'O' and ""Posted"" = 'N' "
            l_sql += ") a"
        End If

        l_tab = DataProvider.EGetDataTable(l_sql)

        If l_tab Is Nothing OrElse l_tab.Rows.Count = 0 Then
            Return l_tab
        End If

        l_megjelolttab = GetMegjeloltSzamlak(p_fej_row, p_tet_row)

        'A SORREND mondja meg a kiegyenlítés sorrendjét, de szándékosan 100001-től kezdődik ez az l_tab-ban
        'Mert azok, amiket az ügyfél megjelölt (és tényleg fizetendők), azokat előre veszzük. Ezért abből kivonunk 100000-et
        'Reméljük, soha nem lesz 100000-nél több nyitott számlája egy ügyfélnek :)
        l_view = New DataView(l_tab, "", "OBJTYPE, DOCENTRY", DataViewRowState.CurrentRows)
        Dim i As Integer = 0
        Dim l_poz As Integer
        For Each l_row As DataRow In l_megjelolttab.Rows
            l_poz = l_view.Find(New Object() {l_row("OBJTYPE"), l_row("DOCENTRY")})
            If l_poz > -1 Then
                l_view(l_poz).Row("SORREND") = CType(l_view(l_poz)("SORREND"), Integer) - 100000
            End If
        Next

        'Végigmegyünk a kiegyenlítendő számlákon
        l_amount = Math.Abs(CType(p_tet_row("U_Amount"), Decimal)) * CType(p_tet_row("U_Arfolyam"), Decimal)

        l_view = New DataView(l_tab, "", "SORREND", DataViewRowState.CurrentRows)
        For Each l_rv As DataRowView In l_view
            If CType(l_rv("INVAMOUNT"), Decimal) > 0 Then
                If l_rv("DOCCUR").ToString() = m_sajat_currcode Then
                    l_arfolyaminv = 1
                Else
                    l_arfolyaminv = DataProvider.ExecuteScalarDouble("select " + QueryResource.SQL_isnull("min(""Rate"")", "0") + " from ortt where ""RateDate"" = " + IFSZ_Globals.SQLConstantPrepare(l_rv("DOCDATE")) + " and ""Currency"" = " + IFSZ_Globals.SQLConstantPrepare(l_rv("DOCCUR")))
                End If
                If p_fej_row("U_CurrCode").ToString() = m_sajat_currcode Then
                    l_arfolyambank = 1
                Else
                    l_arfolyambank = DataProvider.ExecuteScalarDouble("select " + QueryResource.SQL_isnull("min(""Rate"")", "0") + " from ortt where ""RateDate"" = " + IFSZ_Globals.SQLConstantPrepare(l_rv("DOCDATE")) + " and ""Currency"" = " + IFSZ_Globals.SQLConstantPrepare(p_fej_row("U_CurrCode")))
                End If
                If l_arfolyaminv <= 0 Then
                    l_rv.Row("SUMAPPLIED") = 0
                    Continue For
                End If
                l_allpaidamount = Math.Round(l_amount / l_arfolyaminv, l_kerekites)
                If l_allpaidamount < CType(l_rv("INVAMOUNT"), Decimal) Then
                    l_invpaidamount = l_allpaidamount
                Else
                    l_invpaidamount = CType(l_rv("INVAMOUNT"), Decimal)
                End If
                l_invpaidmain = l_invpaidamount * l_arfolyaminv
                l_amount = l_amount - l_invpaidmain

                l_rv.Row("ALLPAIDAMOUNT") = l_allpaidamount
                l_rv.Row("INVPAIDAMOUNT") = l_invpaidamount
                l_rv.Row("SUMAPPLIED") = l_sumapplied
            End If
        Next

    End Function

    ''' <summary>
    ''' Megmondja a fizetés számkörét
    ''' </summary>
    ''' <param name="p_fej_row"></param>
    ''' <param name="p_tet_row"></param>
    ''' <returns></returns>
    Protected Overridable Function GetSeriesA(ByVal p_fej_row As DataRow, ByVal p_tet_row As DataRow) As Integer
        Dim l_Series As Integer
        If Not String.IsNullOrEmpty(p_tet_row.Item("U_ErtNap").ToString) Then
            If p_tet_row("Amount") > 0 Then
                If Not GetSeries(p_tet_row.Item("U_ErtNap"), "B", "SZAM", l_Series) Then
                    Return 0
                End If
            Else
                If Not GetSeries(p_tet_row.Item("U_ErtNap"), "K", "SZAM", l_Series) Then
                    Return 0
                End If
            End If
        End If
        Return l_Series
    End Function

    ''' <summary>
    ''' Létrehozza a fizetést, amennyiben főkönyvi típusú a sor
    ''' Visszaadja a létrehozott fizetés azonosítóját (string típussal, mert a GetNewObjectKey azt ad vissza
    ''' Ha ""-t adunk vissza, akkor hiba történt. A hiba a p_errcode és p_errmsg-be kerül
    ''' </summary>
    ''' <param name="p_fej_row"></param>
    ''' <param name="p_tet_row"></param>
    ''' <param name="p_errcode"></param>
    ''' <param name="p_errmsg"></param>
    ''' <returns></returns>
    Protected Overridable Function CreateFokonyviFizetes(ByVal p_fej_row As DataRow, ByVal p_tet_row As DataRow, ByRef p_errcode As String, ByRef p_errmsg As String) As String
        Dim l_Series As Integer = 0
        Dim l_payment As SAPbobsCOM.Payments
        Dim l_arfolyam As Decimal
        Dim l_fizcode As String

        If p_tet_row.Item("U_Amount") > 0 Then
            l_payment = m_ParentAddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oIncomingPayments)
        Else
            l_payment = m_ParentAddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oVendorPayments)
        End If

        l_arfolyam = GetTxnLineArfolyam(p_fej_row, p_tet_row)
        If l_arfolyam = 0 Then
            p_errcode = ""
            Return ""
        End If

        l_Series = GetSeriesA(p_fej_row, p_tet_row)
        If l_Series = 0 Then
            p_errcode = ""
            Return ""
        End If

        l_payment.GetByKey(-1)

        l_payment.ApplyVAT = SAPbobsCOM.BoYesNoEnum.tNO
        'l_payment.CardCode = m_ParentAddon.parameter_ertek("TECH_FOK")

        l_payment.CashSum = 0
        If l_Series > 0 Then
            l_payment.Series = l_Series
        End If
        l_payment.DocCurrency = p_tet_row.Item("fizetendo_pnm").ToString
        l_payment.DocDate = p_tet_row.Item("U_ErtNap").ToString
        l_payment.TaxDate = p_tet_row.Item("U_ErtNap").ToString
        l_payment.VatDate = p_tet_row.Item("U_ErtNap").ToString
        l_payment.DocRate = l_arfolyam
        l_payment.Reference2 = p_tet_row.Item("Code").ToString
        l_payment.CounterReference = p_tet_row.Item("Code").ToString
        l_payment.DocTypte = SAPbobsCOM.BoRcptTypes.rAccount
        l_payment.HandWritten = SAPbobsCOM.BoYesNoEnum.tNO
        'l_payment.JournalRemarks = "Incoming - D10004"
        'VenTable.LocalCurrency = SAPbobsCOM.BoYesNoEnum.tNO
        'VenTable.Reference1 = 8
        l_payment.Remarks = p_fej_row.Item("U_KntKod").ToString
        If Not String.IsNullOrEmpty(m_BranchID) Then l_payment.BPLID = m_BranchID

        l_payment.TaxDate = p_tet_row.Item("U_ErtNap").ToString
        l_payment.VatDate = p_tet_row.Item("U_ErtNap").ToString
        l_payment.TransferAccount = p_fej_row.Item("U_Account").ToString
        l_payment.TransferDate = p_tet_row.Item("U_ErtNap").ToString
        l_payment.TransferSum = Math.Abs(p_tet_row.Item("fizetendo_osszeg"))

        l_payment.AccountPayments.ProfitCenter = p_tet_row.Item("U_PrcCode").ToString
        l_payment.AccountPayments.ProfitCenter2 = p_tet_row.Item("U_OcrCode2").ToString
        l_payment.AccountPayments.ProfitCenter3 = p_tet_row.Item("U_OcrCode3").ToString
        l_payment.AccountPayments.ProfitCenter4 = p_tet_row.Item("U_OcrCode4").ToString
        l_payment.AccountPayments.ProfitCenter5 = p_tet_row.Item("U_OcrCode5").ToString
        l_payment.AccountPayments.ProjectCode = p_tet_row.Item("U_PrjCode").ToString

        l_payment.AccountPayments.AccountCode = p_tet_row.Item("U_Account").ToString()
        l_payment.AccountPayments.SumPaid = Math.Abs(p_tet_row.Item("fizetendo_osszeg"))
        'l_payment.AccountPayments.Add()

        If (l_payment.Add() <> 0) Then
            m_ParentAddon.SboCompany.GetLastError(p_errcode, p_errmsg)
            Return ""
        Else
            m_ParentAddon.SboCompany.GetNewObjectCode(l_fizcode)
            Return l_fizcode
        End If

    End Function

    ''' <summary>
    ''' Partneri fizetést hoz létre
    ''' Visszaadja a létrehozott fizetés azonosítóját (string típussal, mert a GetNewObjectKey azt ad vissza
    ''' Ha ""-t adunk vissza, akkor hiba történt. A hiba a p_errcode és p_errmsg-be kerül
    ''' </summary>
    ''' <param name="p_fej_row"></param>
    ''' <param name="p_tet_row"></param>
    ''' <param name="p_kiegytab"></param>
    ''' <param name="p_errcode"></param>
    ''' <param name="p_errmsg"></param>
    ''' <returns></returns>
    Protected Overridable Function CreatePartneriFizetes(ByVal p_fej_row As DataRow, ByVal p_tet_row As DataRow, ByVal p_kiegytab As DataTable, ByRef p_errcode As String, ByRef p_errmsg As String) As String
        Dim l_Series As Integer = 0
        Dim l_payment As SAPbobsCOM.Payments
        Dim l_arfolyam As Decimal
        Dim l_fizcode As String
        Dim l_kiegyview As DataView

        If p_tet_row.Item("U_Amount") > 0 Then
            l_payment = m_ParentAddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oIncomingPayments)
        Else
            l_payment = m_ParentAddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oVendorPayments)
        End If

        l_arfolyam = GetTxnLineArfolyam(p_fej_row, p_tet_row)
        If l_arfolyam = 0 Then
            p_errcode = ""
            Return ""
        End If

        l_Series = GetSeriesA(p_fej_row, p_tet_row)
        If l_Series = 0 Then
            p_errcode = ""
            Return ""
        End If

        l_kiegyview = New DataView(p_kiegytab, "", "SORREND", DataViewRowState.CurrentRows)

        l_payment.GetByKey(-1)

        l_payment.CardCode = l_kiegyview(0)("CARDCODE")
        If p_tet_row.Item("fizetendo_pnm").ToString <> p_fej_row.Item("U_CurrCode").ToString Then
            l_payment.TransferAccount = m_ParentAddon.parameter_ertek("TECH_FOK")
        Else
            l_payment.TransferAccount = p_fej_row.Item("U_Account").ToString
        End If

        l_payment.DocCurrency = p_tet_row.Item("fizetendo_pnm").ToString

        If Not String.IsNullOrEmpty(m_BranchID) Then l_payment.BPLID = m_BranchID
        l_payment.DocDate = p_tet_row.Item("U_ErtNap").ToString
        l_payment.VatDate = p_tet_row.Item("U_ErtNap").ToString
        l_payment.DocRate = l_arfolyam
        l_payment.Reference2 = p_tet_row.Item("Code").ToString
        l_payment.CounterReference = p_tet_row.Item("Code").ToString
        If p_tet_row.Item("U_Jelleg").ToString = "V" Then
            l_payment.DocTypte = SAPbobsCOM.BoRcptTypes.rCustomer
        Else
            l_payment.DocTypte = SAPbobsCOM.BoRcptTypes.rSupplier
        End If
        l_payment.Remarks = p_fej_row.Item("U_KntKod").ToString
        l_payment.HandWritten = SAPbobsCOM.BoYesNoEnum.tNO
        l_payment.TaxDate = p_tet_row.Item("U_ErtNap").ToString
        l_payment.VatDate = p_tet_row.Item("U_ErtNap").ToString
        l_payment.TransferSum = Math.Abs(p_tet_row.Item("fizetendo_osszeg"))

        For Each l_rv As DataRowView In l_kiegyview
            l_payment.Invoices.DocEntry = l_rv("DOCENTRY")
            l_payment.Invoices.InvoiceType = l_rv("OBJTYPE")
            l_payment.Invoices.SumApplied = l_rv("SUMAPPLIED")
        Next

        If (l_payment.Add() <> 0) Then
            m_ParentAddon.SboCompany.GetLastError(p_errcode, p_errmsg)
            Return ""
        Else
            m_ParentAddon.SboCompany.GetNewObjectCode(l_fizcode)
            Return l_fizcode
        End If

    End Function

End Class
