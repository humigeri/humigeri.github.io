﻿Public Class IFSZ_BankTxn_Feldolgozas
    Inherits IFSZ_BankTxn_FeldolgozasBase

    Sub New(ByRef p_hivo_form As IFSZ_BankTxn_Matrix, ByRef p_parentaddon As SBOAddOn)
        MyBase.New(p_hivo_form, p_parentaddon)
    End Sub

End Class
