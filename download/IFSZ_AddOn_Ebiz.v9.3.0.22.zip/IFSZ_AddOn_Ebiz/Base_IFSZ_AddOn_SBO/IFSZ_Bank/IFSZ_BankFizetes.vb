Imports SboAddOnBase
Imports IFSZ_AddOnBase
Public Class IFSZ_BankFizetes
    Inherits SboForm

    Public Sub New( _
        ByVal ParentAddOn As SBOAddOn, _
        ByRef oEredetiForm As IFSZ_BankTxn_Matrix, _
        ByVal FunctionCode As String, _
        ByVal FormUID As String, _
        ByVal l_BankTxn As String, _
        ByVal l_pnr_kod As String, _
        ByVal l_szamla_tipus As String, _
        ByVal l_pnm_kod As String, _
        ByVal l_konyvelesi_datum As DateTime, _
        ByVal l_osszeg As Double, _
        ByVal l_osszegFC As Double, _
        ByVal l_fokonyvi_szam As String, _
        ByVal l_fokonyvi_szamMGS As String, _
        ByVal l_osszegS As Double, _
        ByVal l_pnm_kodS As String, _
        ByVal l_PrcCode As String, _
        ByVal l_OcrCode2 As String, _
        ByVal l_OcrCode3 As String, _
        ByVal l_OcrCode4 As String, _
        ByVal l_OcrCode5 As String, _
        ByVal l_TxnCode As String, _
        ByVal l_code As String, _
        ByVal l_bizonylat_szam As String, _
        ByVal l_ado_kod As String, _
        ByVal l_megjegyzes As String, _
        ByVal l_arfolyam As Double, _
        ByVal l_PrjCode As String, _
        ByVal l_szamla_hiv As String, _
        ByVal l_jcmcode As String, _
        ByVal l_bankktg As Decimal, _
        Optional ByVal l_SeriesName As String = "" _
        )


        MyBase.New(ParentAddOn, enSboFormTypes.LogicOnly, enSAPFormTypes.IFSZ_Function_UDF, FunctionCode, FormUID)
        oForm_Eredeti = oEredetiForm
        'p_konyvelesi_datum = l_konyvelesi_datum.ToString(IFSZ_Globals_SBO.GetSystemDateFormat)
        p_konyvelesi_datum = IFSZ_Globals_SBO.KonvertDateToSBOString(l_konyvelesi_datum)
        p_osszeg = IFSZ_Globals_SBO.RoundMoney(l_osszeg, l_pnm_kod)
        p_osszegFC = l_osszegFC
        p_pnr_kod = l_pnr_kod
        p_szamla_tipus = l_szamla_tipus
        p_pnm_kod = l_pnm_kod
        p_fokonyvi_szam = l_fokonyvi_szam
        p_osszegS = l_osszegS
        p_pnm_kodS = l_pnm_kodS
        p_PrcCode = l_PrcCode
        p_OcrCode2 = l_OcrCode2
        p_OcrCode3 = l_OcrCode3
        p_OcrCode4 = l_OcrCode4
        p_OcrCode5 = l_OcrCode5
        p_PrjCode = l_PrjCode
        p_BankTxn = l_BankTxn
        p_fokonyvi_szamMGS = l_fokonyvi_szamMGS
        p_TxnCode = l_TxnCode
        p_code = l_code
        Me.p_ref2 = l_code
        p_bizonylat_szam = l_bizonylat_szam
        p_ado_kod = l_ado_kod
        p_megjegyzes = l_megjegyzes
        p_arfolyam = l_arfolyam
        Me.oForm_Eredeti.m_beirt_arfolyam = IFSZ_Globals_SBO.FormatRate(p_arfolyam)
        p_szamla_hiv = l_szamla_hiv
        p_JcmCode = l_jcmcode
        p_SeriesName = l_SeriesName
        Me.m_bankktg = l_bankktg
        m_tech_fok = Me.m_ParentAddon.parameter_ertek("TECH_FOK")

        Dim l_temp As String = Me.m_ParentAddon.parameter_ertek("KIFIZARF")        If Not String.IsNullOrEmpty(l_temp) AndAlso (l_temp.ToLower = "a" OrElse l_temp.ToLower = "�" OrElse l_temp.ToLower = "�tl" OrElse l_temp.ToLower = "atl" OrElse l_temp.ToLower = "�tlag" OrElse l_temp.ToLower = "atlag") Then            Me.m_kimeno_atlag_arfolyam = True
        End If
        l_temp = Me.m_ParentAddon.parameter_ertek("BNKMEGJPBIZ")        If String.IsNullOrEmpty(l_temp) OrElse l_temp.ToLower() = "n" Then            Me.m_comments_pbizbe = False
        Else
            Me.m_comments_pbizbe = True
        End If
    End Sub

    Private oForm_Eredeti As IFSZ_BankTxn_Matrix
    Private p_konyvelesi_datum As String
    Private p_pnr_kod, p_BankTxn, p_fokonyvS As String
    Private p_pnm_kod, l_tzo_kod, p_pnm_kodS, p_ref2 As String
    Private p_osszeg, p_osszegFC, p_osszegS, p_arfolyam As Double
    Private p_Seq As Integer
    Private p_szamla_tipus, p_szamla_hiv As String
    Private p_ModalFormUID, p_megjegyzes As String
    Private p_fokonyvi_szam, p_bizonylat_szam, p_ado_kod, p_SeriesName As String
    Private p_fokonyvi_szamMGS, p_JcmCode, p_series, l_sajat_pnm As String
    Private p_code, p_name, p_TxnCode, p_LineSts, p_PrcCode, p_PrjCode, p_OcrCode2, p_OcrCode3, p_OcrCode4, p_OcrCode5 As String
    Private p_DocNum As String
    Private p_irany As Integer
    Private p_elso As Boolean = True
    Private m_bankktg As Decimal
    Private m_tech_fok As String

    Private m_kimeno_atlag_arfolyam As Boolean = False    Public m_arfolyam_letiltando As Boolean = False    Private m_szamla_kijeloles As Int16 = 0
    Private m_comments_pbizbe As Boolean = False
    Public Overrides Sub HANDLE_FORM_EVENTS(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Static l_Event_Count As Integer = 1
        Dim newThread As Threading.Thread
        Dim oOption As SAPbouiCOM.OptionBtn
        Dim oMatrix As SAPbouiCOM.Matrix
        Dim oColumn As SAPbouiCOM.Column
        Dim oEditText As SAPbouiCOM.EditText

        If IFSZ_BankTxn_Matrix.KimenoFizetes = True Or IFSZ_BankTxn_Matrix.BejovoFizetes = True Then
            If pVal.FormType = 426 Or pVal.FormType = 170 Then

                'If (Not Me.p_ModalFormUID Is Nothing) Then
                '    Dim oForm As SboForm
                '    Dim oFormSBO As SAPbouiCOM.Form
                '    For Each oForm In Me.m_ParentAddon.SBOForms
                '        If oForm.UniqueID = Me.p_ModalFormUID Then
                '            oFormSBO = Me.m_ParentAddon.SboApplication.Forms.Item(oForm.UniqueID)
                '            oFormSBO.Select()
                '            If pVal.ItemUID = "1" Or pVal.ItemUID = "2" Then
                '                BubbleEvent = False
                '            End If
                '            Exit Sub
                '        End If
                '    Next
                '    Me.p_ModalFormUID = Nothing
                'End If

                If pVal.Before_Action = True And pVal.EventType = SAPbouiCOM.BoEventTypes.et_CLICK And pVal.ItemUID = "49" Then
                    BubbleEvent = False
                End If
                If pVal.EventType = SAPbouiCOM.BoEventTypes.et_FORM_LOAD Then
                    Dim oForm As SboForm
                    Dim oFormSBO As SAPbouiCOM.Form
                    Dim i As Integer
                    i = 1
                    'oForm = New IFSZ_Fizetesi_modok(Me.m_ParentAddon, "F_FSM", FormUID, Me.p_fokonyvi_szam, Me.p_osszeg, Me.p_pnm_kod)
                    'Me.m_ParentAddon.SBOForms.Add(oForm, oForm.UniqueID)
                    'Me.p_ModalFormUID = oForm.UniqueID
                End If
                If pVal.EventType = SAPbouiCOM.BoEventTypes.et_FORM_LOAD And l_Event_Count = 1 And pVal.Before_Action = False Then
                    Dim l_megjegyzes As String
                    Try
                        Me.m_SboForm.Select()
                        l_Event_Count += 1
                        'Me.m_SboForm.Items.Item("22").Enabled = False
                        If Me.p_szamla_tipus = "V" And pVal.FormType = 426 Then
                            oOption = Me.m_SboForm.Items.Item("56").Specific
                            oOption.Selected = True
                            Me.set_item_value("5", "", 0, p_pnr_kod)
                            Me.set_item_value("10", "", 0, Replace(p_konyvelesi_datum, " ", ""))
                            If Me.p_SeriesName <> "" Then
                                Me.set_item_value("87", "", 0, p_SeriesName)
                            End If
                            Me.m_SboForm.Items.Item("32").Click()
                            Me.m_SboForm.Items.Item("5").Enabled = False
                            Me.m_SboForm.Items.Item("56").Enabled = False
                            Me.m_SboForm.Items.Item("57").Enabled = False
                            Me.m_SboForm.Items.Item("58").Enabled = False
                            'Me.set_item_value("13", "", 0, p_osszeg)
                            'Me.m_SboForm.Items.Item("13").Enabled = False
                        ElseIf Me.p_szamla_tipus = "S" And pVal.FormType = 426 Then
                            oOption = Me.m_SboForm.Items.Item("57").Specific
                            oOption.Selected = True
                            Me.set_item_value("5", "", 0, p_pnr_kod)
                            Me.set_item_value("10", "", 0, Replace(p_konyvelesi_datum, " ", ""))
                            If Me.p_SeriesName <> "" Then
                                Me.set_item_value("87", "", 0, p_SeriesName)
                            End If

                            Me.m_SboForm.Items.Item("32").Click()
                            Me.m_SboForm.Items.Item("56").Enabled = False
                            Me.m_SboForm.Items.Item("57").Enabled = False
                            Me.m_SboForm.Items.Item("58").Enabled = False
                            Me.m_SboForm.Items.Item("5").Enabled = False
                            'Me.set_item_value("13", "", 0, p_osszeg)
                            'Me.m_SboForm.Items.Item("13").Enabled = False
                        ElseIf Me.p_szamla_tipus = "S" And pVal.FormType = 170 Then
                            oOption = Me.m_SboForm.Items.Item("57").Specific
                            oOption.Selected = True
                            Me.set_item_value("5", "", 0, p_pnr_kod)
                            Me.set_item_value("10", "", 0, Replace(p_konyvelesi_datum, " ", ""))
                            If Me.p_SeriesName <> "" Then
                                Me.set_item_value("87", "", 0, p_SeriesName)
                            End If

                            Me.m_SboForm.Items.Item("32").Click()
                            Me.m_SboForm.Items.Item("5").Enabled = False
                            Me.m_SboForm.Items.Item("56").Enabled = False
                            Me.m_SboForm.Items.Item("57").Enabled = False
                            Me.m_SboForm.Items.Item("58").Enabled = False
                            'Me.set_item_value("13", "", 0, p_osszeg)
                            'Me.m_SboForm.Items.Item("13").Enabled = False
                        ElseIf Me.p_szamla_tipus = "V" And pVal.FormType = 170 Then
                            oOption = Me.m_SboForm.Items.Item("56").Specific
                            oOption.Selected = True
                            Me.set_item_value("5", "", 0, p_pnr_kod)
                            Me.set_item_value("10", "", 0, Replace(p_konyvelesi_datum, " ", ""))
                            If Me.p_SeriesName <> "" Then
                                Me.set_item_value("87", "", 0, p_SeriesName)
                            End If

                            Me.m_SboForm.Items.Item("32").Click()
                            Me.m_SboForm.Items.Item("56").Enabled = False
                            Me.m_SboForm.Items.Item("57").Enabled = False
                            Me.m_SboForm.Items.Item("58").Enabled = False
                            Me.m_SboForm.Items.Item("5").Enabled = False
                            'Me.set_item_value("13", "", 0, p_osszeg)
                            'Me.m_SboForm.Items.Item("13").Enabled = False
                        ElseIf Me.p_szamla_tipus = "F" Then
                            Dim oRecordSet As SAPbobsCOM.Recordset
                            Dim oRecordSet2 As SAPbobsCOM.Recordset
                            Dim p_select, p_select2, l_penznem As String
                            Dim l_rate As Double
                            Try
                                oRecordSet = Me.SBO_Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                                oRecordSet2 = Me.SBO_Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                                p_select = QueryResource.GetQuery("Base_IFSZ_AddOn_SBO", "sel_rate_from_ovtg_by_code", Me.p_ado_kod)
                                p_select2 = QueryResource.GetQuery("Base_IFSZ_AddOn_SBO", "sel_actcurr_from_oact_by_acctcode", Me.p_fokonyvi_szamMGS)
                                oRecordSet2.DoQuery(p_select2)
                                oRecordSet2.MoveFirst()
                                l_penznem = oRecordSet2.Fields.Item(0).Value

                                oRecordSet.DoQuery(p_select)
                                oRecordSet.MoveFirst()

                                oOption = Me.m_SboForm.Items.Item("58").Specific
                                oOption.Selected = True
                                Me.m_SboForm.Items.Item("56").Enabled = False
                                Me.m_SboForm.Items.Item("57").Enabled = False
                                Me.m_SboForm.Items.Item("58").Enabled = False
                                Me.m_SboForm.Items.Item("5").Enabled = False
                                'If IFSZ_BankTxn_Matrix.BejovoFizetes = True And Me.p_osszegS > 0 And Me.p_pnm_kodS <> "" Then
                                '    Me.set_item_value("74", "", 0, Me.p_pnm_kodS)
                                '    'Else
                                '    '    Me.set_item_value("74", "", 0, Me.p_pnm_kod)
                                'End If

                                'If IFSZ_BankTxn_Matrix.BejovoFizetes = True And Me.p_pnm_kod <> "Ft" Then
                                If Me.p_pnm_kod <> IFSZ_Globals_SBO.MainCurrency Then
                                    Me.set_item_value("74", "", 0, Me.p_pnm_kod)
                                End If
                                Me.set_item_value("71", "8", 1, Me.p_fokonyvi_szamMGS)
                                Me.set_item_value("71", "4", 1, Me.p_ado_kod)
                                Me.set_item_value("71", "3", 1, Me.p_megjegyzes)
                                'Me.p_megjegyzes = oRecordSet.Fields.Item(0).Value

                                'If IFSZ_BankTxn_Matrix.BejovoFizetes = True And Me.p_pnm_kod <> "Ft" Then
                                '    Me.set_item_value("71", "5", 1, (Me.p_osszeg / (1 + (oRecordSet.Fields.Item(0).Value / 100))))
                                'ElseIf IFSZ_BankTxn_Matrix.BejovoFizetes = False And Me.p_pnm_kod <> "Ft" And l_penznem = Me.p_pnm_kod Then
                                '    Me.set_item_value("71", "5", 1, Me.p_osszeg)
                                'Else
                                '    Me.set_item_value("71", "5", 1, (Me.p_osszeg / (1 + (oRecordSet.Fields.Item(0).Value / 100))) * Me.p_arfolyam)
                                'End If

                                If Me.p_arfolyam = 1 Then
                                    Me.set_item_value("71", "5", 1, IFSZ_Globals_SBO.FormatPrice((Me.p_osszeg / (1 + (oRecordSet.Fields.Item(0).Value / 100))) * Me.p_arfolyam, ""))
                                Else
                                    If pVal.FormType = 426 Then
                                        'Me.set_item_value("71", "5", 1, (Me.p_osszeg / (1 + (oRecordSet.Fields.Item(0).Value / 100))) * Me.p_arfolyam)
                                        Me.set_item_value("71", "10000024", 1, IFSZ_Globals_SBO.FormatPrice(Me.p_osszeg / (1 + (oRecordSet.Fields.Item(0).Value / 100)), ""))
                                    Else
                                        'Me.set_item_value("71", "5", 1, (Me.p_osszeg / (1 + (oRecordSet.Fields.Item(0).Value / 100))))
                                        Me.set_item_value("71", "10000024", 1, IFSZ_Globals_SBO.FormatPrice(Me.p_osszeg / (1 + (oRecordSet.Fields.Item(0).Value / 100)), ""))
                                    End If
                                End If

                                Try
                                    If Not String.IsNullOrEmpty(Me.p_PrcCode) Then Me.set_item_value("71", "10000012", 1, Me.p_PrcCode)
                                Catch ex As Exception

                                End Try
                                Try
                                    If Not String.IsNullOrEmpty(Me.p_OcrCode2) Then Me.set_item_value("71", "10000036", 1, Me.p_OcrCode2)
                                Catch ex As Exception

                                End Try
                                Try
                                    If Not String.IsNullOrEmpty(Me.p_OcrCode3) Then Me.set_item_value("71", "10000038", 1, Me.p_OcrCode3)
                                Catch ex As Exception

                                End Try
                                Try
                                    If Not String.IsNullOrEmpty(Me.p_OcrCode4) Then Me.set_item_value("71", "10000040", 1, Me.p_OcrCode4)
                                Catch ex As Exception

                                End Try
                                Try
                                    If Not String.IsNullOrEmpty(Me.p_OcrCode5) Then Me.set_item_value("71", "10000042", 1, Me.p_OcrCode5)
                                Catch ex As Exception

                                End Try

                                oMatrix = Me.m_SboForm.Items.Item("71").Specific()
                                oMatrix.Columns.Item("3").Cells.Item(1).Click()
                                'oMatrix.Columns.Item("8").Editable = False
                                'oMatrix.Columns.Item("2").Editable = False
                                'Me.m_SboForm.Items.Item("74").Enabled = False
                            Finally
                                If (Not oRecordSet Is Nothing) Then
                                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRecordSet)
                                    oRecordSet = Nothing
                                End If
                            End Try
                        End If
                        Me.set_item_value("22", "", 0, p_ref2)
                        Me.set_item_value("10", "", 0, Replace(p_konyvelesi_datum, " ", "")) 'TODO
                        Me.set_item_value("1001", "", 0, Replace(p_konyvelesi_datum, " ", ""))
                        Me.l_tzo_kod = Me.m_ParentAddon.parameter_ertek("TZO_KOD")
                        If Me.l_tzo_kod <> "" Then
                            Me.set_item_value("1002", "", 0, Me.l_tzo_kod)
                        End If
                        'Me.set_item_value("13", "", 0, p_osszeg)
                        If Me.p_osszegS > 0 And Me.p_pnm_kodS <> "" Then
                            l_megjegyzes = "Banki trz. �sszege: " & p_osszegS.ToString & " Kivonatsz�m : " & Me.p_bizonylat_szam
                        Else
                            l_megjegyzes = "Banki trz. �sszege: " & p_osszeg.ToString & " Kivonatsz�m : " & Me.p_bizonylat_szam
                        End If
                        If Me.m_comments_pbizbe Then
                            Me.set_item_value("26", "", 0, p_megjegyzes)
                        Else
                            Me.set_item_value("26", "", 0, l_megjegyzes)
                        End If
                        'If Me.p_szamla_tipus <> "F" And Me.p_szamla_hiv <> "" Then
                        '    Dim i As Integer
                        '    oMatrix = Me.m_SboForm.Items.Item("20").Specific
                        '    For i = 1 To oMatrix.RowCount
                        '        If Me.get_item_value("20", "1", i) = Me.p_szamla_hiv Then
                        '            oMatrix.Columns.Item("10000127").Cells.Item(i).Click()
                        '            If Me.p_osszegS > 0 And Me.p_pnm_kodS <> "" Then
                        '                Me.set_item_value("20", 24, i, Me.p_osszegS)
                        '            Else
                        '                Me.set_item_value("20", 24, i, Me.p_osszeg)
                        '            End If
                        '            Exit For
                        '        End If
                        '    Next
                        'End If

                        Dim oRecordSet_pnr As SAPbobsCOM.Recordset
                        Dim p_select_pnr, l_penznem_pnr As String

                        Try
                            oRecordSet_pnr = Me.SBO_Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                            p_select_pnr = "select ""Currency"" from OCRD where ""CardCode"" = '" & Me.p_pnr_kod & "'"

                            oRecordSet_pnr.DoQuery(p_select_pnr)
                            oRecordSet_pnr.MoveFirst()
                            l_penznem_pnr = oRecordSet_pnr.Fields.Item(0).Value


                            If Me.p_pnm_kod <> IFSZ_Globals_SBO.MainCurrency Then
                                If pVal.FormType <> "170" AndAlso Me.m_kimeno_atlag_arfolyam = True Then
                                    Me.m_arfolyam_letiltando = True
                                End If
                                If l_penznem_pnr <> "##" Then
                                    If Me.p_szamla_tipus = "V" Then
                                        If Me.m_SboForm.Items.Item("21").Visible = True Then
                                            Me.set_item_value("21", "", 0, IFSZ_Globals_SBO.FormatRate(Me.p_arfolyam))
                                            Me.m_SboForm.Items.Item("121").Click()
                                            Me.m_SboForm.Items.Item("21").Enabled = (pVal.FormType = "170" OrElse Me.m_kimeno_atlag_arfolyam = False)
                                        End If
                                    ElseIf Me.p_szamla_tipus = "S" Then
                                        If Me.m_SboForm.Items.Item("21").Visible = True Then
                                            Me.set_item_value("21", "", 0, IFSZ_Globals_SBO.FormatRate(Me.p_arfolyam))
                                            Me.m_SboForm.Items.Item("121").Click()
                                            Me.m_SboForm.Items.Item("21").Enabled = (pVal.FormType = "170" OrElse Me.m_kimeno_atlag_arfolyam = False)
                                        End If
                                    Else
                                        If Me.m_SboForm.Items.Item("72").Visible = True Then
                                            Me.set_item_value("72", "", 0, IFSZ_Globals_SBO.FormatRate(Me.p_arfolyam))
                                            Me.m_SboForm.Items.Item("121").Click()
                                            Me.m_SboForm.Items.Item("72").Enabled = (pVal.FormType = "170" OrElse Me.m_kimeno_atlag_arfolyam = False)
                                            Me.m_SboForm.Items.Item("74").Enabled = (pVal.FormType = "170" OrElse Me.m_kimeno_atlag_arfolyam = False)
                                        End If
                                    End If
                                    Me.oForm_Eredeti.m_beirt_arfolyam = IFSZ_Globals_SBO.FormatRate(Me.p_arfolyam)
                                End If
                            End If
                            'Me.m_SboForm.Items.Item("13").Enabled = False
                            Me.m_SboForm.Items.Item("10").Enabled = False
                            Me.m_SboForm.Items.Item("22").Enabled = False

                            If (p_szamla_tipus = "S" And pVal.FormType = 170) Then
                                'Me.set_item_value("13", "", 0, Me.p_osszeg)
                                If l_penznem_pnr = "##" Then
                                    Me.set_item_value("13", "", 0, Math.Round(Me.p_osszegFC))
                                Else
                                    Me.set_item_value("13", "", 0, Me.p_osszeg)
                                End If
                            ElseIf (p_szamla_tipus = "V" And pVal.FormType = 426) Then
                                If l_penznem_pnr = "##" Then
                                    Me.set_item_value("13", "", 0, Math.Round(Me.p_osszegFC))
                                Else
                                    Me.set_item_value("13", "", 0, Me.p_osszeg)
                                End If
                            End If
                        Catch ex As Exception

                        Finally
                            If (Not oRecordSet_pnr Is Nothing) Then
                                System.Runtime.InteropServices.Marshal.ReleaseComObject(oRecordSet_pnr)
                                oRecordSet_pnr = Nothing
                            End If

                        End Try
                        'm_SboForm.EnableMenu("5892", False)
                        'Me.m_ParentAddon.SboApplication.ActivateMenuItem(enSAPMenuUIDs.KimenoSzamla)
                        If pVal.Before_Action = False Then
                            'Me.m_ParentAddon.SboApplication.ActivateMenuItem(5892)
                        End If
                    Catch ex As Exception
                        m_ParentAddon.SboApplication.MessageBox(ex.ToString)
                    End Try

                ElseIf pVal.EventType = SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE And pVal.Before_Action = False And l_Event_Count = 1 Then
                    l_Event_Count += 1

                ElseIf pVal.EventType = SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE And pVal.Before_Action = False And Me.m_szamla_kijeloles = 1 Then
                    Me.m_szamla_kijeloles = 2
                    If Me.p_szamla_tipus <> "F" And Me.p_szamla_hiv <> "" Then
                        Dim i As Integer
                        oMatrix = Me.m_SboForm.Items.Item("20").Specific
                        For i = 1 To oMatrix.RowCount
                            If Me.get_item_value("20", "1", i) = Me.p_szamla_hiv Then
                                oMatrix.Columns.Item("10000127").Cells.Item(i).Click()
                                If Me.p_osszegS > 0 And Me.p_pnm_kodS <> "" Then
                                    Me.set_item_value("20", 24, i, Me.p_osszegS)
                                Else
                                    Me.set_item_value("20", 24, i, Me.p_osszeg)
                                End If
                                Exit For
                            End If
                        Next
                    End If

                End If

            End If
            If pVal.EventType = SAPbouiCOM.BoEventTypes.et_FORM_LOAD Then
                Dim oForm As SboForm
                Dim oFormSBO As SAPbouiCOM.Form
                Dim i As Integer
                i = 1
                'oForm = New IFSZ_Fizetesi_modok(Me.m_ParentAddon, "F_FSM", FormUID, Me.p_fokonyvi_szam, Me.p_osszeg, Me.p_pnm_kod)
                'Me.m_ParentAddon.SBOForms.Add(oForm, oForm.UniqueID)
                'Me.p_ModalFormUID = oForm.UniqueID
            End If


            If pVal.Before_Action = False Then
                Select Case pVal.EventType
                    Case SAPbouiCOM.BoEventTypes.et_CLICK
                        If pVal.ItemUID = "1" Then
                            Dim oRcdSet As SAPbobsCOM.Recordset
                            Dim oCurrRate As SAPbobsCOM.SBObob
                            Dim oCheckBox As SAPbouiCOM.CheckBox
                            Dim l_ossz As Double
                            Dim l_osszIP As Double
                            Dim l_osszSP As Double
                            Dim l_pr, l_rate, l_rateS As String
                            Dim l_oszto As Double = 1

                            Try

                                oRcdSet = Me.SBO_Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                                oCurrRate = Me.m_ParentAddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoBridge)
                                oRcdSet = oCurrRate.GetLocalCurrency

                                If Me.m_SboForm.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE Then
                                    Exit Sub
                                End If
                                oCheckBox = Me.m_SboForm.Items.Item("37").Specific
                                oMatrix = Me.m_SboForm.Items.Item("20").Specific
                                If oCheckBox.Checked = False Then
                                    If (oMatrix.GetNextSelectedRow = -1 And p_szamla_tipus = "V" And pVal.FormType = 170) Or (oMatrix.GetNextSelectedRow = -1 And p_szamla_tipus = "S" And pVal.FormType = 426) Then
                                        m_ParentAddon.SboApplication.MessageBox("Nincs kiv�lsztva sz�mla!")
                                        BubbleEvent = False
                                        Exit Sub
                                    End If
                                End If

                                If Me.p_pnm_kodS <> "" And Me.p_osszegS > 0 Then
                                    oCurrRate = Me.m_ParentAddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoBridge)
                                    oRcdSet = oCurrRate.GetLocalCurrency
                                    l_sajat_pnm = oRcdSet.Fields.Item(0).Value
                                    If Me.p_pnm_kod <> l_sajat_pnm Then
                                        oRcdSet = oCurrRate.GetCurrencyRate(Me.p_pnm_kod, Date.Parse(Me.p_konyvelesi_datum))
                                        l_rate = oRcdSet.Fields.Item(0).Value
                                    Else
                                        l_rate = 1
                                    End If
                                    If Me.p_pnm_kodS <> l_sajat_pnm Then
                                        oRcdSet = oCurrRate.GetCurrencyRate(Me.p_pnm_kodS, Date.Parse(Me.p_konyvelesi_datum))
                                        l_rateS = oRcdSet.Fields.Item(0).Value
                                    Else
                                        l_rateS = 1
                                    End If
                                    'm_ParentAddOn.SboApplication.MessageBox(Me.p_osszeg * l_rate & " " & Me.p_pnm_kod & "; " & Me.p_osszegS * l_rateS & " " & Me.p_pnm_kodS & "; ")
                                End If

                                Me.p_series = Me.get_item_value("87", "", 0)
                                If pVal.FormType = 170 Then
                                    If Me.p_szamla_tipus = "V" Then
                                        l_pr = Me.get_item_value("12", "", 0)
                                        If l_pr = "" Then
                                            m_ParentAddon.SboApplication.MessageBox("Adja meg a sz�ks�ges �rt�ket")
                                            Exit Sub
                                        End If

                                        'l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))
                                        'l_ossz = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))
                                        'l_pr = Me.get_item_value("44", "", 0)
                                        'l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))
                                        If IsNumeric(l_pr.Substring(0, 1)) = False Then
                                            'If l_pr.IndexOf(" ") = -1 Then
                                            '    l_pr = "0"
                                            'Else
                                            '    l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))
                                            'End If
                                            'l_ossz = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))
                                            l_ossz = IFSZ_Globals_SBO.KonvertSBOSzam(l_pr)
                                            l_pr = Me.get_item_value("44", "", 0)
                                            If l_pr.StartsWith("**") Then   't�bb p�nznem
                                                l_pr = Me.get_item_value("45", "", 0)
                                            End If
                                            'If l_pr.IndexOf(" ") = -1 Then
                                            '    l_pr = "0"
                                            'Else
                                            '    l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))
                                            'End If
                                        Else
                                            'If l_pr.IndexOf(" ") = -1 Then
                                            '    l_pr = "0"
                                            'Else
                                            '    l_pr = l_pr.Remove(l_pr.IndexOf(" "), (l_pr.Length - l_pr.IndexOf(" ")))
                                            'End If
                                            'l_ossz = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))
                                            l_ossz = IFSZ_Globals_SBO.KonvertSBOSzam(l_pr)
                                            l_pr = Me.get_item_value("44", "", 0)
                                            If l_pr.StartsWith("**") Then   't�bb p�nznem
                                                l_pr = Me.get_item_value("45", "", 0)
                                                l_oszto = Me.p_arfolyam
                                            End If
                                            If l_pr.ToString = "" Then
                                                l_pr = 0
                                            Else
                                                'If l_pr.IndexOf(" ") = -1 Then
                                                '    l_pr = "0"
                                                'Else
                                                '    l_pr = l_pr.Remove(l_pr.IndexOf(" "), (l_pr.Length - l_pr.IndexOf(" ")))
                                                'End If
                                            End If
                                        End If
                                        l_osszIP = IFSZ_Globals_SBO.KonvertSBOSzam(l_pr) / l_oszto
                                        'l_osszSP = CDbl(Replace(Me.get_item_value("45", "", 0), oForm_Eredeti.p_EzresEvt, ""))
                                        If l_osszIP = 0 Then
                                            l_osszIP = l_ossz
                                        End If
                                        If Me.p_osszegS > 0 And Me.p_pnm_kodS <> "" Then
                                            If l_osszIP - Me.m_bankktg <> p_osszegS Then
                                                m_ParentAddon.SboApplication.MessageBox(m_ParentAddon.LocRM.GetString("ifsz-15011"))
                                                BubbleEvent = False
                                                Exit Sub
                                            End If
                                        Else
                                            If l_osszIP - Me.m_bankktg <> p_osszeg Then
                                                m_ParentAddon.SboApplication.MessageBox(m_ParentAddon.LocRM.GetString("ifsz-15011"))
                                                BubbleEvent = False
                                                Exit Sub
                                            End If
                                        End If

                                    ElseIf Me.p_szamla_tipus = "S" Then
                                        l_pr = Me.get_item_value("12", "", 0)
                                        If l_pr = "" Then
                                            m_ParentAddon.SboApplication.MessageBox("Adja meg a sz�ks�ges �rt�ket")
                                            Exit Sub
                                        End If

                                        'l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))
                                        'l_ossz = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))
                                        'l_pr = Me.get_item_value("44", "", 0)
                                        'l_pr = l_pr.Remove(1, l_pr.IndexOf(" "))
                                        If IsNumeric(l_pr.Substring(0, 1)) = False Then
                                            'If l_pr.IndexOf(" ") = -1 Then
                                            '    l_pr = "0"
                                            'Else
                                            '    l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))
                                            'End If
                                            'l_ossz = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))
                                            l_ossz = IFSZ_Globals_SBO.KonvertSBOSzam(l_pr)
                                            l_pr = Me.get_item_value("44", "", 0)
                                            If l_pr <> "" Then
                                                'If l_pr.IndexOf(" ") = -1 Then
                                                '    l_pr = "0"
                                                'Else
                                                '    l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))
                                                'End If
                                            Else
                                                l_pr = 0
                                            End If
                                        Else
                                            'If l_pr.IndexOf(" ") = -1 Then
                                            '    l_pr = "0"
                                            'Else
                                            '    l_pr = l_pr.Remove(l_pr.IndexOf(" "), (l_pr.Length - l_pr.IndexOf(" ")))
                                            'End If
                                            'l_ossz = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))
                                            l_ossz = IFSZ_Globals_SBO.KonvertSBOSzam(l_pr)
                                            l_pr = Me.get_item_value("44", "", 0)
                                            If l_pr.StartsWith("**") Then   't�bb p�nznem
                                                l_pr = Me.get_item_value("45", "", 0)
                                                l_oszto = Me.p_arfolyam
                                            End If
                                            If l_pr <> "" Then
                                                'If l_pr.IndexOf(" ") = -1 Then
                                                '    l_pr = "0"
                                                'Else
                                                '    l_pr = l_pr.Remove(l_pr.IndexOf(" "), (l_pr.Length - l_pr.IndexOf(" ")))
                                                'End If
                                            Else
                                                l_pr = 0
                                            End If
                                        End If
                                        l_osszIP = IFSZ_Globals_SBO.KonvertSBOSzam(l_pr) / l_oszto
                                        'l_osszSP = CDbl(Replace(Me.get_item_value("45", "", 0), oForm_Eredeti.p_EzresEvt, ""))
                                        If l_osszIP = 0 Then
                                            l_osszIP = l_ossz
                                        End If
                                        If Me.p_osszegS > 0 And Me.p_pnm_kodS <> "" Then
                                            If l_osszIP - Me.m_bankktg <> p_osszegS Then
                                                m_ParentAddon.SboApplication.MessageBox(m_ParentAddon.LocRM.GetString("ifsz-15011"))
                                                BubbleEvent = False
                                                Exit Sub
                                            End If
                                        Else
                                            If Me.p_pnm_kod <> "Ft" Then
                                                If l_osszIP - Me.m_bankktg <> p_osszeg Then
                                                    m_ParentAddon.SboApplication.MessageBox(m_ParentAddon.LocRM.GetString("ifsz-15011"))
                                                    BubbleEvent = False
                                                    Exit Sub
                                                End If
                                            Else
                                                If l_osszIP - Me.m_bankktg <> Math.Round(p_osszeg) Then
                                                    m_ParentAddon.SboApplication.MessageBox(m_ParentAddon.LocRM.GetString("ifsz-15011"))
                                                    BubbleEvent = False
                                                    Exit Sub
                                                End If
                                            End If
                                        End If

                                    ElseIf Me.p_szamla_tipus = "F" Then
                                        l_pr = Me.get_item_value("77", "", 0)
                                        'l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))
                                        'l_ossz = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))
                                        'l_pr = Me.get_item_value("82", "", 0)
                                        'l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))
                                        If IsNumeric(l_pr.Substring(0, 1)) = False Then
                                            'If l_pr.IndexOf(" ") = -1 Then
                                            '    l_pr = "0"
                                            'Else
                                            '    l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))
                                            'End If
                                            'l_ossz = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))
                                            l_ossz = IFSZ_Globals_SBO.KonvertSBOSzam(l_pr)
                                            l_pr = Me.get_item_value("82", "", 0)
                                            'If l_pr.IndexOf(" ") = -1 Then
                                            '    l_pr = "0"
                                            'Else
                                            '    l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))
                                            'End If
                                        Else
                                            'If l_pr.IndexOf(" ") = -1 Then
                                            '    l_pr = "0"
                                            'Else
                                            '    l_pr = l_pr.Remove(l_pr.IndexOf(" "), (l_pr.Length - l_pr.IndexOf(" ")))
                                            'End If
                                            'l_ossz = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))
                                            l_ossz = IFSZ_Globals_SBO.KonvertSBOSzam(l_pr)
                                            l_pr = Me.get_item_value("82", "", 0)
                                            'If l_pr.IndexOf(" ") = -1 Then
                                            '    l_pr = "0"
                                            'Else
                                            '    l_pr = l_pr.Remove(l_pr.IndexOf(" "), (l_pr.Length - l_pr.IndexOf(" ")))
                                            'End If
                                        End If
                                        l_osszIP = IFSZ_Globals_SBO.KonvertSBOSzam(l_pr)
                                        'l_osszIP = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))
                                        'l_osszSP = CDbl(Replace(Me.get_item_value("83", "", 0), oForm_Eredeti.p_EzresEvt, ""))
                                        If Me.p_pnm_kod <> oRcdSet.Fields.Item(0).Value Then
                                            l_ossz = l_osszIP
                                        Else
                                            l_osszIP = l_ossz
                                        End If
                                        If Me.p_pnm_kod <> "Ft" Then
                                            If l_osszIP - Me.m_bankktg <> p_osszeg Then
                                                m_ParentAddon.SboApplication.MessageBox(m_ParentAddon.LocRM.GetString("ifsz-15011"))
                                                BubbleEvent = False
                                                Exit Sub
                                            End If
                                        Else
                                            If l_osszIP - Me.m_bankktg <> Math.Round(p_osszeg) Then
                                                m_ParentAddon.SboApplication.MessageBox(m_ParentAddon.LocRM.GetString("ifsz-15011"))
                                                BubbleEvent = False
                                                Exit Sub
                                            End If
                                        End If

                                    End If
                                Else
                                    If Me.p_szamla_tipus = "V" Then
                                        l_pr = Me.get_item_value("12", "", 0)
                                        'l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))
                                        'l_ossz = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))
                                        'l_pr = Me.get_item_value("44", "", 0)
                                        'l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))
                                        If IsNumeric(l_pr.Substring(0, 1)) = False Then
                                            'If l_pr.IndexOf(" ") = -1 Then
                                            '    l_pr = "0"
                                            'Else
                                            '    l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))
                                            'End If
                                            'l_ossz = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))
                                            l_ossz = IFSZ_Globals_SBO.KonvertSBOSzam(l_pr)
                                            l_pr = Me.get_item_value("44", "", 0)
                                            'If l_pr <> "" Then
                                            '    If l_pr.IndexOf(" ") = -1 Then
                                            '        l_pr = "0"
                                            '    Else
                                            '        l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))
                                            '    End If
                                            'Else
                                            '    l_pr = 0
                                            'End If
                                        Else
                                            'If l_pr.IndexOf(" ") = -1 Then
                                            '    l_pr = "0"
                                            'Else
                                            '    l_pr = l_pr.Remove(l_pr.IndexOf(" "), (l_pr.Length - l_pr.IndexOf(" ")))
                                            'End If
                                            'l_ossz = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))
                                            l_ossz = IFSZ_Globals_SBO.KonvertSBOSzam(l_pr)
                                            l_pr = Me.get_item_value("44", "", 0)
                                            If l_pr.StartsWith("**") Then   't�bb p�nznem
                                                l_pr = Me.get_item_value("45", "", 0)
                                                l_oszto = Me.p_arfolyam
                                            End If
                                            'If l_pr <> "" Then
                                            '    If l_pr.IndexOf(" ") = -1 Then
                                            '        l_pr = "0"
                                            '    Else
                                            '        l_pr = l_pr.Remove(l_pr.IndexOf(" "), (l_pr.Length - l_pr.IndexOf(" ")))
                                            '    End If
                                            'Else
                                            '    l_pr = 0
                                            'End If
                                        End If
                                        l_osszIP = IFSZ_Globals_SBO.KonvertSBOSzam(l_pr) / l_oszto
                                        'l_osszIP = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, "")) / l_oszto
                                        'l_osszSP = CDbl(Replace(Me.get_item_value("45", "", 0), oForm_Eredeti.p_EzresEvt, ""))
                                        If l_osszIP = 0 Then
                                            l_osszIP = l_ossz
                                        End If
                                        If Me.p_osszegS > 0 And Me.p_pnm_kodS <> "" Then
                                            If l_osszIP - Me.m_bankktg <> p_osszegS Then
                                                m_ParentAddon.SboApplication.MessageBox(m_ParentAddon.LocRM.GetString("ifsz-15011"))
                                                BubbleEvent = False
                                                Exit Sub
                                            End If
                                        Else
                                            If Me.p_pnm_kod <> "Ft" Then
                                                If l_osszIP - Me.m_bankktg <> p_osszeg Then
                                                    m_ParentAddon.SboApplication.MessageBox(m_ParentAddon.LocRM.GetString("ifsz-15011"))
                                                    BubbleEvent = False
                                                    Exit Sub
                                                End If
                                            Else
                                                If l_osszIP - Me.m_bankktg <> Math.Round(p_osszeg) Then
                                                    m_ParentAddon.SboApplication.MessageBox(m_ParentAddon.LocRM.GetString("ifsz-15011"))
                                                    BubbleEvent = False
                                                    Exit Sub
                                                End If
                                            End If
                                        End If

                                    ElseIf Me.p_szamla_tipus = "S" Then
                                        l_pr = Me.get_item_value("12", "", 0)
                                        'l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))
                                        'l_ossz = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))
                                        'l_pr = Me.get_item_value("44", "", 0)
                                        'l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))
                                        If IsNumeric(l_pr.Substring(0, 1)) = False Then
                                            'If l_pr.IndexOf(" ") = -1 Then
                                            '    l_pr = "0"
                                            'Else
                                            '    l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))
                                            'End If
                                            'l_ossz = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))
                                            l_ossz = IFSZ_Globals_SBO.KonvertSBOSzam(l_pr)
                                            l_pr = Me.get_item_value("44", "", 0)
                                            'If l_pr.IndexOf(" ") = -1 Then
                                            '    l_pr = "0"
                                            'Else
                                            '    l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))
                                            'End If
                                        Else
                                            'If l_pr.IndexOf(" ") = -1 Then
                                            '    l_pr = "0"
                                            'Else
                                            '    l_pr = l_pr.Remove(l_pr.IndexOf(" "), (l_pr.Length - l_pr.IndexOf(" ")))
                                            'End If
                                            'l_ossz = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))
                                            l_ossz = IFSZ_Globals_SBO.KonvertSBOSzam(l_pr)
                                            l_pr = Me.get_item_value("44", "", 0)
                                            If l_pr.StartsWith("**") Then   't�bb p�nznem
                                                l_pr = Me.get_item_value("45", "", 0)
                                                l_oszto = Me.p_arfolyam
                                            End If
                                            'If l_pr <> "" Then
                                            '    If l_pr.IndexOf(" ") = -1 Then
                                            '        l_pr = "0"
                                            '    Else
                                            '        l_pr = l_pr.Remove(l_pr.IndexOf(" "), (l_pr.Length - l_pr.IndexOf(" ")))
                                            '    End If
                                            'Else
                                            '    l_pr = 0
                                            'End If
                                        End If
                                        l_osszIP = IFSZ_Globals_SBO.KonvertSBOSzam(l_pr) / l_oszto
                                        'l_osszIP = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, "")) / l_oszto
                                        'l_osszSP = CDbl(Replace(Me.get_item_value("45", "", 0), oForm_Eredeti.p_EzresEvt, ""))
                                        If l_osszIP = 0 Then
                                            l_osszIP = l_ossz
                                        End If
                                        If Me.p_osszegS > 0 And Me.p_pnm_kodS <> "" Then
                                            If l_osszIP - Me.m_bankktg <> p_osszegS Then
                                                m_ParentAddon.SboApplication.MessageBox(m_ParentAddon.LocRM.GetString("ifsz-15011"))
                                                BubbleEvent = False
                                                Exit Sub
                                            End If
                                        Else
                                            If Me.p_pnm_kod <> "Ft" Then
                                                If l_osszIP - Me.m_bankktg <> p_osszeg Then
                                                    m_ParentAddon.SboApplication.MessageBox(m_ParentAddon.LocRM.GetString("ifsz-15011"))
                                                    BubbleEvent = False
                                                    Exit Sub
                                                End If
                                            Else
                                                If l_osszIP - Me.m_bankktg <> Math.Round(p_osszeg) Then
                                                    m_ParentAddon.SboApplication.MessageBox(m_ParentAddon.LocRM.GetString("ifsz-15011"))
                                                    BubbleEvent = False
                                                    Exit Sub
                                                End If
                                            End If
                                        End If
                                    ElseIf Me.p_szamla_tipus = "F" Then
                                        l_pr = Me.get_item_value("77", "", 0)
                                        If IsNumeric(l_pr.Substring(0, 1)) = False Then
                                            'If l_pr.IndexOf(" ") = -1 Then
                                            '    l_pr = "0"
                                            'Else
                                            '    l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))
                                            'End If
                                            'l_ossz = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))
                                            l_ossz = IFSZ_Globals_SBO.KonvertSBOSzam(l_pr)
                                            l_pr = Me.get_item_value("82", "", 0)
                                            'If l_pr.IndexOf(" ") = -1 Then
                                            '    l_pr = "0"
                                            'Else
                                            '    l_pr = l_pr.Remove(0, l_pr.IndexOf(" "))
                                            'End If
                                        Else
                                            'If l_pr.IndexOf(" ") = -1 Then
                                            '    l_pr = "0"
                                            'Else
                                            '    l_pr = l_pr.Remove(l_pr.IndexOf(" "), (l_pr.Length - l_pr.IndexOf(" ")))
                                            'End If
                                            'l_ossz = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))
                                            l_ossz = IFSZ_Globals_SBO.KonvertSBOSzam(l_pr)
                                            l_pr = Me.get_item_value("82", "", 0)
                                            'If l_pr.IndexOf(" ") = -1 Then
                                            '    l_pr = "0"
                                            'Else
                                            '    l_pr = l_pr.Remove(l_pr.IndexOf(" "), (l_pr.Length - l_pr.IndexOf(" ")))
                                            'End If
                                        End If
                                        l_osszIP = IFSZ_Globals_SBO.KonvertSBOSzam(l_pr)
                                        'l_osszIP = CDbl(Replace(l_pr, oForm_Eredeti.p_EzresEvt, ""))
                                        'l_osszSP = CDbl(Replace(Me.get_item_value("83", "", 0), oForm_Eredeti.p_EzresEvt, ""))
                                        If l_osszIP = 0 Then
                                            l_osszIP = l_ossz
                                        End If
                                        If Me.p_pnm_kod <> "Ft" Then
                                            If l_osszIP - Me.m_bankktg <> p_osszeg Then
                                                m_ParentAddon.SboApplication.MessageBox(m_ParentAddon.LocRM.GetString("ifsz-15011"))
                                                BubbleEvent = False
                                                Exit Sub
                                            End If
                                        Else
                                            If l_osszIP - Me.m_bankktg <> Math.Round(p_osszeg) Then
                                                m_ParentAddon.SboApplication.MessageBox(m_ParentAddon.LocRM.GetString("ifsz-15011"))
                                                BubbleEvent = False
                                                Exit Sub
                                            End If
                                        End If
                                    End If
                                End If
                                Me.p_DocNum = Me.get_item_value("3", "", 0)
                            Finally
                                If (Not oRcdSet Is Nothing) Then
                                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRcdSet)
                                    oRcdSet = Nothing
                                End If
                                If (Not oCurrRate Is Nothing) Then
                                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oCurrRate)
                                    oCurrRate = Nothing
                                End If
                            End Try
                        End If
                    Case SAPbouiCOM.BoEventTypes.et_FORM_LOAD
                        If pVal.FormType = "196" Or pVal.FormType = "146" Then
                            Dim oForm As SboForm
                            Dim oFormSBO As SAPbouiCOM.Form
                            'If Me.p_osszegS > 0 And Me.p_pnm_kodS <> "" Then
                            '    oForm = New IFSZ_BankFizetesi_modok(Me.m_ParentAddon, "F_FSM", FormUID, Me.m_ParentAddon.parameter_ertek("TECH_FOK"), Me.p_osszegS, Me.p_pnm_kodS, Me.p_konyvelesi_datum)
                            'Else
                            '    oForm = New IFSZ_BankFizetesi_modok(Me.m_ParentAddon, "F_FSM", FormUID, Me.p_fokonyvi_szam, Me.p_osszeg, Me.p_pnm_kod, Me.p_konyvelesi_datum)
                            'End If
                            'Me.m_ParentAddon.SBOForms.Add(oForm, oForm.UniqueID)
                            'Me.p_ModalFormUID = oForm.UniqueID

                            If p_elso Then
                                If Me.p_osszegS > 0 And Me.p_pnm_kodS <> "" And m_tech_fok <> "" Then
                                    oForm = New IFSZ_BankFizetesi_modok(Me.m_ParentAddon, "F_FSM", FormUID, m_tech_fok, Me.p_osszegS, Me.p_pnm_kodS, Me.p_konyvelesi_datum, IIf(Me.p_osszegS > 0 And Me.p_pnm_kodS <> "", -1, IFSZ_Globals_SBO.KonvertSBOSzam(Me.oForm_Eredeti.m_beirt_arfolyam)), Me.m_arfolyam_letiltando, Me.m_bankktg, Me.oForm_Eredeti)
                                Else
                                    oForm = New IFSZ_BankFizetesi_modok(Me.m_ParentAddon, "F_FSM", FormUID, Me.p_fokonyvi_szam, Me.p_osszeg, Me.p_pnm_kod, Me.p_konyvelesi_datum, IIf(Me.p_osszegS > 0 And Me.p_pnm_kodS <> "", -1, IFSZ_Globals_SBO.KonvertSBOSzam(Me.oForm_Eredeti.m_beirt_arfolyam)), Me.m_arfolyam_letiltando, Me.m_bankktg, Me.oForm_Eredeti)
                                End If
                            Else
                                If Me.p_osszegS > 0 And Me.p_pnm_kodS <> "" And m_tech_fok <> "" Then
                                    oForm = New IFSZ_BankFizetesi_modok(Me.m_ParentAddon, "F_FSM", FormUID, m_tech_fok, Me.p_osszegS, Me.p_pnm_kodS, Me.p_konyvelesi_datum, IIf(Me.p_osszegS > 0 And Me.p_pnm_kodS <> "", -1, IFSZ_Globals_SBO.KonvertSBOSzam(Me.oForm_Eredeti.m_beirt_arfolyam)), Me.m_arfolyam_letiltando, Me.m_bankktg, Me.oForm_Eredeti, False)
                                Else
                                    oForm = New IFSZ_BankFizetesi_modok(Me.m_ParentAddon, "F_FSM", FormUID, Me.p_fokonyvi_szam, Me.p_osszeg, Me.p_pnm_kod, Me.p_konyvelesi_datum, IIf(Me.p_osszegS > 0 And Me.p_pnm_kodS <> "", -1, IFSZ_Globals_SBO.KonvertSBOSzam(Me.oForm_Eredeti.m_beirt_arfolyam)), Me.m_arfolyam_letiltando, Me.m_bankktg, Me.oForm_Eredeti, False)
                                End If
                            End If
                            Me.m_ParentAddon.SBOForms.Add(oForm, oForm.UniqueID)
                            Me.p_ModalFormUID = oForm.UniqueID
                            Me.p_elso = False

                        End If
                    Case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED
                        If CStr(pVal.ItemUID) = "1" And pVal.ActionSuccess And SBO_Application.Forms.Item(pVal.FormUID).Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Then
                            'Dim oMatrix As SAPbouiCOM.Matrix
                            Dim oDBsource As SAPbouiCOM.DBDataSource
                            'Dim oEditText As SAPbouiCOM.EditText
                            Dim i, j As Integer
                            Dim index As Integer
                            Dim lng_errCode As Long
                            Dim str_errMsg As String
                            Dim l_matrix_nev As String
                            Dim l_tabla_nev As String
                            Dim l_eredeti_tabla_nev As String
                            'Dim oColumn As SAPbouiCOM.Column
                            Dim l_alias_nev As String
                            Dim l_ertek, l_code, p_select, l_string, p_selectB As String
                            Dim l_lookup_ertek As String
                            Dim utdTable As SAPbobsCOM.UserTable
                            Dim oRecordSet As SAPbobsCOM.Recordset
                            Dim utdTableB As SAPbobsCOM.UserTable
                            Dim oRecordSetB As SAPbobsCOM.Recordset
                            Dim l_datetime As DateTime
                            Dim l_ref2 As String
                            Dim BlnCode As String
                            Dim l_blnc As Double
                            Dim l_ossz_ertek, l_ossz_ertekFC As Double
                            Dim oForm As SAPbouiCOM.Form
                            Dim Journal As SAPbobsCOM.JournalEntries
                            Dim JournalLines As SAPbobsCOM.JournalEntries_Lines
                            Dim l_num As Integer
                            Dim a As Integer
                            Dim b As String
                            Dim utdTableBl As SAPbobsCOM.ChartOfAccounts
                            Dim oRcdSet As SAPbobsCOM.Recordset
                            Dim oCurrRate As SAPbobsCOM.SBObob
                            Dim l_szamla, l_rate As String
                            Dim l_statusz As String
                            Dim VenTable As SAPbobsCOM.Payments
                            Dim InTable As SAPbobsCOM.Payments


                            Try
                                Dim l_irany As Integer
                                If pVal.FormType = 170 Then
                                    l_irany = 1
                                Else
                                    l_irany = -1
                                End If
                                l_statusz = "0"
                                If BubbleEvent = True Then

                                    oRecordSet = Me.SBO_Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                                    oRecordSetB = Me.SBO_Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

                                    p_select = QueryResource.GetQuery("Base_IFSZ_AddOn_SBO", "sel_baseref_from_ojdt_24_46_transtype_by_ref2", Me.p_ref2)


                                    oRecordSet.DoQuery(p_select)
                                    If oRecordSet.RecordCount = 0 Then
                                        'oForm_Eredeti.TetelFeltolt()
                                        Me.m_ParentAddon.SboApplication.MessageBox("Hiba t�rt�nt a fizet�s azonos�t�j�nak visszajelz�se k�zben, a kivonatt�tel nem lett �rv�nyes. Javasoljuk, hogy l�pjen kapcsolatba az IFSZ Kft-vel. (sel_baseref_from_ojdt_24_46_transtype_by_ref2)")
                                        BubbleEvent = False
                                        Exit Sub
                                    End If
                                    oRecordSet.MoveFirst()
                                    Me.p_DocNum = oRecordSet.Fields.Item(0).Value

                                    If Me.p_osszegS > 0 And Me.p_pnm_kodS <> "" Then
                                        m_ParentAddon.SboApplication.MessageBox("A folyamat v�g�n a megadott technikai sz�ml�ra val� k�nyvel�s is megt�rt�nik!")
                                    End If

                                    If Me.p_szamla_tipus <> "F" Then
                                        If pVal.FormType = 170 Then
                                            p_select = QueryResource.GetQuery("Base_IFSZ_AddOn_SBO", "sel_docentry_docnum_seriesname_from_rct2_by_szamlatipus_docnum", Me.p_szamla_tipus, Me.p_DocNum)
                                            oRecordSet.DoQuery(p_select)

                                            oRecordSet.MoveFirst()
                                            For j = 1 To oRecordSet.RecordCount
                                                l_szamla = l_szamla & Me.oForm_Eredeti.GetSzamlaszamString(Me.oForm_Eredeti.l_szamlaszam_method, oRecordSet.Fields.Item(0).Value, Me.p_szamla_tipus)
                                                l_szamla = l_szamla & "; "
                                                oRecordSet.MoveNext()
                                            Next j

                                        Else
                                            p_select = QueryResource.GetQuery("Base_IFSZ_AddOn_SBO", "sel_docentry_docnum_seriesname_from_rct2_by_szamlatipus_docnum", Me.p_szamla_tipus, Me.p_DocNum)
                                            oRecordSet.DoQuery(p_select)

                                            'oRecordSet.MoveFirst()
                                            'For j = 1 To oRecordSet.RecordCount
                                            '    l_szamla = l_szamla & Me.oForm_Eredeti.GetSzamlaszamString(Me.oForm_Eredeti.l_szamlaszam_method, oRecordSet.Fields.Item(0).Value, Me.p_szamla_tipus)
                                            '    l_szamla = l_szamla & "; "
                                            '    oRecordSet.MoveNext()
                                            'Next j
                                        End If
                                    End If

                                    m_ParentAddon.SboCompany.StartTransaction()

                                    l_matrix_nev = "Item26"
                                    l_eredeti_tabla_nev = "@IFSZ_BANK_TXN_LINES"
                                    l_tabla_nev = "IFSZ_BANK_TXN_LINES"
                                    utdTable = m_ParentAddon.SboCompany.UserTables.Item(l_tabla_nev)

                                    'l_code = Me.get_code_from_sequence()
                                    With utdTable.UserFields.Fields

                                        If utdTable.GetByKey(p_code) = True Then

                                            .Item("U_LineSts").Value = "2"
                                            .Item("U_Account").Value = Me.p_fokonyvi_szamMGS
                                            .Item("U_CardCode").Value = Me.p_pnr_kod
                                            .Item("U_JcmCode").Value = Me.p_JcmCode
                                            .Item("U_DocNum").Value = Me.p_DocNum
                                            .Item("U_PrcCode").Value = Me.p_PrcCode
                                            .Item("U_PrjCode").Value = Me.p_PrjCode
                                            .Item("U_Arfolyam").Value = Me.p_arfolyam
                                            If pVal.FormType = 426 Then
                                                .Item("U_AmountSP").Value = -1 * Me.p_osszegFC
                                                .Item("U_Amount").Value = -1 * Me.p_osszeg
                                            Else
                                                .Item("U_AmountSP").Value = Me.p_osszegFC
                                                .Item("U_Amount").Value = Me.p_osszeg
                                            End If
                                            '.Item("U_ErtNap").Value = Replace(Me.p_konyvelesi_datum, " ", "")
                                            If Me.p_pnm_kodS <> "" Then
                                                .Item("U_AmountS").Value = Me.p_osszegS
                                                .Item("U_CashS").Value = Me.p_pnm_kodS
                                            End If
                                            'If (Not l_szamla Is Nothing) Then
                                            '    .Item("U_SzamHiv").Value = l_szamla
                                            'End If
                                            l_datetime = IFSZ_Globals_SBO.KonvertSBODate(Me.SBO_Application.Company.ServerDate)
                                            '.Item("U_CreDate").Value = l_datetime
                                            '.Item("U_CreUser").Value = Me.SBO_Company.UserName
                                            .Item("U_Comment").Value = Me.p_megjegyzes

                                            If utdTable.Update <> 0 Then
                                                m_ParentAddon.SboCompany.GetLastError(lng_errCode, str_errMsg)
                                                m_ParentAddon.SboApplication.MessageBox(str_errMsg & Chr(10) & _
                                                  " hibak�d = " & lng_errCode.ToString())
                                            End If

                                        End If

                                    End With

                                    p_select = QueryResource.GetQuery("Base_IFSZ_AddOn_SBO", "exists_banktxnlines_open_by_bantxn", Me.p_BankTxn)


                                    oRecordSet.DoQuery(p_select)
                                    If oRecordSet.RecordCount = 0 Then
                                        l_tabla_nev = "IFSZ_BANK_TXNS"
                                        utdTable = m_ParentAddon.SboCompany.UserTables.Item(l_tabla_nev)

                                        'l_code = Me.get_code_from_sequence()
                                        With utdTable.UserFields.Fields

                                            If utdTable.GetByKey(Me.p_BankTxn) = True Then

                                                .Item("U_TxnSts").Value = "2"
                                                l_statusz = "2"

                                                If utdTable.Update <> 0 Then
                                                    m_ParentAddon.SboCompany.GetLastError(lng_errCode, str_errMsg)
                                                    m_ParentAddon.SboApplication.MessageBox(str_errMsg & Chr(10) & _
                                                      " hibak�d = " & lng_errCode.ToString())
                                                    Me.m_ParentAddon.SboApplication.MessageBox("Hiba t�rt�nt a fizet�s azonos�t�j�nak visszajelz�se k�zben, a kivonatt�tel nem lett �rv�nyes. Javasoljuk, hogy l�pjen kapcsolatba az IFSZ Kft-vel. (utdTable.Update)")
                                                    BubbleEvent = False
                                                    Exit Sub
                                                End If

                                            End If

                                        End With
                                    End If


                                    'A ProfitCenter besz�r�sa a napl�k�nyvel�sbe
                                    If Me.p_PrcCode <> "" Or Me.p_PrjCode <> "" Then

                                        Journal = Me.m_ParentAddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oJournalEntries)

                                        If pVal.FormType = "170" Then
                                            p_select = QueryResource.GetQuery("Base_IFSZ_AddOn_SBO", "sel_transid_from_orct_by_docnum", Me.p_DocNum)
                                        Else
                                            p_select = QueryResource.GetQuery("Base_IFSZ_AddOn_SBO", "sel_transid_from_ovpm_by_docnum", Me.p_DocNum)
                                        End If
                                        oRecordSet.DoQuery(p_select)

                                        oRecordSet.MoveFirst()
                                        l_num = oRecordSet.Fields.Item(0).Value
                                        Journal.GetByKey(l_num)
                                        JournalLines = Journal.Lines
                                        a = JournalLines.Count

                                        b = JournalLines.AccountCode

                                        JournalLines.SetCurrentLine(1)

                                        For j = 0 To a - 1
                                            JournalLines.SetCurrentLine(j)
                                            b = JournalLines.AccountCode

                                            If Me.p_szamla_tipus = "F" Then
                                                If b = Me.p_fokonyvi_szamMGS Then
                                                    JournalLines.CostingCode = Me.p_PrcCode
                                                    JournalLines.CostingCode2 = Me.p_OcrCode2
                                                    JournalLines.CostingCode3 = Me.p_OcrCode3
                                                    JournalLines.CostingCode4 = Me.p_OcrCode4
                                                    JournalLines.CostingCode5 = Me.p_OcrCode5
                                                    JournalLines.ProjectCode = Me.p_PrjCode
                                                    Journal.Update()
                                                    Exit For
                                                End If
                                            Else
                                                If JournalLines.ShortName = Me.p_pnr_kod Then
                                                    JournalLines.CostingCode = Me.p_PrcCode
                                                    JournalLines.CostingCode2 = Me.p_OcrCode2
                                                    JournalLines.CostingCode3 = Me.p_OcrCode3
                                                    JournalLines.CostingCode4 = Me.p_OcrCode4
                                                    JournalLines.CostingCode5 = Me.p_OcrCode5
                                                    JournalLines.ProjectCode = Me.p_PrjCode
                                                    Journal.Update()
                                                    Exit For
                                                End If
                                                'b = JournalLines.ShortName
                                            End If
                                        Next j

                                    End If
                                    'A ProfitCenter besz�r�sa a napl�k�nyvel�sbe: V�ge!



                                    If pVal.FormType = 170 And Me.p_osszegS > 0 And Me.p_pnm_kodS <> "" AndAlso Not String.IsNullOrEmpty(m_tech_fok) Then
                                        InTable = Me.m_ParentAddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oIncomingPayments)

                                        oCurrRate = Me.m_ParentAddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoBridge)
                                        oRcdSet = oCurrRate.GetLocalCurrency
                                        l_sajat_pnm = oRcdSet.Fields.Item(0).Value
                                        If Me.p_pnm_kod <> l_sajat_pnm Then
                                            oRcdSet = oCurrRate.GetCurrencyRate(Me.p_pnm_kod, Date.Parse(Me.p_konyvelesi_datum))
                                            l_rate = oRcdSet.Fields.Item(0).Value
                                        Else
                                            l_rate = 1
                                        End If
                                        If l_rate Is Nothing Or l_rate = "" Then
                                            Me.m_ParentAddon.SboApplication.MessageBox("Az �rt�k napra az �rfolyamot nem siker�lt meghat�rozni.")
                                            BubbleEvent = False
                                            Exit Sub
                                        End If

                                        'InTable.Address = "622-7"
                                        InTable.ApplyVAT = SAPbobsCOM.BoYesNoEnum.tNO
                                        InTable.CardCode = m_tech_fok
                                        InTable.DocCurrency = Me.p_pnm_kod
                                        InTable.DocDate = Me.p_konyvelesi_datum
                                        InTable.DocRate = l_rate
                                        InTable.Reference2 = Me.p_ref2
                                        InTable.CounterReference = Me.p_ref2
                                        InTable.DocTypte = SAPbobsCOM.BoRcptTypes.rAccount
                                        InTable.HandWritten = SAPbobsCOM.BoYesNoEnum.tNO
                                        InTable.JournalRemarks = "Incoming - D10004"
                                        'InTable.LocalCurrency = SAPbobsCOM.BoYesNoEnum.tNO
                                        'InTable.SplitTransaction = 0
                                        InTable.TaxDate = Me.p_konyvelesi_datum
                                        InTable.TransferAccount = Me.p_fokonyvi_szam
                                        InTable.TransferDate = Me.p_konyvelesi_datum
                                        InTable.TransferSum = Me.p_osszeg
                                        InTable.AccountPayments.AccountCode = m_tech_fok
                                        InTable.AccountPayments.SumPaid = Me.p_osszeg
                                        InTable.AccountPayments.Add()



                                        If (InTable.Add() <> 0) Then
                                            Dim nErr As Long
                                            Dim errMsg As String
                                            CType(IFSZ_Globals.m_ParentAddOn, IFSZ_Addon).SboCompany.GetLastError(nErr, errMsg)
                                            MsgBox("Failed to add a payment " + errMsg)
                                        End If


                                    ElseIf pVal.FormType = 426 And Me.p_osszegS > 0 And Me.p_pnm_kodS <> "" AndAlso Not String.IsNullOrEmpty(m_tech_fok) Then
                                        VenTable = Me.m_ParentAddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oVendorPayments)

                                        oCurrRate = Me.m_ParentAddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoBridge)
                                        oRcdSet = oCurrRate.GetLocalCurrency
                                        l_sajat_pnm = oRcdSet.Fields.Item(0).Value
                                        If Me.p_pnm_kod <> l_sajat_pnm Then
                                            oRcdSet = oCurrRate.GetCurrencyRate(Me.p_pnm_kod, Date.Parse(Me.p_konyvelesi_datum))
                                            l_rate = oRcdSet.Fields.Item(0).Value
                                        Else
                                            l_rate = 1
                                        End If
                                        If l_rate Is Nothing Or l_rate = "" Then
                                            Me.m_ParentAddon.SboApplication.MessageBox("Az �rt�k napra az �rfolyamot nem siker�lt meghat�rozni.")
                                            BubbleEvent = False
                                            Exit Sub
                                        End If

                                        VenTable.ApplyVAT = SAPbobsCOM.BoYesNoEnum.tNO
                                        VenTable.CardCode = m_tech_fok

                                        VenTable.CashSum = 0
                                        VenTable.DocCurrency = Me.p_pnm_kod
                                        VenTable.DocDate = Me.p_konyvelesi_datum
                                        VenTable.DocRate = l_rate
                                        VenTable.Reference2 = Me.p_ref2
                                        VenTable.CounterReference = Me.p_ref2
                                        VenTable.DocTypte = SAPbobsCOM.BoRcptTypes.rAccount
                                        VenTable.HandWritten = SAPbobsCOM.BoYesNoEnum.tNO
                                        VenTable.JournalRemarks = "Incoming - D10004"
                                        'VenTable.LocalCurrency = SAPbobsCOM.BoYesNoEnum.tNO
                                        'VenTable.Reference1 = 8
                                        VenTable.TaxDate = Me.p_konyvelesi_datum
                                        VenTable.TransferAccount = Me.p_fokonyvi_szam
                                        VenTable.TransferDate = Me.p_konyvelesi_datum
                                        VenTable.TransferSum = Me.p_osszeg

                                        VenTable.AccountPayments.AccountCode = m_tech_fok
                                        VenTable.AccountPayments.SumPaid = Me.p_osszeg
                                        VenTable.AccountPayments.Add()

                                        If (VenTable.Add() <> 0) Then
                                            m_ParentAddon.SboCompany.GetLastError(lng_errCode, str_errMsg)
                                            m_ParentAddon.SboApplication.MessageBox(str_errMsg & Chr(10) & _
                                              " hibak�d = " & lng_errCode.ToString())
                                        End If

                                    End If
                                End If

                                Me.CommitTransaction()
                                oForm = Me.m_ParentAddon.SboApplication.Forms.Item(oForm_Eredeti.UniqueID)

                                Dim l_balance As Double

                                utdTableBl = Me.m_ParentAddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oChartOfAccounts)
                                utdTableBl.GetByKey(p_fokonyvi_szam)

                                oRcdSet = Me.SBO_Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

                                oCurrRate = Me.m_ParentAddon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoBridge)
                                oRcdSet = oCurrRate.GetLocalCurrency
                                If oRcdSet.Fields.Item(0).Value <> Me.p_pnm_kod Then
                                    l_balance = utdTableBl.Balance_FrgnCurr
                                Else
                                    l_balance = utdTableBl.Balance
                                End If

                                Dim l_minden_ok As Boolean = False
                                Dim l_hiba As String = ""
                                Dim l_debug As String = "1"
                                While Not l_minden_ok
                                    Try
                                        oForm.Items.Item("Item14").Specific.string = l_balance
                                        l_debug = "2"
                                        oForm_Eredeti.set_item_value("Item26", "Col0", oForm_Eredeti.KivalasztottSor, Me.p_DocNum)
                                        l_debug = "3"
                                        oForm_Eredeti.set_item_value("Item26", "U_DocNum", oForm_Eredeti.KivalasztottSor, Me.p_DocNum)
                                        l_debug = "4"
                                        If Not (Me.p_osszegS > 0 And Me.p_pnm_kodS <> "") Then
                                            oForm_Eredeti.set_item_value("Item26", "Col25", oForm_Eredeti.KivalasztottSor, Me.oForm_Eredeti.m_beirt_arfolyam)
                                            l_debug = "5"
                                            oForm_Eredeti.UjArfolyam() = IFSZ_Globals_SBO.KonvertSBOSzam(Me.oForm_Eredeti.m_beirt_arfolyam)
                                        End If
                                        l_debug = "6"
                                        oForm_Eredeti.set_item_value("Item26", "Col15", oForm_Eredeti.KivalasztottSor, 2)
                                        'oForm.Items.Item("Item30").Specific.string = l_statusz
                                        l_debug = "7"
                                        If l_statusz <> "0" Then
                                            oForm_Eredeti.set_item_value("Item30", "", 0, l_statusz)
                                            l_debug = "8"
                                        End If
                                        l_debug = "9"
                                        oForm_Eredeti.Mentes()
                                        l_debug = "10"

                                        l_minden_ok = True

                                    Catch ex As Exception
                                        If Me.m_ParentAddon.SboApplication.MessageBox("Hiba t�rt�nt a banki forgalmi adatok k�perny�re t�rt�n� vissza�r�sakor. Megpr�b�ljuk �jra?", 1, "Igen", "Nem") <> 1 Then
                                            l_hiba = "Hiba�zenet: " + ex.ToString
                                            l_minden_ok = True
                                        End If
                                    End Try
                                End While

                                If l_hiba <> "" Then
                                    If Me.m_ParentAddon.SboApplication.MessageBox("A fizet�si azonos�t� visszajelz�se a banki kivonatra nem t�rt�nt meg. Automatikus hiba�zenet k�ld�se az IFSZ Kft.-nek?", 1, "Igen", "Nem") = 1 Then
                                        Try
                                            Dim l_vallalat As String = DataProvider.ExecuteScalarString("select ""CompnyName"" from oadm")
                                            SmtpHelper.SendMail(
                                                "ifszonlineszla@gmail.com" _
                                                , "fghUIO987" _
                                                , "smtp.gmail.com" _
                                                , 587 _
                                                , True _
                                                , "ifszonlineszla@gmail.com" _
                                                , "otrs.uzemeltetes@ifsz.hu" _
                                                , "Bank interf�sz hiba " + l_vallalat _
                                                , "Bank interf�sz hiba " + vbNewLine + l_vallalat + vbNewLine + DataProvider.GetDBName() + vbNewLine + "  Adatok: " + p_code + " " + Me.p_DocNum + " " + l_debug + " " + l_hiba _
                                                , False _
                                            )
                                            m_ParentAddon.SboApplication.MessageBox("�zenet elk�ldve. K�rj�k, a ""Banki forgalmi adatok"" men�pontot z�rja be, �s nyissa meg �jra.")
                                        Catch ex As Exception
                                            m_ParentAddon.SboApplication.MessageBox("Az �zenet elk�ld�se nem siker�lt. K�perny�fot�zza le ezt az �zenetet, �s k�ldje el az IFSZ Kft. helpdesk c�m�re. Adatok: " + p_code + " " + Me.p_DocNum + " " + l_debug + " " + l_hiba)
                                        End Try
                                    Else
                                        m_ParentAddon.SboApplication.MessageBox("Adatok: " + p_code + " " + Me.p_DocNum + " " + l_debug + " " + l_hiba)
                                    End If
                                End If

                                'oForm_Eredeti.TetelFeltolt()
                                Me.m_SboForm.Close()

                            Catch ex As Exception
                                Me.RollbackTransaction()
                                m_ParentAddon.SboApplication.MessageBox(ex.ToString)
                                Me.m_ParentAddon.SboApplication.MessageBox("Hiba t�rt�nt a fizet�s azonos�t�j�nak visszajelz�se k�zben, a kivonatt�tel nem lett �rv�nyes. Javasoljuk, hogy l�pjen kapcsolatba az IFSZ Kft-vel.")
                                m_ParentAddon.BlockEvents = False
                                BubbleEvent = False
                            Finally
                                If (Not oRecordSet Is Nothing) Then
                                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRecordSet)
                                    oRecordSet = Nothing
                                End If
                                If (Not oRecordSetB Is Nothing) Then
                                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRecordSetB)
                                    oRecordSet = Nothing
                                End If
                                If (Not Journal Is Nothing) Then
                                    System.Runtime.InteropServices.Marshal.ReleaseComObject(Journal)
                                    Journal = Nothing
                                End If
                                If (Not utdTableBl Is Nothing) Then
                                    System.Runtime.InteropServices.Marshal.ReleaseComObject(utdTableBl)
                                    utdTableBl = Nothing
                                End If
                                If (Not oRcdSet Is Nothing) Then
                                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRcdSet)
                                    oRcdSet = Nothing
                                End If
                                If (Not oCurrRate Is Nothing) Then
                                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oCurrRate)
                                    oCurrRate = Nothing
                                End If
                                If IFSZ_BankTxn_Matrix.KimenoFizetes = True Then
                                    IFSZ_BankTxn_Matrix.KimenoFizetes = False
                                ElseIf IFSZ_BankTxn_Matrix.BejovoFizetes = True Then
                                    IFSZ_BankTxn_Matrix.BejovoFizetes = False
                                End If

                            End Try

                        End If

                End Select

            Else    ' If pval.Before_action = False (else=true)
                If pVal.EventType = SAPbouiCOM.BoEventTypes.et_VALIDATE AndAlso (pVal.ItemUID = "21" OrElse pVal.ItemUID = "72") And pVal.InnerEvent = False Then
                    Me.oForm_Eredeti.m_beirt_arfolyam = get_item_value(pVal.ItemUID, "", 0)
                End If

                If pVal.EventType = SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED AndAlso pVal.ItemUID = "1" AndAlso Me.m_SboForm.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Then
                    'M�g hozz�ad�s el�tt felhozzuk �jra a fizet�si m�dok ablakot, kerek�t�si gondok megold�sa miatt (Ticket#2014090210000104)
                    If Me.p_pnm_kod <> IFSZ_Globals_SBO.MainCurrency Then
                        Me.p_elso = True
                        Me.m_ParentAddon.SboApplication.ActivateMenuItem(5892)
                        oForm_Eredeti.m_szemafor = True
                        Dim i As Integer = 0
                        While oForm_Eredeti.m_szemafor = True
                            i += 1
                            System.Threading.Thread.Sleep(200)
                            If i > 20 Then
                                oForm_Eredeti.m_szemafor = False
                            End If
                        End While
                    End If
                End If

            End If
        End If
    End Sub

    Public Overrides Sub HANDLE_MENU_EVENTS(ByRef pVal As SAPbouiCOM.MenuEvent, ByRef BubbleEvent As Boolean)
        'Me.m_ParentAddon.SboApplication.ActivateMenuItem(enSAPMenuUIDs.KimenoSzamla)
        If pVal.MenuUID = "2818" And Me.p_elso Then
            'Me.m_ParentAddon.SboApplication.ActivateMenuItem(5892)
            Dim l_menuactivatethread As New System.Threading.Thread(AddressOf Me.threadmenuactivate)
            l_menuactivatethread.Start()
        End If

        If pVal.MenuUID = "2817" And Me.p_elso Then
            'Me.m_ParentAddon.SboApplication.ActivateMenuItem(5892)
            Dim l_menuactivatethread As New System.Threading.Thread(AddressOf Me.threadmenuactivate)
            l_menuactivatethread.Start()
        End If

        If IFSZ_BankTxn_Matrix.KimenoFizetes = True Then

        End If
    End Sub

#Region "Public"
    Public Overridable Sub set_item_value(ByVal p_item As String, ByVal p_oszlop As String, ByVal p_sor As Integer, ByVal p_ertek As String, Optional ByVal p_combo_index As Integer = 0)
        Dim oMatrix As SAPbouiCOM.Matrix
        Dim oColumn As SAPbouiCOM.Column
        Dim oEditText As SAPbouiCOM.EditText
        Dim oComboBox As SAPbouiCOM.ComboBox
        Dim oCheckBox As SAPbouiCOM.CheckBox
        Dim l_ertek As String
        If m_SboForm.Items.Item(p_item).Type = SAPbouiCOM.BoFormItemTypes.it_MATRIX Then

            oMatrix = m_SboForm.Items.Item(p_item).Specific
            oColumn = oMatrix.Columns.Item(p_oszlop)

            Select Case oColumn.Type
                Case SAPbouiCOM.BoFormItemTypes.it_EDIT
                    oEditText = oColumn.Cells.Item(p_sor).Specific
                    oEditText.String = p_ertek
                Case SAPbouiCOM.BoFormItemTypes.it_COMBO_BOX
                    oComboBox = oColumn.Cells.Item(p_sor).Specific
                    oComboBox.Select(p_ertek, p_combo_index)
                Case SAPbouiCOM.BoFormItemTypes.it_CHECK_BOX
                    oCheckBox = oColumn.Cells.Item(p_sor).Specific
                    If oCheckBox.Checked() <> p_ertek Then
                        'oCheckBox.Checked = True
                        oMatrix.Columns.Item(p_oszlop).Cells.Item(p_sor).Click()
                    End If
                Case SAPbouiCOM.BoFormItemTypes.it_LINKED_BUTTON
                    oEditText = oColumn.Cells.Item(p_sor).Specific
                    'oLink = oColumn.Cells.Item(p_sor).Specific
                    'oColumn.Editable = True
                    If p_ertek = "" Then
                        'oLink.String = Nothing
                        oEditText.String = Nothing
                    Else
                        'oLink.String = p_ertek
                        oEditText.String = p_ertek
                    End If
            End Select

        ElseIf m_SboForm.Items.Item(p_item).Type = SAPbouiCOM.BoFormItemTypes.it_EDIT Then
            oEditText = m_SboForm.Items.Item(p_item).Specific
            oEditText.String = p_ertek
        ElseIf m_SboForm.Items.Item(p_item).Type = SAPbouiCOM.BoFormItemTypes.it_COMBO_BOX Then
            oComboBox = m_SboForm.Items.Item(p_item).Specific
            oComboBox.Select(p_ertek, p_combo_index)
        ElseIf m_SboForm.Items.Item(p_item).Type = SAPbouiCOM.BoFormItemTypes.it_CHECK_BOX Then
            oCheckBox = m_SboForm.Items.Item(p_item).Specific
            If oCheckBox.Checked() <> p_ertek Then
                m_SboForm.Items.Item(p_item).Click()
            End If
        ElseIf m_SboForm.Items.Item(p_item).Type = SAPbouiCOM.BoFormItemTypes.it_EXTEDIT Then
            oEditText = m_SboForm.Items.Item(p_item).Specific
            oEditText.String = p_ertek
        End If
    End Sub

    Public Function get_item_value(ByVal p_item As String, ByVal p_oszlop As String, ByVal p_sor As Integer, Optional ByVal lookup_e As Boolean = False)
        Dim oMatrix As SAPbouiCOM.Matrix
        Dim oColumn As SAPbouiCOM.Column
        Dim oEditText As SAPbouiCOM.EditText
        Dim oComboBox As SAPbouiCOM.ComboBox
        Dim oCheckBox As SAPbouiCOM.CheckBox
        Dim l_ertek As String
        Try

            If m_SboForm.Items.Item(p_item).Type = SAPbouiCOM.BoFormItemTypes.it_MATRIX Then

                oMatrix = m_SboForm.Items.Item(p_item).Specific
                oColumn = oMatrix.Columns.Item(p_oszlop)

                Select Case oColumn.Type
                    Case SAPbouiCOM.BoFormItemTypes.it_EDIT
                        oEditText = oColumn.Cells.Item(p_sor).Specific
                        l_ertek = oEditText.String
                        Return l_ertek
                    Case SAPbouiCOM.BoFormItemTypes.it_LINKED_BUTTON
                        oEditText = oColumn.Cells.Item(p_sor).Specific
                        l_ertek = oEditText.String
                        Return l_ertek
                    Case SAPbouiCOM.BoFormItemTypes.it_COMBO_BOX
                        oComboBox = oColumn.Cells.Item(p_sor).Specific
                        If lookup_e = True Then
                            Return oComboBox.Selected.Description
                        Else
                            Return oComboBox.Selected.Value
                        End If
                    Case SAPbouiCOM.BoFormItemTypes.it_CHECK_BOX
                        oCheckBox = oColumn.Cells.Item(p_sor).Specific
                        If oCheckBox.Checked Then
                            Return oCheckBox.ValOn
                        Else
                            Return oCheckBox.ValOff
                        End If

                End Select

            ElseIf m_SboForm.Items.Item(p_item).Type = SAPbouiCOM.BoFormItemTypes.it_EDIT Then
                oEditText = m_SboForm.Items.Item(p_item).Specific
                l_ertek = oEditText.String
                Return l_ertek
            ElseIf m_SboForm.Items.Item(p_item).Type = SAPbouiCOM.BoFormItemTypes.it_COMBO_BOX Then
                oComboBox = m_SboForm.Items.Item(p_item).Specific
                If (Not oComboBox.Selected Is Nothing) Then
                    If lookup_e = True Then
                        Return oComboBox.Selected.Description
                    Else
                        Return oComboBox.Selected.Value
                    End If
                Else
                    Return ""
                End If
            ElseIf m_SboForm.Items.Item(p_item).Type = SAPbouiCOM.BoFormItemTypes.it_CHECK_BOX Then
                oCheckBox = m_SboForm.Items.Item(p_item).Specific
                If oCheckBox.Checked Then
                    Return oCheckBox.ValOn
                Else
                    Return oCheckBox.ValOff
                End If
            End If
            Return ""
        Catch ex As Exception
            m_ParentAddon.SboApplication.MessageBox(p_item + ":" + p_oszlop)
        End Try



    End Function
#End Region

    Private Function get_code_from_sequence() As String
        Dim l_seq As New IFSZ_Sequence(m_ParentAddon)
        Return l_seq.get_next_seq("DEFAULT")
    End Function

    Private Function get_osszeg(ByVal formtype As Integer) As Double
        Dim oMatrix As SAPbouiCOM.Matrix
        Dim oColumn As SAPbouiCOM.Column
        If Me.p_szamla_tipus = "S" And formtype = 426 Then
            oMatrix = Me.m_SboForm.Items.Item("20").Specific
        End If

    End Function

    Private Sub CommitTransaction()
        If m_ParentAddon.SboCompany.InTransaction Then
            m_ParentAddon.SboCompany.EndTransaction(SAPbobsCOM.BoWfTransOpt.wf_Commit)
        End If
    End Sub

    Private Sub RollbackTransaction()
        If m_ParentAddon.SboCompany.InTransaction Then
            m_ParentAddon.SboCompany.EndTransaction(SAPbobsCOM.BoWfTransOpt.wf_RollBack)
        End If
    End Sub

    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub

    Public Sub threadmenuactivate()
        Dim m_oProgBar As SAPbouiCOM.ProgressBar
        m_oProgBar = Me.m_ParentAddon.SboApplication.StatusBar.CreateProgressBar("Fizet�s form adatainak kit�lt�se", 10, False)
        Dim i As Integer = 0
        For i = 0 To 5
            m_oProgBar.Value = i
            System.Threading.Thread.Sleep(10)
        Next
        m_oProgBar.Stop()
        m_oProgBar = Nothing
        Me.m_ParentAddon.SboApplication.ActivateMenuItem(5892)
        Me.m_szamla_kijeloles = 1
    End Sub

End Class