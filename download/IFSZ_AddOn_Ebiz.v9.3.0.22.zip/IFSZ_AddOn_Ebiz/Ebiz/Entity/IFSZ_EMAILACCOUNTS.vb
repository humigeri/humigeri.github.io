﻿'----------------------------------------------------------------------------'
'Ez a fájl módosítható, saját és override-olt eljárások írhatóak benne
'----------------------------------------------------------------------------'
'Generálva: 2020.03.22
'EntityGenerator2 - számára. Verzió: 1.1.16.6
'

Imports IFSZ_AddOnBase
Imports System.Text

Partial Public Class IFSZ_EMAILACCOUNTS
    Inherits IFSZ_EMAILACCOUNTS_Base

#Region "Konstruktor"

    Public Sub New(ByRef pGlobal As IFSZ_Globals)
        MyBase.New(pGlobal)
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef pGlobal As IFSZ_Globals)
        MyBase.New(entity, pGlobal)
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef l_form As IFSZ_Form)
        MyBase.New(entity, l_form)
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef l_form As IFSZ_Form, ByRef pGlobal As IFSZ_Globals)
        MyBase.New(entity, l_form, pGlobal)
    End Sub

    Public Sub New(ByRef pGlobal As IFSZ_Globals, ByVal p_TableName As String)
        MyBase.New(pGlobal, p_TableName)
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef pGlobal As IFSZ_Globals, ByVal p_TableName As String)
        MyBase.New(entity, pGlobal, p_TableName)
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef l_form As IFSZ_Form, ByVal p_TableName As String)
        MyBase.New(entity, l_form, p_TableName)
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef l_form As IFSZ_Form, ByRef pGlobal As IFSZ_Globals, ByVal p_TableName As String)
        MyBase.New(entity, l_form, pGlobal, p_TableName)
    End Sub

#End Region

#Region "Overrides"

    Protected Overrides Function PreAutomatizmus(p_op As IFSZ_Types.DMLOperation, ByRef p_record As Object, ByRef p_message As String, ByRef p_dao As IFSZ_EMAILACCOUNTSDAO, ByRef Optional p_record_old As DataRowView = Nothing) As Boolean
        If p_op = IFSZ_Types.DMLOperation.Insert OrElse p_op = IFSZ_Types.DMLOperation.Update Then
            If p_record("NAME").ToString() = "" Then
                p_message = "A Név mezőt kötelező megadni"
                Return False
            End If
        End If
        Return True
    End Function

    Protected Overrides Function PostAutomatizmus(p_op As IFSZ_Types.DMLOperation, ByRef p_record As Object, ByRef p_message As String, ByRef p_dao As IFSZ_EMAILACCOUNTSDAO, ByRef Optional p_record_old As DataRowView = Nothing) As Boolean
        If p_op = IFSZ_Types.DMLOperation.Insert OrElse p_op = IFSZ_Types.DMLOperation.Update Then
            'Egyediség: NAME
            Dim l_count As Integer = DataProvider.ExecuteScalar("select count(9) from IFSZ_EMAILACCOUNTS where ""NAME"" = " + IFSZ_Globals.SQLConstantPrepare(p_record("NAME")) + " and id <> " + p_record("ID").ToString().TrimStart("0"))
            If l_count > 0 Then
                p_message = "Ezzel az elnevezéssel már lett felvéve kimenő levelező szerver"
                Return False
            End If

            'Alapban úgy oldottam meg a kukacos táblákat, hogy a Code-ba és a Name-be is az id kerül, de itt szükség van a Name-ra. Igaz, csak utólag, de beupdate-elem az U_NAME-t
            '(insert során a dao még beszúrja az id-t a Name-be, de itt most felülvágom. Később már úgysem foglalkozunk vele, a Code-ot tekintjük ID-nak pl. update-nél)
            DataProvider.EExecuteNonQuery("update ""@IFSZ_EMAILACCOUNTS"" set ""Name"" = " + IFSZ_Globals.SQLConstantPrepare(p_record("NAME")) + " where ""Code"" = " + IFSZ_Globals.SQLConstantPrepare(p_record("ID").ToString().TrimStart("0")))
        End If
        Return True
    End Function

#End Region

    Public Shared Function JelszoKodol(ByVal p_jelszo As String) As String
        Return IFSZ_EMAILACCOUNTS.bekodol(p_jelszo)
    End Function

    Public Shared Function JelszoVisszaKodol(ByVal p_jelszo As String) As String
        Return IFSZ_EMAILACCOUNTS.visszakodol(p_jelszo)
    End Function

    Public Shared Function visszakodol(ByVal p_kod As String) As String
        Dim ByteConverter As Encoding = Encoding.Unicode
        Dim l_encrypted_kulcs() As Byte

        l_encrypted_kulcs = IFSZ_Security.GetEncryptedByte(p_kod)
        Dim key As New System.Security.Cryptography.DESCryptoServiceProvider()
        Dim plaintext As String = IFSZ_Security.DESDecrypt(l_encrypted_kulcs, key)
        Return plaintext
    End Function

    Public Shared Function bekodol(ByVal p_kod As String) As String
        Dim ByteConverter As Encoding = Encoding.Unicode
        Dim dataToEncrypt As Byte() = ByteConverter.GetBytes(p_kod)
        Dim l_kulcs As String
        Dim key As New System.Security.Cryptography.DESCryptoServiceProvider()
        Dim buffer As Byte() = IFSZ_Security.DESEncrypt(p_kod, key)
        l_kulcs = ByteConverter.GetString(buffer)

        Dim l_string As String
        Dim j As Integer
        For j = 1 To buffer.Length
            If l_string <> "" Then
                l_string = l_string & "&" & buffer(j - 1).ToString
            Else
                l_string = l_string & buffer(j - 1).ToString
            End If
        Next

        ' Decrypt the byte array back to a string.
        Dim plaintext As String = IFSZ_Security.DESDecrypt(buffer, key)
        Return l_string
    End Function

End Class
