﻿'----------------------------------------------------------------------------'
'GENERÁLT FÁJL!!!! NE MÓDOSÍTSD!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
'----------------------------------------------------------------------------'
'Generálva: 2023.02.27
'EntityGenerator - számára. Verzió: 1.1.16.10
'
'entitygenerator2 xml EMAILOUT C:\svn\gergo\modulok\IFSZ_AddOn_Ebiz\IFSZ_AddOn_Ebiz\Ebiz\Entity IFSZ_EMAILOUTLINE
'
'Paraméterek:
'Workarea/Xml file név: H:\SBO\Fejlesztes\Work\Repository\XmlRepository.xml
'Alkalmazásrendszer: EMAILOUT
'Könyvtár: C:\svn\gergo\modulok\IFSZ_AddOn_Ebiz\IFSZ_AddOn_Ebiz\Ebiz\Entity\
'Tábla neve: IFSZ_EMAILOUTLINE
'
'
'----------------------------------------------------------------------------'

'----------------------------------------------------------------------------'
' create view "IFSZ_EMAILOUTLINE" as select "Code" as ID, "U_DOCTYPE" as "DOCTYPE", "U_CRYSTAL" as "CRYSTAL", "U_MAIL_SUBJECT" as "MAIL_SUBJECT", "U_MAIL_BODY" as "MAIL_BODY", "U_FILE" as "FILE", "U_STATUS" as "STATUS", "U_EOH_ID" as "EOH_ID", "U_LINENUM" as "LINENUM", "U_DOCENTRY" as "DOCENTRY", "U_DOCNUM" as "DOCNUM", "U_SENTTS" as "SENTTS", "U_ISHTML" as "ISHTML", "U_EBIZTIP" as "EBIZTIP", "U_MD5_FILE" as "MD5_FILE", "U_MD5_SIGNED" as "MD5_SIGNED" from "@IFSZ_EMAILOUTLINE"
'----------------------------------------------------------------------------'

Imports System
Imports System.Resources.ResourceReader
Imports System.Collections
Imports System.Text
Imports IFSZ_AddOnBase


Public Class IFSZ_EMAILOUTLINE_Base
    'Inherits ObjectDataBinding.BaseClasses.FSBindingItem
    Implements IFSZ_IEntity

#Region "Variables"
    Protected p_ID As Integer
    Protected p_DOCTYPE As String
    Protected p_DOCTYPE_FORMAT As String = ""
    Protected p_DOCTYPE_LANGVAL As String
    Protected p_DOCTYPE_MEAN As String
    Protected p_CRYSTAL As String
    Protected p_MAIL_SUBJECT As String
    Protected p_MAIL_BODY As String
    Protected p_FILE As String
    Protected p_STATUS As String
    Protected p_STATUS_LANGVAL As String
    Protected p_STATUS_MEAN As String
    Protected p_EOH_ID As String
    Protected p_EOH_ID_FORMAT As String = ""
    Protected p_LINENUM As String
    Protected p_LINENUM_FORMAT As String = ""
    Protected p_DOCENTRY As String
    Protected p_DOCENTRY_FORMAT As String = ""
    Protected p_DOCNUM As String
    Protected p_SENTTS As String
    Protected p_SENTTS_FORMAT As String = ""
    Protected p_ISHTML As String
    Protected p_ISHTML_LANGVAL As String
    Protected p_ISHTML_MEAN As String
    Protected p_EBIZTIP As String
    Protected p_EBIZTIP_LANGVAL As String
    Protected p_EBIZTIP_MEAN As String
    Protected p_MD5_FILE As String
    Protected p_MD5_SIGNED As String
    Protected p_tablanev As String
    Protected p_ChildWhere As String
    Protected p_DefaultWhere As String
    Protected p_LastWhere As String
    Protected p_LastQuery As String
    Protected p_ViewName As String
    Protected p_LastPosition As String
    Protected p_NewRowEnabled As Boolean = True
    Protected p_IFSZ_Globals As IFSZ_Globals
    Protected p_Columns() As String = {"ID", "DOCTYPE", "CRYSTAL", "MAIL_SUBJECT", "MAIL_BODY", "FILE", "STATUS", "EOH_ID", "LINENUM", "DOCENTRY", "DOCNUM", "SENTTS", "ISHTML", "EBIZTIP", "MD5_FILE", "MD5_SIGNED"}
    Protected p_form As IFSZ_Form
    Protected p_ChildTableNames(0) As String
    Protected p_ChildRelations As IFSZ_Types.Relations
    Protected p_PrimaryKey As IFSZ_Types.PrimaryKeys = New IFSZ_Types.PrimaryKeys
    Protected p_SqlQuery As String = "Select ID, DOCTYPE, CRYSTAL, MAIL_SUBJECT, MAIL_BODY, FILE, STATUS, EOH_ID, LINENUM, DOCENTRY, DOCNUM, SENTTS, ISHTML, EBIZTIP, MD5_FILE, MD5_SIGNED From IFSZ_EMAILOUTLINE "
    Protected MyCultureInfo As System.Globalization.CultureInfo = New System.Globalization.CultureInfo("en-gb")
#End Region


#Region "Konstruktor"

    Public Sub New(ByRef pGlobal As IFSZ_Globals)
        m_IFSZ_Globals = pGlobal
        FormatumBeallitas()
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef pGlobal As IFSZ_Globals)
        m_IFSZ_Globals = pGlobal
        If entity Is Nothing Then
            ReDim Preserve entity(0)
        Else
            ReDim Preserve entity(entity.GetUpperBound(0) + 1)
        End If
        entity(entity.GetUpperBound(0)) = Me
        Me.TableName = "IFSZ_EMAILOUTLINE"
        FormatumBeallitas()
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef l_form As IFSZ_Form)
        If entity Is Nothing Then
            ReDim Preserve entity(0)
        Else
            ReDim Preserve entity(entity.GetUpperBound(0) + 1)
        End If
        entity(entity.GetUpperBound(0)) = Me
        Me.TableName = "IFSZ_EMAILOUTLINE"
        Me.p_form = l_form
        FormatumBeallitas()
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef l_form As IFSZ_Form, ByRef pGlobal As IFSZ_Globals)
        If entity Is Nothing Then
            ReDim Preserve entity(0)
        Else
            ReDim Preserve entity(entity.GetUpperBound(0) + 1)
        End If
        m_IFSZ_Globals = pGlobal
        entity(entity.GetUpperBound(0)) = Me
        Me.TableName = "IFSZ_EMAILOUTLINE"
        Me.p_form = l_form
        FormatumBeallitas()
    End Sub

    Public Sub New(ByRef pGlobal As IFSZ_Globals, ByVal p_TableName As String)
        m_IFSZ_Globals = pGlobal
        Me.TableName = p_TableName
        FormatumBeallitas()
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef pGlobal As IFSZ_Globals, ByVal p_TableName As String)
        m_IFSZ_Globals = pGlobal
        If entity Is Nothing Then
            ReDim Preserve entity(0)
        Else
            ReDim Preserve entity(entity.GetUpperBound(0) + 1)
        End If
        entity(entity.GetUpperBound(0)) = Me
        Me.TableName = "IFSZ_EMAILOUTLINE"
        Me.TableName = p_TableName
        FormatumBeallitas()
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef l_form As IFSZ_Form, ByVal p_TableName As String)
        If entity Is Nothing Then
            ReDim Preserve entity(0)
        Else
            ReDim Preserve entity(entity.GetUpperBound(0) + 1)
        End If
        entity(entity.GetUpperBound(0)) = Me
        Me.TableName = "IFSZ_EMAILOUTLINE"
        Me.p_form = l_form
        Me.TableName = p_TableName
        FormatumBeallitas()
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef l_form As IFSZ_Form, ByRef pGlobal As IFSZ_Globals, ByVal p_TableName As String)
        If entity Is Nothing Then
            ReDim Preserve entity(0)
        Else
            ReDim Preserve entity(entity.GetUpperBound(0) + 1)
        End If
        m_IFSZ_Globals = pGlobal
        entity(entity.GetUpperBound(0)) = Me
        Me.TableName = "IFSZ_EMAILOUTLINE"
        Me.p_form = l_form
        Me.TableName = p_TableName
        FormatumBeallitas()
    End Sub

#End Region

#Region "Property"

    Public Property TableName() As String Implements IFSZ_IEntity.TableName
        Get
            Return p_tablanev
        End Get
        Set(ByVal value As String)
            p_tablanev = value
        End Set
    End Property

    Public ReadOnly Property Columns() As String() Implements IFSZ_IEntity.Columns
        Get
            Return Me.p_Columns
        End Get
    End Property

    Public Property ChildWhere() As String Implements IFSZ_IEntity.ChildWhere
        Get
            Return p_ChildWhere
        End Get
        Set(ByVal value As String)
            p_ChildWhere = value
        End Set
    End Property

    Public Property DefaultWhere() As String Implements IFSZ_IEntity.DefaultWhere
        Get
            Return p_DefaultWhere
        End Get
        Set(ByVal value As String)
            p_DefaultWhere = value
        End Set
    End Property

    Public Property LastWhere() As String Implements IFSZ_IEntity.LastWhere
        Get
            Return p_LastWhere
        End Get
        Set(ByVal value As String)
            p_LastWhere = value
        End Set
    End Property

    Public Property LastPosition() As Integer Implements IFSZ_IEntity.LastPosition
        Get
            Return p_LastPosition
        End Get
        Set(ByVal value As Integer)
            p_LastPosition = value
        End Set
    End Property

    Public Property NewRowEnabled() As Boolean Implements IFSZ_IEntity.NewRowEnabled
        Get
            Return p_NewRowEnabled
        End Get
        Set(ByVal value As Boolean)
            p_NewRowEnabled = value
        End Set
    End Property

    Protected Property ID(Optional ByVal p_visible As Boolean = True) As Integer
        Get
            Return p_ID
        End Get
        Set(ByVal value As Integer)
            p_ID = value
            If p_visible Then
                Me.set_item("ID", value)
            End If
        End Set
    End Property

    Protected Property DOCTYPE(Optional ByVal p_visible As Boolean = True) As String
        Get
            Return p_DOCTYPE
        End Get
        Set(ByVal value As String)
            If Not value Is Nothing And value <> "" Then
                p_DOCTYPE = value
                If p_visible Then
                    Me.set_item("DOCTYPE", IFSZ_Globals.GetInternalStringToDouble(value))
                End If
            Else
                p_DOCTYPE = Nothing
                If p_visible Then
                    Me.set_item("DOCTYPE", DBNull.Value)
                End If
            End If
        End Set
    End Property

    Friend Property DOCTYPE_FORMAT() As String
        Get
            Return p_DOCTYPE_FORMAT
        End Get
        Set(ByVal value As String)
            p_DOCTYPE_FORMAT = value
        End Set
    End Property

    Protected Property DOCTYPE_LANGVAL(Optional ByVal p_visible As Boolean = True) As String
        Get
            Return p_DOCTYPE_LANGVAL
        End Get
        Set(ByVal value As String)
            p_DOCTYPE_LANGVAL = value
            If p_visible Then
                Me.set_item("DOCTYPE_LANGVAL", value)
            End If
        End Set
    End Property

    Protected Property DOCTYPE_MEAN(Optional ByVal p_visible As Boolean = True) As String
        Get
            Return p_DOCTYPE_MEAN
        End Get
        Set(ByVal value As String)
            p_DOCTYPE_MEAN = value
            If p_visible Then
                Me.set_item("DOCTYPE_MEAN", value)
            End If
        End Set
    End Property

    Protected Property CRYSTAL(Optional ByVal p_visible As Boolean = True) As String
        Get
            Return p_CRYSTAL
        End Get
        Set(ByVal value As String)
            If Not value Is Nothing And value <> "" Then
                p_CRYSTAL = value
                If p_visible Then
                    Me.set_item("CRYSTAL", value)
                End If
            Else
                p_CRYSTAL = Nothing
                If p_visible Then
                    Me.set_item("CRYSTAL", DBNull.Value)
                End If
            End If
        End Set
    End Property

    Protected Property MAIL_SUBJECT(Optional ByVal p_visible As Boolean = True) As String
        Get
            Return p_MAIL_SUBJECT
        End Get
        Set(ByVal value As String)
            If Not value Is Nothing And value <> "" Then
                p_MAIL_SUBJECT = value
                If p_visible Then
                    Me.set_item("MAIL_SUBJECT", value)
                End If
            Else
                p_MAIL_SUBJECT = Nothing
                If p_visible Then
                    Me.set_item("MAIL_SUBJECT", DBNull.Value)
                End If
            End If
        End Set
    End Property

    Protected Property MAIL_BODY(Optional ByVal p_visible As Boolean = True) As String
        Get
            Return p_MAIL_BODY
        End Get
        Set(ByVal value As String)
            If Not value Is Nothing And value <> "" Then
                p_MAIL_BODY = value
                If p_visible Then
                    Me.set_item("MAIL_BODY", value)
                End If
            Else
                p_MAIL_BODY = Nothing
                If p_visible Then
                    Me.set_item("MAIL_BODY", DBNull.Value)
                End If
            End If
        End Set
    End Property

    Protected Property FILE(Optional ByVal p_visible As Boolean = True) As String
        Get
            Return p_FILE
        End Get
        Set(ByVal value As String)
            If Not value Is Nothing And value <> "" Then
                p_FILE = value
                If p_visible Then
                    Me.set_item("FILE", value)
                End If
            Else
                p_FILE = Nothing
                If p_visible Then
                    Me.set_item("FILE", DBNull.Value)
                End If
            End If
        End Set
    End Property

    Protected Property STATUS(Optional ByVal p_visible As Boolean = True) As String
        Get
            Return p_STATUS
        End Get
        Set(ByVal value As String)
            If Not value Is Nothing And value <> "" Then
                p_STATUS = value
                If p_visible Then
                    Me.set_item("STATUS", value)
                End If
            Else
                p_STATUS = Nothing
                If p_visible Then
                    Me.set_item("STATUS", DBNull.Value)
                End If
            End If
        End Set
    End Property

    Protected Property STATUS_LANGVAL(Optional ByVal p_visible As Boolean = True) As String
        Get
            Return p_STATUS_LANGVAL
        End Get
        Set(ByVal value As String)
            p_STATUS_LANGVAL = value
            If p_visible Then
                Me.set_item("STATUS_LANGVAL", value)
            End If
        End Set
    End Property

    Protected Property STATUS_MEAN(Optional ByVal p_visible As Boolean = True) As String
        Get
            Return p_STATUS_MEAN
        End Get
        Set(ByVal value As String)
            p_STATUS_MEAN = value
            If p_visible Then
                Me.set_item("STATUS_MEAN", value)
            End If
        End Set
    End Property

    Protected Property EOH_ID(Optional ByVal p_visible As Boolean = True) As String
        Get
            Return p_EOH_ID
        End Get
        Set(ByVal value As String)
            If Not value Is Nothing And value <> "" Then
                p_EOH_ID = value
                If p_visible Then
                    Me.set_item("EOH_ID", IFSZ_Globals.GetInternalStringToDouble(value))
                End If
            Else
                p_EOH_ID = Nothing
                If p_visible Then
                    Me.set_item("EOH_ID", DBNull.Value)
                End If
            End If
        End Set
    End Property

    Friend Property EOH_ID_FORMAT() As String
        Get
            Return p_EOH_ID_FORMAT
        End Get
        Set(ByVal value As String)
            p_EOH_ID_FORMAT = value
        End Set
    End Property

    Protected Property LINENUM(Optional ByVal p_visible As Boolean = True) As String
        Get
            Return p_LINENUM
        End Get
        Set(ByVal value As String)
            If Not value Is Nothing And value <> "" Then
                p_LINENUM = value
                If p_visible Then
                    Me.set_item("LINENUM", IFSZ_Globals.GetInternalStringToDouble(value))
                End If
            Else
                p_LINENUM = Nothing
                If p_visible Then
                    Me.set_item("LINENUM", DBNull.Value)
                End If
            End If
        End Set
    End Property

    Friend Property LINENUM_FORMAT() As String
        Get
            Return p_LINENUM_FORMAT
        End Get
        Set(ByVal value As String)
            p_LINENUM_FORMAT = value
        End Set
    End Property

    Protected Property DOCENTRY(Optional ByVal p_visible As Boolean = True) As String
        Get
            Return p_DOCENTRY
        End Get
        Set(ByVal value As String)
            If Not value Is Nothing And value <> "" Then
                p_DOCENTRY = value
                If p_visible Then
                    Me.set_item("DOCENTRY", IFSZ_Globals.GetInternalStringToDouble(value))
                End If
            Else
                p_DOCENTRY = Nothing
                If p_visible Then
                    Me.set_item("DOCENTRY", DBNull.Value)
                End If
            End If
        End Set
    End Property

    Friend Property DOCENTRY_FORMAT() As String
        Get
            Return p_DOCENTRY_FORMAT
        End Get
        Set(ByVal value As String)
            p_DOCENTRY_FORMAT = value
        End Set
    End Property

    Protected Property DOCNUM(Optional ByVal p_visible As Boolean = True) As String
        Get
            Return p_DOCNUM
        End Get
        Set(ByVal value As String)
            If Not value Is Nothing And value <> "" Then
                p_DOCNUM = value
                If p_visible Then
                    Me.set_item("DOCNUM", value)
                End If
            Else
                p_DOCNUM = Nothing
                If p_visible Then
                    Me.set_item("DOCNUM", DBNull.Value)
                End If
            End If
        End Set
    End Property

    Protected Property SENTTS(Optional ByVal p_visible As Boolean = True) As String
        Get
            Return p_SENTTS
        End Get
        Set(ByVal value As String)
            If Not value Is Nothing And value <> "" Then
                p_SENTTS = value
                If p_visible Then
                    Me.set_item("SENTTS", IFSZ_Globals.GetInternalStringToDateTime(value))
                End If
            Else
                p_SENTTS = Nothing
                If p_visible Then
                    Me.set_item("SENTTS", DBNull.Value)
                End If
            End If
        End Set
    End Property

    Friend Property SENTTS_FORMAT() As String
        Get
            Return p_SENTTS_FORMAT
        End Get
        Set(ByVal value As String)
            p_SENTTS_FORMAT = value
        End Set
    End Property

    Protected Property ISHTML(Optional ByVal p_visible As Boolean = True) As String
        Get
            Return p_ISHTML
        End Get
        Set(ByVal value As String)
            Dim l_value As String
            If Not value Is Nothing And value <> "" Then
                Select Case value
                    Case "False"
                        l_value = "N"
                    Case "True"
                        l_value = "I"
                    Case Else
                        l_value = value
                End Select
                p_ISHTML = l_value
                If p_visible Then
                    Me.set_item("ISHTML", l_value)
                End If
            Else
                p_ISHTML = Nothing
                If p_visible Then
                    Me.set_item("ISHTML", DBNull.Value)
                End If
            End If
        End Set
    End Property

    Protected Property ISHTML_LANGVAL(Optional ByVal p_visible As Boolean = True) As String
        Get
            Return p_ISHTML_LANGVAL
        End Get
        Set(ByVal value As String)
            p_ISHTML_LANGVAL = value
            If p_visible Then
                Me.set_item("ISHTML_LANGVAL", value)
            End If
        End Set
    End Property

    Protected Property ISHTML_MEAN(Optional ByVal p_visible As Boolean = True) As String
        Get
            Return p_ISHTML_MEAN
        End Get
        Set(ByVal value As String)
            p_ISHTML_MEAN = value
            If p_visible Then
                Me.set_item("ISHTML_MEAN", value)
            End If
        End Set
    End Property

    Protected Property EBIZTIP(Optional ByVal p_visible As Boolean = True) As String
        Get
            Return p_EBIZTIP
        End Get
        Set(ByVal value As String)
            If Not value Is Nothing And value <> "" Then
                p_EBIZTIP = value
                If p_visible Then
                    Me.set_item("EBIZTIP", value)
                End If
            Else
                p_EBIZTIP = Nothing
                If p_visible Then
                    Me.set_item("EBIZTIP", DBNull.Value)
                End If
            End If
        End Set
    End Property

    Protected Property EBIZTIP_LANGVAL(Optional ByVal p_visible As Boolean = True) As String
        Get
            Return p_EBIZTIP_LANGVAL
        End Get
        Set(ByVal value As String)
            p_EBIZTIP_LANGVAL = value
            If p_visible Then
                Me.set_item("EBIZTIP_LANGVAL", value)
            End If
        End Set
    End Property

    Protected Property EBIZTIP_MEAN(Optional ByVal p_visible As Boolean = True) As String
        Get
            Return p_EBIZTIP_MEAN
        End Get
        Set(ByVal value As String)
            p_EBIZTIP_MEAN = value
            If p_visible Then
                Me.set_item("EBIZTIP_MEAN", value)
            End If
        End Set
    End Property

    Protected Property MD5_FILE(Optional ByVal p_visible As Boolean = True) As String
        Get
            Return p_MD5_FILE
        End Get
        Set(ByVal value As String)
            If Not value Is Nothing And value <> "" Then
                p_MD5_FILE = value
                If p_visible Then
                    Me.set_item("MD5_FILE", value)
                End If
            Else
                p_MD5_FILE = Nothing
                If p_visible Then
                    Me.set_item("MD5_FILE", DBNull.Value)
                End If
            End If
        End Set
    End Property

    Protected Property MD5_SIGNED(Optional ByVal p_visible As Boolean = True) As String
        Get
            Return p_MD5_SIGNED
        End Get
        Set(ByVal value As String)
            If Not value Is Nothing And value <> "" Then
                p_MD5_SIGNED = value
                If p_visible Then
                    Me.set_item("MD5_SIGNED", value)
                End If
            Else
                p_MD5_SIGNED = Nothing
                If p_visible Then
                    Me.set_item("MD5_SIGNED", DBNull.Value)
                End If
            End If
        End Set
    End Property

#End Region

#Region "Implements"


    Public Overridable Function GetAttribute(ByVal p_oszlop As String) As Object Implements IFSZ_IEntity.GetAttribute
        Dim p_valid As Boolean = True
        Select Case p_oszlop
            Case "ID"
                Return ID
            Case "DOCTYPE"
                Return IFSZ_Globals.GetInternalStringToDouble(DOCTYPE)
            Case "DOCTYPE.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.Double"), 10, 0, p_DOCTYPE_FORMAT)
            Case "CRYSTAL"
                Return CRYSTAL
            Case "CRYSTAL.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.String"), 50, 0, "")
            Case "MAIL_SUBJECT"
                Return MAIL_SUBJECT
            Case "MAIL_SUBJECT.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.String"), 100, 0, "")
            Case "MAIL_BODY"
                Return MAIL_BODY
            Case "MAIL_BODY.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.String"), 4000, 0, "")
            Case "FILE"
                Return FILE
            Case "FILE.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.String"), 254, 0, "")
            Case "STATUS"
                Return STATUS
            Case "STATUS.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.String"), 1, 0, "")
            Case "EOH_ID"
                Return IFSZ_Globals.GetInternalStringToDouble(EOH_ID)
            Case "EOH_ID.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.Double"), 10, 0, p_EOH_ID_FORMAT)
            Case "LINENUM"
                Return IFSZ_Globals.GetInternalStringToDouble(LINENUM)
            Case "LINENUM.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.Double"), 10, 0, p_LINENUM_FORMAT)
            Case "DOCENTRY"
                Return IFSZ_Globals.GetInternalStringToDouble(DOCENTRY)
            Case "DOCENTRY.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.Double"), 10, 0, p_DOCENTRY_FORMAT)
            Case "DOCNUM"
                Return DOCNUM
            Case "DOCNUM.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.String"), 50, 0, "")
            Case "SENTTS"
                Return IFSZ_Globals.GetInternalStringToDateTime(SENTTS)
            Case "SENTTS.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.DateTime"), 23, 3, p_SENTTS_FORMAT)
            Case "ISHTML"
                Return ISHTML
            Case "ISHTML.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.String"), 1, 0, "")
            Case "EBIZTIP"
                Return EBIZTIP
            Case "EBIZTIP.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.String"), 1, 0, "")
            Case "MD5_FILE"
                Return MD5_FILE
            Case "MD5_FILE.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.String"), 254, 0, "")
            Case "MD5_SIGNED"
                Return MD5_SIGNED
            Case "MD5_SIGNED.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.String"), 254, 0, "")
            Case Else
                Return False

        End Select
        Return Nothing
    End Function

    ''' <summary>
    ''' Ez abban különbözik a GetAttribute-tól, hogy DbNull.Value-t tud visszaadni. (A GetAttribute szám esetén pl. 0-t ad vissza
    ''' <summary>
    ''' <param name="p_oszlop"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overridable Function GetAttribute2(ByVal p_oszlop As String) As Object
        Dim p_valid As Boolean = True
        Select Case p_oszlop
            Case "ID"
                If ID <= 0 Then Return DBNull.Value Else Return ID
            Case "DOCTYPE"
                If DOCTYPE Is Nothing Then Return DBNull.Value Else Return IFSZ_Globals.GetInternalStringToDouble(DOCTYPE)
            Case "DOCTYPE.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.Double"), 10, 0, p_DOCTYPE_FORMAT)
            Case "CRYSTAL"
                If CRYSTAL Is Nothing Then Return DBNull.Value Else Return CRYSTAL
            Case "CRYSTAL.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.String"), 50, 0, "")
            Case "MAIL_SUBJECT"
                If MAIL_SUBJECT Is Nothing Then Return DBNull.Value Else Return MAIL_SUBJECT
            Case "MAIL_SUBJECT.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.String"), 100, 0, "")
            Case "MAIL_BODY"
                If MAIL_BODY Is Nothing Then Return DBNull.Value Else Return MAIL_BODY
            Case "MAIL_BODY.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.String"), 4000, 0, "")
            Case "FILE"
                If FILE Is Nothing Then Return DBNull.Value Else Return FILE
            Case "FILE.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.String"), 254, 0, "")
            Case "STATUS"
                If STATUS Is Nothing Then Return DBNull.Value Else Return STATUS
            Case "STATUS.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.String"), 1, 0, "")
            Case "EOH_ID"
                If EOH_ID Is Nothing Then Return DBNull.Value Else Return IFSZ_Globals.GetInternalStringToDouble(EOH_ID)
            Case "EOH_ID.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.Double"), 10, 0, p_EOH_ID_FORMAT)
            Case "LINENUM"
                If LINENUM Is Nothing Then Return DBNull.Value Else Return IFSZ_Globals.GetInternalStringToDouble(LINENUM)
            Case "LINENUM.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.Double"), 10, 0, p_LINENUM_FORMAT)
            Case "DOCENTRY"
                If DOCENTRY Is Nothing Then Return DBNull.Value Else Return IFSZ_Globals.GetInternalStringToDouble(DOCENTRY)
            Case "DOCENTRY.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.Double"), 10, 0, p_DOCENTRY_FORMAT)
            Case "DOCNUM"
                If DOCNUM Is Nothing Then Return DBNull.Value Else Return DOCNUM
            Case "DOCNUM.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.String"), 50, 0, "")
            Case "SENTTS"
                If SENTTS Is Nothing Then Return DBNull.Value Else Return IFSZ_Globals.GetInternalStringToDateTime(SENTTS)
            Case "SENTTS.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.DateTime"), 23, 3, p_SENTTS_FORMAT)
            Case "ISHTML"
                If ISHTML Is Nothing Then Return DBNull.Value Else Return ISHTML
            Case "ISHTML.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.String"), 1, 0, "")
            Case "EBIZTIP"
                If EBIZTIP Is Nothing Then Return DBNull.Value Else Return EBIZTIP
            Case "EBIZTIP.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.String"), 1, 0, "")
            Case "MD5_FILE"
                If MD5_FILE Is Nothing Then Return DBNull.Value Else Return MD5_FILE
            Case "MD5_FILE.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.String"), 254, 0, "")
            Case "MD5_SIGNED"
                If MD5_SIGNED Is Nothing Then Return DBNull.Value Else Return MD5_SIGNED
            Case "MD5_SIGNED.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.String"), 254, 0, "")
            Case Else
                Return False

        End Select
        Return Nothing
    End Function

    Public Function GetDataRow() As DataRow
        Dim l_mintatab As DataTable
        l_mintatab = DataProvider.GetDataTable("select * from IFSZ_EMAILOUTLINE where 1=2")
        Dim l_row As DataRow = l_mintatab.NewRow()

        For Each l_col As DataColumn In l_mintatab.Columns
            l_row(l_col.ColumnName) = Me.GetAttribute2(l_col.ColumnName)
        Next

        l_mintatab.Rows.Add(l_row)
        l_mintatab.AcceptChanges()
        Return l_row
    End Function

    Public Overridable Sub SetAttribute(ByVal p_oszlop As String, ByRef p_ertek As Object)
        Dim p_valid As Boolean = True
        Select Case p_oszlop
            Case "ID"
                ID(False) = p_ertek
            Case "DOCTYPE"
                If p_ertek.GetType.Name.ToLower <> "dbnull" Then
                    DOCTYPE(False) = IFSZ_Globals.GetInternalDoubleToString(p_ertek)
                Else
                    DOCTYPE(False) = Nothing
                End If
            Case "CRYSTAL"
                If p_ertek.GetType.Name.ToLower <> "dbnull" Then
                    CRYSTAL(False) = p_ertek
                Else
                    CRYSTAL(False) = Nothing
                End If
            Case "MAIL_SUBJECT"
                If p_ertek.GetType.Name.ToLower <> "dbnull" Then
                    MAIL_SUBJECT(False) = p_ertek
                Else
                    MAIL_SUBJECT(False) = Nothing
                End If
            Case "MAIL_BODY"
                If p_ertek.GetType.Name.ToLower <> "dbnull" Then
                    MAIL_BODY(False) = p_ertek
                Else
                    MAIL_BODY(False) = Nothing
                End If
            Case "FILE"
                If p_ertek.GetType.Name.ToLower <> "dbnull" Then
                    FILE(False) = p_ertek
                Else
                    FILE(False) = Nothing
                End If
            Case "STATUS"
                If p_ertek.GetType.Name.ToLower <> "dbnull" Then
                    STATUS(False) = p_ertek
                Else
                    STATUS(False) = Nothing
                End If
            Case "EOH_ID"
                If p_ertek.GetType.Name.ToLower <> "dbnull" Then
                    EOH_ID(False) = IFSZ_Globals.GetInternalDoubleToString(p_ertek)
                Else
                    EOH_ID(False) = Nothing
                End If
            Case "LINENUM"
                If p_ertek.GetType.Name.ToLower <> "dbnull" Then
                    LINENUM(False) = IFSZ_Globals.GetInternalDoubleToString(p_ertek)
                Else
                    LINENUM(False) = Nothing
                End If
            Case "DOCENTRY"
                If p_ertek.GetType.Name.ToLower <> "dbnull" Then
                    DOCENTRY(False) = IFSZ_Globals.GetInternalDoubleToString(p_ertek)
                Else
                    DOCENTRY(False) = Nothing
                End If
            Case "DOCNUM"
                If p_ertek.GetType.Name.ToLower <> "dbnull" Then
                    DOCNUM(False) = p_ertek
                Else
                    DOCNUM(False) = Nothing
                End If
            Case "SENTTS"
                If p_ertek.GetType.Name.ToLower <> "dbnull" Then
                    SENTTS(False) = IFSZ_Globals.GetInternalDateTimeToString(p_ertek)
                Else
                    SENTTS(False) = Nothing
                End If
            Case "ISHTML"
                If p_ertek.GetType.Name.ToLower <> "dbnull" Then
                    ISHTML(False) = p_ertek
                Else
                    ISHTML(False) = Nothing
                End If
            Case "EBIZTIP"
                If p_ertek.GetType.Name.ToLower <> "dbnull" Then
                    EBIZTIP(False) = p_ertek
                Else
                    EBIZTIP(False) = Nothing
                End If
            Case "MD5_FILE"
                If p_ertek.GetType.Name.ToLower <> "dbnull" Then
                    MD5_FILE(False) = p_ertek
                Else
                    MD5_FILE(False) = Nothing
                End If
            Case "MD5_SIGNED"
                If p_ertek.GetType.Name.ToLower <> "dbnull" Then
                    MD5_SIGNED(False) = p_ertek
                Else
                    MD5_SIGNED(False) = Nothing
                End If
        End Select

    End Sub

    Friend Function Val_Attribute(ByVal p_oszlop As String, ByRef p_ertek As String, ByRef p_message As String) As Boolean Implements IFSZ_IEntity.Val_Attribute
        Dim p_valid As Boolean = True
        Dim p_value As String
        Dim l_date_ertek As DateTime
        Dim l_double_ertek As Double
        Select Case p_oszlop
            Case "ID"
                p_valid = Me.Val_ID(p_ertek, p_message)
                If p_valid Then
                    ID = p_ertek
                End If
                Return p_valid
            Case "DOCTYPE"
                Dim l_ertek_string As String
                If p_ertek Is Nothing Or p_ertek = "" Then
                    l_ertek_string = Nothing
                Else
                    If Not IFSZ_Globals.FormStringToDouble(p_ertek, l_double_ertek, p_DOCTYPE_FORMAT) Then
                        p_message = IFSZ_Globals.GetString("IFSZ_01008")
                        Return False
                    End If
                    l_ertek_string = IFSZ_Globals.GetInternalDoubleToString(l_double_ertek)
                End If
                p_valid = Me.Val_DOCTYPE(l_ertek_string, p_message)
                If p_valid Then
                    DOCTYPE = l_ertek_string
                End If
                Return p_valid
            Case "DOCTYPE_MEAN"
                If p_ertek Is Nothing Or p_ertek = "" Then
                    p_valid = Me.Val_DOCTYPE(Nothing, p_message)
                    If p_valid Then
                        DOCTYPE = Nothing
                        DOCTYPE_LANGVAL = Nothing
                        DOCTYPE_MEAN = Nothing
                    End If
                Else
                    p_value = Me.p_IFSZ_Globals.m_IFSZ_Domains.GetValue("EDOC_DOCTYPE", p_ertek)
                    If p_value Is Nothing Or p_value = "" Then
                        p_message = IFSZ_Globals.GetString("IFSZ_01009", p_ertek)
                        Return False
                    End If
                    p_valid = Me.Val_DOCTYPE(p_value, p_message)
                    If p_valid Then
                        DOCTYPE = p_value
                        DOCTYPE_LANGVAL = Me.p_IFSZ_Globals.m_IFSZ_Domains.GetLangValue("EDOC_DOCTYPE", p_value)
                        DOCTYPE_MEAN = p_ertek
                    End If
                End If
                Return p_valid
            Case "DOCTYPE_LANGVAL"
                If p_ertek Is Nothing Or p_ertek = "" Then
                    p_valid = Me.Val_DOCTYPE(Nothing, p_message)
                    If p_valid Then
                        DOCTYPE = Nothing
                        DOCTYPE_LANGVAL = Nothing
                        DOCTYPE_MEAN = Nothing
                    End If
                Else
                    p_value = Me.p_IFSZ_Globals.m_IFSZ_Domains.GetLangValue("EDOC_DOCTYPE", p_ertek)
                    If p_value Is Nothing Or p_value = "" Then
                        p_message = IFSZ_Globals.GetString("IFSZ_01009", p_ertek)
                        Return False
                    End If
                    p_valid = Me.Val_DOCTYPE(p_value, p_message)
                    If p_valid Then
                        DOCTYPE = p_value
                        DOCTYPE_LANGVAL = Me.p_IFSZ_Globals.m_IFSZ_Domains.GetLangValue("EDOC_DOCTYPE", p_value)
                        DOCTYPE_MEAN = p_ertek
                    End If
                End If
                Return p_valid
            Case "CRYSTAL"
                p_valid = Me.Val_CRYSTAL(p_ertek, p_message)
                If p_valid Then
                    CRYSTAL = p_ertek
                End If
                Return p_valid
            Case "MAIL_SUBJECT"
                p_valid = Me.Val_MAIL_SUBJECT(p_ertek, p_message)
                If p_valid Then
                    MAIL_SUBJECT = p_ertek
                End If
                Return p_valid
            Case "MAIL_BODY"
                p_valid = Me.Val_MAIL_BODY(p_ertek, p_message)
                If p_valid Then
                    MAIL_BODY = p_ertek
                End If
                Return p_valid
            Case "FILE"
                p_valid = Me.Val_FILE(p_ertek, p_message)
                If p_valid Then
                    FILE = p_ertek
                End If
                Return p_valid
            Case "STATUS"
                p_valid = Me.Val_STATUS(p_ertek, p_message)
                If p_valid Then
                    STATUS = p_ertek
                End If
                Return p_valid
            Case "STATUS_MEAN"
                If p_ertek Is Nothing Or p_ertek = "" Then
                    p_valid = Me.Val_STATUS(Nothing, p_message)
                    If p_valid Then
                        STATUS = Nothing
                        STATUS_LANGVAL = Nothing
                        STATUS_MEAN = Nothing
                    End If
                Else
                    p_value = Me.p_IFSZ_Globals.m_IFSZ_Domains.GetValue("EDOC_LINE_STATUS", p_ertek)
                    If p_value Is Nothing Or p_value = "" Then
                        p_message = IFSZ_Globals.GetString("IFSZ_01009", p_ertek)
                        Return False
                    End If
                    p_valid = Me.Val_STATUS(p_value, p_message)
                    If p_valid Then
                        STATUS = p_value
                        STATUS_LANGVAL = Me.p_IFSZ_Globals.m_IFSZ_Domains.GetLangValue("EDOC_LINE_STATUS", p_value)
                        STATUS_MEAN = p_ertek
                    End If
                End If
                Return p_valid
            Case "STATUS_LANGVAL"
                If p_ertek Is Nothing Or p_ertek = "" Then
                    p_valid = Me.Val_STATUS(Nothing, p_message)
                    If p_valid Then
                        STATUS = Nothing
                        STATUS_LANGVAL = Nothing
                        STATUS_MEAN = Nothing
                    End If
                Else
                    p_value = Me.p_IFSZ_Globals.m_IFSZ_Domains.GetLangValue("EDOC_LINE_STATUS", p_ertek)
                    If p_value Is Nothing Or p_value = "" Then
                        p_message = IFSZ_Globals.GetString("IFSZ_01009", p_ertek)
                        Return False
                    End If
                    p_valid = Me.Val_STATUS(p_value, p_message)
                    If p_valid Then
                        STATUS = p_value
                        STATUS_LANGVAL = Me.p_IFSZ_Globals.m_IFSZ_Domains.GetLangValue("EDOC_LINE_STATUS", p_value)
                        STATUS_MEAN = p_ertek
                    End If
                End If
                Return p_valid
            Case "EOH_ID"
                Dim l_ertek_string As String
                If p_ertek Is Nothing Or p_ertek = "" Then
                    l_ertek_string = Nothing
                Else
                    If Not IFSZ_Globals.FormStringToDouble(p_ertek, l_double_ertek, p_EOH_ID_FORMAT) Then
                        p_message = IFSZ_Globals.GetString("IFSZ_01008")
                        Return False
                    End If
                    l_ertek_string = IFSZ_Globals.GetInternalDoubleToString(l_double_ertek)
                End If
                p_valid = Me.Val_EOH_ID(l_ertek_string, p_message)
                If p_valid Then
                    EOH_ID = l_ertek_string
                End If
                Return p_valid
            Case "LINENUM"
                Dim l_ertek_string As String
                If p_ertek Is Nothing Or p_ertek = "" Then
                    l_ertek_string = Nothing
                Else
                    If Not IFSZ_Globals.FormStringToDouble(p_ertek, l_double_ertek, p_LINENUM_FORMAT) Then
                        p_message = IFSZ_Globals.GetString("IFSZ_01008")
                        Return False
                    End If
                    l_ertek_string = IFSZ_Globals.GetInternalDoubleToString(l_double_ertek)
                End If
                p_valid = Me.Val_LINENUM(l_ertek_string, p_message)
                If p_valid Then
                    LINENUM = l_ertek_string
                End If
                Return p_valid
            Case "DOCENTRY"
                Dim l_ertek_string As String
                If p_ertek Is Nothing Or p_ertek = "" Then
                    l_ertek_string = Nothing
                Else
                    If Not IFSZ_Globals.FormStringToDouble(p_ertek, l_double_ertek, p_DOCENTRY_FORMAT) Then
                        p_message = IFSZ_Globals.GetString("IFSZ_01008")
                        Return False
                    End If
                    l_ertek_string = IFSZ_Globals.GetInternalDoubleToString(l_double_ertek)
                End If
                p_valid = Me.Val_DOCENTRY(l_ertek_string, p_message)
                If p_valid Then
                    DOCENTRY = l_ertek_string
                End If
                Return p_valid
            Case "DOCNUM"
                p_valid = Me.Val_DOCNUM(p_ertek, p_message)
                If p_valid Then
                    DOCNUM = p_ertek
                End If
                Return p_valid
            Case "SENTTS"
                Dim l_ertek_string As String
                If p_ertek Is Nothing Or p_ertek = "" Then
                    l_ertek_string = Nothing
                Else
                    If Not IFSZ_Globals.FormStringToDateTime(p_ertek, l_date_ertek, p_SENTTS_FORMAT) Then
                        p_message = IFSZ_Globals.GetString("IFSZ_01007")
                        Return False
                    End If
                    l_ertek_string = IFSZ_Globals.GetInternalDateTimeToString(l_date_ertek)
                End If
                p_valid = Me.Val_SENTTS(l_ertek_string, p_message)
                If p_valid Then
                    SENTTS = l_ertek_string
                End If
                If l_ertek_string Is Nothing Then
                    p_ertek = Nothing
                Else
                    l_date_ertek = IFSZ_Globals.GetInternalStringToDateTime(l_ertek_string)
                    p_ertek = IFSZ_Globals.DateTimeToFormString(l_date_ertek, p_SENTTS_FORMAT)
                End If
                Return p_valid
            Case "ISHTML"
                p_valid = Me.Val_ISHTML(p_ertek, p_message)
                If p_valid Then
                    ISHTML = p_ertek
                End If
                Return p_valid
            Case "ISHTML_MEAN"
                If p_ertek Is Nothing Or p_ertek = "" Then
                    p_valid = Me.Val_ISHTML(Nothing, p_message)
                    If p_valid Then
                        ISHTML = Nothing
                        ISHTML_LANGVAL = Nothing
                        ISHTML_MEAN = Nothing
                    End If
                Else
                    p_value = Me.p_IFSZ_Globals.m_IFSZ_Domains.GetValue("LOGIKAI_Y", p_ertek)
                    If p_value Is Nothing Or p_value = "" Then
                        p_message = IFSZ_Globals.GetString("IFSZ_01009", p_ertek)
                        Return False
                    End If
                    p_valid = Me.Val_ISHTML(p_value, p_message)
                    If p_valid Then
                        ISHTML = p_value
                        ISHTML_LANGVAL = Me.p_IFSZ_Globals.m_IFSZ_Domains.GetLangValue("LOGIKAI_Y", p_value)
                        ISHTML_MEAN = p_ertek
                    End If
                End If
                Return p_valid
            Case "ISHTML_LANGVAL"
                If p_ertek Is Nothing Or p_ertek = "" Then
                    p_valid = Me.Val_ISHTML(Nothing, p_message)
                    If p_valid Then
                        ISHTML = Nothing
                        ISHTML_LANGVAL = Nothing
                        ISHTML_MEAN = Nothing
                    End If
                Else
                    p_value = Me.p_IFSZ_Globals.m_IFSZ_Domains.GetLangValue("LOGIKAI_Y", p_ertek)
                    If p_value Is Nothing Or p_value = "" Then
                        p_message = IFSZ_Globals.GetString("IFSZ_01009", p_ertek)
                        Return False
                    End If
                    p_valid = Me.Val_ISHTML(p_value, p_message)
                    If p_valid Then
                        ISHTML = p_value
                        ISHTML_LANGVAL = Me.p_IFSZ_Globals.m_IFSZ_Domains.GetLangValue("LOGIKAI_Y", p_value)
                        ISHTML_MEAN = p_ertek
                    End If
                End If
                Return p_valid
            Case "EBIZTIP"
                p_valid = Me.Val_EBIZTIP(p_ertek, p_message)
                If p_valid Then
                    EBIZTIP = p_ertek
                End If
                Return p_valid
            Case "EBIZTIP_MEAN"
                If p_ertek Is Nothing Or p_ertek = "" Then
                    p_valid = Me.Val_EBIZTIP(Nothing, p_message)
                    If p_valid Then
                        EBIZTIP = Nothing
                        EBIZTIP_LANGVAL = Nothing
                        EBIZTIP_MEAN = Nothing
                    End If
                Else
                    p_value = Me.p_IFSZ_Globals.m_IFSZ_Domains.GetValue("EBIZ_ETIP", p_ertek)
                    If p_value Is Nothing Or p_value = "" Then
                        p_message = IFSZ_Globals.GetString("IFSZ_01009", p_ertek)
                        Return False
                    End If
                    p_valid = Me.Val_EBIZTIP(p_value, p_message)
                    If p_valid Then
                        EBIZTIP = p_value
                        EBIZTIP_LANGVAL = Me.p_IFSZ_Globals.m_IFSZ_Domains.GetLangValue("EBIZ_ETIP", p_value)
                        EBIZTIP_MEAN = p_ertek
                    End If
                End If
                Return p_valid
            Case "EBIZTIP_LANGVAL"
                If p_ertek Is Nothing Or p_ertek = "" Then
                    p_valid = Me.Val_EBIZTIP(Nothing, p_message)
                    If p_valid Then
                        EBIZTIP = Nothing
                        EBIZTIP_LANGVAL = Nothing
                        EBIZTIP_MEAN = Nothing
                    End If
                Else
                    p_value = Me.p_IFSZ_Globals.m_IFSZ_Domains.GetLangValue("EBIZ_ETIP", p_ertek)
                    If p_value Is Nothing Or p_value = "" Then
                        p_message = IFSZ_Globals.GetString("IFSZ_01009", p_ertek)
                        Return False
                    End If
                    p_valid = Me.Val_EBIZTIP(p_value, p_message)
                    If p_valid Then
                        EBIZTIP = p_value
                        EBIZTIP_LANGVAL = Me.p_IFSZ_Globals.m_IFSZ_Domains.GetLangValue("EBIZ_ETIP", p_value)
                        EBIZTIP_MEAN = p_ertek
                    End If
                End If
                Return p_valid
            Case "MD5_FILE"
                p_valid = Me.Val_MD5_FILE(p_ertek, p_message)
                If p_valid Then
                    MD5_FILE = p_ertek
                End If
                Return p_valid
            Case "MD5_SIGNED"
                p_valid = Me.Val_MD5_SIGNED(p_ertek, p_message)
                If p_valid Then
                    MD5_SIGNED = p_ertek
                End If
                Return p_valid
            Case Else
                Return True

        End Select

    End Function

    Friend Function Delete(ByRef p_record As Object, ByVal p_record_old As Object, Optional ByRef p_message As String = "") As Integer Implements IFSZ_IEntity.Delete
        Dim dao As New IFSZ_EMAILOUTLINEDAO

        If Not PreAutomatizmus(IFSZ_Types.DMLOperation.Delete, p_record_old, p_message, dao) Then
            Return -1
        End If
        Dim l_retval As Integer
        l_retval = dao.Delete(p_record, p_record_old, p_message)
        If l_retval = -1 Then
            p_message = IFSZ_Globals.GetString(p_message)
        Else
            If Not PostAutomatizmus(IFSZ_Types.DMLOperation.Delete, p_record_old, p_message, dao) Then
                Return -1
            End If
        End If
        Return l_retval
    End Function

    Friend Function insert(ByRef p_record As Object, Optional ByRef p_message As String = "") As Integer Implements IFSZ_IEntity.Insert
        Dim dao As New IFSZ_EMAILOUTLINEDAO
        Dim l_retval As Integer

        If Not BeforeAutomatizmus(IFSZ_Types.DMLOperation.Insert, p_record, p_message, dao) Then
            Return -1
        End If

        If CType(p_record, DataRow).Table.Columns.IndexOf("DOCTYPE") >= 0 Then
            If p_record.IsNull("DOCTYPE") Then
                If Not Val_DOCTYPE(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_DOCTYPE(IFSZ_Globals.GetInternalDoubleToString(CType(p_record, DataRow).Item("DOCTYPE")), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_DOCTYPE(Nothing, p_message) Then
                Return -1
            End If
        End If
        If CType(p_record, DataRow).Table.Columns.IndexOf("CRYSTAL") >= 0 Then
            If p_record.IsNull("CRYSTAL") Then
                If Not Val_CRYSTAL(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_CRYSTAL(CType(CType(p_record, DataRow).Item("CRYSTAL"), String), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_CRYSTAL(Nothing, p_message) Then
                Return -1
            End If
        End If
        If CType(p_record, DataRow).Table.Columns.IndexOf("MAIL_SUBJECT") >= 0 Then
            If p_record.IsNull("MAIL_SUBJECT") Then
                If Not Val_MAIL_SUBJECT(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_MAIL_SUBJECT(CType(CType(p_record, DataRow).Item("MAIL_SUBJECT"), String), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_MAIL_SUBJECT(Nothing, p_message) Then
                Return -1
            End If
        End If
        If CType(p_record, DataRow).Table.Columns.IndexOf("MAIL_BODY") >= 0 Then
            If p_record.IsNull("MAIL_BODY") Then
                If Not Val_MAIL_BODY(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_MAIL_BODY(CType(CType(p_record, DataRow).Item("MAIL_BODY"), String), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_MAIL_BODY(Nothing, p_message) Then
                Return -1
            End If
        End If
        If CType(p_record, DataRow).Table.Columns.IndexOf("FILE") >= 0 Then
            If p_record.IsNull("FILE") Then
                If Not Val_FILE(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_FILE(CType(CType(p_record, DataRow).Item("FILE"), String), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_FILE(Nothing, p_message) Then
                Return -1
            End If
        End If
        If CType(p_record, DataRow).Table.Columns.IndexOf("STATUS") >= 0 Then
            If p_record.IsNull("STATUS") Then
                p_record.Item("STATUS") = "R"
            End If
            If p_record.IsNull("STATUS") Then
                If Not Val_STATUS(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_STATUS(CType(CType(p_record, DataRow).Item("STATUS"), String), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_STATUS(Nothing, p_message) Then
                Return -1
            End If
        End If
        If CType(p_record, DataRow).Table.Columns.IndexOf("EOH_ID") >= 0 Then
            If p_record.IsNull("EOH_ID") Then
                If Not Val_EOH_ID(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_EOH_ID(IFSZ_Globals.GetInternalDoubleToString(CType(p_record, DataRow).Item("EOH_ID")), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_EOH_ID(Nothing, p_message) Then
                Return -1
            End If
        End If
        If CType(p_record, DataRow).Table.Columns.IndexOf("LINENUM") >= 0 Then
            If p_record.IsNull("LINENUM") Then
                If Not Val_LINENUM(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_LINENUM(IFSZ_Globals.GetInternalDoubleToString(CType(p_record, DataRow).Item("LINENUM")), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_LINENUM(Nothing, p_message) Then
                Return -1
            End If
        End If
        If CType(p_record, DataRow).Table.Columns.IndexOf("DOCENTRY") >= 0 Then
            If p_record.IsNull("DOCENTRY") Then
                If Not Val_DOCENTRY(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_DOCENTRY(IFSZ_Globals.GetInternalDoubleToString(CType(p_record, DataRow).Item("DOCENTRY")), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_DOCENTRY(Nothing, p_message) Then
                Return -1
            End If
        End If
        If CType(p_record, DataRow).Table.Columns.IndexOf("DOCNUM") >= 0 Then
            If p_record.IsNull("DOCNUM") Then
                If Not Val_DOCNUM(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_DOCNUM(CType(CType(p_record, DataRow).Item("DOCNUM"), String), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_DOCNUM(Nothing, p_message) Then
                Return -1
            End If
        End If
        If CType(p_record, DataRow).Table.Columns.IndexOf("SENTTS") >= 0 Then
            If p_record.IsNull("SENTTS") Then
                If Not Val_SENTTS(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_SENTTS(IFSZ_Globals.GetInternalDateTimeToString(CType(p_record, DataRow).Item("SENTTS")), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_SENTTS(Nothing, p_message) Then
                Return -1
            End If
        End If
        If CType(p_record, DataRow).Table.Columns.IndexOf("ISHTML") >= 0 Then
            If p_record.IsNull("ISHTML") Then
                p_record.Item("ISHTML") = "N"
            End If
            If p_record.IsNull("ISHTML") Then
                If Not Val_ISHTML(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_ISHTML(CType(CType(p_record, DataRow).Item("ISHTML"), String), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_ISHTML(Nothing, p_message) Then
                Return -1
            End If
        End If
        If CType(p_record, DataRow).Table.Columns.IndexOf("EBIZTIP") >= 0 Then
            If p_record.IsNull("EBIZTIP") Then
                If Not Val_EBIZTIP(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_EBIZTIP(CType(CType(p_record, DataRow).Item("EBIZTIP"), String), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_EBIZTIP(Nothing, p_message) Then
                Return -1
            End If
        End If
        If CType(p_record, DataRow).Table.Columns.IndexOf("MD5_FILE") >= 0 Then
            If p_record.IsNull("MD5_FILE") Then
                If Not Val_MD5_FILE(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_MD5_FILE(CType(CType(p_record, DataRow).Item("MD5_FILE"), String), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_MD5_FILE(Nothing, p_message) Then
                Return -1
            End If
        End If
        If CType(p_record, DataRow).Table.Columns.IndexOf("MD5_SIGNED") >= 0 Then
            If p_record.IsNull("MD5_SIGNED") Then
                If Not Val_MD5_SIGNED(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_MD5_SIGNED(CType(CType(p_record, DataRow).Item("MD5_SIGNED"), String), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_MD5_SIGNED(Nothing, p_message) Then
                Return -1
            End If
        End If

        If Not PreAutomatizmus(IFSZ_Types.DMLOperation.Insert, p_record, p_message, dao) Then
            Return -1
        End If
        l_retval = dao.Insert(p_record, p_message)
        If l_retval = -1 Then
            p_message = IFSZ_Globals.GetString(p_message)
        Else
            If Not PostAutomatizmus(IFSZ_Types.DMLOperation.Insert, p_record, p_message, dao) Then
                Return -1
            End If
        End If
        Return l_retval
    End Function

    Friend Function Update(ByRef p_record As Object, ByVal p_record_old As Object, Optional ByRef p_message As String = "") As Integer Implements IFSZ_IEntity.Update
        Dim dao As New IFSZ_EMAILOUTLINEDAO
        Dim l_retval As Integer

        If Not BeforeAutomatizmus(IFSZ_Types.DMLOperation.Update, p_record, p_message, dao, p_record_old) Then
            Return -1
        End If

        If CType(p_record, DataRow).Table.Columns.IndexOf("DOCTYPE") >= 0 Then
            If p_record.IsNull("DOCTYPE") Then
                If Not Val_DOCTYPE(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_DOCTYPE(IFSZ_Globals.GetInternalDoubleToString(CType(p_record, DataRow).Item("DOCTYPE")), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_DOCTYPE(Nothing, p_message) Then
                Return -1
            End If
        End If
        If CType(p_record, DataRow).Table.Columns.IndexOf("CRYSTAL") >= 0 Then
            If p_record.IsNull("CRYSTAL") Then
                If Not Val_CRYSTAL(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_CRYSTAL(CType(CType(p_record, DataRow).Item("CRYSTAL"), String), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_CRYSTAL(Nothing, p_message) Then
                Return -1
            End If
        End If
        If CType(p_record, DataRow).Table.Columns.IndexOf("MAIL_SUBJECT") >= 0 Then
            If p_record.IsNull("MAIL_SUBJECT") Then
                If Not Val_MAIL_SUBJECT(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_MAIL_SUBJECT(CType(CType(p_record, DataRow).Item("MAIL_SUBJECT"), String), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_MAIL_SUBJECT(Nothing, p_message) Then
                Return -1
            End If
        End If
        If CType(p_record, DataRow).Table.Columns.IndexOf("MAIL_BODY") >= 0 Then
            If p_record.IsNull("MAIL_BODY") Then
                If Not Val_MAIL_BODY(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_MAIL_BODY(CType(CType(p_record, DataRow).Item("MAIL_BODY"), String), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_MAIL_BODY(Nothing, p_message) Then
                Return -1
            End If
        End If
        If CType(p_record, DataRow).Table.Columns.IndexOf("FILE") >= 0 Then
            If p_record.IsNull("FILE") Then
                If Not Val_FILE(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_FILE(CType(CType(p_record, DataRow).Item("FILE"), String), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_FILE(Nothing, p_message) Then
                Return -1
            End If
        End If
        If CType(p_record, DataRow).Table.Columns.IndexOf("STATUS") >= 0 Then
            If p_record.IsNull("STATUS") Then
                If Not Val_STATUS(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_STATUS(CType(CType(p_record, DataRow).Item("STATUS"), String), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_STATUS(Nothing, p_message) Then
                Return -1
            End If
        End If
        If CType(p_record, DataRow).Table.Columns.IndexOf("EOH_ID") >= 0 Then
            If p_record.IsNull("EOH_ID") Then
                If Not Val_EOH_ID(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_EOH_ID(IFSZ_Globals.GetInternalDoubleToString(CType(p_record, DataRow).Item("EOH_ID")), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_EOH_ID(Nothing, p_message) Then
                Return -1
            End If
        End If
        If CType(p_record, DataRow).Table.Columns.IndexOf("LINENUM") >= 0 Then
            If p_record.IsNull("LINENUM") Then
                If Not Val_LINENUM(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_LINENUM(IFSZ_Globals.GetInternalDoubleToString(CType(p_record, DataRow).Item("LINENUM")), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_LINENUM(Nothing, p_message) Then
                Return -1
            End If
        End If
        If CType(p_record, DataRow).Table.Columns.IndexOf("DOCENTRY") >= 0 Then
            If p_record.IsNull("DOCENTRY") Then
                If Not Val_DOCENTRY(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_DOCENTRY(IFSZ_Globals.GetInternalDoubleToString(CType(p_record, DataRow).Item("DOCENTRY")), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_DOCENTRY(Nothing, p_message) Then
                Return -1
            End If
        End If
        If CType(p_record, DataRow).Table.Columns.IndexOf("DOCNUM") >= 0 Then
            If p_record.IsNull("DOCNUM") Then
                If Not Val_DOCNUM(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_DOCNUM(CType(CType(p_record, DataRow).Item("DOCNUM"), String), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_DOCNUM(Nothing, p_message) Then
                Return -1
            End If
        End If
        If CType(p_record, DataRow).Table.Columns.IndexOf("SENTTS") >= 0 Then
            If p_record.IsNull("SENTTS") Then
                If Not Val_SENTTS(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_SENTTS(IFSZ_Globals.GetInternalDateTimeToString(CType(p_record, DataRow).Item("SENTTS")), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_SENTTS(Nothing, p_message) Then
                Return -1
            End If
        End If
        If CType(p_record, DataRow).Table.Columns.IndexOf("ISHTML") >= 0 Then
            If p_record.IsNull("ISHTML") Then
                If Not Val_ISHTML(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_ISHTML(CType(CType(p_record, DataRow).Item("ISHTML"), String), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_ISHTML(Nothing, p_message) Then
                Return -1
            End If
        End If
        If CType(p_record, DataRow).Table.Columns.IndexOf("EBIZTIP") >= 0 Then
            If p_record.IsNull("EBIZTIP") Then
                If Not Val_EBIZTIP(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_EBIZTIP(CType(CType(p_record, DataRow).Item("EBIZTIP"), String), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_EBIZTIP(Nothing, p_message) Then
                Return -1
            End If
        End If
        If CType(p_record, DataRow).Table.Columns.IndexOf("MD5_FILE") >= 0 Then
            If p_record.IsNull("MD5_FILE") Then
                If Not Val_MD5_FILE(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_MD5_FILE(CType(CType(p_record, DataRow).Item("MD5_FILE"), String), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_MD5_FILE(Nothing, p_message) Then
                Return -1
            End If
        End If
        If CType(p_record, DataRow).Table.Columns.IndexOf("MD5_SIGNED") >= 0 Then
            If p_record.IsNull("MD5_SIGNED") Then
                If Not Val_MD5_SIGNED(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_MD5_SIGNED(CType(CType(p_record, DataRow).Item("MD5_SIGNED"), String), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_MD5_SIGNED(Nothing, p_message) Then
                Return -1
            End If
        End If

        If Not PreAutomatizmus(IFSZ_Types.DMLOperation.Update, p_record, p_message, dao, p_record_old) Then
            Return -1
        End If
        l_retval = dao.Update(p_record, p_record_old, p_message)
        If l_retval = -1 Then
            p_message = IFSZ_Globals.GetString(p_message)
        Else
            If Not PostAutomatizmus(IFSZ_Types.DMLOperation.Update, p_record, p_message, dao, p_record_old) Then
                Return -1
            End If
        End If
        Return l_retval
    End Function

    Public Overridable Sub create(ByRef p_record As Object) Implements IFSZ_IEntity.Create
        Me.set_item("ID", m_IFSZ_Globals.get_next_seq("DEFAULT"))
        Me.set_item("STATUS", "R")
        Me.set_item("STATUS_LANGVAL", IFSZ_Globals.LocRM.GetString("EDOC_LINE_STATUS_R_langval"))
        Me.set_item("STATUS_MEAN", IFSZ_Globals.LocRM.GetString("EDOC_LINE_STATUS_R_meaning"))
        Me.set_item("ISHTML", "N")
        Me.set_item("ISHTML_LANGVAL", IFSZ_Globals.LocRM.GetString("LOGIKAI_Y_N_langval"))
        Me.set_item("ISHTML_MEAN", IFSZ_Globals.LocRM.GetString("LOGIKAI_Y_N_meaning"))
    End Sub

    Public Overridable Sub set_row(ByVal p_row As DataRow) Implements IFSZ_IEntity.set_row
        Dim i As Integer

        For i = 0 To p_row.Table.Columns.Count - 1
            Select Case p_row.Table.Columns.Item(i).ColumnName
                Case "ID"
                    If p_row.IsNull(i) Then
                        ID(False) = Nothing
                    Else
                        ID(False) = p_row.Item(i)
                    End If
                Case "DOCTYPE"
                    If p_row.IsNull(i) Then
                        DOCTYPE(False) = Nothing
                    Else
                        DOCTYPE(False) = IFSZ_Globals.GetInternalDoubleToString(p_row.Item(i))
                    End If
                Case "CRYSTAL"
                    If p_row.IsNull(i) Then
                        CRYSTAL(False) = Nothing
                    Else
                        CRYSTAL(False) = p_row.Item(i)
                    End If
                Case "MAIL_SUBJECT"
                    If p_row.IsNull(i) Then
                        MAIL_SUBJECT(False) = Nothing
                    Else
                        MAIL_SUBJECT(False) = p_row.Item(i)
                    End If
                Case "MAIL_BODY"
                    If p_row.IsNull(i) Then
                        MAIL_BODY(False) = Nothing
                    Else
                        MAIL_BODY(False) = p_row.Item(i)
                    End If
                Case "FILE"
                    If p_row.IsNull(i) Then
                        FILE(False) = Nothing
                    Else
                        FILE(False) = p_row.Item(i)
                    End If
                Case "STATUS"
                    If p_row.IsNull(i) Then
                        STATUS(False) = Nothing
                    Else
                        STATUS(False) = p_row.Item(i)
                    End If
                Case "EOH_ID"
                    If p_row.IsNull(i) Then
                        EOH_ID(False) = Nothing
                    Else
                        EOH_ID(False) = IFSZ_Globals.GetInternalDoubleToString(p_row.Item(i))
                    End If
                Case "LINENUM"
                    If p_row.IsNull(i) Then
                        LINENUM(False) = Nothing
                    Else
                        LINENUM(False) = IFSZ_Globals.GetInternalDoubleToString(p_row.Item(i))
                    End If
                Case "DOCENTRY"
                    If p_row.IsNull(i) Then
                        DOCENTRY(False) = Nothing
                    Else
                        DOCENTRY(False) = IFSZ_Globals.GetInternalDoubleToString(p_row.Item(i))
                    End If
                Case "DOCNUM"
                    If p_row.IsNull(i) Then
                        DOCNUM(False) = Nothing
                    Else
                        DOCNUM(False) = p_row.Item(i)
                    End If
                Case "SENTTS"
                    If p_row.IsNull(i) Then
                        SENTTS(False) = Nothing
                    Else
                        SENTTS(False) = IFSZ_Globals.GetInternalDateTimeToString(p_row.Item(i))
                    End If
                Case "ISHTML"
                    If p_row.IsNull(i) Then
                        ISHTML(False) = Nothing
                    Else
                        ISHTML(False) = p_row.Item(i)
                    End If
                Case "EBIZTIP"
                    If p_row.IsNull(i) Then
                        EBIZTIP(False) = Nothing
                    Else
                        EBIZTIP(False) = p_row.Item(i)
                    End If
                Case "MD5_FILE"
                    If p_row.IsNull(i) Then
                        MD5_FILE(False) = Nothing
                    Else
                        MD5_FILE(False) = p_row.Item(i)
                    End If
                Case "MD5_SIGNED"
                    If p_row.IsNull(i) Then
                        MD5_SIGNED(False) = Nothing
                    Else
                        MD5_SIGNED(False) = p_row.Item(i)
                    End If
            End Select
        Next
    End Sub


    Public Overridable Function get_ChildTableNames() As String() Implements IFSZ_IEntity.get_ChildTableNames
        Return Me.p_ChildTableNames
    End Function

    Public Overridable Function get_DataTable(ByVal p_where As String) As System.Data.DataTable Implements IFSZ_IEntity.get_DataTable
        Dim p_query As String
        If p_where = "" Then
            p_query = Me.p_SqlQuery
        Else
            p_query = Me.p_SqlQuery & p_where
        End If
        Return DataProvider.GetDataTable(p_query)

    End Function

    Public Overridable Function getChildEntity(ByVal p_TableName As String) As IFSZ_IEntity Implements IFSZ_IEntity.getChildEntity
        Return Nothing
    End Function

#End Region

#Region "Privates"

    Protected Overridable Function Val_ID(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        Return True
    End Function

    Protected Overridable Function Val_DOCTYPE(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        If Not p_ertek Is Nothing And p_ertek <> "" Then
            If Not Me.m_IFSZ_Globals.m_IFSZ_Domains.ValDomainValue("EDOC_DOCTYPE", p_ertek) Then
                Dim l_ertek As String = Me.m_IFSZ_Globals.m_IFSZ_Domains.GetValue("EDOC_DOCTYPE", p_ertek)
                If l_ertek Is Nothing Then
                    p_message = IFSZ_Globals.GetString("IFSZ_01009", p_ertek)
                    Return False
                Else
                    p_ertek = l_ertek
                End If
            End If
        End If
        'Alapvető validálás karakterek száma, hossz, formázásra vonatkozóan
        Dim l_format As IFSZ_Types.EntityFieldType = Me.GetAttribute("DOCTYPE.TYPE")
        If Not p_ertek Is Nothing And p_ertek <> "" And l_format.MaximumLength > 0 Then
            If IFSZ_Globals.GetInternalStringToDouble(p_ertek) >= Math.Pow(10, l_format.MaximumLength - l_format.DecimalPlaces) Then
                p_message = IFSZ_Globals.GetString("DIGITS_OVERRUN", (l_format.MaximumLength - l_format.DecimalPlaces).ToString, l_format.DecimalPlaces.ToString)
                Return False
            End If
        End If
        Return CustVal_DOCTYPE(p_ertek, p_message)
    End Function

    Protected Overridable Function Val_CRYSTAL(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        'Alapvető validálás karakterek száma, hossz, formázásra vonatkozóan
        Dim l_format As IFSZ_Types.EntityFieldType = Me.GetAttribute("CRYSTAL.TYPE")
        If Not p_ertek Is Nothing And p_ertek <> "" And l_format.MaximumLength > 0 Then
            If p_ertek.Length > l_format.MaximumLength Then
                p_message = IFSZ_Globals.GetString("CHARLEN_OVERRUN", l_format.MaximumLength.ToString)
                Return False
            End If
        End If
        Return CustVal_CRYSTAL(p_ertek, p_message)
    End Function

    Protected Overridable Function Val_MAIL_SUBJECT(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        'Alapvető validálás karakterek száma, hossz, formázásra vonatkozóan
        Dim l_format As IFSZ_Types.EntityFieldType = Me.GetAttribute("MAIL_SUBJECT.TYPE")
        If Not p_ertek Is Nothing And p_ertek <> "" And l_format.MaximumLength > 0 Then
            If p_ertek.Length > l_format.MaximumLength Then
                p_message = IFSZ_Globals.GetString("CHARLEN_OVERRUN", l_format.MaximumLength.ToString)
                Return False
            End If
        End If
        Return CustVal_MAIL_SUBJECT(p_ertek, p_message)
    End Function

    Protected Overridable Function Val_MAIL_BODY(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        'Alapvető validálás karakterek száma, hossz, formázásra vonatkozóan
        Dim l_format As IFSZ_Types.EntityFieldType = Me.GetAttribute("MAIL_BODY.TYPE")
        If Not p_ertek Is Nothing And p_ertek <> "" And l_format.MaximumLength > 0 Then
            If p_ertek.Length > l_format.MaximumLength Then
                p_message = IFSZ_Globals.GetString("CHARLEN_OVERRUN", l_format.MaximumLength.ToString)
                Return False
            End If
        End If
        Return CustVal_MAIL_BODY(p_ertek, p_message)
    End Function

    Protected Overridable Function Val_FILE(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        'Alapvető validálás karakterek száma, hossz, formázásra vonatkozóan
        Dim l_format As IFSZ_Types.EntityFieldType = Me.GetAttribute("FILE.TYPE")
        If Not p_ertek Is Nothing And p_ertek <> "" And l_format.MaximumLength > 0 Then
            If p_ertek.Length > l_format.MaximumLength Then
                p_message = IFSZ_Globals.GetString("CHARLEN_OVERRUN", l_format.MaximumLength.ToString)
                Return False
            End If
        End If
        Return CustVal_FILE(p_ertek, p_message)
    End Function

    Protected Overridable Function Val_STATUS(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        If Not p_ertek Is Nothing And p_ertek <> "" Then
            If Not Me.m_IFSZ_Globals.m_IFSZ_Domains.ValDomainValue("EDOC_LINE_STATUS", p_ertek) Then
                Dim l_ertek As String = Me.m_IFSZ_Globals.m_IFSZ_Domains.GetValue("EDOC_LINE_STATUS", p_ertek)
                If l_ertek Is Nothing Then
                    p_message = IFSZ_Globals.GetString("IFSZ_01009", p_ertek)
                    Return False
                Else
                    p_ertek = l_ertek
                End If
            End If
        End If
        'Alapvető validálás karakterek száma, hossz, formázásra vonatkozóan
        Dim l_format As IFSZ_Types.EntityFieldType = Me.GetAttribute("STATUS.TYPE")
        If Not p_ertek Is Nothing And p_ertek <> "" And l_format.MaximumLength > 0 Then
            If p_ertek.Length > l_format.MaximumLength Then
                p_message = IFSZ_Globals.GetString("CHARLEN_OVERRUN", l_format.MaximumLength.ToString)
                Return False
            End If
        End If
        Return CustVal_STATUS(p_ertek, p_message)
    End Function

    Protected Overridable Function Val_EOH_ID(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        'Alapvető validálás karakterek száma, hossz, formázásra vonatkozóan
        Dim l_format As IFSZ_Types.EntityFieldType = Me.GetAttribute("EOH_ID.TYPE")
        If Not p_ertek Is Nothing And p_ertek <> "" And l_format.MaximumLength > 0 Then
            If IFSZ_Globals.GetInternalStringToDouble(p_ertek) >= Math.Pow(10, l_format.MaximumLength - l_format.DecimalPlaces) Then
                p_message = IFSZ_Globals.GetString("DIGITS_OVERRUN", (l_format.MaximumLength - l_format.DecimalPlaces).ToString, l_format.DecimalPlaces.ToString)
                Return False
            End If
        End If
        Return CustVal_EOH_ID(p_ertek, p_message)
    End Function

    Protected Overridable Function Val_LINENUM(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        'Alapvető validálás karakterek száma, hossz, formázásra vonatkozóan
        Dim l_format As IFSZ_Types.EntityFieldType = Me.GetAttribute("LINENUM.TYPE")
        If Not p_ertek Is Nothing And p_ertek <> "" And l_format.MaximumLength > 0 Then
            If IFSZ_Globals.GetInternalStringToDouble(p_ertek) >= Math.Pow(10, l_format.MaximumLength - l_format.DecimalPlaces) Then
                p_message = IFSZ_Globals.GetString("DIGITS_OVERRUN", (l_format.MaximumLength - l_format.DecimalPlaces).ToString, l_format.DecimalPlaces.ToString)
                Return False
            End If
        End If
        Return CustVal_LINENUM(p_ertek, p_message)
    End Function

    Protected Overridable Function Val_DOCENTRY(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        'Alapvető validálás karakterek száma, hossz, formázásra vonatkozóan
        Dim l_format As IFSZ_Types.EntityFieldType = Me.GetAttribute("DOCENTRY.TYPE")
        If Not p_ertek Is Nothing And p_ertek <> "" And l_format.MaximumLength > 0 Then
            If IFSZ_Globals.GetInternalStringToDouble(p_ertek) >= Math.Pow(10, l_format.MaximumLength - l_format.DecimalPlaces) Then
                p_message = IFSZ_Globals.GetString("DIGITS_OVERRUN", (l_format.MaximumLength - l_format.DecimalPlaces).ToString, l_format.DecimalPlaces.ToString)
                Return False
            End If
        End If
        Return CustVal_DOCENTRY(p_ertek, p_message)
    End Function

    Protected Overridable Function Val_DOCNUM(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        'Alapvető validálás karakterek száma, hossz, formázásra vonatkozóan
        Dim l_format As IFSZ_Types.EntityFieldType = Me.GetAttribute("DOCNUM.TYPE")
        If Not p_ertek Is Nothing And p_ertek <> "" And l_format.MaximumLength > 0 Then
            If p_ertek.Length > l_format.MaximumLength Then
                p_message = IFSZ_Globals.GetString("CHARLEN_OVERRUN", l_format.MaximumLength.ToString)
                Return False
            End If
        End If
        Return CustVal_DOCNUM(p_ertek, p_message)
    End Function

    Protected Overridable Function Val_SENTTS(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        Return CustVal_SENTTS(p_ertek, p_message)
    End Function

    Protected Overridable Function Val_ISHTML(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        Select Case p_ertek
            Case "False"
                p_ertek = "N"
            Case "True"
                p_ertek = "I"
        End Select
        If Not p_ertek Is Nothing And p_ertek <> "" Then
            If Not Me.m_IFSZ_Globals.m_IFSZ_Domains.ValDomainValue("LOGIKAI_Y", p_ertek) Then
                Dim l_ertek As String = Me.m_IFSZ_Globals.m_IFSZ_Domains.GetValue("LOGIKAI_Y", p_ertek)
                If l_ertek Is Nothing Then
                    p_message = IFSZ_Globals.GetString("IFSZ_01009", p_ertek)
                    Return False
                Else
                    p_ertek = l_ertek
                End If
            End If
        End If
        'Alapvető validálás karakterek száma, hossz, formázásra vonatkozóan
        Dim l_format As IFSZ_Types.EntityFieldType = Me.GetAttribute("ISHTML.TYPE")
        If Not p_ertek Is Nothing And p_ertek <> "" And l_format.MaximumLength > 0 Then
            If p_ertek.Length > l_format.MaximumLength Then
                p_message = IFSZ_Globals.GetString("CHARLEN_OVERRUN", l_format.MaximumLength.ToString)
                Return False
            End If
        End If
        Return CustVal_ISHTML(p_ertek, p_message)
    End Function

    Protected Overridable Function Val_EBIZTIP(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        If p_ertek Is Nothing Or p_ertek = "" Then
            p_message = IFSZ_Globals.GetString("NOTNULL", IFSZ_Globals.GetPrompt("IFSZ_EMAILOUTLINE", "EBIZTIP", IFSZ_Types.EGetPromptTypes.Prompt))
            Return False
        End If
        If Not p_ertek Is Nothing And p_ertek <> "" Then
            If Not Me.m_IFSZ_Globals.m_IFSZ_Domains.ValDomainValue("EBIZ_ETIP", p_ertek) Then
                Dim l_ertek As String = Me.m_IFSZ_Globals.m_IFSZ_Domains.GetValue("EBIZ_ETIP", p_ertek)
                If l_ertek Is Nothing Then
                    p_message = IFSZ_Globals.GetString("IFSZ_01009", p_ertek)
                    Return False
                Else
                    p_ertek = l_ertek
                End If
            End If
        End If
        'Alapvető validálás karakterek száma, hossz, formázásra vonatkozóan
        Dim l_format As IFSZ_Types.EntityFieldType = Me.GetAttribute("EBIZTIP.TYPE")
        If Not p_ertek Is Nothing And p_ertek <> "" And l_format.MaximumLength > 0 Then
            If p_ertek.Length > l_format.MaximumLength Then
                p_message = IFSZ_Globals.GetString("CHARLEN_OVERRUN", l_format.MaximumLength.ToString)
                Return False
            End If
        End If
        Return CustVal_EBIZTIP(p_ertek, p_message)
    End Function

    Protected Overridable Function Val_MD5_FILE(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        'Alapvető validálás karakterek száma, hossz, formázásra vonatkozóan
        Dim l_format As IFSZ_Types.EntityFieldType = Me.GetAttribute("MD5_FILE.TYPE")
        If Not p_ertek Is Nothing And p_ertek <> "" And l_format.MaximumLength > 0 Then
            If p_ertek.Length > l_format.MaximumLength Then
                p_message = IFSZ_Globals.GetString("CHARLEN_OVERRUN", l_format.MaximumLength.ToString)
                Return False
            End If
        End If
        Return CustVal_MD5_FILE(p_ertek, p_message)
    End Function

    Protected Overridable Function Val_MD5_SIGNED(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        'Alapvető validálás karakterek száma, hossz, formázásra vonatkozóan
        Dim l_format As IFSZ_Types.EntityFieldType = Me.GetAttribute("MD5_SIGNED.TYPE")
        If Not p_ertek Is Nothing And p_ertek <> "" And l_format.MaximumLength > 0 Then
            If p_ertek.Length > l_format.MaximumLength Then
                p_message = IFSZ_Globals.GetString("CHARLEN_OVERRUN", l_format.MaximumLength.ToString)
                Return False
            End If
        End If
        Return CustVal_MD5_SIGNED(p_ertek, p_message)
    End Function

    Protected Overridable Sub set_item(ByVal p_oszlop As String, ByVal p_ertek As Object) Implements IFSZ_IEntity.set_item
        Dim l_rowindex As Integer
        Dim l_ertek As Object

        l_ertek = p_ertek
        If p_ertek Is Nothing Then
            l_ertek = DBNull.Value
        Else
            If p_ertek.GetType.Name = "String" Then
                If p_ertek = "" Then
                    l_ertek = DBNull.Value
                End If
            End If
        End If

        'Me.p_form.p_dataset.Tables.Item(TableName).Rows.Item(Me.p_form.BindingContext(Me.p_form.p_dataset, TableName).Position()).Item(p_oszlop) = _ertek
        If Me.p_form IsNot Nothing Then
            If Me.p_form.BindingContext(Me.p_form.p_dataset, TableName).Position > -1 Then
                Dim l_row As DataRow
                If Me.p_form.BindingContext(Me.p_form.p_dataset, TableName).Current.GetType Is GetType(DataRowView) Then
                    l_row = CType(Me.p_form.BindingContext(Me.p_form.p_dataset, TableName).Current, DataRowView).Row
                ElseIf Me.p_form.BindingContext(Me.p_form.p_dataset, TableName).Current.GetType Is GetType(DataRow) Then
                    l_row = Me.p_form.BindingContext(Me.p_form.p_dataset, TableName).Current
                Else
                    l_row = Nothing
                End If
                If l_row IsNot Nothing AndAlso l_row.Table.Columns.Contains(p_oszlop) Then
                    l_row.Item(p_oszlop) = l_ertek
                End If
            End If
        End If

        'l_rowindex = Me.p_form.p_dataset.Tables.Item(TableName).Rows.IndexOf(Me.p_form.BindingContext(Me.p_form.p_dataset, TableName).Current.Row)
        'Me.p_form.p_dataset.Tables.Item(TableName).Rows.Item(l_rowindex).Item(p_oszlop) = l_ertek
        Me.SetAttribute(p_oszlop, l_ertek)
    End Sub

    Friend Sub set_item(ByVal p_oszlop As String, ByVal p_ertek As Object, ByVal p_StatusChange As Boolean)
        Dim l_rowindex As Integer
        Dim l_ertek As Object

        l_ertek = p_ertek
        If p_ertek Is Nothing Then
            l_ertek = DBNull.Value
        Else
            If p_ertek.GetType.Name = "String" Then
                If p_ertek = "" Then
                    l_ertek = DBNull.Value
                End If
            End If
        End If

        If Me.p_form IsNot Nothing Then
            If Me.p_form.BindingContext(Me.p_form.p_dataset, TableName).Position > -1 Then
                Dim l_row As DataRow
                If Me.p_form.BindingContext(Me.p_form.p_dataset, TableName).Current.GetType Is GetType(DataRowView) Then
                    l_row = CType(Me.p_form.BindingContext(Me.p_form.p_dataset, TableName).Current, DataRowView).Row
                ElseIf Me.p_form.BindingContext(Me.p_form.p_dataset, TableName).Current.GetType Is GetType(DataRow) Then
                    l_row = Me.p_form.BindingContext(Me.p_form.p_dataset, TableName).Current
                Else
                    l_row = Nothing
                End If
                If l_row IsNot Nothing AndAlso l_row.Table.Columns.Contains(p_oszlop) Then
                    l_row.Item(p_oszlop) = l_ertek
                End If
            End If
        End If
        Me.SetAttribute(p_oszlop, l_ertek)
    End Sub

#End Region


    Public Overridable Function get_ChildRows(ByVal p_TableName As String, ByVal p_FK_ID As Integer, Optional ByVal p_FkOszlop As String = "", Optional ByVal p_where As String = "") As System.Data.DataRowCollection Implements IFSZ_IEntity.get_ChildRows
        Dim p_row As DataRow
        Dim p_message As String
        Try
        Catch ex As Exception
            MsgBox(ex.ToString, MsgBoxStyle.OkCancel, "Hiba!")
            Return Nothing
        End Try

    End Function

    Public Overridable Function get_DataRow(ByVal p_ID As Integer) As System.Data.DataRow Implements IFSZ_IEntity.get_DataRow
        Dim p_row As DataRow
        Dim p_message As String
        Dim p_IFSZ_EMAILOUTLINE As IFSZ_EMAILOUTLINEDAO = New IFSZ_EMAILOUTLINEDAO
        Try
            p_row = p_IFSZ_EMAILOUTLINE.get_DataRecord(p_ID, p_message)
            Return p_row
        Catch ex As Exception
            MsgBox(ex.ToString, MsgBoxStyle.OkCancel, "Hiba!")
            Return Nothing
        End Try
    End Function

    Public Overridable Function get_DataRows(ByVal p_where As String) As System.Data.DataRowCollection Implements IFSZ_IEntity.get_DataRows
        Dim p_row As DataRowCollection
        Dim p_message As String
        Dim p_IFSZ_EMAILOUTLINE As IFSZ_EMAILOUTLINEDAO = New IFSZ_EMAILOUTLINEDAO
        Try
            p_row = p_IFSZ_EMAILOUTLINE.get_DataRecords(p_where, p_message)
            Return p_row
        Catch ex As Exception
            MsgBox(ex.ToString, MsgBoxStyle.OkCancel, "Hiba!")
            Return Nothing
        End Try
    End Function


    Public Overridable Function get_ParentTableNames() As String() Implements IFSZ_IEntity.get_ParentTableNames
        Return Nothing
    End Function

    Public Overridable Function getParentEntity(ByVal p_TableName As String) As IFSZ_IEntity Implements IFSZ_IEntity.getParentEntity
        Return (Nothing)
    End Function

    Public Overridable Function get_ParentRow(ByVal p_TableName As String, ByVal p_ID As String) As System.Data.DataRow Implements IFSZ_IEntity.get_ParentRow
        Return Nothing
    End Function

    Public Property ChildRelation() As IFSZ_Types.Relations Implements IFSZ_IEntity.ChildRelation
        Get
            Return Me.p_ChildRelations
        End Get
        Set(ByVal value As IFSZ_Types.Relations)
            Me.p_ChildRelations = value
        End Set
    End Property

    Public Property PrimaryKey() As IFSZ_Types.PrimaryKeys Implements IFSZ_IEntity.PrimaryKey
        Get
            Return Me.p_PrimaryKey
        End Get
        Set(ByVal value As IFSZ_Types.PrimaryKeys)
            Me.p_PrimaryKey = value
        End Set
    End Property

    Public Property m_IFSZ_Globals() As IFSZ_Globals Implements IFSZ_IEntity.m_IFSZ_Globals
        Get
            Return Me.p_IFSZ_Globals
        End Get
        Set(ByVal value As IFSZ_Globals)
            Me.p_IFSZ_Globals = value
        End Set
    End Property

    Public Overridable Function GetAttributeDomain(ByVal p_oszlop As String) As Object Implements IFSZ_IEntity.GetAttributeDomain
        Dim p_valid As Boolean = True
        Select Case p_oszlop
            Case "DOCTYPE_MEAN"
                Return Me.m_IFSZ_Globals.m_IFSZ_Domains.GetDomain("EDOC_DOCTYPE")
            Case "DOCTYPE_LANGVAL"
                Return Me.m_IFSZ_Globals.m_IFSZ_Domains.GetDomain("EDOC_DOCTYPE")
            Case "STATUS_MEAN"
                Return Me.m_IFSZ_Globals.m_IFSZ_Domains.GetDomain("EDOC_LINE_STATUS")
            Case "STATUS_LANGVAL"
                Return Me.m_IFSZ_Globals.m_IFSZ_Domains.GetDomain("EDOC_LINE_STATUS")
            Case "ISHTML_MEAN"
                Return Me.m_IFSZ_Globals.m_IFSZ_Domains.GetDomain("LOGIKAI_Y")
            Case "ISHTML_LANGVAL"
                Return Me.m_IFSZ_Globals.m_IFSZ_Domains.GetDomain("LOGIKAI_Y")
            Case "EBIZTIP_MEAN"
                Return Me.m_IFSZ_Globals.m_IFSZ_Domains.GetDomain("EBIZ_ETIP")
            Case "EBIZTIP_LANGVAL"
                Return Me.m_IFSZ_Globals.m_IFSZ_Domains.GetDomain("EBIZ_ETIP")
            Case Else
                Return Nothing
        End Select
        Return Nothing
    End Function

    Function GetAttributeType(ByVal p_oszlop As String) As String Implements IFSZ_IEntity.GetAttributeType
        Select Case p_oszlop
            Case "ID"
                Return "NUMBER"
            Case "DOCTYPE"
                Return "NUMBER"
            Case "CRYSTAL"
                Return "VARCHAR"
            Case "MAIL_SUBJECT"
                Return "VARCHAR"
            Case "MAIL_BODY"
                Return "VARCHAR"
            Case "FILE"
                Return "VARCHAR"
            Case "STATUS"
                Return "VARCHAR"
            Case "EOH_ID"
                Return "NUMBER"
            Case "LINENUM"
                Return "NUMBER"
            Case "DOCENTRY"
                Return "NUMBER"
            Case "DOCNUM"
                Return "VARCHAR"
            Case "SENTTS"
                Return "DATE"
            Case "ISHTML"
                Return "VARCHAR"
            Case "EBIZTIP"
                Return "VARCHAR"
            Case "MD5_FILE"
                Return "VARCHAR"
            Case "MD5_SIGNED"
                Return "VARCHAR"
        End Select
        Return "VARCHAR"
    End Function

    Public Overridable Property ArchivEnabled() As Boolean Implements IFSZ_IEntity.ArchivEnabled
        Get

        End Get
        Set(ByVal value As Boolean)

        End Set
    End Property

    Public Overridable Property ArchivFormTipus() As IFSZ_Types.LOV_Form Implements IFSZ_IEntity.ArchivFormTipus
        Get

        End Get
        Set(ByVal value As IFSZ_Types.LOV_Form)

        End Set
    End Property

    Public Overridable Property ArchivKey() As IFSZ_Types.PrimaryKeys Implements IFSZ_IEntity.ArchivKey
        Get

        End Get
        Set(ByVal value As IFSZ_Types.PrimaryKeys)

        End Set
    End Property

    Public Overridable Property ArchivOszlopTipus() As IFSZ_Types.LOV_OszlopTipus() Implements IFSZ_IEntity.ArchivOszlopTipus
        Get

        End Get
        Set(ByVal value As IFSZ_Types.LOV_OszlopTipus())

        End Set
    End Property

    Public Overridable Property ArchivQuery() As String Implements IFSZ_IEntity.ArchivQuery
        Get

        End Get
        Set(ByVal value As String)

        End Set
    End Property

    Public Property ViewName() As String Implements IFSZ_IEntity.ViewName
        Get
            Return p_ViewName
        End Get
        Set(ByVal value As String)
            p_ViewName = value
        End Set
    End Property

    Public Property LastQuery() As String Implements IFSZ_IEntity.LastQuery
        Get
            Return p_LastQuery
        End Get
        Set(ByVal value As String)
            p_LastQuery = value
        End Set
    End Property

#Region "Saját kódok"

    Protected Overridable Sub FormatumBeallitas()
        p_DOCTYPE_FORMAT = ""
        p_EOH_ID_FORMAT = ""
        p_LINENUM_FORMAT = ""
        p_DOCENTRY_FORMAT = ""
        p_SENTTS_FORMAT = ""
    End Sub

    Protected Overridable Function CustVal_DOCTYPE(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        Return True
    End Function

    Protected Overridable Function CustVal_CRYSTAL(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        Return True
    End Function

    Protected Overridable Function CustVal_MAIL_SUBJECT(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        Return True
    End Function

    Protected Overridable Function CustVal_MAIL_BODY(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        Return True
    End Function

    Protected Overridable Function CustVal_FILE(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        Return True
    End Function

    Protected Overridable Function CustVal_STATUS(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        Return True
    End Function

    Protected Overridable Function CustVal_EOH_ID(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        Return True
    End Function

    Protected Overridable Function CustVal_LINENUM(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        Return True
    End Function

    Protected Overridable Function CustVal_DOCENTRY(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        Return True
    End Function

    Protected Overridable Function CustVal_DOCNUM(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        Return True
    End Function

    Protected Overridable Function CustVal_SENTTS(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        Return True
    End Function

    Protected Overridable Function CustVal_ISHTML(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        Return True
    End Function

    Protected Overridable Function CustVal_EBIZTIP(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        Return True
    End Function

    Protected Overridable Function CustVal_MD5_FILE(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        Return True
    End Function

    Protected Overridable Function CustVal_MD5_SIGNED(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        Return True
    End Function


    ''' <summary>
    ''' Az insert/update eljárások legelején hívódik meg, amikor még nem történtek meg az oszloponkénti validálások
    ''' </summary>
    ''' <param name="p_op"></param>
    ''' <param name="p_record"></param>
    ''' <param name="p_message"></param>
    ''' <param name="p_dao"></param>
    ''' <param name="p_record_old"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Protected Overridable Function BeforeAutomatizmus(ByVal p_op As IFSZ_Types.DMLOperation, ByRef p_record As Object, ByRef p_message As String, ByRef p_dao As IFSZ_EMAILOUTLINEDAO, Optional ByRef p_record_old As DataRowView = Nothing) As Boolean

        Return True
    End Function

    ''' <summary>
    ''' Közvetlenül az insert/update/delete előtt hívódik meg, az utolsó ellenőrzések, automatikus adattöltések történhetnek itt
    ''' </summary>
    ''' <param name="p_op"></param>
    ''' <param name="p_record"></param>
    ''' <param name="p_message"></param>
    ''' <param name="p_dao"></param>
    ''' <param name="p_record_old"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Protected Overridable Function PreAutomatizmus(ByVal p_op As IFSZ_Types.DMLOperation, ByRef p_record As Object, ByRef p_message As String, ByRef p_dao As IFSZ_EMAILOUTLINEDAO, Optional ByRef p_record_old As DataRowView = Nothing) As Boolean

        Return True
    End Function

    ''' <summary>
    ''' Közvetlenül a sikeres insert/update/delete után hívódik meg.
    ''' Itt már az adatok az adatbázisban vannak, de ha false-szal térünk vissza, akkor rollbackelődni fog
    ''' </summary>
    ''' <param name="p_op"></param>
    ''' <param name="p_record"></param>
    ''' <param name="p_message"></param>
    ''' <param name="p_dao"></param>
    ''' <param name="p_record_old"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Protected Overridable Function PostAutomatizmus(ByVal p_op As IFSZ_Types.DMLOperation, ByRef p_record As Object, ByRef p_message As String, ByRef p_dao As IFSZ_EMAILOUTLINEDAO, Optional ByRef p_record_old As DataRowView = Nothing) As Boolean

        Return True
    End Function

#End Region

End Class
