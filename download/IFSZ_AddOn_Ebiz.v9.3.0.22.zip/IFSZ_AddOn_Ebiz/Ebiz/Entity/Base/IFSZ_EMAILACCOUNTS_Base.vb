﻿'----------------------------------------------------------------------------'
'GENERÁLT FÁJL!!!! NE MÓDOSÍTSD!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
'----------------------------------------------------------------------------'
'Generálva: 2021.01.23
'EntityGenerator - számára. Verzió: 1.1.16.10
'
'entitygenerator2 xml EMAILOUT C:\svn\gergo\modulok\IFSZ_AddOn_Ebiz\IFSZ_AddOn_Ebiz\Ebiz\Entity IFSZ_EMAILACCOUNTS
'
'Paraméterek:
'Workarea/Xml file név: H:\SBO\Fejlesztes\Work\Repository\XmlRepository.xml
'Alkalmazásrendszer: EMAILOUT
'Könyvtár: C:\svn\gergo\modulok\IFSZ_AddOn_Ebiz\IFSZ_AddOn_Ebiz\Ebiz\Entity\
'Tábla neve: IFSZ_EMAILACCOUNTS
'
'
'----------------------------------------------------------------------------'

'----------------------------------------------------------------------------'
' create view "IFSZ_EMAILACCOUNTS" as select "Code" as ID, "U_NAME" as "NAME", "U_SMTP_SERVER" as "SMTP_SERVER", "U_SMTP_PORT" as "SMTP_PORT", "U_USERNAME" as "USERNAME", "U_PASSWORD" as "PASSWORD", "U_SSL" as "SSL" from "@IFSZ_EMAILACCOUNTS"
'----------------------------------------------------------------------------'

Imports System
Imports System.Resources.ResourceReader
Imports System.Collections
Imports System.Text
Imports IFSZ_AddOnBase


Public Class IFSZ_EMAILACCOUNTS_Base
    'Inherits ObjectDataBinding.BaseClasses.FSBindingItem
    Implements IFSZ_IEntity

#Region "Variables"
    Protected p_ID As Integer
    Protected p_NAME As String
    Protected p_SMTP_SERVER As String
    Protected p_SMTP_PORT As String
    Protected p_SMTP_PORT_FORMAT As String = ""
    Protected p_USERNAME As String
    Protected p_PASSWORD As String
    Protected p_SSL As String
    Protected p_SSL_LANGVAL As String
    Protected p_SSL_MEAN As String
    Protected p_tablanev As String
    Protected p_ChildWhere As String
    Protected p_DefaultWhere As String
    Protected p_LastWhere As String
    Protected p_LastQuery As String
    Protected p_ViewName As String
    Protected p_LastPosition As String
    Protected p_NewRowEnabled As Boolean = True
    Protected p_IFSZ_Globals As IFSZ_Globals
    Protected p_Columns() As String = {"ID", "NAME", "SMTP_SERVER", "SMTP_PORT", "USERNAME", "PASSWORD", "SSL"}
    Protected p_form As IFSZ_Form
    Protected p_ChildTableNames(0) As String
    Protected p_ChildRelations As IFSZ_Types.Relations
    Protected p_PrimaryKey As IFSZ_Types.PrimaryKeys = New IFSZ_Types.PrimaryKeys
    Protected p_SqlQuery As String = "Select ID, NAME, SMTP_SERVER, SMTP_PORT, USERNAME, PASSWORD, SSL From IFSZ_EMAILACCOUNTS "
    Protected MyCultureInfo As System.Globalization.CultureInfo = New System.Globalization.CultureInfo("en-gb")
#End Region


#Region "Konstruktor"

    Public Sub New(ByRef pGlobal As IFSZ_Globals)
        m_IFSZ_Globals = pGlobal
        FormatumBeallitas()
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef pGlobal As IFSZ_Globals)
        m_IFSZ_Globals = pGlobal
        If entity Is Nothing Then
            ReDim Preserve entity(0)
        Else
            ReDim Preserve entity(entity.GetUpperBound(0) + 1)
        End If
        entity(entity.GetUpperBound(0)) = Me
        Me.TableName = "IFSZ_EMAILACCOUNTS"
        FormatumBeallitas()
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef l_form As IFSZ_Form)
        If entity Is Nothing Then
            ReDim Preserve entity(0)
        Else
            ReDim Preserve entity(entity.GetUpperBound(0) + 1)
        End If
        entity(entity.GetUpperBound(0)) = Me
        Me.TableName = "IFSZ_EMAILACCOUNTS"
        Me.p_form = l_form
        FormatumBeallitas()
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef l_form As IFSZ_Form, ByRef pGlobal As IFSZ_Globals)
        If entity Is Nothing Then
            ReDim Preserve entity(0)
        Else
            ReDim Preserve entity(entity.GetUpperBound(0) + 1)
        End If
        m_IFSZ_Globals = pGlobal
        entity(entity.GetUpperBound(0)) = Me
        Me.TableName = "IFSZ_EMAILACCOUNTS"
        Me.p_form = l_form
        FormatumBeallitas()
    End Sub

    Public Sub New(ByRef pGlobal As IFSZ_Globals, ByVal p_TableName As String)
        m_IFSZ_Globals = pGlobal
        Me.TableName = p_TableName
        FormatumBeallitas()
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef pGlobal As IFSZ_Globals, ByVal p_TableName As String)
        m_IFSZ_Globals = pGlobal
        If entity Is Nothing Then
            ReDim Preserve entity(0)
        Else
            ReDim Preserve entity(entity.GetUpperBound(0) + 1)
        End If
        entity(entity.GetUpperBound(0)) = Me
        Me.TableName = "IFSZ_EMAILACCOUNTS"
        Me.TableName = p_TableName
        FormatumBeallitas()
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef l_form As IFSZ_Form, ByVal p_TableName As String)
        If entity Is Nothing Then
            ReDim Preserve entity(0)
        Else
            ReDim Preserve entity(entity.GetUpperBound(0) + 1)
        End If
        entity(entity.GetUpperBound(0)) = Me
        Me.TableName = "IFSZ_EMAILACCOUNTS"
        Me.p_form = l_form
        Me.TableName = p_TableName
        FormatumBeallitas()
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef l_form As IFSZ_Form, ByRef pGlobal As IFSZ_Globals, ByVal p_TableName As String)
        If entity Is Nothing Then
            ReDim Preserve entity(0)
        Else
            ReDim Preserve entity(entity.GetUpperBound(0) + 1)
        End If
        m_IFSZ_Globals = pGlobal
        entity(entity.GetUpperBound(0)) = Me
        Me.TableName = "IFSZ_EMAILACCOUNTS"
        Me.p_form = l_form
        Me.TableName = p_TableName
        FormatumBeallitas()
    End Sub

#End Region

#Region "Property"

    Public Property TableName() As String Implements IFSZ_IEntity.TableName
        Get
            Return p_tablanev
        End Get
        Set(ByVal value As String)
            p_tablanev = value
        End Set
    End Property

    Public ReadOnly Property Columns() As String() Implements IFSZ_IEntity.Columns
        Get
            Return Me.p_Columns
        End Get
    End Property

    Public Property ChildWhere() As String Implements IFSZ_IEntity.ChildWhere
        Get
            Return p_ChildWhere
        End Get
        Set(ByVal value As String)
            p_ChildWhere = value
        End Set
    End Property

    Public Property DefaultWhere() As String Implements IFSZ_IEntity.DefaultWhere
        Get
            Return p_DefaultWhere
        End Get
        Set(ByVal value As String)
            p_DefaultWhere = value
        End Set
    End Property

    Public Property LastWhere() As String Implements IFSZ_IEntity.LastWhere
        Get
            Return p_LastWhere
        End Get
        Set(ByVal value As String)
            p_LastWhere = value
        End Set
    End Property

    Public Property LastPosition() As Integer Implements IFSZ_IEntity.LastPosition
        Get
            Return p_LastPosition
        End Get
        Set(ByVal value As Integer)
            p_LastPosition = value
        End Set
    End Property

    Public Property NewRowEnabled() As Boolean Implements IFSZ_IEntity.NewRowEnabled
        Get
            Return p_NewRowEnabled
        End Get
        Set(ByVal value As Boolean)
            p_NewRowEnabled = value
        End Set
    End Property

    Protected Property ID(Optional ByVal p_visible As Boolean = True) As Integer
        Get
            Return p_ID
        End Get
        Set(ByVal value As Integer)
            p_ID = value
            If p_visible Then
                Me.set_item("ID", value)
            End If
        End Set
    End Property

    Protected Property NAME(Optional ByVal p_visible As Boolean = True) As String
        Get
            Return p_NAME
        End Get
        Set(ByVal value As String)
            If Not value Is Nothing And value <> "" Then
                p_NAME = value
                If p_visible Then
                    Me.set_item("NAME", value)
                End If
            Else
                p_NAME = Nothing
                If p_visible Then
                    Me.set_item("NAME", DBNull.Value)
                End If
            End If
        End Set
    End Property

    Protected Property SMTP_SERVER(Optional ByVal p_visible As Boolean = True) As String
        Get
            Return p_SMTP_SERVER
        End Get
        Set(ByVal value As String)
            If Not value Is Nothing And value <> "" Then
                p_SMTP_SERVER = value
                If p_visible Then
                    Me.set_item("SMTP_SERVER", value)
                End If
            Else
                p_SMTP_SERVER = Nothing
                If p_visible Then
                    Me.set_item("SMTP_SERVER", DBNull.Value)
                End If
            End If
        End Set
    End Property

    Protected Property SMTP_PORT(Optional ByVal p_visible As Boolean = True) As String
        Get
            Return p_SMTP_PORT
        End Get
        Set(ByVal value As String)
            If Not value Is Nothing And value <> "" Then
                p_SMTP_PORT = value
                If p_visible Then
                    Me.set_item("SMTP_PORT", IFSZ_Globals.GetInternalStringToDouble(value))
                End If
            Else
                p_SMTP_PORT = Nothing
                If p_visible Then
                    Me.set_item("SMTP_PORT", DBNull.Value)
                End If
            End If
        End Set
    End Property

    Friend Property SMTP_PORT_FORMAT() As String
        Get
            Return p_SMTP_PORT_FORMAT
        End Get
        Set(ByVal value As String)
            p_SMTP_PORT_FORMAT = value
        End Set
    End Property

    Protected Property USERNAME(Optional ByVal p_visible As Boolean = True) As String
        Get
            Return p_USERNAME
        End Get
        Set(ByVal value As String)
            If Not value Is Nothing And value <> "" Then
                p_USERNAME = value
                If p_visible Then
                    Me.set_item("USERNAME", value)
                End If
            Else
                p_USERNAME = Nothing
                If p_visible Then
                    Me.set_item("USERNAME", DBNull.Value)
                End If
            End If
        End Set
    End Property

    Protected Property PASSWORD(Optional ByVal p_visible As Boolean = True) As String
        Get
            Return p_PASSWORD
        End Get
        Set(ByVal value As String)
            If Not value Is Nothing And value <> "" Then
                p_PASSWORD = value
                If p_visible Then
                    Me.set_item("PASSWORD", value)
                End If
            Else
                p_PASSWORD = Nothing
                If p_visible Then
                    Me.set_item("PASSWORD", DBNull.Value)
                End If
            End If
        End Set
    End Property

    Protected Property SSL(Optional ByVal p_visible As Boolean = True) As String
        Get
            Return p_SSL
        End Get
        Set(ByVal value As String)
            Dim l_value As String
            If Not value Is Nothing And value <> "" Then
                Select Case value
                    Case "False"
                        l_value = "N"
                    Case "True"
                        l_value = "I"
                    Case Else
                        l_value = value
                End Select
                p_SSL = l_value
                If p_visible Then
                    Me.set_item("SSL", l_value)
                End If
            Else
                p_SSL = Nothing
                If p_visible Then
                    Me.set_item("SSL", DBNull.Value)
                End If
            End If
        End Set
    End Property

    Protected Property SSL_LANGVAL(Optional ByVal p_visible As Boolean = True) As String
        Get
            Return p_SSL_LANGVAL
        End Get
        Set(ByVal value As String)
            p_SSL_LANGVAL = value
            If p_visible Then
                Me.set_item("SSL_LANGVAL", value)
            End If
        End Set
    End Property

    Protected Property SSL_MEAN(Optional ByVal p_visible As Boolean = True) As String
        Get
            Return p_SSL_MEAN
        End Get
        Set(ByVal value As String)
            p_SSL_MEAN = value
            If p_visible Then
                Me.set_item("SSL_MEAN", value)
            End If
        End Set
    End Property

#End Region

#Region "Implements"


    Public Overridable Function GetAttribute(ByVal p_oszlop As String) As Object Implements IFSZ_IEntity.GetAttribute
        Dim p_valid As Boolean = True
        Select Case p_oszlop
            Case "ID"
                Return ID
            Case "NAME"
                Return NAME
            Case "NAME.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.String"), 50, 0, "")
            Case "SMTP_SERVER"
                Return SMTP_SERVER
            Case "SMTP_SERVER.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.String"), 50, 0, "")
            Case "SMTP_PORT"
                Return IFSZ_Globals.GetInternalStringToDouble(SMTP_PORT)
            Case "SMTP_PORT.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.Double"), 10, 0, p_SMTP_PORT_FORMAT)
            Case "USERNAME"
                Return USERNAME
            Case "USERNAME.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.String"), 50, 0, "")
            Case "PASSWORD"
                Return PASSWORD
            Case "PASSWORD.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.String"), 254, 0, "")
            Case "SSL"
                Return SSL
            Case "SSL.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.String"), 1, 0, "")
            Case Else
                Return False

        End Select
        Return Nothing
    End Function

    ''' <summary>
    ''' Ez abban különbözik a GetAttribute-tól, hogy DbNull.Value-t tud visszaadni. (A GetAttribute szám esetén pl. 0-t ad vissza
    ''' <summary>
    ''' <param name="p_oszlop"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overridable Function GetAttribute2(ByVal p_oszlop As String) As Object
        Dim p_valid As Boolean = True
        Select Case p_oszlop
            Case "ID"
                If ID <= 0 Then Return DBNull.Value Else Return ID
            Case "NAME"
                If NAME Is Nothing Then Return DBNull.Value Else Return NAME
            Case "NAME.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.String"), 50, 0, "")
            Case "SMTP_SERVER"
                If SMTP_SERVER Is Nothing Then Return DBNull.Value Else Return SMTP_SERVER
            Case "SMTP_SERVER.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.String"), 50, 0, "")
            Case "SMTP_PORT"
                If SMTP_PORT Is Nothing Then Return DBNull.Value Else Return IFSZ_Globals.GetInternalStringToDouble(SMTP_PORT)
            Case "SMTP_PORT.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.Double"), 10, 0, p_SMTP_PORT_FORMAT)
            Case "USERNAME"
                If USERNAME Is Nothing Then Return DBNull.Value Else Return USERNAME
            Case "USERNAME.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.String"), 50, 0, "")
            Case "PASSWORD"
                If PASSWORD Is Nothing Then Return DBNull.Value Else Return PASSWORD
            Case "PASSWORD.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.String"), 254, 0, "")
            Case "SSL"
                If SSL Is Nothing Then Return DBNull.Value Else Return SSL
            Case "SSL.TYPE"
                Return New IFSZ_Types.EntityFieldType(Type.GetType("System.String"), 1, 0, "")
            Case Else
                Return False

        End Select
        Return Nothing
    End Function

    Public Function GetDataRow() As DataRow
        Dim l_mintatab As DataTable
        l_mintatab = DataProvider.GetDataTable("select * from IFSZ_EMAILACCOUNTS where 1=2")
        Dim l_row As DataRow = l_mintatab.NewRow()

        For Each l_col As DataColumn In l_mintatab.Columns
            l_row(l_col.ColumnName) = Me.GetAttribute2(l_col.ColumnName)
        Next

        l_mintatab.Rows.Add(l_row)
        l_mintatab.AcceptChanges()
        Return l_row
    End Function

    Public Overridable Sub SetAttribute(ByVal p_oszlop As String, ByRef p_ertek As Object)
        Dim p_valid As Boolean = True
        Select Case p_oszlop
            Case "ID"
                ID(False) = p_ertek
            Case "NAME"
                If p_ertek.GetType.Name.ToLower <> "dbnull" Then
                    NAME(False) = p_ertek
                Else
                    NAME(False) = Nothing
                End If
            Case "SMTP_SERVER"
                If p_ertek.GetType.Name.ToLower <> "dbnull" Then
                    SMTP_SERVER(False) = p_ertek
                Else
                    SMTP_SERVER(False) = Nothing
                End If
            Case "SMTP_PORT"
                If p_ertek.GetType.Name.ToLower <> "dbnull" Then
                    SMTP_PORT(False) = IFSZ_Globals.GetInternalDoubleToString(p_ertek)
                Else
                    SMTP_PORT(False) = Nothing
                End If
            Case "USERNAME"
                If p_ertek.GetType.Name.ToLower <> "dbnull" Then
                    USERNAME(False) = p_ertek
                Else
                    USERNAME(False) = Nothing
                End If
            Case "PASSWORD"
                If p_ertek.GetType.Name.ToLower <> "dbnull" Then
                    PASSWORD(False) = p_ertek
                Else
                    PASSWORD(False) = Nothing
                End If
            Case "SSL"
                If p_ertek.GetType.Name.ToLower <> "dbnull" Then
                    SSL(False) = p_ertek
                Else
                    SSL(False) = Nothing
                End If
        End Select

    End Sub

    Friend Function Val_Attribute(ByVal p_oszlop As String, ByRef p_ertek As String, ByRef p_message As String) As Boolean Implements IFSZ_IEntity.Val_Attribute
        Dim p_valid As Boolean = True
        Dim p_value As String
        Dim l_date_ertek As DateTime
        Dim l_double_ertek As Double
        Select Case p_oszlop
            Case "ID"
                p_valid = Me.Val_ID(p_ertek, p_message)
                If p_valid Then
                    ID = p_ertek
                End If
                Return p_valid
            Case "NAME"
                p_valid = Me.Val_NAME(p_ertek, p_message)
                If p_valid Then
                    NAME = p_ertek
                End If
                Return p_valid
            Case "SMTP_SERVER"
                p_valid = Me.Val_SMTP_SERVER(p_ertek, p_message)
                If p_valid Then
                    SMTP_SERVER = p_ertek
                End If
                Return p_valid
            Case "SMTP_PORT"
                Dim l_ertek_string As String
                If p_ertek Is Nothing Or p_ertek = "" Then
                    l_ertek_string = Nothing
                Else
                    If Not IFSZ_Globals.FormStringToDouble(p_ertek, l_double_ertek, p_SMTP_PORT_FORMAT) Then
                        p_message = IFSZ_Globals.GetString("IFSZ_01008")
                        Return False
                    End If
                    l_ertek_string = IFSZ_Globals.GetInternalDoubleToString(l_double_ertek)
                End If
                p_valid = Me.Val_SMTP_PORT(l_ertek_string, p_message)
                If p_valid Then
                    SMTP_PORT = l_ertek_string
                End If
                Return p_valid
            Case "USERNAME"
                p_valid = Me.Val_USERNAME(p_ertek, p_message)
                If p_valid Then
                    USERNAME = p_ertek
                End If
                Return p_valid
            Case "PASSWORD"
                p_valid = Me.Val_PASSWORD(p_ertek, p_message)
                If p_valid Then
                    PASSWORD = p_ertek
                End If
                Return p_valid
            Case "SSL"
                p_valid = Me.Val_SSL(p_ertek, p_message)
                If p_valid Then
                    SSL = p_ertek
                End If
                Return p_valid
            Case "SSL_MEAN"
                If p_ertek Is Nothing Or p_ertek = "" Then
                    p_valid = Me.Val_SSL(Nothing, p_message)
                    If p_valid Then
                        SSL = Nothing
                        SSL_LANGVAL = Nothing
                        SSL_MEAN = Nothing
                    End If
                Else
                    p_value = Me.p_IFSZ_Globals.m_IFSZ_Domains.GetValue("LOGIKAI", p_ertek)
                    If p_value Is Nothing Or p_value = "" Then
                        p_message = IFSZ_Globals.GetString("IFSZ_01009", p_ertek)
                        Return False
                    End If
                    p_valid = Me.Val_SSL(p_value, p_message)
                    If p_valid Then
                        SSL = p_value
                        SSL_LANGVAL = Me.p_IFSZ_Globals.m_IFSZ_Domains.GetLangValue("LOGIKAI", p_value)
                        SSL_MEAN = p_ertek
                    End If
                End If
                Return p_valid
            Case "SSL_LANGVAL"
                If p_ertek Is Nothing Or p_ertek = "" Then
                    p_valid = Me.Val_SSL(Nothing, p_message)
                    If p_valid Then
                        SSL = Nothing
                        SSL_LANGVAL = Nothing
                        SSL_MEAN = Nothing
                    End If
                Else
                    p_value = Me.p_IFSZ_Globals.m_IFSZ_Domains.GetLangValue("LOGIKAI", p_ertek)
                    If p_value Is Nothing Or p_value = "" Then
                        p_message = IFSZ_Globals.GetString("IFSZ_01009", p_ertek)
                        Return False
                    End If
                    p_valid = Me.Val_SSL(p_value, p_message)
                    If p_valid Then
                        SSL = p_value
                        SSL_LANGVAL = Me.p_IFSZ_Globals.m_IFSZ_Domains.GetLangValue("LOGIKAI", p_value)
                        SSL_MEAN = p_ertek
                    End If
                End If
                Return p_valid
            Case Else
                Return True

        End Select

    End Function

    Friend Function Delete(ByRef p_record As Object, ByVal p_record_old As Object, Optional ByRef p_message As String = "") As Integer Implements IFSZ_IEntity.Delete
        Dim dao As New IFSZ_EMAILACCOUNTSDAO

        If Not PreAutomatizmus(IFSZ_Types.DMLOperation.Delete, p_record_old, p_message, dao) Then
            Return -1
        End If
        Dim l_retval As Integer
        l_retval = dao.Delete(p_record, p_record_old, p_message)
        If l_retval = -1 Then
            p_message = IFSZ_Globals.GetString(p_message)
        Else
            If Not PostAutomatizmus(IFSZ_Types.DMLOperation.Delete, p_record_old, p_message, dao) Then
                Return -1
            End If
        End If
        Return l_retval
    End Function

    Friend Function insert(ByRef p_record As Object, Optional ByRef p_message As String = "") As Integer Implements IFSZ_IEntity.Insert
        Dim dao As New IFSZ_EMAILACCOUNTSDAO
        Dim l_retval As Integer

        If Not BeforeAutomatizmus(IFSZ_Types.DMLOperation.Insert, p_record, p_message, dao) Then
            Return -1
        End If

        If CType(p_record, DataRow).Table.Columns.IndexOf("NAME") >= 0 Then
            If p_record.IsNull("NAME") Then
                If Not Val_NAME(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_NAME(CType(CType(p_record, DataRow).Item("NAME"), String), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_NAME(Nothing, p_message) Then
                Return -1
            End If
        End If
        If CType(p_record, DataRow).Table.Columns.IndexOf("SMTP_SERVER") >= 0 Then
            If p_record.IsNull("SMTP_SERVER") Then
                If Not Val_SMTP_SERVER(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_SMTP_SERVER(CType(CType(p_record, DataRow).Item("SMTP_SERVER"), String), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_SMTP_SERVER(Nothing, p_message) Then
                Return -1
            End If
        End If
        If CType(p_record, DataRow).Table.Columns.IndexOf("SMTP_PORT") >= 0 Then
            If p_record.IsNull("SMTP_PORT") Then
                If Not Val_SMTP_PORT(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_SMTP_PORT(IFSZ_Globals.GetInternalDoubleToString(CType(p_record, DataRow).Item("SMTP_PORT")), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_SMTP_PORT(Nothing, p_message) Then
                Return -1
            End If
        End If
        If CType(p_record, DataRow).Table.Columns.IndexOf("USERNAME") >= 0 Then
            If p_record.IsNull("USERNAME") Then
                If Not Val_USERNAME(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_USERNAME(CType(CType(p_record, DataRow).Item("USERNAME"), String), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_USERNAME(Nothing, p_message) Then
                Return -1
            End If
        End If
        If CType(p_record, DataRow).Table.Columns.IndexOf("PASSWORD") >= 0 Then
            If p_record.IsNull("PASSWORD") Then
                If Not Val_PASSWORD(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_PASSWORD(CType(CType(p_record, DataRow).Item("PASSWORD"), String), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_PASSWORD(Nothing, p_message) Then
                Return -1
            End If
        End If
        If CType(p_record, DataRow).Table.Columns.IndexOf("SSL") >= 0 Then
            If p_record.IsNull("SSL") Then
                p_record.Item("SSL") = "I"
            End If
            If p_record.IsNull("SSL") Then
                If Not Val_SSL(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_SSL(CType(CType(p_record, DataRow).Item("SSL"), String), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_SSL(Nothing, p_message) Then
                Return -1
            End If
        End If

        If Not PreAutomatizmus(IFSZ_Types.DMLOperation.Insert, p_record, p_message, dao) Then
            Return -1
        End If
        l_retval = dao.Insert(p_record, p_message)
        If l_retval = -1 Then
            p_message = IFSZ_Globals.GetString(p_message)
        Else
            If Not PostAutomatizmus(IFSZ_Types.DMLOperation.Insert, p_record, p_message, dao) Then
                Return -1
            End If
        End If
        Return l_retval
    End Function

    Friend Function Update(ByRef p_record As Object, ByVal p_record_old As Object, Optional ByRef p_message As String = "") As Integer Implements IFSZ_IEntity.Update
        Dim dao As New IFSZ_EMAILACCOUNTSDAO
        Dim l_retval As Integer

        If Not BeforeAutomatizmus(IFSZ_Types.DMLOperation.Update, p_record, p_message, dao, p_record_old) Then
            Return -1
        End If

        If CType(p_record, DataRow).Table.Columns.IndexOf("NAME") >= 0 Then
            If p_record.IsNull("NAME") Then
                If Not Val_NAME(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_NAME(CType(CType(p_record, DataRow).Item("NAME"), String), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_NAME(Nothing, p_message) Then
                Return -1
            End If
        End If
        If CType(p_record, DataRow).Table.Columns.IndexOf("SMTP_SERVER") >= 0 Then
            If p_record.IsNull("SMTP_SERVER") Then
                If Not Val_SMTP_SERVER(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_SMTP_SERVER(CType(CType(p_record, DataRow).Item("SMTP_SERVER"), String), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_SMTP_SERVER(Nothing, p_message) Then
                Return -1
            End If
        End If
        If CType(p_record, DataRow).Table.Columns.IndexOf("SMTP_PORT") >= 0 Then
            If p_record.IsNull("SMTP_PORT") Then
                If Not Val_SMTP_PORT(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_SMTP_PORT(IFSZ_Globals.GetInternalDoubleToString(CType(p_record, DataRow).Item("SMTP_PORT")), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_SMTP_PORT(Nothing, p_message) Then
                Return -1
            End If
        End If
        If CType(p_record, DataRow).Table.Columns.IndexOf("USERNAME") >= 0 Then
            If p_record.IsNull("USERNAME") Then
                If Not Val_USERNAME(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_USERNAME(CType(CType(p_record, DataRow).Item("USERNAME"), String), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_USERNAME(Nothing, p_message) Then
                Return -1
            End If
        End If
        If CType(p_record, DataRow).Table.Columns.IndexOf("PASSWORD") >= 0 Then
            If p_record.IsNull("PASSWORD") Then
                If Not Val_PASSWORD(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_PASSWORD(CType(CType(p_record, DataRow).Item("PASSWORD"), String), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_PASSWORD(Nothing, p_message) Then
                Return -1
            End If
        End If
        If CType(p_record, DataRow).Table.Columns.IndexOf("SSL") >= 0 Then
            If p_record.IsNull("SSL") Then
                If Not Val_SSL(Nothing, p_message) Then
                    Return -1
                End If
            Else
                If Not Val_SSL(CType(CType(p_record, DataRow).Item("SSL"), String), p_message) Then
                    Return -1
                End If
            End If
        Else
            If Not Val_SSL(Nothing, p_message) Then
                Return -1
            End If
        End If

        If Not PreAutomatizmus(IFSZ_Types.DMLOperation.Update, p_record, p_message, dao, p_record_old) Then
            Return -1
        End If
        l_retval = dao.Update(p_record, p_record_old, p_message)
        If l_retval = -1 Then
            p_message = IFSZ_Globals.GetString(p_message)
        Else
            If Not PostAutomatizmus(IFSZ_Types.DMLOperation.Update, p_record, p_message, dao, p_record_old) Then
                Return -1
            End If
        End If
        Return l_retval
    End Function

    Public Overridable Sub create(ByRef p_record As Object) Implements IFSZ_IEntity.Create
        Me.set_item("ID", m_IFSZ_Globals.get_next_seq("DEFAULT"))
        Me.set_item("SSL", "I")
        Me.set_item("SSL_LANGVAL", IFSZ_Globals.LocRM.GetString("LOGIKAI_I_langval"))
        Me.set_item("SSL_MEAN", IFSZ_Globals.LocRM.GetString("LOGIKAI_I_meaning"))
    End Sub

    Public Overridable Sub set_row(ByVal p_row As DataRow) Implements IFSZ_IEntity.set_row
        Dim i As Integer

        For i = 0 To p_row.Table.Columns.Count - 1
            Select Case p_row.Table.Columns.Item(i).ColumnName
                Case "ID"
                    If p_row.IsNull(i) Then
                        ID(False) = Nothing
                    Else
                        ID(False) = p_row.Item(i)
                    End If
                Case "NAME"
                    If p_row.IsNull(i) Then
                        NAME(False) = Nothing
                    Else
                        NAME(False) = p_row.Item(i)
                    End If
                Case "SMTP_SERVER"
                    If p_row.IsNull(i) Then
                        SMTP_SERVER(False) = Nothing
                    Else
                        SMTP_SERVER(False) = p_row.Item(i)
                    End If
                Case "SMTP_PORT"
                    If p_row.IsNull(i) Then
                        SMTP_PORT(False) = Nothing
                    Else
                        SMTP_PORT(False) = IFSZ_Globals.GetInternalDoubleToString(p_row.Item(i))
                    End If
                Case "USERNAME"
                    If p_row.IsNull(i) Then
                        USERNAME(False) = Nothing
                    Else
                        USERNAME(False) = p_row.Item(i)
                    End If
                Case "PASSWORD"
                    If p_row.IsNull(i) Then
                        PASSWORD(False) = Nothing
                    Else
                        PASSWORD(False) = p_row.Item(i)
                    End If
                Case "SSL"
                    If p_row.IsNull(i) Then
                        SSL(False) = Nothing
                    Else
                        SSL(False) = p_row.Item(i)
                    End If
            End Select
        Next
    End Sub


    Public Overridable Function get_ChildTableNames() As String() Implements IFSZ_IEntity.get_ChildTableNames
        Return Me.p_ChildTableNames
    End Function

    Public Overridable Function get_DataTable(ByVal p_where As String) As System.Data.DataTable Implements IFSZ_IEntity.get_DataTable
        Dim p_query As String
        If p_where = "" Then
            p_query = Me.p_SqlQuery
        Else
            p_query = Me.p_SqlQuery & p_where
        End If
        Return DataProvider.GetDataTable(p_query)

    End Function

    Public Overridable Function getChildEntity(ByVal p_TableName As String) As IFSZ_IEntity Implements IFSZ_IEntity.getChildEntity
        Return Nothing
    End Function

#End Region

#Region "Privates"

    Protected Overridable Function Val_ID(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        Return True
    End Function

    Protected Overridable Function Val_NAME(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        'Alapvető validálás karakterek száma, hossz, formázásra vonatkozóan
        Dim l_format As IFSZ_Types.EntityFieldType = Me.GetAttribute("NAME.TYPE")
        If Not p_ertek Is Nothing And p_ertek <> "" And l_format.MaximumLength > 0 Then
            If p_ertek.Length > l_format.MaximumLength Then
                p_message = IFSZ_Globals.GetString("CHARLEN_OVERRUN", l_format.MaximumLength.ToString)
                Return False
            End If
        End If
        Return CustVal_NAME(p_ertek, p_message)
    End Function

    Protected Overridable Function Val_SMTP_SERVER(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        'Alapvető validálás karakterek száma, hossz, formázásra vonatkozóan
        Dim l_format As IFSZ_Types.EntityFieldType = Me.GetAttribute("SMTP_SERVER.TYPE")
        If Not p_ertek Is Nothing And p_ertek <> "" And l_format.MaximumLength > 0 Then
            If p_ertek.Length > l_format.MaximumLength Then
                p_message = IFSZ_Globals.GetString("CHARLEN_OVERRUN", l_format.MaximumLength.ToString)
                Return False
            End If
        End If
        Return CustVal_SMTP_SERVER(p_ertek, p_message)
    End Function

    Protected Overridable Function Val_SMTP_PORT(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        'Alapvető validálás karakterek száma, hossz, formázásra vonatkozóan
        Dim l_format As IFSZ_Types.EntityFieldType = Me.GetAttribute("SMTP_PORT.TYPE")
        If Not p_ertek Is Nothing And p_ertek <> "" And l_format.MaximumLength > 0 Then
            If IFSZ_Globals.GetInternalStringToDouble(p_ertek) >= Math.Pow(10, l_format.MaximumLength - l_format.DecimalPlaces) Then
                p_message = IFSZ_Globals.GetString("DIGITS_OVERRUN", (l_format.MaximumLength - l_format.DecimalPlaces).ToString, l_format.DecimalPlaces.ToString)
                Return False
            End If
        End If
        Return CustVal_SMTP_PORT(p_ertek, p_message)
    End Function

    Protected Overridable Function Val_USERNAME(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        'Alapvető validálás karakterek száma, hossz, formázásra vonatkozóan
        Dim l_format As IFSZ_Types.EntityFieldType = Me.GetAttribute("USERNAME.TYPE")
        If Not p_ertek Is Nothing And p_ertek <> "" And l_format.MaximumLength > 0 Then
            If p_ertek.Length > l_format.MaximumLength Then
                p_message = IFSZ_Globals.GetString("CHARLEN_OVERRUN", l_format.MaximumLength.ToString)
                Return False
            End If
        End If
        Return CustVal_USERNAME(p_ertek, p_message)
    End Function

    Protected Overridable Function Val_PASSWORD(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        'Alapvető validálás karakterek száma, hossz, formázásra vonatkozóan
        Dim l_format As IFSZ_Types.EntityFieldType = Me.GetAttribute("PASSWORD.TYPE")
        If Not p_ertek Is Nothing And p_ertek <> "" And l_format.MaximumLength > 0 Then
            If p_ertek.Length > l_format.MaximumLength Then
                p_message = IFSZ_Globals.GetString("CHARLEN_OVERRUN", l_format.MaximumLength.ToString)
                Return False
            End If
        End If
        Return CustVal_PASSWORD(p_ertek, p_message)
    End Function

    Protected Overridable Function Val_SSL(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        Select Case p_ertek
            Case "False"
                p_ertek = "N"
            Case "True"
                p_ertek = "I"
        End Select
        If p_ertek Is Nothing Or p_ertek = "" Then
            p_message = IFSZ_Globals.GetString("NOTNULL", IFSZ_Globals.GetPrompt("IFSZ_EMAILACCOUNTS", "SSL", IFSZ_Types.EGetPromptTypes.Prompt))
            Return False
        End If
        If Not p_ertek Is Nothing And p_ertek <> "" Then
            If Not Me.m_IFSZ_Globals.m_IFSZ_Domains.ValDomainValue("LOGIKAI", p_ertek) Then
                Dim l_ertek As String = Me.m_IFSZ_Globals.m_IFSZ_Domains.GetValue("LOGIKAI", p_ertek)
                If l_ertek Is Nothing Then
                    p_message = IFSZ_Globals.GetString("IFSZ_01009", p_ertek)
                    Return False
                Else
                    p_ertek = l_ertek
                End If
            End If
        End If
        'Alapvető validálás karakterek száma, hossz, formázásra vonatkozóan
        Dim l_format As IFSZ_Types.EntityFieldType = Me.GetAttribute("SSL.TYPE")
        If Not p_ertek Is Nothing And p_ertek <> "" And l_format.MaximumLength > 0 Then
            If p_ertek.Length > l_format.MaximumLength Then
                p_message = IFSZ_Globals.GetString("CHARLEN_OVERRUN", l_format.MaximumLength.ToString)
                Return False
            End If
        End If
        Return CustVal_SSL(p_ertek, p_message)
    End Function

    Protected Overridable Sub set_item(ByVal p_oszlop As String, ByVal p_ertek As Object) Implements IFSZ_IEntity.set_item
        Dim l_rowindex As Integer
        Dim l_ertek As Object

        l_ertek = p_ertek
        If p_ertek Is Nothing Then
            l_ertek = DBNull.Value
        Else
            If p_ertek.GetType.Name = "String" Then
                If p_ertek = "" Then
                    l_ertek = DBNull.Value
                End If
            End If
        End If

        'Me.p_form.p_dataset.Tables.Item(TableName).Rows.Item(Me.p_form.BindingContext(Me.p_form.p_dataset, TableName).Position()).Item(p_oszlop) = _ertek
        If Me.p_form IsNot Nothing Then
            If Me.p_form.BindingContext(Me.p_form.p_dataset, TableName).Position > -1 Then
                Dim l_row As DataRow
                If Me.p_form.BindingContext(Me.p_form.p_dataset, TableName).Current.GetType Is GetType(DataRowView) Then
                    l_row = CType(Me.p_form.BindingContext(Me.p_form.p_dataset, TableName).Current, DataRowView).Row
                ElseIf Me.p_form.BindingContext(Me.p_form.p_dataset, TableName).Current.GetType Is GetType(DataRow) Then
                    l_row = Me.p_form.BindingContext(Me.p_form.p_dataset, TableName).Current
                Else
                    l_row = Nothing
                End If
                If l_row IsNot Nothing AndAlso l_row.Table.Columns.Contains(p_oszlop) Then
                    l_row.Item(p_oszlop) = l_ertek
                End If
            End If
        End If

        'l_rowindex = Me.p_form.p_dataset.Tables.Item(TableName).Rows.IndexOf(Me.p_form.BindingContext(Me.p_form.p_dataset, TableName).Current.Row)
        'Me.p_form.p_dataset.Tables.Item(TableName).Rows.Item(l_rowindex).Item(p_oszlop) = l_ertek
        Me.SetAttribute(p_oszlop, l_ertek)
    End Sub

    Friend Sub set_item(ByVal p_oszlop As String, ByVal p_ertek As Object, ByVal p_StatusChange As Boolean)
        Dim l_rowindex As Integer
        Dim l_ertek As Object

        l_ertek = p_ertek
        If p_ertek Is Nothing Then
            l_ertek = DBNull.Value
        Else
            If p_ertek.GetType.Name = "String" Then
                If p_ertek = "" Then
                    l_ertek = DBNull.Value
                End If
            End If
        End If

        If Me.p_form IsNot Nothing Then
            If Me.p_form.BindingContext(Me.p_form.p_dataset, TableName).Position > -1 Then
                Dim l_row As DataRow
                If Me.p_form.BindingContext(Me.p_form.p_dataset, TableName).Current.GetType Is GetType(DataRowView) Then
                    l_row = CType(Me.p_form.BindingContext(Me.p_form.p_dataset, TableName).Current, DataRowView).Row
                ElseIf Me.p_form.BindingContext(Me.p_form.p_dataset, TableName).Current.GetType Is GetType(DataRow) Then
                    l_row = Me.p_form.BindingContext(Me.p_form.p_dataset, TableName).Current
                Else
                    l_row = Nothing
                End If
                If l_row IsNot Nothing AndAlso l_row.Table.Columns.Contains(p_oszlop) Then
                    l_row.Item(p_oszlop) = l_ertek
                End If
            End If
        End If
        Me.SetAttribute(p_oszlop, l_ertek)
    End Sub

#End Region


    Public Overridable Function get_ChildRows(ByVal p_TableName As String, ByVal p_FK_ID As Integer, Optional ByVal p_FkOszlop As String = "", Optional ByVal p_where As String = "") As System.Data.DataRowCollection Implements IFSZ_IEntity.get_ChildRows
        Dim p_row As DataRow
        Dim p_message As String
        Try
        Catch ex As Exception
            MsgBox(ex.ToString, MsgBoxStyle.OkCancel, "Hiba!")
            Return Nothing
        End Try

    End Function

    Public Overridable Function get_DataRow(ByVal p_ID As Integer) As System.Data.DataRow Implements IFSZ_IEntity.get_DataRow
        Dim p_row As DataRow
        Dim p_message As String
        Dim p_IFSZ_EMAILACCOUNTS As IFSZ_EMAILACCOUNTSDAO = New IFSZ_EMAILACCOUNTSDAO
        Try
            p_row = p_IFSZ_EMAILACCOUNTS.get_DataRecord(p_ID, p_message)
            Return p_row
        Catch ex As Exception
            MsgBox(ex.ToString, MsgBoxStyle.OkCancel, "Hiba!")
            Return Nothing
        End Try
    End Function

    Public Overridable Function get_DataRows(ByVal p_where As String) As System.Data.DataRowCollection Implements IFSZ_IEntity.get_DataRows
        Dim p_row As DataRowCollection
        Dim p_message As String
        Dim p_IFSZ_EMAILACCOUNTS As IFSZ_EMAILACCOUNTSDAO = New IFSZ_EMAILACCOUNTSDAO
        Try
            p_row = p_IFSZ_EMAILACCOUNTS.get_DataRecords(p_where, p_message)
            Return p_row
        Catch ex As Exception
            MsgBox(ex.ToString, MsgBoxStyle.OkCancel, "Hiba!")
            Return Nothing
        End Try
    End Function


    Public Overridable Function get_ParentTableNames() As String() Implements IFSZ_IEntity.get_ParentTableNames
        Return Nothing
    End Function

    Public Overridable Function getParentEntity(ByVal p_TableName As String) As IFSZ_IEntity Implements IFSZ_IEntity.getParentEntity
        Return (Nothing)
    End Function

    Public Overridable Function get_ParentRow(ByVal p_TableName As String, ByVal p_ID As String) As System.Data.DataRow Implements IFSZ_IEntity.get_ParentRow
        Return Nothing
    End Function

    Public Property ChildRelation() As IFSZ_Types.Relations Implements IFSZ_IEntity.ChildRelation
        Get
            Return Me.p_ChildRelations
        End Get
        Set(ByVal value As IFSZ_Types.Relations)
            Me.p_ChildRelations = value
        End Set
    End Property

    Public Property PrimaryKey() As IFSZ_Types.PrimaryKeys Implements IFSZ_IEntity.PrimaryKey
        Get
            Return Me.p_PrimaryKey
        End Get
        Set(ByVal value As IFSZ_Types.PrimaryKeys)
            Me.p_PrimaryKey = value
        End Set
    End Property

    Public Property m_IFSZ_Globals() As IFSZ_Globals Implements IFSZ_IEntity.m_IFSZ_Globals
        Get
            Return Me.p_IFSZ_Globals
        End Get
        Set(ByVal value As IFSZ_Globals)
            Me.p_IFSZ_Globals = value
        End Set
    End Property

    Public Overridable Function GetAttributeDomain(ByVal p_oszlop As String) As Object Implements IFSZ_IEntity.GetAttributeDomain
        Dim p_valid As Boolean = True
        Select Case p_oszlop
            Case "SSL_MEAN"
                Return Me.m_IFSZ_Globals.m_IFSZ_Domains.GetDomain("LOGIKAI")
            Case "SSL_LANGVAL"
                Return Me.m_IFSZ_Globals.m_IFSZ_Domains.GetDomain("LOGIKAI")
            Case Else
                Return Nothing
        End Select
        Return Nothing
    End Function

    Function GetAttributeType(ByVal p_oszlop As String) As String Implements IFSZ_IEntity.GetAttributeType
        Select Case p_oszlop
            Case "ID"
                Return "NUMBER"
            Case "NAME"
                Return "VARCHAR"
            Case "SMTP_SERVER"
                Return "VARCHAR"
            Case "SMTP_PORT"
                Return "NUMBER"
            Case "USERNAME"
                Return "VARCHAR"
            Case "PASSWORD"
                Return "VARCHAR"
            Case "SSL"
                Return "VARCHAR"
        End Select
        Return "VARCHAR"
    End Function

    Public Overridable Property ArchivEnabled() As Boolean Implements IFSZ_IEntity.ArchivEnabled
        Get

        End Get
        Set(ByVal value As Boolean)

        End Set
    End Property

    Public Overridable Property ArchivFormTipus() As IFSZ_Types.LOV_Form Implements IFSZ_IEntity.ArchivFormTipus
        Get

        End Get
        Set(ByVal value As IFSZ_Types.LOV_Form)

        End Set
    End Property

    Public Overridable Property ArchivKey() As IFSZ_Types.PrimaryKeys Implements IFSZ_IEntity.ArchivKey
        Get

        End Get
        Set(ByVal value As IFSZ_Types.PrimaryKeys)

        End Set
    End Property

    Public Overridable Property ArchivOszlopTipus() As IFSZ_Types.LOV_OszlopTipus() Implements IFSZ_IEntity.ArchivOszlopTipus
        Get

        End Get
        Set(ByVal value As IFSZ_Types.LOV_OszlopTipus())

        End Set
    End Property

    Public Overridable Property ArchivQuery() As String Implements IFSZ_IEntity.ArchivQuery
        Get

        End Get
        Set(ByVal value As String)

        End Set
    End Property

    Public Property ViewName() As String Implements IFSZ_IEntity.ViewName
        Get
            Return p_ViewName
        End Get
        Set(ByVal value As String)
            p_ViewName = value
        End Set
    End Property

    Public Property LastQuery() As String Implements IFSZ_IEntity.LastQuery
        Get
            Return p_LastQuery
        End Get
        Set(ByVal value As String)
            p_LastQuery = value
        End Set
    End Property

#Region "Saját kódok"

    Protected Overridable Sub FormatumBeallitas()
        p_SMTP_PORT_FORMAT = ""
    End Sub

    Protected Overridable Function CustVal_NAME(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        Return True
    End Function

    Protected Overridable Function CustVal_SMTP_SERVER(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        Return True
    End Function

    Protected Overridable Function CustVal_SMTP_PORT(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        Return True
    End Function

    Protected Overridable Function CustVal_USERNAME(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        Return True
    End Function

    Protected Overridable Function CustVal_PASSWORD(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        Return True
    End Function

    Protected Overridable Function CustVal_SSL(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        Return True
    End Function


    ''' <summary>
    ''' Az insert/update eljárások legelején hívódik meg, amikor még nem történtek meg az oszloponkénti validálások
    ''' </summary>
    ''' <param name="p_op"></param>
    ''' <param name="p_record"></param>
    ''' <param name="p_message"></param>
    ''' <param name="p_dao"></param>
    ''' <param name="p_record_old"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Protected Overridable Function BeforeAutomatizmus(ByVal p_op As IFSZ_Types.DMLOperation, ByRef p_record As Object, ByRef p_message As String, ByRef p_dao As IFSZ_EMAILACCOUNTSDAO, Optional ByRef p_record_old As DataRowView = Nothing) As Boolean

        Return True
    End Function

    ''' <summary>
    ''' Közvetlenül az insert/update/delete előtt hívódik meg, az utolsó ellenőrzések, automatikus adattöltések történhetnek itt
    ''' </summary>
    ''' <param name="p_op"></param>
    ''' <param name="p_record"></param>
    ''' <param name="p_message"></param>
    ''' <param name="p_dao"></param>
    ''' <param name="p_record_old"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Protected Overridable Function PreAutomatizmus(ByVal p_op As IFSZ_Types.DMLOperation, ByRef p_record As Object, ByRef p_message As String, ByRef p_dao As IFSZ_EMAILACCOUNTSDAO, Optional ByRef p_record_old As DataRowView = Nothing) As Boolean

        Return True
    End Function

    ''' <summary>
    ''' Közvetlenül a sikeres insert/update/delete után hívódik meg.
    ''' Itt már az adatok az adatbázisban vannak, de ha false-szal térünk vissza, akkor rollbackelődni fog
    ''' </summary>
    ''' <param name="p_op"></param>
    ''' <param name="p_record"></param>
    ''' <param name="p_message"></param>
    ''' <param name="p_dao"></param>
    ''' <param name="p_record_old"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Protected Overridable Function PostAutomatizmus(ByVal p_op As IFSZ_Types.DMLOperation, ByRef p_record As Object, ByRef p_message As String, ByRef p_dao As IFSZ_EMAILACCOUNTSDAO, Optional ByRef p_record_old As DataRowView = Nothing) As Boolean

        Return True
    End Function

#End Region

End Class
