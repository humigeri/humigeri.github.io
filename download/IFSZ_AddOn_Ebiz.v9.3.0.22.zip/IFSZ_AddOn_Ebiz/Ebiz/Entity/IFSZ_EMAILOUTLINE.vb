﻿'----------------------------------------------------------------------------'
'Ez a fájl módosítható, saját és override-olt eljárások írhatóak benne
'----------------------------------------------------------------------------'
'Generálva: 2020.03.22
'EntityGenerator2 - számára. Verzió: 1.1.16.6
'

Imports IFSZ_AddOnBase

Partial Public Class IFSZ_EMAILOUTLINE
    Inherits IFSZ_EMAILOUTLINE_Base

#Region "Konstruktor"

    Public Sub New(ByRef pGlobal As IFSZ_Globals)
        MyBase.New(pGlobal)
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef pGlobal As IFSZ_Globals)
        MyBase.New(entity, pGlobal)
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef l_form As IFSZ_Form)
        MyBase.New(entity, l_form)
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef l_form As IFSZ_Form, ByRef pGlobal As IFSZ_Globals)
        MyBase.New(entity, l_form, pGlobal)
    End Sub

    Public Sub New(ByRef pGlobal As IFSZ_Globals, ByVal p_TableName As String)
        MyBase.New(pGlobal, p_TableName)
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef pGlobal As IFSZ_Globals, ByVal p_TableName As String)
        MyBase.New(entity, pGlobal, p_TableName)
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef l_form As IFSZ_Form, ByVal p_TableName As String)
        MyBase.New(entity, l_form, p_TableName)
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef l_form As IFSZ_Form, ByRef pGlobal As IFSZ_Globals, ByVal p_TableName As String)
        MyBase.New(entity, l_form, pGlobal, p_TableName)
    End Sub

#End Region

#Region "Overrides"

    Protected Overrides Function PreAutomatizmus(p_op As IFSZ_Types.DMLOperation, ByRef p_record As Object, ByRef p_message As String, ByRef p_dao As IFSZ_EMAILOUTLINEDAO, ByRef Optional p_record_old As DataRowView = Nothing) As Boolean
        Dim l_eoh_id As Integer = p_record("EOH_ID")
        Dim l_fej_statusz As String = DataProvider.ExecuteScalarString("select min(status) from IFSZ_EMAILOUTHEAD where id = " + l_eoh_id.ToString())

        If p_op = IFSZ_Types.DMLOperation.Insert OrElse p_op = IFSZ_Types.DMLOperation.Delete Then
            If l_fej_statusz <> "R" Then
                p_message = "Csak rögzítés alatti státuszú küldési bizonylathoz lehet új tételsort felvenni"
                Return False
            End If
        End If

        If p_op = IFSZ_Types.DMLOperation.Insert Then
            'Ismételten ne lehessen kétszer ugyanazt felvenni:
            If DataProvider.ExecuteScalar("select count(9) from IFSZ_EMAILOUTLINE where EOH_ID = " + l_eoh_id.ToString() + " and DOCTYPE = " + p_record("DOCTYPE").ToString() + " and DOCENTRY = " + p_record("DOCENTRY").ToString()) > 0 Then
                p_message = "A " + p_record("DOCNUM").ToString() + " bizonylat már hozzá lett adva a küldési bizonylathoz"
                Return False
            End If

            'LINENUM meghatározása:
            Dim l_linenum As Integer = DataProvider.ExecuteScalar("select " + QueryResource.SQL_isnull("max(linenum)", "0") + " from IFSZ_EMAILOUTLINE where EOH_ID = " + l_eoh_id.ToString())
            p_record("LINENUM") = l_linenum + 1

            'CRYSTAL:
            Dim l_crystal As String = DataProvider.ExecuteScalarString("select " + QueryResource.SQL_dbopont + "IFSZ_GET_DEF_CRYSTAL_LAYOUT_F(" + IFSZ_Globals.SQLConstantPrepare(p_record("DOCTYPE")) + ", " + IFSZ_Globals.SQLConstantPrepare(p_record("DOCENTRY")) + ", " + IFSZ_Globals.SQLConstantPrepare(IFSZ_Globals.USER_ID) + ") " + QueryResource.SQL_FromDummy)
            If Not String.IsNullOrEmpty(l_crystal) Then
                p_record("CRYSTAL") = l_crystal
            End If

        End If

        Return True

    End Function

    Protected Overrides Function PostAutomatizmus(p_op As IFSZ_Types.DMLOperation, ByRef p_record As Object, ByRef p_message As String, ByRef p_dao As IFSZ_EMAILOUTLINEDAO, ByRef Optional p_record_old As DataRowView = Nothing) As Boolean
        Dim l_message As String
        If p_op = IFSZ_Types.DMLOperation.Insert Then
            Try
                'Címzettek automatikus hozzáadása
                Dim l_tab As DataTable = DataProvider.EGetDataTable("select * from IFSZ_EDOC_ADDRESSES_V where DOCENTRY = " + IFSZ_Globals.SQLConstantPrepare(p_record("DOCENTRY")) + " and OBJTYPE = " + IFSZ_Globals.SQLConstantPrepare(p_record("DOCTYPE")))

                If l_tab IsNot Nothing AndAlso l_tab.Rows.Count > 0 Then
                    For Each l_row As DataRow In l_tab.Rows
                        Dim l_ent As New IFSZ_EMAILOUTADDR(Me.m_IFSZ_Globals)
                        Dim l_trow As DataRow = l_ent.GetDataRow()
                        l_ent.create(l_trow)
                        l_ent.SetAttribute("EOL_ID", p_record("ID"))
                        l_ent.SetAttribute("CNTCT_NAME", l_row("U_EBIZNAME"))
                        l_ent.SetAttribute("CNTCT_EMAIL", l_row("EMAIL"))
                        l_trow = l_ent.GetDataRow()
                        If l_ent.insert(l_trow, l_message) <> 1 Then
                            p_message = l_message
                            Return False
                        End If
                    Next
                End If

            Catch ex As Exception
                p_message = ex.Message
                Return False
            End Try

        End If

        Return True

    End Function

#End Region

    ''' <summary>
    ''' Beállítja, hogy ki lett küldve a levél.
    ''' Kívül nyissunk tranzakciót, és még commit előtt küldjük el a levelet. Ha az hibára fut, akkor rollback
    ''' </summary>
    ''' <param name="p_eol_id"></param>
    ''' <param name="p_crystal"></param>
    ''' <returns></returns>
    Public Shared Function Kuldes(ByVal p_eol_id As Integer, ByVal p_crystal As String) As String
        Dim l_message As String
        Dim l_glob As New IFSZ_Globals
        Dim l_md5 As String

        Dim l_tab As DataTable = DataProvider.EGetDataTable("select * from IFSZ_EMAILOUTLINE where ID = " + p_eol_id.ToString())
        If l_tab IsNot Nothing AndAlso l_tab.Rows.Count > 0 Then
            For Each l_row As DataRowView In l_tab.DefaultView
                Dim l_ent As New IFSZ_EMAILOUTLINE(l_glob)
                l_ent.set_row(l_row.Row)
                l_ent.set_item("STATUS", "S")
                l_ent.set_item("SENTTS", IFSZ_Globals.GetServerDateTime)
                l_ent.set_item("FILE", p_crystal)
                l_md5 = IFSZ_Globals.GetMD5HashFile(p_crystal)
                l_ent.set_item("MD5_SIGNED", l_md5)
                Dim l_ujrow = l_ent.GetDataRow()
                If l_ent.Update(l_ujrow, l_row, l_message) <> 1 Then
                    Return l_message
                End If

                DataProvider.EExecuteNonQuery("update " + IFSZ_EMAILOUTLINE.GetTablaNev(l_row("DOCTYPE")) + " set ""Printed"" = 'Y', ""CopyNumber"" = ""CopyNumber"" + 1 where ""DocEntry"" = " + l_row("DOCENTRY").ToString)

                'Archiválás:
                Dim l_archdb As String = IFSZ_Globals.GetParameter("EBIZARCH")

                If Not String.IsNullOrEmpty(l_archdb) Then
                    Dim l_count As Integer = DataProvider.ExecuteScalar("select count(9) from " + l_archdb + "." + QueryResource.SQL_dbopont + "IFSZ_EMAILOUTLINE where db = " + IFSZ_Globals.SQLConstantPrepare(DataProvider.GetDBName()) + " and id = " + l_row("ID").ToString())
                    If l_count = 0 Then
                        l_count = DataProvider.InsertUpdateFile("insert into " + l_archdb + "." + QueryResource.SQL_dbopont + "IFSZ_EMAILOUTLINE(db, id, file_path, md5_signed, file_bin) values(" + IFSZ_Globals.SQLConstantPrepare(DataProvider.GetDBName()) + ", " + l_row("ID").ToString() + ", " + IFSZ_Globals.SQLConstantPrepare(p_crystal) + ", " + IFSZ_Globals.SQLConstantPrepare(l_md5) + ", @file)", p_crystal, l_message, False, False)
                        If l_count <= 0 Then
                            Return "Nem sikerült az archiválás: " + l_message
                        End If
                    Else
                        l_count = DataProvider.InsertUpdateFile("update " + l_archdb + "." + QueryResource.SQL_dbopont + "IFSZ_EMAILOUTLINE set file = " + IFSZ_Globals.SQLConstantPrepare(p_crystal) + ", md5_signed = " + IFSZ_Globals.SQLConstantPrepare(l_md5) + ", file_bin = @file where db = " + IFSZ_Globals.SQLConstantPrepare(DataProvider.GetDBName()) + " and id = " + l_row("ID").ToString(), p_crystal, l_message, False, False)
                        If l_count <= 0 Then
                            Return "Nem sikerült az archiválás: " + l_message
                        End If
                    End If
                End If

            Next
        End If

        Return ""

    End Function

    Public Shared Function Generalas(ByVal p_eol_id As Integer, ByVal p_crystal As String) As String
        Dim l_message As String
        Dim l_glob As New IFSZ_Globals

        SyncLock IFSZ_Globals.m_connLockObject
            Try
                If IFSZ_Globals.m_Connection Is Nothing Then
                    IFSZ_Globals.m_Connection = New ConnectionProvider
                Else
                    IFSZ_Globals.m_Connection.BeginTransaction()
                End If

                Dim l_tab As DataTable = DataProvider.EGetDataTable("select * from IFSZ_EMAILOUTLINE where ID = " + p_eol_id.ToString())
                If l_tab IsNot Nothing AndAlso l_tab.Rows.Count > 0 Then
                    For Each l_row As DataRowView In l_tab.DefaultView
                        Dim l_ent As New IFSZ_EMAILOUTLINE(l_glob)
                        l_ent.set_row(l_row.Row)
                        l_ent.set_item("FILE", p_crystal)
                        l_ent.set_item("MD5_FILE", IFSZ_Globals.GetMD5HashFile(p_crystal))
                        Dim l_ujrow = l_ent.GetDataRow()
                        If l_ent.Update(l_ujrow, l_row, l_message) <> 1 Then
                            Return l_message
                        End If

                    Next
                End If

                IFSZ_Globals.m_Connection.Commit()

            Catch ex As Exception
                If IFSZ_Globals.m_Connection IsNot Nothing Then IFSZ_Globals.m_Connection.Rollback()
                IFSZ_Globals.m_Connection = Nothing
                Return ex.Message()
            Finally
                IFSZ_Globals.m_Connection = Nothing
            End Try
        End SyncLock

        Return ""

    End Function

    Private Shared Function GetTablaNev(ByVal p_objtype As Integer) As String
        Select Case p_objtype
            Case 13
                Return "OINV"
            Case 14
                Return "ORIN"
            Case 165
                Return "OCSI"
            Case 166
                Return "OCSV"
        End Select
        Return ""
    End Function

End Class
