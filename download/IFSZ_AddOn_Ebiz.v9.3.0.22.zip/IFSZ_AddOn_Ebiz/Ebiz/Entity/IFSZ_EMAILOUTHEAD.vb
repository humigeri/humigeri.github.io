﻿'----------------------------------------------------------------------------'
'Ez a fájl módosítható, saját és override-olt eljárások írhatóak benne
'----------------------------------------------------------------------------'
'Generálva: 2020.03.22
'EntityGenerator2 - számára. Verzió: 1.1.16.6
'

Imports IFSZ_AddOnBase

Partial Public Class IFSZ_EMAILOUTHEAD
    Inherits IFSZ_EMAILOUTHEAD_Base

#Region "Konstruktor"

    Public Sub New(ByRef pGlobal As IFSZ_Globals)
        MyBase.New(pGlobal)
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef pGlobal As IFSZ_Globals)
        MyBase.New(entity, pGlobal)
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef l_form As IFSZ_Form)
        MyBase.New(entity, l_form)
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef l_form As IFSZ_Form, ByRef pGlobal As IFSZ_Globals)
        MyBase.New(entity, l_form, pGlobal)
    End Sub

    Public Sub New(ByRef pGlobal As IFSZ_Globals, ByVal p_TableName As String)
        MyBase.New(pGlobal, p_TableName)
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef pGlobal As IFSZ_Globals, ByVal p_TableName As String)
        MyBase.New(entity, pGlobal, p_TableName)
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef l_form As IFSZ_Form, ByVal p_TableName As String)
        MyBase.New(entity, l_form, p_TableName)
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef l_form As IFSZ_Form, ByRef pGlobal As IFSZ_Globals, ByVal p_TableName As String)
        MyBase.New(entity, l_form, pGlobal, p_TableName)
    End Sub

#End Region

#Region "Variables"

    Public Shared l_fs_domain, l_fs_username, l_fs_passwordStr As String
    Public Shared m_impersonated As Boolean = False
    Private m_impersonator As AliasAccount

#End Region

#Region "Overrides"

    Protected Overrides Function PreAutomatizmus(p_op As IFSZ_Types.DMLOperation, ByRef p_record As Object, ByRef p_message As String, ByRef p_dao As IFSZ_EMAILOUTHEADDAO, ByRef Optional p_record_old As DataRowView = Nothing) As Boolean
        If p_op = IFSZ_Types.DMLOperation.Insert Then
            Try
                If IFSZ_EMAILOUTHEAD.m_impersonated Then
                    m_impersonator = New AliasAccount(IFSZ_EMAILOUTHEAD.l_fs_username, IFSZ_EMAILOUTHEAD.l_fs_passwordStr, IFSZ_EMAILOUTHEAD.l_fs_domain)
                    m_impersonator.BeginImpersonation()
                End If

                Dim l_path As String = IFSZ_Globals.GetParameter("EBIZPATH")
                If String.IsNullOrEmpty(l_path) Then
                    p_message = "Nincs megadva az EBIZPATH paraméter a generálandó fájlok útvonalával"
                    Return False
                End If
                If Not System.IO.Directory.Exists(l_path) Then
                    p_message = "Nem létezik, vagy nem elérhető az EBIZPATH paraméterben megadott útvonal: " + l_path
                    Return False
                End If
                Try
                    p_record("DOCNUM") = IFSZ_EMAILOUTHEAD.GetNextBizszam(True)
                Catch ex As Exception
                    p_message = ex.Message
                    Return False
                End Try
                l_path = l_path.TrimEnd("\".ToCharArray()) + "\" + p_record("DOCNUM").ToString() + "_" + p_record("USERCODE").ToString() + "_" + IFSZ_Globals.GetServerDateTime().ToString("yyyyMMddHHmmss")
                p_record("PATH") = l_path
                Try
                    System.IO.Directory.CreateDirectory(l_path)
                Catch ex As Exception
                    p_message = "Nem lehetett létrehozni a küldési bizonylathoz tartozó mappát: " + l_path
                    Return False
                End Try

            Catch ex As Exception
                p_message = ex.Message
                Return False
            Finally
                If IFSZ_EMAILOUTHEAD.m_impersonated Then
                    m_impersonator.EndImpersonation()
                End If
            End Try

        End If
        Return True
    End Function

#End Region

    ''' <summary>
    ''' Hívása legyen egy keretrendszeres tranzakcióban, és try-catch-ben is!
    ''' </summary>
    ''' <param name="p_kioszt"></param>
    ''' <returns></returns>
    Public Shared Function GetNextBizszam(ByVal p_kioszt As Boolean) As String
        Dim l_command As String
        Dim l_tab As DataTable
        Dim l_date As DateTime = IFSZ_Globals.GetServerDate
        Dim l_val As Integer

        l_command = QueryResource.GetQuery("Base_IFSZ_AddOn_SBO", "sel_next_from_dnassigns_updlock", "EMAILOUT", l_date)        l_tab = DataProvider.EGetDataTable(l_command)

        If l_tab Is Nothing OrElse l_tab.Rows.Count = 0 Then
            'Nem létező Bizonylatszám kategória ("<1>"), vagy nincs érvényes hozzárendelés a megadott időpontban ("<2>")
            Throw New Exception(IFSZ_Globals.m_ParentAddOn.LocRM.GetString("ifsz-02004").Replace("<1>", "EMAILOUT").Replace("<2>", l_date.ToString("s")))
        End If

        If l_tab.Rows.Count > 1 Then
            'Több érvényes hozzárendelés is létezik a megadott időpontban ("<1>") a bizonylatszám kategóriához ("<2>")
            Throw New Exception(IFSZ_Globals.m_ParentAddOn.LocRM.GetString("ifsz-02005").Replace("<2>", l_date.ToString("s")).Replace("<1>", "EMAILOUT"))
            Return -1
        End If

        l_val = CType(l_tab.Rows(0)(0), Integer) + 1        If p_kioszt Then
            DataProvider.EExecuteNonQuery(QueryResource.GetQuery("Base_IFSZ_AddOn_SBO", "upd_dnassigns_next_plus1", l_tab.Rows(0)(1)))
        End If        Return IFSZ_Globals.GetDocNumString("EMAILOUT", l_val, l_date)
    End Function

    Public Shared Function TorolOsszesTetel(ByVal p_eoh_id As Integer) As String
        Dim l_glob As New IFSZ_Globals
        Dim l_message As String
        SyncLock IFSZ_Globals.m_connLockObject
            Try
                If IFSZ_Globals.m_Connection Is Nothing Then
                    IFSZ_Globals.m_Connection = New ConnectionProvider
                Else
                    IFSZ_Globals.m_Connection.BeginTransaction()
                End If

                Dim l_tab As DataTable = DataProvider.EGetDataTable("select * from IFSZ_EMAILOUTLINE where EOH_ID = " + p_eoh_id.ToString() + " and STATUS = 'R'")
                If l_tab IsNot Nothing AndAlso l_tab.Rows.Count > 0 Then
                    For Each l_row As DataRowView In l_tab.DefaultView
                        Dim l_ent As New IFSZ_EMAILOUTLINE(l_glob)
                        l_ent.set_row(l_row.Row)
                        If l_ent.Delete(l_row.Row, l_row, l_message) <> 1 Then
                            If IFSZ_Globals.m_Connection IsNot Nothing Then IFSZ_Globals.m_Connection.Rollback()
                            IFSZ_Globals.m_Connection = Nothing
                            Return l_message
                        End If
                    Next
                End If

                IFSZ_Globals.m_Connection.Commit()

            Catch ex As Exception
                If IFSZ_Globals.m_Connection IsNot Nothing Then IFSZ_Globals.m_Connection.Rollback()
                IFSZ_Globals.m_Connection = Nothing
                Return ex.Message()
            Finally
                IFSZ_Globals.m_Connection = Nothing
            End Try
        End SyncLock

        Return ""

    End Function

    Public Shared Function Visszavon(ByVal p_eoh_id As Integer) As String
        Dim l_message As String
        Dim l_glob As New IFSZ_Globals
        SyncLock IFSZ_Globals.m_connLockObject
            Try
                If IFSZ_Globals.m_Connection Is Nothing Then
                    IFSZ_Globals.m_Connection = New ConnectionProvider
                Else
                    IFSZ_Globals.m_Connection.BeginTransaction()
                End If

                Dim l_tab As DataTable = DataProvider.EGetDataTable("select * from IFSZ_EMAILOUTHEAD where ID = " + p_eoh_id.ToString())
                If l_tab IsNot Nothing AndAlso l_tab.Rows.Count > 0 Then
                    For Each l_row As DataRowView In l_tab.DefaultView
                        Dim l_ent As New IFSZ_EMAILOUTHEAD(l_glob)
                        l_ent.set_row(l_row.Row)
                        l_ent.set_item("STATUS", "C")
                        Dim l_ujrow = l_ent.GetDataRow()
                        If l_ent.Update(l_ujrow, l_row, l_message) <> 1 Then
                            If IFSZ_Globals.m_Connection IsNot Nothing Then IFSZ_Globals.m_Connection.Rollback()
                            IFSZ_Globals.m_Connection = Nothing
                            Return l_message
                        End If
                    Next
                End If

                IFSZ_Globals.m_Connection.Commit()

            Catch ex As Exception
                If IFSZ_Globals.m_Connection IsNot Nothing Then IFSZ_Globals.m_Connection.Rollback()
                IFSZ_Globals.m_Connection = Nothing
                Return ex.Message()
            Finally
                IFSZ_Globals.m_Connection = Nothing
            End Try
        End SyncLock

        Return ""

    End Function

    ''' <summary>
    ''' Leellenőrzi, hogy van-e még nyitott, R-es tétele. Ha nincs, lezárja a fejet is
    ''' Visszaadja, hogy hány nyitott van még. Ha 0-t ad vissza, akkor S-re állította a fejet
    ''' Ha már eleve nem R a fej státusza, akkor -1-et ad vissza
    ''' Ha valami egyéb hiba történne, akkor kivételt vált ki
    ''' </summary>
    ''' <param name="p_eoh_id"></param>
    ''' <returns></returns>
    Public Shared Function ElkuldveCheck(ByVal p_eoh_id As Integer) As Integer
        Dim l_message As String
        Dim l_count As Integer = -2
        Dim l_glob As New IFSZ_Globals
        SyncLock IFSZ_Globals.m_connLockObject
            Try
                If IFSZ_Globals.m_Connection Is Nothing Then
                    IFSZ_Globals.m_Connection = New ConnectionProvider
                Else
                    IFSZ_Globals.m_Connection.BeginTransaction()
                End If

                Dim l_tab As DataTable = DataProvider.EGetDataTable("select h.*, (select count(9) from IFSZ_EMAILOUTLINE l where l.eoh_id = h.id and l.status = 'R') as RCOUNT from IFSZ_EMAILOUTHEAD h where ID = " + p_eoh_id.ToString())
                If l_tab IsNot Nothing AndAlso l_tab.Rows.Count > 0 Then
                    For Each l_row As DataRowView In l_tab.DefaultView
                        If l_row("STATUS") <> "R" Then
                            If IFSZ_Globals.m_Connection IsNot Nothing Then IFSZ_Globals.m_Connection.Rollback()
                            IFSZ_Globals.m_Connection = Nothing
                            Return -1
                        End If
                        l_count = l_row("RCOUNT")
                        If l_count = 0 Then
                            Dim l_ent As New IFSZ_EMAILOUTHEAD(l_glob)
                            l_ent.set_row(l_row.Row)
                            l_ent.set_item("STATUS", "S")
                            l_ent.set_item("SENTTS", IFSZ_Globals.GetServerDateTime())
                            Dim l_ujrow = l_ent.GetDataRow()
                            If l_ent.Update(l_ujrow, l_row, l_message) <> 1 Then
                                Throw New Exception(l_message)
                            End If
                        End If
                    Next
                End If

                IFSZ_Globals.m_Connection.Commit()

            Catch ex As Exception
                If IFSZ_Globals.m_Connection IsNot Nothing Then IFSZ_Globals.m_Connection.Rollback()
                IFSZ_Globals.m_Connection = Nothing
                Throw
            Finally
                IFSZ_Globals.m_Connection = Nothing
            End Try
        End SyncLock

        Return l_count

    End Function

End Class
