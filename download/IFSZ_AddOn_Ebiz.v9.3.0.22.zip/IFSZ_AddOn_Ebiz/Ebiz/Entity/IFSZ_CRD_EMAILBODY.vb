﻿'----------------------------------------------------------------------------'
'Ez a fájl módosítható, saját és override-olt eljárások írhatóak benne
'----------------------------------------------------------------------------'
'Generálva: 2020.04.09
'EntityGenerator2 - számára. Verzió: 1.1.16.7
'

Imports IFSZ_AddOnBase

Partial Public Class IFSZ_CRD_EMAILBODY
    Inherits IFSZ_CRD_EMAILBODY_Base

#Region "Konstruktor"

    Public Sub New(ByRef pGlobal As IFSZ_Globals)
        MyBase.New(pGlobal)
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef pGlobal As IFSZ_Globals)
        MyBase.New(entity, pGlobal)
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef l_form As IFSZ_Form)
        MyBase.New(entity, l_form)
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef l_form As IFSZ_Form, ByRef pGlobal As IFSZ_Globals)
        MyBase.New(entity, l_form, pGlobal)
    End Sub

    Public Sub New(ByRef pGlobal As IFSZ_Globals, ByVal p_TableName As String)
        MyBase.New(pGlobal, p_TableName)
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef pGlobal As IFSZ_Globals, ByVal p_TableName As String)
        MyBase.New(entity, pGlobal, p_TableName)
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef l_form As IFSZ_Form, ByVal p_TableName As String)
        MyBase.New(entity, l_form, p_TableName)
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef l_form As IFSZ_Form, ByRef pGlobal As IFSZ_Globals, ByVal p_TableName As String)
        MyBase.New(entity, l_form, pGlobal, p_TableName)
    End Sub

#End Region

#Region "Overrides"

    Protected Overrides Function PreAutomatizmus(p_op As IFSZ_Types.DMLOperation, ByRef p_record As Object, ByRef p_message As String, ByRef p_dao As IFSZ_CRD_EMAILBODYDAO, ByRef Optional p_record_old As DataRowView = Nothing) As Boolean
        If p_op = IFSZ_Types.DMLOperation.Insert OrElse p_op = IFSZ_Types.DMLOperation.Update Then
            If p_record("CARDCODE").ToString() = "" Then
                p_message = "A partnert kötelező megadni"
                Return False
            End If
            If p_record("BODY").ToString() = "" Then
                p_message = "A sablonkód mezőt kötelező megadni"
                Return False
            End If
        End If
        Return True
    End Function

    Protected Overrides Function PostAutomatizmus(p_op As IFSZ_Types.DMLOperation, ByRef p_record As Object, ByRef p_message As String, ByRef p_dao As IFSZ_CRD_EMAILBODYDAO, ByRef Optional p_record_old As DataRowView = Nothing) As Boolean
        Dim l_count As Integer
        If p_op = IFSZ_Types.DMLOperation.Insert OrElse p_op = IFSZ_Types.DMLOperation.Update Then
            'Egyediség: U_CARDCODE + U_BODY
            l_count = DataProvider.ExecuteScalar("select count(9) from IFSZ_CRD_EMAILBODY where ""CARDCODE"" = " + IFSZ_Globals.SQLConstantPrepare(p_record("CARDCODE")) + " and ""BODY"" = " + IFSZ_Globals.SQLConstantPrepare(p_record("BODY")) + " and id <> " + p_record("ID").ToString())
            If l_count > 0 Then
                p_message = "Ez a partner már hozzá lett rendelve ehhez a sablonhoz"
                Return False
            End If
            'Egyediség: U_CARDCODE + Ugyanilyen típushoz
            Dim l_objtype As String = DataProvider.ExecuteScalarString("select min(DOCTYPE) from IFSZ_EMAILOUTBODY where ID = " + p_record("BODY").ToString())
            Dim l_masik_sablon As String = DataProvider.ExecuteScalarString("select min(eob.""NAME"") from IFSZ_CRD_EMAILBODY ceb join IFSZ_EMAILOUTBODY eob on ceb.BODY = eob.ID where ceb.""CARDCODE"" = " + IFSZ_Globals.SQLConstantPrepare(p_record("CARDCODE")) + " and eob.""DOCTYPE"" = " + IFSZ_Globals.SQLConstantPrepare(l_objtype) + " and ceb.id <> " + p_record("ID").ToString())
            If Not String.IsNullOrEmpty(l_masik_sablon) Then
                p_message = "Ez a partner már hozzá lett rendelve egy ugyanilyen bizonylattípusú sablonhoz: " + l_masik_sablon
                Return False
            End If
        End If
        Return True
    End Function

#End Region

End Class
