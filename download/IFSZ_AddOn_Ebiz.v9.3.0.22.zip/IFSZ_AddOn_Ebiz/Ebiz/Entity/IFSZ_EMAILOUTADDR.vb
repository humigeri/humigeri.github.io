﻿'----------------------------------------------------------------------------'
'Ez a fájl módosítható, saját és override-olt eljárások írhatóak benne
'----------------------------------------------------------------------------'
'Generálva: 2020.03.22
'EntityGenerator2 - számára. Verzió: 1.1.16.6
'

Public Partial Class IFSZ_EMAILOUTADDR
    Inherits IFSZ_EMAILOUTADDR_Base

#Region "Konstruktor"

    Public Sub New(ByRef pGlobal As IFSZ_Globals)
        MyBase.New(pGlobal)
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef pGlobal As IFSZ_Globals)
        MyBase.New(entity, pGlobal)
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef l_form As IFSZ_Form)
        MyBase.New(entity, l_form)
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef l_form As IFSZ_Form, ByRef pGlobal As IFSZ_Globals)
        MyBase.New(entity, l_form, pGlobal)
    End Sub

    Public Sub New(ByRef pGlobal As IFSZ_Globals, ByVal p_TableName As String)
        MyBase.New(pGlobal, p_TableName)
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef pGlobal As IFSZ_Globals, ByVal p_TableName As String)
        MyBase.New(entity, pGlobal, p_TableName)
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef l_form As IFSZ_Form, ByVal p_TableName As String)
        MyBase.New(entity, l_form, p_TableName)
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef l_form As IFSZ_Form, ByRef pGlobal As IFSZ_Globals, ByVal p_TableName As String)
        MyBase.New(entity, l_form, pGlobal, p_TableName)
    End Sub

#End Region

#Region "Overrides"

#End Region

End Class
