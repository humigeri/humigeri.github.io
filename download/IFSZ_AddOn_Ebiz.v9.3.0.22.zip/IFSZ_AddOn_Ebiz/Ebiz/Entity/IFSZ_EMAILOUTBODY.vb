﻿'----------------------------------------------------------------------------'
'Ez a fájl módosítható, saját és override-olt eljárások írhatóak benne
'----------------------------------------------------------------------------'
'Generálva: 2020.03.22
'EntityGenerator2 - számára. Verzió: 1.1.16.6
'

Imports IFSZ_AddOnBase

Partial Public Class IFSZ_EMAILOUTBODY
    Inherits IFSZ_EMAILOUTBODY_Base

#Region "Konstruktor"

    Public Sub New(ByRef pGlobal As IFSZ_Globals)
        MyBase.New(pGlobal)
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef pGlobal As IFSZ_Globals)
        MyBase.New(entity, pGlobal)
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef l_form As IFSZ_Form)
        MyBase.New(entity, l_form)
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef l_form As IFSZ_Form, ByRef pGlobal As IFSZ_Globals)
        MyBase.New(entity, l_form, pGlobal)
    End Sub

    Public Sub New(ByRef pGlobal As IFSZ_Globals, ByVal p_TableName As String)
        MyBase.New(pGlobal, p_TableName)
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef pGlobal As IFSZ_Globals, ByVal p_TableName As String)
        MyBase.New(entity, pGlobal, p_TableName)
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef l_form As IFSZ_Form, ByVal p_TableName As String)
        MyBase.New(entity, l_form, p_TableName)
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef l_form As IFSZ_Form, ByRef pGlobal As IFSZ_Globals, ByVal p_TableName As String)
        MyBase.New(entity, l_form, pGlobal, p_TableName)
    End Sub

#End Region

#Region "Overrides"

    Protected Overrides Function PreAutomatizmus(p_op As IFSZ_Types.DMLOperation, ByRef p_record As Object, ByRef p_message As String, ByRef p_dao As IFSZ_EMAILOUTBODYDAO, ByRef Optional p_record_old As DataRowView = Nothing) As Boolean
        If p_op = IFSZ_Types.DMLOperation.Insert OrElse p_op = IFSZ_Types.DMLOperation.Update Then
            'Kötelezőség
            If p_record("NAME").ToString() = "" Then
                p_message = "A Név mezőt kötelező megadni"
                Return False
            End If
            If p_record("DOCTYPE").ToString() = "" Then
                p_message = "A bizonylattípus mezőt kötelező megadni"
                Return False
            End If
            If p_record("SUBJECT").ToString() = "" Then
                p_message = "Az email tárgya mezőt kötelező megadni"
                Return False
            End If
            If p_record("BODY").ToString() = "" Then
                p_message = "Az email szövegtörzse mezőt kötelező megadni"
                Return False
            End If

            'A LANG értékének ellenőrzése
            If Not IsDBNull(p_record("LANG")) Then
                If DataProvider.ExecuteScalar("select count(9) from OLNG where ""Code"" = " + p_record("LANG").ToString()) = 0 Then
                    p_message = "Nem létező nyelvet adott meg"
                    Return False
                End If
            End If

        Else
            Dim l_count As Integer = DataProvider.ExecuteScalar("select count(9) from IFSZ_CRD_EMAILBODY where BODY = " + p_record("ID").ToString())
            If l_count > 0 Then
                p_message = "Vannak partner hozzárendelések, először ezeket törölje"
                Return False
            End If
        End If
        Return True
    End Function

    Protected Overrides Function PostAutomatizmus(p_op As IFSZ_Types.DMLOperation, ByRef p_record As Object, ByRef p_message As String, ByRef p_dao As IFSZ_EMAILOUTBODYDAO, ByRef Optional p_record_old As DataRowView = Nothing) As Boolean
        Dim l_count As Integer
        If p_op = IFSZ_Types.DMLOperation.Insert OrElse p_op = IFSZ_Types.DMLOperation.Update Then
            'Egyediség: NAME
            Dim l_shortname As String = DataProvider.ExecuteScalarString("select shortname from IFSZ_EDOC_TYPES_V where code = " + IFSZ_Globals.SQLConstantPrepare(p_record("DOCTYPE").ToString()))
            If String.IsNullOrEmpty(l_shortname) Then
                p_message = "Hibás bizonylattípus: " + p_record("DOCTYPE").ToString()
                Return False
            End If
            l_count = DataProvider.ExecuteScalar("select count(9) from IFSZ_EMAILOUTBODY where ""NAME"" = " + IFSZ_Globals.SQLConstantPrepare(p_record("NAME")) + " and id <> " + p_record("ID").ToString().TrimStart("0"))
            If l_count > 0 Then
                p_message = "Ezzel a kóddal már lett felvéve email sablon"
                Return False
            End If

            'Alapban úgy oldottam meg a kukacos táblákat, hogy a Code-ba és a Name-be is az id kerül, de itt szükség van a Name-ra. Igaz, csak utólag, de beupdate-elem az U_NAME-t
            '(insert során a dao még beszúrja az id-t a Name-be, de itt most felülvágom. Később már úgysem foglalkozunk vele, a Code-ot tekintjük ID-nak pl. update-nél)
            DataProvider.EExecuteNonQuery("update ""@IFSZ_EMAILOUTBODY"" set ""Name"" = " + IFSZ_Globals.SQLConstantPrepare(p_record("NAME").ToString()) + " where ""Code"" = " + IFSZ_Globals.SQLConstantPrepare(p_record("ID").ToString().TrimStart("0")))

            'Csak egy default lehet
            If p_record("DEFAULTEMAIL").ToString() = "Y" Then
                Dim l_lang_where As String
                If IsDBNull(p_record("LANG")) Then
                    l_lang_where = "LANG is null"
                Else
                    l_lang_where = "LANG = " + p_record("LANG").ToString()
                End If
                l_count = DataProvider.ExecuteScalar("select count(9) from IFSZ_EMAILOUTBODY where defaultemail = 'Y' and doctype = " + IFSZ_Globals.SQLConstantPrepare(p_record("DOCTYPE").ToString()) + " and " + l_lang_where + " and id <> " + p_record("ID").ToString().TrimStart("0"))
                If l_count > 0 Then
                    p_message = "Csak egy alapértelmezett email sablon lehet" + IIf(IsDBNull(p_record("LANG")), "", " nyelvenként")
                    Return False
                End If
            End If

        End If
        Return True
    End Function
#End Region

End Class
