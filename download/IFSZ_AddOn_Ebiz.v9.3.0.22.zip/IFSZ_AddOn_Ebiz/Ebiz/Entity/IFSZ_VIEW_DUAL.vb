Imports System
Imports System.Resources.ResourceReader
Imports System.Collections
Imports System.Text
Imports IFSZ_AddOnBase

Public Class IFSZ_VIEW_DUAL
    'Inherits ObjectDataBinding.BaseClasses.FSBindingItem
    Implements IFSZ_IEntity

#Region "Variables"
    Private p_ID As Integer
    Private p_DOCENTRY As String
    Private p_MEGNEVEZES As String
    Private p_MEGJEGYZES As String
    Private p_tablanev As String
    Private p_ChildWhere As String
    Private p_DefaultWhere As String
    Private p_LastWhere As String
    Private p_LastPosition As String
    Private p_NewRowEnabled As Boolean = True
    Private p_IFSZ_Globals As IFSZ_Globals
    Private p_Columns() As String = {"ID", "MEGNEVEZES", "MEGJEGYZES"}
    Private p_form As IFSZ_Form
    Private p_ChildTableNames(0) As String
    Private p_ChildRelations As IFSZ_Types.Relations
    Private p_PrimaryKey As IFSZ_Types.PrimaryKeys = New IFSZ_Types.PrimaryKeys
    Private p_SqlQuery As String = QueryResource.GetQuery("Base_IFSZ_Keretrendszer", "sel_from_ifsz_dual") + " "
    Private MyCultureInfo As System.Globalization.CultureInfo = New System.Globalization.CultureInfo("en-gb")
#End Region


#Region "Construktor"
    Public Sub New(ByRef pGlobal As IFSZ_Globals)
        m_IFSZ_Globals = pGlobal
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef pGlobal As IFSZ_Globals)
        m_IFSZ_Globals = pGlobal
        If entity Is Nothing Then
            ReDim Preserve entity(0)
        Else
            ReDim Preserve entity(entity.GetUpperBound(0) + 1)
        End If
        entity(entity.GetUpperBound(0)) = Me
        Me.TableName = "IFSZ_DUAL"
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef l_form As IFSZ_Form)
        If entity Is Nothing Then
            ReDim Preserve entity(0)
        Else
            ReDim Preserve entity(entity.GetUpperBound(0) + 1)
        End If
        entity(entity.GetUpperBound(0)) = Me
        Me.TableName = "IFSZ_DUAL"
        Me.p_form = l_form
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef l_form As IFSZ_Form, ByRef pGlobal As IFSZ_Globals)
        If entity Is Nothing Then
            ReDim Preserve entity(0)
        Else
            ReDim Preserve entity(entity.GetUpperBound(0) + 1)
        End If
        m_IFSZ_Globals = pGlobal
        entity(entity.GetUpperBound(0)) = Me
        Me.TableName = "IFSZ_DUAL"
        Me.p_form = l_form
    End Sub

    Public Sub New(ByRef entity() As IFSZ_IEntity, ByRef l_form As IFSZ_Form, ByRef pGlobal As IFSZ_Globals, ByVal p_tablename As String)
        If entity Is Nothing Then
            ReDim Preserve entity(0)
        Else
            ReDim Preserve entity(entity.GetUpperBound(0) + 1)
        End If
        m_IFSZ_Globals = pGlobal
        entity(entity.GetUpperBound(0)) = Me
        Me.TableName = p_tablename
        Me.p_form = l_form
    End Sub

#End Region

#Region "Property"

    Public Property TableName() As String Implements IFSZ_IEntity.TableName
        Get
            Return p_tablanev
        End Get
        Set(ByVal value As String)
            p_tablanev = value
        End Set
    End Property

    Public ReadOnly Property Columns() As String() Implements IFSZ_IEntity.Columns
        Get
            Return Me.p_Columns
        End Get
    End Property

    Public Property ChildWhere() As String Implements IFSZ_IEntity.ChildWhere
        Get
            Return p_ChildWhere
        End Get
        Set(ByVal value As String)
            p_ChildWhere = value
        End Set
    End Property

    Public Property DefaultWhere() As String Implements IFSZ_IEntity.DefaultWhere
        Get
            Return p_DefaultWhere
        End Get
        Set(ByVal value As String)
            p_DefaultWhere = value
        End Set
    End Property

    Public Property LastWhere() As String Implements IFSZ_IEntity.LastWhere
        Get
            Return p_LastWhere
        End Get
        Set(ByVal value As String)
            p_LastWhere = value
        End Set
    End Property

    Public Property LastPosition() As Integer Implements IFSZ_IEntity.LastPosition
        Get
            Return p_LastPosition
        End Get
        Set(ByVal value As Integer)
            p_LastPosition = value
        End Set
    End Property

    Public Property NewRowEnabled() As Boolean Implements IFSZ_IEntity.NewRowEnabled
        Get
            Return p_NewRowEnabled
        End Get
        Set(ByVal value As Boolean)
            p_NewRowEnabled = value
        End Set
    End Property

    Public Property ID(Optional ByVal p_visible As Boolean = True) As Integer
        Get
            Return p_ID
        End Get
        Set(ByVal value As Integer)
            p_ID = value
            If p_visible Then
                Me.set_item("ID", value)
            End If
        End Set
    End Property

    Public Property DOCENTRY(Optional ByVal p_visible As Boolean = True) As Integer
        Get
            Return p_DOCENTRY
        End Get
        Set(ByVal value As Integer)
            p_DOCENTRY = value
            If p_visible Then
                Me.set_item("DOCENTRY", value)
            End If
        End Set
    End Property

    Public Property MEGNEVEZES(Optional ByVal p_visible As Boolean = True) As String
        Get
            Return p_MEGNEVEZES
        End Get
        Set(ByVal value As String)
            If Not value Is Nothing And value <> "" Then
                p_MEGNEVEZES = value
                If p_visible Then
                    Me.set_item("MEGNEVEZES", value)
                End If
            Else
                p_MEGNEVEZES = Nothing
                If p_visible Then
                    Me.set_item("MEGNEVEZES", DBNull.Value)
                End If
            End If
        End Set
    End Property

    Public Property MEGJEGYZES(Optional ByVal p_visible As Boolean = True) As String
        Get
            Return p_MEGJEGYZES
        End Get
        Set(ByVal value As String)
            If Not value Is Nothing And value <> "" Then
                p_MEGJEGYZES = value
                If p_visible Then
                    Me.set_item("MEGJEGYZES", value)
                End If
            Else
                p_MEGJEGYZES = Nothing
                If p_visible Then
                    Me.set_item("MEGJEGYZES", DBNull.Value)
                End If
            End If
        End Set
    End Property

#End Region

#Region "Implements"


    Public Function GetAttribute(ByVal p_oszlop As String) As Object Implements IFSZ_IEntity.GetAttribute
        Dim p_valid As Boolean = True
        Select Case p_oszlop
            Case "ID"
                Return ID
            Case "DOCENTRY"
                Return DOCENTRY
            Case "MEGNEVEZES"
                Return MEGNEVEZES
            Case "MEGJEGYZES"
                Return MEGJEGYZES
            Case Else
                Return False

        End Select
        Return Nothing
    End Function

    Private Sub SetAttribute(ByVal p_oszlop As String, ByRef p_ertek As Object)
        Dim p_valid As Boolean = True
        Select Case p_oszlop
            Case "ID"
                ID(False) = p_ertek
            Case "DOCENTRY"
                DOCENTRY(False) = p_ertek

            Case "MEGNEVEZES"
                If p_ertek.GetType.Name.ToLower <> "dbnull" Then
                    MEGNEVEZES(False) = p_ertek
                Else
                    MEGNEVEZES(False) = Nothing
                End If
            Case "MEGJEGYZES"
                If p_ertek.GetType.Name.ToLower <> "dbnull" Then
                    MEGJEGYZES(False) = p_ertek
                Else
                    MEGJEGYZES(False) = Nothing
                End If
        End Select

    End Sub

    Friend Function Val_Attribute(ByVal p_oszlop As String, ByRef p_ertek As String, ByRef p_message As String) As Boolean Implements IFSZ_IEntity.Val_Attribute
        Dim p_valid As Boolean = True
        Dim p_value As String
        Select Case p_oszlop
            Case "ID"
                p_valid = Me.Val_ID(p_ertek, p_message)
                If p_valid Then
                    ID = p_ertek
                End If
                Return p_valid
            Case "MEGNEVEZES"
                p_valid = Me.Val_MEGNEVEZES(p_ertek, p_message)
                If p_valid Then
                    MEGNEVEZES = p_ertek
                End If
                Return p_valid
            Case "MEGJEGYZES"
                p_valid = Me.Val_MEGJEGYZES(p_ertek, p_message)
                If p_valid Then
                    MEGJEGYZES = p_ertek
                End If
                Return p_valid
            Case Else
                set_item(p_oszlop, p_ertek)
                Return True

        End Select

    End Function

    Friend Function Delete(ByRef p_record As Object, ByVal p_record_old As Object, Optional ByRef p_message As String = "") As Integer Implements IFSZ_IEntity.Delete
        Dim l_retval As Integer = 1
        Return l_retval
    End Function

    Friend Function insert(ByRef p_record As Object, Optional ByRef p_message As String = "") As Integer Implements IFSZ_IEntity.Insert
        Dim l_retval As Integer = 1
        Return l_retval
    End Function

    Friend Function Update(ByRef p_record As Object, ByVal p_record_old As Object, Optional ByRef p_message As String = "") As Integer Implements IFSZ_IEntity.Update
        Dim l_retval As Integer = 1
        Return l_retval
    End Function

    Private Sub create(ByRef p_record As Object) Implements IFSZ_IEntity.Create
        'Me.set_item("ID", m_IFSZ_Globals.get_next_seq("DEFAULT"))
    End Sub

    Private Sub set_row(ByVal p_row As DataRow) Implements IFSZ_IEntity.set_row
        Dim i As Integer

        For i = 0 To p_row.Table.Columns.Count - 1
            Select Case p_row.Table.Columns.Item(i).ColumnName
                Case "ID"
                    If p_row.IsNull(i) Then
                        ID(False) = Nothing
                    Else
                        ID(False) = p_row.Item(i)
                    End If
                Case "DOCENTRY"
                    If p_row.IsNull(i) Then
                        DOCENTRY(False) = Nothing
                    Else
                        DOCENTRY(False) = p_row.Item(i)
                    End If
                Case "MEGNEVEZES"
                    If p_row.IsNull(i) Then
                        MEGNEVEZES(False) = Nothing
                    Else
                        MEGNEVEZES(False) = p_row.Item(i)
                    End If
                Case "MEGJEGYZES"
                    If p_row.IsNull(i) Then
                        MEGJEGYZES(False) = Nothing
                    Else
                        MEGJEGYZES(False) = p_row.Item(i)
                    End If
            End Select
        Next
    End Sub


    Public Function get_ChildTableNames() As String() Implements IFSZ_IEntity.get_ChildTableNames
        Return Me.p_ChildTableNames
    End Function

    Public Function get_DataTable(ByVal p_where As String) As System.Data.DataTable Implements IFSZ_IEntity.get_DataTable
        Dim p_query As String
        If p_where = "" Then
            p_query = Me.p_SqlQuery
        Else
            p_query = Me.p_SqlQuery & p_where
        End If
        Return DataProvider.GetDataTable(p_query)

    End Function

    Public Function getChildEntity(ByVal p_TableName As String) As IFSZ_IEntity Implements IFSZ_IEntity.getChildEntity
        Return Nothing
    End Function

#End Region

#Region "Privates"

    Private Function Val_ID(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        Return True
    End Function

    Private Function Val_MEGNEVEZES(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        Return True
    End Function

    Private Function Val_MEGJEGYZES(ByRef p_ertek As String, ByRef p_message As String) As Boolean
        Return True
    End Function

    Private Sub set_item(ByVal p_oszlop As String, ByVal p_ertek As Object) Implements IFSZ_IEntity.set_item

    End Sub

    Private Function GetMessage(ByVal pMessage As String) As String
        Dim l_Message As String
        If pMessage Is Nothing Or pMessage = "" Then
            Return Nothing
        End If
        l_Message = Me.m_IFSZ_Globals.LocRM.GetString(pMessage)
        If l_Message Is Nothing Then
            Return pMessage
        Else
            Return l_Message
        End If
        MsgBox(l_Message)
    End Function

#End Region


    Public Function get_ChildRows(ByVal p_TableName As String, ByVal p_FK_ID As Integer, Optional ByVal p_FkOszlop As String = "", Optional ByVal p_where As String = "") As System.Data.DataRowCollection Implements IFSZ_IEntity.get_ChildRows
        Dim p_row As DataRow
        Dim p_message As String
        Try
        Catch ex As Exception
            MsgBox(ex.ToString, MsgBoxStyle.OkCancel, "Hiba!")
            Return Nothing
        End Try

    End Function

    Public Function get_DataRow(ByVal p_ID As Integer) As System.Data.DataRow Implements IFSZ_IEntity.get_DataRow
        Return Nothing
    End Function

    Public Function get_DataRows(ByVal p_where As String) As System.Data.DataRowCollection Implements IFSZ_IEntity.get_DataRows
        Return Nothing
    End Function


    Public Function get_ParentTableNames() As String() Implements IFSZ_IEntity.get_ParentTableNames
        Return Nothing
    End Function

    Public Function getParentEntity(ByVal p_TableName As String) As IFSZ_IEntity Implements IFSZ_IEntity.getParentEntity
        Return (Nothing)
    End Function

    Public Function get_ParentRow(ByVal p_TableName As String, ByVal p_ID As String) As System.Data.DataRow Implements IFSZ_IEntity.get_ParentRow
        Return Nothing
    End Function

    Public Property ChildRelation() As IFSZ_Types.Relations Implements IFSZ_IEntity.ChildRelation
        Get
            Return Me.p_ChildRelations
        End Get
        Set(ByVal value As IFSZ_Types.Relations)
            Me.p_ChildRelations = value
        End Set
    End Property

    Public Property m_IFSZ_Globals() As IFSZ_Globals Implements IFSZ_IEntity.m_IFSZ_Globals
        Get
            Return Me.p_IFSZ_Globals
        End Get
        Set(ByVal value As IFSZ_Globals)
            Me.p_IFSZ_Globals = value
        End Set
    End Property

    Public Function GetAttributeDomain(ByVal p_oszlop As String) As Object Implements IFSZ_IEntity.GetAttributeDomain
        Dim p_valid As Boolean = True
        Select Case p_oszlop
            Case Else
                Return Nothing
        End Select
        Return Nothing
    End Function

    Function GetAttributeType(ByVal p_oszlop As String) As String Implements IFSZ_IEntity.GetAttributeType
        Select Case p_oszlop
            Case "ID"
                Return "NUMBER"
            Case "MEGNEVEZES"
                Return "VARCHAR"
            Case "MEGJEGYZES"
                Return "VARCHAR"
        End Select
        Return "VARCHAR"
    End Function

    Public Property PrimaryKey() As IFSZ_Types.PrimaryKeys Implements IFSZ_IEntity.PrimaryKey
        Get
            Return Me.p_PrimaryKey
        End Get
        Set(ByVal value As IFSZ_Types.PrimaryKeys)
            Me.p_PrimaryKey = value
        End Set
    End Property

    Public Property ArchivKey() As IFSZ_Types.PrimaryKeys Implements IFSZ_IEntity.ArchivKey
        Get

        End Get
        Set(ByVal value As IFSZ_Types.PrimaryKeys)

        End Set
    End Property

    Public Property ArchivQuery() As String Implements IFSZ_IEntity.ArchivQuery
        Get

        End Get
        Set(ByVal value As String)

        End Set
    End Property

    Public Property ArchivFormTipus() As IFSZ_Types.LOV_Form Implements IFSZ_IEntity.ArchivFormTipus
        Get

        End Get
        Set(ByVal value As IFSZ_Types.LOV_Form)

        End Set
    End Property

    Public Property ArchivOszlopTipus() As IFSZ_Types.LOV_OszlopTipus() Implements IFSZ_IEntity.ArchivOszlopTipus
        Get

        End Get
        Set(ByVal value As IFSZ_Types.LOV_OszlopTipus())

        End Set
    End Property

    Public Property ArchivEnabled() As Boolean Implements IFSZ_IEntity.ArchivEnabled
        Get

        End Get
        Set(ByVal value As Boolean)

        End Set
    End Property

    Public Property ViewName As String Implements IFSZ_IEntity.ViewName
        Get

        End Get
        Set(value As String)

        End Set
    End Property

    Public Property LastQuery As String Implements IFSZ_IEntity.LastQuery
        Get

        End Get
        Set(value As String)

        End Set
    End Property
End Class