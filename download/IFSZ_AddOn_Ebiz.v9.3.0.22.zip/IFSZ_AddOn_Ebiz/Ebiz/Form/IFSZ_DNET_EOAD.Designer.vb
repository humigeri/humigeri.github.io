<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _Partial Class IFSZ_DNET_EOAD    'Inherits System.Windows.Forms.Form
    Inherits IFSZ_Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _    Protected Overrides Sub Dispose(ByVal disposing As Boolean)        If disposing AndAlso components IsNot Nothing Then            components.Dispose()        End If        MyBase.Dispose(disposing)    End Sub    'Required by the Windows Form Designer    Private components As System.ComponentModel.IContainer    'NOTE: The following procedure is required by the Windows Form Designer    'It can be modified using the Windows Form Designer.      'Do not modify it using the code editor.    <System.Diagnostics.DebuggerStepThrough()> _    Private Sub InitializeComponent()        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.IDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_EOL_ID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_CNTCT_NAME = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_CNTCT_EMAIL = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.IFSZKODViewBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.OK = New System.Windows.Forms.Button()
        Me.MEGSE = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.IFSZKODViewBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridView1.AutoGenerateColumns = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IDDataGridViewTextBoxColumn, Me.DG1_EOL_ID, Me.DG1_CNTCT_NAME, Me.DG1_CNTCT_EMAIL})
        Me.DataGridView1.DataSource = Me.IFSZKODViewBindingSource
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView1.DefaultCellStyle = DataGridViewCellStyle2
        Me.DataGridView1.Location = New System.Drawing.Point(12, 12)
        Me.DataGridView1.Name = "DataGridView1"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.DataGridView1.Size = New System.Drawing.Size(419, 214)
        Me.DataGridView1.TabIndex = 1
        '
        'IDDataGridViewTextBoxColumn
        '
        Me.IDDataGridViewTextBoxColumn.DataPropertyName = "ID"
        Me.IDDataGridViewTextBoxColumn.HeaderText = "ID"
        Me.IDDataGridViewTextBoxColumn.Name = "IDDataGridViewTextBoxColumn"
        Me.IDDataGridViewTextBoxColumn.Visible = False
        '
        'DG1_EOL_ID
        '
        Me.DG1_EOL_ID.DataPropertyName = "EOL_ID"
        Me.DG1_EOL_ID.HeaderText = "EOL_ID"
        Me.DG1_EOL_ID.Name = "DG1_EOL_ID"
        Me.DG1_EOL_ID.Visible = False
        '
        'DG1_CNTCT_NAME
        '
        Me.DG1_CNTCT_NAME.DataPropertyName = "CNTCT_NAME"
        Me.DG1_CNTCT_NAME.HeaderText = "N�v"
        Me.DG1_CNTCT_NAME.Name = "DG1_CNTCT_NAME"
        Me.DG1_CNTCT_NAME.Width = 200
        '
        'DG1_CNTCT_EMAIL
        '
        Me.DG1_CNTCT_EMAIL.DataPropertyName = "CNTCT_EMAIL"
        Me.DG1_CNTCT_EMAIL.HeaderText = "Email"
        Me.DG1_CNTCT_EMAIL.Name = "DG1_CNTCT_EMAIL"
        Me.DG1_CNTCT_EMAIL.Width = 150
        '
        'IFSZKODViewBindingSource
        '
        Me.IFSZKODViewBindingSource.DataSource = GetType(IFSZ_AddOnBase.IFSZ_EOAD_View)
        '
        'OK
        '
        Me.OK.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.OK.Location = New System.Drawing.Point(12, 232)
        Me.OK.Name = "OK"
        Me.OK.Size = New System.Drawing.Size(75, 23)
        Me.OK.TabIndex = 2
        Me.OK.Text = "Ok"
        Me.OK.UseVisualStyleBackColor = True
        '
        'MEGSE
        '
        Me.MEGSE.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.MEGSE.Location = New System.Drawing.Point(93, 232)
        Me.MEGSE.Name = "MEGSE"
        Me.MEGSE.Size = New System.Drawing.Size(75, 23)
        Me.MEGSE.TabIndex = 3
        Me.MEGSE.Text = "M�gse"
        Me.MEGSE.UseVisualStyleBackColor = True
        '
        'IFSZ_DNET_EOAD
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(439, 267)
        Me.Controls.Add(Me.MEGSE)
        Me.Controls.Add(Me.OK)
        Me.Controls.Add(Me.DataGridView1)
        Me.Name = "IFSZ_DNET_EOAD"
        Me.Text = "C�mzettek"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.IFSZKODViewBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView    Friend WithEvents IFSZKODViewBindingSource As System.Windows.Forms.BindingSource    Friend WithEvents OK As System.Windows.Forms.Button    Friend WithEvents MEGSE As System.Windows.Forms.Button    Friend WithEvents KODDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn    Friend WithEvents MEGNEVEZESDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn    Friend WithEvents ERVENYESEDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn    Friend WithEvents MEGJEGYZESDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn    Friend WithEvents TIPUSDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents IDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DG1_EOL_ID As DataGridViewTextBoxColumn
    Friend WithEvents DG1_CNTCT_NAME As DataGridViewTextBoxColumn
    Friend WithEvents DG1_CNTCT_EMAIL As DataGridViewTextBoxColumn
End Class