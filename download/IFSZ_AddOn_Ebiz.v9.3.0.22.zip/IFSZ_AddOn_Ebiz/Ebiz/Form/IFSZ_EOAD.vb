﻿'----------------------------------------------------------------------------''Generálva: 2008.09.01'FormViewGenerator. Verzió: 1.0.4.0'----------------------------------------------------------------------------'Option Explicit OnImports IFSZ_AddOnBasePublic Class IFSZ_EOAD    'Inherits IFSZ_Interim_SBO
    Inherits IFSZ_InterimBridge_SBO

    Public m_eol_id As Integer    Public m_hivo_formuid As String
    Public Sub New(
        ByRef ParentAddon As SBOAddOn,
        ByVal FunctionCode As String,
        ByRef p_eoh_formuid As String,
        ByVal p_eol_id As Integer
    )        MyBase.New(ParentAddon, FunctionCode)        m_hivo_formuid = p_eoh_formuid
        Me.m_eol_id = p_eol_id        p_ParentAddon = ParentAddon    End Sub    Public Overrides Sub ConstructForm()
        oForm = New IFSZ_DNET_EOAD(Me.p_ParentAddon, Me, m_eol_id)    End Sub    Public Overrides Sub FORMEVENT(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)        If pVal.Before_Action = False Then        Else            If pVal.EventType = SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE Then                If oForm.Visible Then                    BubbleEvent = False                End If            ElseIf pVal.EventType = SAPbouiCOM.BoEventTypes.et_CLICK Then                oForm.Visible = False            End If        End If    End Sub
    'Public Overrides Sub HANDLE_MENU_EVENTS(ByRef pVal As SAPbouiCOM.MenuEvent, ByRef BubbleEvent As Boolean)
    '    Dim i As Integer
    '    i = 0
    'End Sub
    Protected Overrides Sub Finalize()        MyBase.Finalize()    End Sub    Public Overrides Sub FormClose()
        IFSZ_EOH_Ctrl.m_frissit = True
        For i As Integer = 1 To m_ParentAddon.SBOForms.Count
            If m_ParentAddon.SBOForms(i).GetType() Is GetType(IFSZ_EOH) Then
                If CType(m_ParentAddon.SBOForms(i), IFSZ_EOH).UniqueID = m_hivo_formuid Then
                    CType(m_ParentAddon.SBOForms(i), IFSZ_EOH).oForm.SelectWindow()
                    Exit For
                End If
            End If
        Next
        MyBase.FormClose()
    End SubEnd Class