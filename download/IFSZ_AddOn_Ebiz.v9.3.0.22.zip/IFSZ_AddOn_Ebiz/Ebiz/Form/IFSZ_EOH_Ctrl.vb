﻿'----------------------------------------------------------------------------'
'Generálva: 2020.03.22
'FormViewGenerator. Verzió: 1.0.7.0
'----------------------------------------------------------------------------'

Imports IFSZ_AddOnBase.IFSZ_Types
Imports System
Imports System.IO
Imports System.Text
Imports System.Net
Imports System.Text.RegularExpressions

Public Class IFSZ_EOH_Ctrl
    Implements IFSZ_ICTRL
    Implements IIFSZ_FileDialogResult

    Public Sub New()

    End Sub

    Public Sub New(ByRef frmMain As Object)
        frmForm = frmMain
        plSaveFileDialog = New IFSZ_FileDialog()
        Me.m_frmView = New IFSZ_EOH_View()
    End Sub

    Public Shared m_frissit As Boolean = False
    Private m_crystal_suly As Integer = 1
    Private m_pdf_suly As Integer = 1
    Private m_email_suly As Integer = 1

    Private frmForm As IFSZ_DNET_EOH
    Private plFileDialogOpen As Boolean = False
    Private plSaveFileDialog As IFSZ_FileDialog
    Private m_frmView As IFSZ_EOH_View

    Private m_sablon_atirhato_e As Boolean = True
    Private m_cimzett_modosithato_e As Boolean = True
    Private m_crystal_modosithato_e As Boolean = True
    Private m_file_formatum As String = ""

    Private m_controlok As Dictionary(Of Control, Boolean)
    Private m_megallit As Boolean = False
    Public m_abort As Boolean = False

    Private m_progress_osszes As Integer = 0
    Private m_progress_akt As Integer = 0
    Private m_progress_felirat As String = ""
    Private m_ebiz_srv As String = ""
    Private m_req_read_receipt As Boolean = False
    Private m_req_del_not As Boolean = False

    Private m_crystalok As Dictionary(Of String, CrystalDecisions.CrystalReports.Engine.ReportDocument)

    Private m_BeallitDataGrid As DataGridView

    Public m_impersonator As AliasAccount

    Public Sub Form_Event(ByVal pEvent As String, ByVal sender As Object, ByVal e As System.EventArgs) Implements IFSZ_ICTRL.Form_Event
        Dim p_relation As IFSZ_Types.Relations = New IFSZ_Types.Relations
        If pEvent = "PreForm" Then
            Me.frmForm.T_USERCODE.Tag = Me.frmForm.entity(0)
            Me.frmForm.T_DOCNUM.Tag = Me.frmForm.entity(0)
            Me.frmForm.T_STATUS.Tag = Me.frmForm.entity(0)
            Me.frmForm.T_NOTE.Tag = Me.frmForm.entity(0)
            Me.frmForm.T_SENTTS.Tag = Me.frmForm.entity(0)
            Me.frmForm.T_PATH.Tag = Me.frmForm.entity(0)

            Dim l_role As IFSZ_Role
            l_role = New IFSZ_Role(Me.frmForm.m_ParentAddon)

            Dim l_temp As String = IFSZ_Globals.GetParameter("EBIZTEMPLMOD")
            If Not String.IsNullOrEmpty(l_temp) AndAlso l_temp.ToUpper() = "N" Then
                m_sablon_atirhato_e = False
                If l_role.HasRole("EBIZTEMPLMOD") Then
                    m_sablon_atirhato_e = True
                End If
            End If

            l_temp = IFSZ_Globals.GetParameter("EBIZADDRMOD")
            If Not String.IsNullOrEmpty(l_temp) AndAlso l_temp.ToUpper() = "N" Then
                m_cimzett_modosithato_e = False
                If l_role.HasRole("EBIZADDRMOD") Then
                    m_cimzett_modosithato_e = True
                End If
            End If

            l_temp = IFSZ_Globals.GetParameter("EBIZPRINTLAYOUTMOD")
            If Not String.IsNullOrEmpty(l_temp) AndAlso l_temp.ToUpper() = "N" Then
                m_crystal_modosithato_e = False
                If l_role.HasRole("EBIZPRINTLAYOUTMOD") Then
                    m_crystal_modosithato_e = True
                End If
            End If

            l_temp = IFSZ_Globals.GetParameter("EBIZSRV")
            If Not String.IsNullOrEmpty(l_temp) Then
                m_ebiz_srv = l_temp
            End If

            l_temp = IFSZ_Globals.GetParameter("EBIZRRR")
            If Not String.IsNullOrEmpty(l_temp) AndAlso l_temp.ToUpper() = "I" Then
                m_req_read_receipt = True
            End If

            l_temp = IFSZ_Globals.GetParameter("EBIZDSN")
            If Not String.IsNullOrEmpty(l_temp) AndAlso l_temp.ToUpper() = "I" Then
                m_req_del_not = True
            End If

            l_temp = IFSZ_Globals.GetParameter("EBIZFILENAME")
            If String.IsNullOrEmpty(l_temp) Then
                m_file_formatum = "<docnum>_<timestamp>"
            Else
                m_file_formatum = l_temp
            End If

            Me.GridBeallitas()

            IFSZ_EMAILOUTHEAD.l_fs_domain = IFSZ_Globals.GetParameter("EBIZPATH_DOMAIN")
            IFSZ_EMAILOUTHEAD.l_fs_username = IFSZ_Globals.GetParameter("EBIZPATH_USER")
            IFSZ_EMAILOUTHEAD.l_fs_passwordStr = IFSZ_Globals.GetParameter("EBIZPATH_PASSWORD")
            If Not String.IsNullOrEmpty(IFSZ_EMAILOUTHEAD.l_fs_username) AndAlso Not String.IsNullOrEmpty(IFSZ_EMAILOUTHEAD.l_fs_passwordStr) Then
                If IFSZ_EMAILOUTHEAD.l_fs_passwordStr.StartsWith("CRYPT:") Then
                    IFSZ_EMAILOUTHEAD.l_fs_passwordStr = IFSZ_EMAILOUTHEAD.l_fs_passwordStr.Substring(6)
                    If IFSZ_EMAILOUTHEAD.l_fs_passwordStr <> "" Then
                        IFSZ_EMAILOUTHEAD.l_fs_passwordStr = IFSZ_EMAILACCOUNTS.JelszoVisszaKodol(IFSZ_EMAILOUTHEAD.l_fs_passwordStr)
                    End If
                Else
                    Dim l_vissza As String = IFSZ_EMAILACCOUNTS.JelszoKodol(IFSZ_EMAILOUTHEAD.l_fs_passwordStr)
                    DataProvider.EExecuteNonQuery("update ""@IFSZ_PARAMETERS"" set ""U_Value"" = " + IFSZ_Globals.SQLConstantPrepare("CRYPT:" + l_vissza) + " where ""Name"" = " + IFSZ_Globals.SQLConstantPrepare("EBIZPATH_PASSWORD"))
                End If
                m_impersonator = New AliasAccount(IFSZ_EMAILOUTHEAD.l_fs_username, IFSZ_EMAILOUTHEAD.l_fs_passwordStr, IFSZ_EMAILOUTHEAD.l_fs_domain)
                IFSZ_EMAILOUTHEAD.m_impersonated = True
            Else
                IFSZ_EMAILOUTHEAD.m_impersonated = False
            End If

        ElseIf pEvent = "FormLoad" Then

            Me.frmForm.entity(0).NewRowEnabled = True

            Me.frmForm.p_dataset = m_frmView.getDataSet
            ReDim Preserve p_relation.Tables(0)            ReDim Preserve p_relation.Tables(0).PK_Columns(0)            ReDim Preserve p_relation.Tables(0).FK_Columns(0)            p_relation.Tables(0).Table = "IFSZ_EMAILOUTLINE"            p_relation.Tables(0).PK_Columns(0) = "ID"            p_relation.Tables(0).FK_Columns(0) = "EOH_ID"            Me.frmForm.entity(0).ChildRelation = p_relation
            Me.frmForm.T_USERCODE.DataBindings.Add("TEXT", Me.frmForm.p_dataset, "IFSZ_EMAILOUTHEAD.USERCODE", True, DataSourceUpdateMode.OnValidation)
            Me.frmForm.T_DOCNUM.DataBindings.Add("TEXT", Me.frmForm.p_dataset, "IFSZ_EMAILOUTHEAD.DOCNUM", True, DataSourceUpdateMode.OnValidation)
            Me.frmForm.T_STATUS.DataBindings.Add("TEXT", Me.frmForm.p_dataset, "IFSZ_EMAILOUTHEAD.STATUS_MEAN", True, DataSourceUpdateMode.OnValidation)
            Me.frmForm.T_NOTE.DataBindings.Add("TEXT", Me.frmForm.p_dataset, "IFSZ_EMAILOUTHEAD.NOTE", True, DataSourceUpdateMode.OnValidation)
            Me.frmForm.T_SENTTS.DataBindings.Add("TEXT", Me.frmForm.p_dataset, "IFSZ_EMAILOUTHEAD.SENTTS", True, DataSourceUpdateMode.OnValidation)
            Me.frmForm.T_PATH.DataBindings.Add("TEXT", Me.frmForm.p_dataset, "IFSZ_EMAILOUTHEAD.PATH", True, DataSourceUpdateMode.OnValidation)

            Me.frmForm.entity(1).NewRowEnabled = False

            Me.frmForm.DataGridView1.DataSource = Me.frmForm.p_dataset
            Me.frmForm.DataGridView1.Name = "IFSZ_EMAILOUTLINE"
            Me.frmForm.DataGridView1.DataMember = "IFSZ_EMAILOUTLINE"

            Me.GridBeallitas()

        ElseIf pEvent = "AfterFormLoad" Then
            If CType(Me.frmForm.m_Interim_SBO, IFSZ_EOH).m_eoh_id > -1 Then
                Me.frmForm.entity(0).DefaultWhere = " ID = " & IFSZ_Globals.SQLConstantPrepare(CType(Me.frmForm.m_Interim_SBO, IFSZ_EOH).m_eoh_id)
                Me.frmForm.BlockRefresh("IFSZ_EMAILOUTHEAD")
                Me.frmForm.entity(0).DefaultWhere = ""

            Else
                Dim l_tab As DataTable = get_DataTable("IFSZ_EMAILOUTHEAD", "TABLE", Nothing, " STATUS = 'R' and USERCODE = " + IFSZ_Globals.SQLConstantPrepare(IFSZ_Globals.SboUserName))
                If l_tab Is Nothing OrElse l_tab.Rows.Count = 0 Then
                    Me.frmForm.uj_sor(Me.frmForm.T_NOTE)
                Else
                    Me.frmForm.entity(0).DefaultWhere = " STATUS = 'R' and USERCODE = " + IFSZ_Globals.SQLConstantPrepare(IFSZ_Globals.SboUserName)
                    Me.frmForm.BlockRefresh("IFSZ_EMAILOUTHEAD")
                    Me.frmForm.entity(0).DefaultWhere = ""
                End If

            End If

            Me.frmForm.T_NOTE.Focus()

        End If
    End Sub

    Public Function get_DataTable(ByVal p_TableName As String, Optional ByVal p_tipus As String = "", Optional ByVal sender As Object = Nothing, Optional ByVal p_where As String = "") As System.Data.DataTable Implements IFSZ_ICTRL.get_DataTable
        Dim p_SqlQuery As String
        'Dim frm_view As IFSZ_EgyszBeszerTerv_View = New IFSZ_EgyszBeszerTerv_View()
        Dim i, j, p_pk_num As Integer
        'Dim p_relation As IFSZ_Types.Relations
        Dim p_table As IFSZ_Types.RelationTable
        'Dim p_pk_id, p_fk_id As String
        Dim l_datatable As DataTable
        Dim l_row As DataRow

        Select Case p_tipus
            Case "MASTER/DETAIL"
                For i = 0 To frmForm.entity.GetUpperBound(0)
                    If sender.Position > -1 AndAlso frmForm.entity(i).TableName = sender.current.row.table.tablename() Then
                        For Each p_table In frmForm.entity(i).ChildRelation.Tables
                            If p_table.Table = p_TableName Then
                                For p_pk_num = 0 To p_table.PK_Columns.GetUpperBound(0)
                                    If p_pk_num = 0 Then
                                        p_SqlQuery = Me.m_frmView.getSqlQuery(p_TableName, p_tipus) & "where " & p_table.FK_Columns(p_pk_num) & " = " & sender.current.row(p_table.PK_Columns(p_pk_num))
                                    Else
                                        p_SqlQuery = Me.m_frmView.getSqlQuery(p_TableName, p_tipus) & " and " & p_table.FK_Columns(p_pk_num) & " = " & sender.current.row(p_table.PK_Columns(p_pk_num))
                                    End If
                                Next
                                For j = 0 To frmForm.entity.GetUpperBound(0)
                                    If frmForm.entity(j).TableName = p_TableName Then
                                        frmForm.entity(j).ChildWhere = p_SqlQuery.Substring(p_SqlQuery.ToUpper.IndexOf("WHERE") + 5, p_SqlQuery.Length - p_SqlQuery.ToUpper.IndexOf("WHERE") - 5).Trim
                                        If frmForm.entity(j).DefaultWhere <> "" Then
                                            p_SqlQuery = p_SqlQuery & " and " & frmForm.entity(j).DefaultWhere
                                            'p_SqlQuery = p_SqlQuery & " and " & frmForm.entity(i).DefaultWhere
                                        End If
                                        'frmForm.entity(j).ChildWhere = p_SqlQuery.Substring(p_SqlQuery.ToUpper.IndexOf("WHERE") + 5, p_SqlQuery.Length - p_SqlQuery.ToUpper.IndexOf("WHERE") - 5).Trim
                                    End If
                                Next
                            End If
                        Next
                    End If

                    'If frmForm.entity(i).TableName = p_TableName Then
                    '    p_SqlQuery = frm_view.getSqlQuery(p_TableName, p_tipus) & sender.current.row("ID")
                    '    frmForm.entity(i).ChildWhere = p_SqlQuery.Substring(p_SqlQuery.ToUpper.IndexOf("WHERE") + 5, p_SqlQuery.Length - p_SqlQuery.ToUpper.IndexOf("WHERE") - 5).Trim
                    'End If
                    'frmForm.entity(i).ChildWhere = p_SqlQuery.Substring(p_SqlQuery.ToUpper.IndexOf("WHERE") + 5, p_SqlQuery.Length - p_SqlQuery.ToUpper.IndexOf("WHERE") - 5).Trim
                Next
                l_datatable = DataProvider.GetDataTable(p_SqlQuery)
                Return l_datatable
            Case "TABLE"
                p_SqlQuery = Me.m_frmView.getSqlQuery(p_TableName, p_tipus)
                If p_where = "" Then
                    p_where = "1=1"
                Else
                    p_where = p_where.Replace("'False'", "'N'").Replace("'True'", "'Y'")
                End If
                For i = 0 To frmForm.entity.GetUpperBound(0)
                    If frmForm.entity(i).TableName = p_TableName And frmForm.entity(i).DefaultWhere <> "" Then
                        p_where = p_where & " and " & frmForm.entity(i).DefaultWhere
                        If frmForm.entity(i).ChildWhere <> "" Then
                            p_where = p_where & " and " & frmForm.entity(i).ChildWhere
                        End If
                    ElseIf frmForm.entity(i).TableName = p_TableName And frmForm.entity(i).ChildWhere <> "" Then
                        p_where = p_where & " and " & frmForm.entity(i).ChildWhere
                    End If
                Next
                p_SqlQuery = p_SqlQuery & " where " & p_where
                If p_TableName = "IFSZ_EMAILOUTHEAD" Then
                    p_SqlQuery += " order by id desc"
                End If
                l_datatable = DataProvider.GetDataTable(p_SqlQuery)
                Return l_datatable
            Case Else
                l_datatable = DataProvider.GetDataTable(p_SqlQuery)
                Return l_datatable
        End Select

    End Function

    '----------------------------------------------------------------------------
    '----------------------------------------------------------------------------
    'Item_Event
    '----------------------------------------------------------------------------
    '----------------------------------------------------------------------------
    Public Sub Item_Event(ByVal pEvent As IFSZ_Types.PItemEvent, ByVal sender As Object, ByVal e As System.EventArgs) Implements IFSZ_ICTRL.Item_Event
        'Dim i As Integer
        '----------------------------------------------------------------------------
        'ItemClick esemény
        '----------------------------------------------------------------------------
        If pEvent = PItemEvent.ItemClick Then
            If sender.GetType() Is GetType(Button) Then
                Select Case CType(sender, Button).Name
                    Case "B_EMAILS"
                        Dim l_status As String = Me.frmForm.entity(0).GetAttribute("STATUS").ToString()
                        If l_status = "R" AndAlso m_cimzett_modosithato_e Then
                            If Me.frmForm.p_dataset.HasChanges Then
                                Me.frmForm.aktualizal()
                            End If
                            If Not Me.frmForm.p_dataset.HasChanges Then
                                Dim l_row As DataRow = Me.frmForm.getSelectedRow("IFSZ_EMAILOUTLINE")
                                If IsDBNull(l_row("ID")) Then
                                    Me.frmForm.show_error("Válasszon ki egy tételsort")
                                Else
                                    Me.ControlokLetilt()
                                    Dim oForm As IFSZ_EOAD
                                    oForm = New IFSZ_EOAD(Me.frmForm.m_ParentAddon, "F_EOAD", Me.frmForm.m_Interim_SBO.UniqueID, l_row("ID"))
                                    If oForm IsNot Nothing Then
                                        Me.frmForm.m_ParentAddon.SBOForms.Add(oForm, oForm.UniqueID)
                                    End If
                                End If
                            End If
                        End If

                    Case "B_KIVALASZT"
                        Dim l_status As String = Me.frmForm.entity(0).GetAttribute("STATUS").ToString()
                        If l_status = "R" Then
                            If Me.frmForm.p_dataset.HasChanges Then
                                Me.frmForm.aktualizal()
                            End If
                            If Not Me.frmForm.p_dataset.HasChanges Then
                                Me.ControlokLetilt()
                                Dim oForm As IFSZ_SZLAKIV
                                oForm = New IFSZ_SZLAKIV(Me.frmForm.m_ParentAddon, "F_SZLAKV", Me.frmForm.m_Interim_SBO.UniqueID, Me.frmForm.entity(0).GetAttribute("ID"))
                                If oForm IsNot Nothing Then
                                    Me.frmForm.m_ParentAddon.SBOForms.Add(oForm, oForm.UniqueID)
                                End If
                            End If
                        End If

                    Case "B_TET_TOROL"
                        Dim l_status As String = Me.frmForm.entity(0).GetAttribute("STATUS").ToString()
                        If l_status = "R" Then
                            If Me.frmForm.p_dataset.HasChanges Then
                                Me.frmForm.aktualizal()
                            End If
                            If Not Me.frmForm.p_dataset.HasChanges Then
                                Dim l_count As Integer = DataProvider.ExecuteScalar("select count(9) from IFSZ_EMAILOUTLINE where EOH_ID = " + Me.frmForm.entity(0).GetAttribute("ID").ToString() + " and STATUS = 'R'")
                                If l_count > 0 Then
                                    If Me.frmForm.show_question("Biztosan töröl " + l_count.ToString() + " tételsort a bizonylatról?") = MsgBoxResult.Yes Then
                                        Dim l_message As String = IFSZ_EMAILOUTHEAD.TorolOsszesTetel(Me.frmForm.entity(0).GetAttribute("ID"))
                                        If Not String.IsNullOrEmpty(l_message) Then
                                            Me.frmForm.show_error(l_message)
                                        Else
                                            Me.Visszater(False)
                                        End If
                                    End If
                                End If
                            End If
                        End If

                    Case "B_VISSZAVON"
                        Dim l_status As String = Me.frmForm.entity(0).GetAttribute("STATUS").ToString()
                        If l_status = "R" Then
                            If Me.frmForm.p_dataset.HasChanges Then
                                Me.frmForm.aktualizal()
                            End If
                            If Not Me.frmForm.p_dataset.HasChanges Then
                                If Me.frmForm.show_question("Biztosan visszavonja a küldési bizonylatot?") = MsgBoxResult.Yes Then
                                    Dim l_message As String = IFSZ_EMAILOUTHEAD.Visszavon(Me.frmForm.entity(0).GetAttribute("ID"))
                                    If Not String.IsNullOrEmpty(l_message) Then
                                        Me.frmForm.show_error(l_message)
                                    Else
                                        Dim l_row As DataRow = Me.frmForm.getSelectedRow("IFSZ_EMAILOUTHEAD")
                                        Dim l_rc As DataRowCollection = DataProvider.GetDataRecord(Me.m_frmView.getSqlQuery("IFSZ_EMAILOUTHEAD", "TABLE") + " where id = " + Me.frmForm.entity(0).GetAttribute("ID").ToString())
                                        If l_rc IsNot Nothing AndAlso l_rc.Count > 0 Then
                                            For Each l_col As DataColumn In l_rc(0).Table.Columns
                                                If l_col.ColumnName.EndsWith("_MEAN") Then
                                                    Dim l_domain_values As Collection = Me.frmForm.entity(0).GetAttributeDomain(l_col.ColumnName)
                                                    If l_domain_values IsNot Nothing Then
                                                        For Each l_temp As IFSZ_Domains.st_domain_values In l_domain_values
                                                            If l_temp.value = l_row(l_col.ColumnName.Replace("_MEAN", "")).ToString() Then
                                                                l_row(l_col.ColumnName) = l_temp.meaning
                                                                Exit For
                                                            End If
                                                        Next
                                                    End If
                                                Else
                                                    l_row(l_col.ColumnName) = l_rc(0)(l_col.ColumnName)
                                                End If
                                            Next
                                        End If
                                        Me.frmForm.p_dataset.Tables("IFSZ_EMAILOUTHEAD").AcceptChanges()
                                        Dim l_eng As Boolean = Me.FejEngedelyez()
                                        For Each l_trow As DataRow In Me.frmForm.p_dataset.Tables("IFSZ_EMAILOUTLINE").Rows
                                            Me.TetEngedelyez(l_eng, l_trow)
                                        Next
                                        Me.TetEngedelyez(l_eng)
                                    End If
                                End If
                            End If
                        End If

                    Case "B_GENERAL"
                        Dim l_status As String = Me.frmForm.entity(0).GetAttribute("STATUS").ToString()
                        If l_status = "R" Then
                            If Me.frmForm.p_dataset.HasChanges Then
                                Me.frmForm.aktualizal()
                            End If
                            If Not Me.frmForm.p_dataset.HasChanges Then
                                If Me.frmForm.show_question("Biztosan legenerálja a bizonylatokat?") = MsgBoxResult.Yes Then
                                    Me.ControlokLetilt()

                                    Dim l_thread As New System.Threading.Thread(AddressOf ThreadGeneralas)
                                    l_thread.SetApartmentState(Threading.ApartmentState.STA)
                                    l_thread.Start()

                                End If
                            End If
                        End If

                    Case "B_GENERAL_KULD"
                        Dim l_status As String = Me.frmForm.entity(0).GetAttribute("STATUS").ToString()
                        If l_status = "R" Then
                            If Me.frmForm.p_dataset.HasChanges Then
                                Me.frmForm.aktualizal()
                            End If
                            If Not Me.frmForm.p_dataset.HasChanges Then
                                If Me.frmForm.show_question("Biztosan legenerálja és elküldi a bizonylatokat?") = MsgBoxResult.Yes Then
                                    Me.ControlokLetilt()

                                    Dim l_thread As New System.Threading.Thread(AddressOf ThreadGeneralasKuldes)
                                    l_thread.SetApartmentState(Threading.ApartmentState.STA)
                                    l_thread.Start()

                                End If
                            End If
                        End If

                    Case "B_STOP"
                        m_megallit = True

                End Select
            End If
        End If

        '----------------------------------------------------------------------------
        'Item validálás esemény
        '----------------------------------------------------------------------------
        If pEvent = PItemEvent.ItemValidate Then
            If sender.GetType.Name = "DataGridView" Then
                If Me.frmForm.getObjectName(sender, e) = "DG1_CRYSTALNAME" Then
                    Dim l_row As DataRow = Me.frmForm.getSelectedRow("IFSZ_EMAILOUTLINE")
                    If CType(e, System.Windows.Forms.DataGridViewCellValidatingEventArgs).FormattedValue.ToString.Length > 0 Then
                        If CType(e, System.Windows.Forms.DataGridViewCellValidatingEventArgs).FormattedValue.ToString.Substring(CType(e, System.Windows.Forms.DataGridViewCellValidatingEventArgs).FormattedValue.ToString.Length - 1, 1) = "*" Then
                            CType(e, System.Windows.Forms.DataGridViewCellValidatingEventArgs).Cancel = True
                            If CType(e, System.Windows.Forms.DataGridViewCellValidatingEventArgs).FormattedValue.ToString.Length > 1 Then
                                Me.Crystal_lov(sender, CType(e, System.Windows.Forms.DataGridViewCellValidatingEventArgs).FormattedValue.ToString.Substring(0, CType(e, System.Windows.Forms.DataGridViewCellValidatingEventArgs).FormattedValue.ToString.Length - 1), l_row("DOCTYPE"), l_row("DOCENTRY"))
                            Else
                                Me.Crystal_lov(sender, "", l_row("DOCTYPE"), l_row("DOCENTRY"))
                            End If

                        Else
                            Dim l_DataRowCollection As DataRowCollection = Me.get_elso_crystal(CType(e, System.Windows.Forms.DataGridViewCellValidatingEventArgs).FormattedValue, l_row("DOCTYPE"), l_row("DOCENTRY"))
                            If l_DataRowCollection.Count = 1 OrElse (l_DataRowCollection.Count > 1 AndAlso l_DataRowCollection(0)("DOCNAME").ToString().ToUpper() = CType(e, System.Windows.Forms.DataGridViewCellValidatingEventArgs).FormattedValue.ToString().ToUpper()) Then
                                Me.frmForm.entity(1).set_item("CRYSTAL", l_DataRowCollection(0)("DOCCODE"))
                                Me.frmForm.entity(1).set_item("CRYSTALNAME", l_DataRowCollection(0)("DOCNAME"))
                            Else
                                Me.frmForm.show_error(sender, "Nem létező nyomtatási formátum! Használjon értéklistát!", e)
                            End If

                        End If

                    Else
                        Me.frmForm.entity(1).set_item("CRYSTAL", DBNull.Value)
                        Me.frmForm.entity(1).set_item("CRYSTALNAME", DBNull.Value)

                    End If
                End If
            End If
        End If

        If pEvent = PItemEvent.CreateRow Then
            If sender.GetType() Is GetType(TextBox) Then
                If GetType(IFSZ_IEntity).IsAssignableFrom(CType(sender, TextBox).Tag.GetType()) AndAlso CType(CType(sender, TextBox).Tag, IFSZ_IEntity).TableName = "IFSZ_EMAILOUTHEAD" Then
                    Me.frmForm.entity(0).set_item("USERCODE", IFSZ_Globals.SboUserName)
                    Try
                        Me.frmForm.entity(0).set_item("DOCNUM", IFSZ_EMAILOUTHEAD.GetNextBizszam(False))
                    Catch ex As Exception
                        Me.frmForm.show_error(ex.Message)
                    End Try
                    Dim l_eng As Boolean = Me.FejEngedelyez()
                    For Each l_trow As DataRow In Me.frmForm.p_dataset.Tables("IFSZ_EMAILOUTLINE").Rows
                        Me.TetEngedelyez(l_eng, l_trow)
                    Next
                    Me.TetEngedelyez(l_eng)
                End If
            End If
        End If

        If pEvent = PItemEvent.PositionChanged Then
            If CType(sender.current, DataRowView).Row.Table.TableName = "IFSZ_EMAILOUTHEAD" Then
                Dim l_row As DataRow = Me.frmForm.getSelectedRow("IFSZ_EMAILOUTHEAD")
                Dim l_eng As Boolean = Me.FejEngedelyez(l_row)
                For Each l_trow As DataRow In Me.frmForm.p_dataset.Tables("IFSZ_EMAILOUTLINE").Rows
                    Me.TetEngedelyez(l_eng, l_trow)
                Next
                Me.TetEngedelyez(l_eng)
            ElseIf CType(sender.current, DataRowView).Row.Table.TableName = "IFSZ_EMAILOUTLINE" Then
                Dim l_row As DataRow = Me.frmForm.getSelectedRow("IFSZ_EMAILOUTHEAD")
                Dim l_eng As Boolean = Me.FejEngedelyez(l_row)
                Me.TetEngedelyez(l_eng)
            End If
        End If

        If pEvent = PItemEvent.AfterQuery Then
            Dim l_eng As Boolean = Me.FejEngedelyez()
            For Each l_trow As DataRow In Me.frmForm.p_dataset.Tables("IFSZ_EMAILOUTLINE").Rows
                Me.TetEngedelyez(l_eng, l_trow)
            Next
            Me.TetEngedelyez(l_eng)
        End If

        '----------------------------------------------------------------------------
        'Lefúrás
        '----------------------------------------------------------------------------
        If pEvent = PItemEvent.LinkPressed Then
            If sender.GetType() Is GetType(DataGridView) AndAlso sender.Name = "IFSZ_EMAILOUTLINE" Then

                'Partner lefúrás
                Try
                    If sender.Columns(CType(e, DataGridViewCellMouseEventArgs).ColumnIndex).GetType.Name = "TextAndImageColumn" _
                               AndAlso CType(e, DataGridViewCellMouseEventArgs).RowIndex >= 0 _
                               AndAlso CType(e, DataGridViewCellMouseEventArgs).ColumnIndex = Me.frmForm.DataGridView1.Columns.Item("DG1_CARDCODE").Index _
                             Then

                        Try
                            If Not IFSZ_Globals.IsNull(Me.frmForm.p_dataset.Tables(1).Rows(CType(e, DataGridViewCellMouseEventArgs).RowIndex)("CARDCODE")) _
                                Then
                                Me.frmForm.m_Interim_SBO.SBOLefur(SAPbouiCOM.BoLinkedObject.lf_BusinessPartner, Me.frmForm.p_dataset.Tables(1).Rows(CType(e, DataGridViewCellMouseEventArgs).RowIndex)("CARDCODE"))
                            End If
                        Catch
                        Finally

                        End Try

                    End If
                Catch ex As Exception
                End Try

                'Bizonylat lefúrás
                Try
                    If sender.Columns(CType(e, DataGridViewCellMouseEventArgs).ColumnIndex).GetType.Name = "TextAndImageColumn" _
                               AndAlso CType(e, DataGridViewCellMouseEventArgs).RowIndex >= 0 _
                               AndAlso CType(e, DataGridViewCellMouseEventArgs).ColumnIndex = Me.frmForm.DataGridView1.Columns.Item("DG1_DOCNUM").Index _
                             Then

                        Try
                            If Not IFSZ_Globals.IsNull(Me.frmForm.p_dataset.Tables(1).Rows(CType(e, DataGridViewCellMouseEventArgs).RowIndex)("DOCENTRY")) _
                                Then
                                Me.frmForm.m_Interim_SBO.SBOLefur(Me.frmForm.p_dataset.Tables(1).Rows(CType(e, DataGridViewCellMouseEventArgs).RowIndex)("DOCTYPE"), Me.frmForm.p_dataset.Tables(1).Rows(CType(e, DataGridViewCellMouseEventArgs).RowIndex)("DOCENTRY"))
                            End If
                        Catch
                        Finally

                        End Try

                    End If
                Catch ex As Exception
                End Try

                'Fájl
                Try
                    If sender.Columns(CType(e, DataGridViewCellMouseEventArgs).ColumnIndex).GetType.Name = "TextAndImageColumn" _
                               AndAlso CType(e, DataGridViewCellMouseEventArgs).RowIndex >= 0 _
                               AndAlso CType(e, DataGridViewCellMouseEventArgs).ColumnIndex = Me.frmForm.DataGridView1.Columns.Item("DG1_FILE").Index _
                             Then

                        Try
                            If Not IFSZ_Globals.IsNull(Me.frmForm.p_dataset.Tables(1).Rows(CType(e, DataGridViewCellMouseEventArgs).RowIndex)("FILE")) _
                                Then
                                Dim l_file As String = ""
                                Dim l_fs As System.IO.FileStream
                                Try
                                    If IFSZ_EMAILOUTHEAD.m_impersonated Then
                                        m_impersonator.BeginImpersonation()
                                        Me.GetNextFileName(l_fs, l_file)
                                        System.IO.File.Copy(Me.frmForm.p_dataset.Tables(1).Rows(CType(e, DataGridViewCellMouseEventArgs).RowIndex)("FILE"), l_file, True)
                                    Else
                                        l_file = Me.frmForm.p_dataset.Tables(1).Rows(CType(e, DataGridViewCellMouseEventArgs).RowIndex)("FILE")
                                    End If

                                    Dim l_proc As System.Diagnostics.Process = System.Diagnostics.Process.Start(l_file)
                                    If l_proc IsNot Nothing Then
                                        Win32Helper.SetForegroundWindow(l_proc.MainWindowHandle())
                                    End If

                                Catch ex As Exception
                                    Me.frmForm.show_info(ex.Message)
                                Finally
                                    If IFSZ_EMAILOUTHEAD.m_impersonated Then
                                        m_impersonator.EndImpersonation()
                                    End If
                                End Try
                            End If
                        Catch
                        Finally

                        End Try

                    End If
                Catch ex As Exception
                End Try

            End If

        End If

        If pEvent = PItemEvent.BeforQueryEnter Then
            If sender.GetType() Is GetType(TextBox) Then
                If CType(sender, TextBox).Tag IsNot Nothing AndAlso CType(sender, TextBox).Tag.Equals(Me.frmForm.entity(0)) Then
                    'Fejnél enter query:
                    'Nem akarom, hogy rákérdezzen, ezért mentek
                    If Me.frmForm.p_dataset.HasChanges() Then
                        Me.frmForm.aktualizal()
                    End If
                End If
            End If
        End If

        If pEvent = PItemEvent.CellClick Then
            If sender.GetType() Is GetType(DataGridView) AndAlso CType(sender, DataGridView).Name = "IFSZ_EMAILOUTLINE" Then
                If CType(e, DataGridViewCellEventArgs).RowIndex = -1 AndAlso CType(e, DataGridViewCellEventArgs).ColumnIndex = -1 Then
                    Me.m_BeallitDataGrid = sender
                    Me.frmForm.GridBeallitMenu.Show(sender, New Point(0, 0))

                End If
            End If
        End If

    End Sub

    '----------------------------------------------------------------------------
    '----------------------------------------------------------------------------
    'ItemEvent vége
    '----------------------------------------------------------------------------
    '----------------------------------------------------------------------------

#Region "Implements IIFSZ_FileDialogResult"


    Public Sub SetFajlNev(ByVal pFajlNev As String) Implements IIFSZ_FileDialogResult.SetFajlNev
        plFileDialogOpen = False
        'ExportToCSV(pFajlNev)
    End Sub

    Public Sub NemValasztott() Implements IIFSZ_FileDialogResult.NemValasztott
        plFileDialogOpen = False
    End Sub

    Public Sub ShowFileDialog()

        Me.plSaveFileDialog.InitialDirectory = IFSZ_Globals.GetMyProc.StartInfo.WorkingDirectory
        Me.plSaveFileDialog.DefaultExt = ".csv"
        Me.plSaveFileDialog.InitialFileName = "IFSZ_EOH_" + DateTime.Now().ToString("yyyyMMddHHmmss") + ".csv"

        Me.plSaveFileDialog.SaveFileDialog(Me, IFSZ_Globals.GetMyProc)

    End Sub


    Public Function get_view() As Object Implements IFSZ_ICTRL.get_view

    End Function

#End Region

#Region "Private"

    Public Function get_elso_crystal(ByVal p_code As String, ByVal p_objtype As Integer, ByVal p_docentry As Integer) As DataRowCollection
        Dim l_query As String
        Dim l_where As String
        Dim l_rc As DataRowCollection

        l_query = "select top 2 DOCCODE, DOCNAME from IFSZ_EDOC_CRYSTALS_V where OBJTYPE = " + p_objtype.ToString() + " and DOCENTRY = " + p_docentry.ToString() + " and upper(DOCNAME) like " & IFSZ_Globals.SQLConstantPrepare(p_code.ToUpper() + "%") & " order by DOCNAME"

        l_rc = DataProvider.GetDataRecord(l_query.ToString())
        If l_rc Is Nothing OrElse l_rc.Count = 0 Then
            l_query = "select top 2 DOCCODE, DOCNAME from IFSZ_EDOC_CRYSTALS_V where OBJTYPE = " + p_objtype.ToString() + " and DOCENTRY = " + p_docentry.ToString() + " and upper(DOCNAME) like " & IFSZ_Globals.SQLConstantPrepare("%" + p_code.ToUpper() + "%") & " order by DOCNAME"
            Return DataProvider.GetDataRecord(l_query.ToString())
        Else
            Return l_rc
        End If
    End Function

    Delegate Sub ControlokLetilt_Callback()

    Private Sub ControlokLetilt()
        If Me.frmForm.InvokeRequired() Then
            Dim d As New ControlokLetilt_Callback(AddressOf ControlokLetilt)
            Me.frmForm.Invoke(d)
        Else
            m_controlok = New Dictionary(Of Control, Boolean)
            For Each l_control As Control In Me.frmForm.Controls
                If l_control.GetType() Is GetType(TextBox) OrElse l_control.GetType() Is GetType(ComboBox) OrElse l_control.GetType() Is GetType(Button) OrElse l_control.GetType() Is GetType(DataGridView) Then
                    If l_control.Name <> "MEGSE" AndAlso l_control.Name <> "T_PROGRESS" Then
                        If l_control.Enabled Then
                            m_controlok.Add(l_control, True)
                            l_control.Enabled = False
                        End If
                    End If
                End If
            Next
            m_megallit = False
        End If
    End Sub

    Delegate Sub ControlokEnged_Callback()

    Private Sub ControlokEnged()
        If Me.frmForm.InvokeRequired() Then
            Dim d As New ControlokEnged_Callback(AddressOf ControlokEnged)
            Me.frmForm.Invoke(d)
        Else
            If m_controlok IsNot Nothing Then
                For Each l_kv As KeyValuePair(Of Control, Boolean) In m_controlok
                    l_kv.Key.Enabled = True
                Next
                If Me.frmForm.T_PROGRESS.Visible = True Then
                    Me.frmForm.T_PROGRESS.Visible = False
                    Me.frmForm.ProgressBar1.Visible = False
                    Me.frmForm.B_EMAILS.Visible = True
                    Me.frmForm.B_GENERAL.Visible = True
                    Me.frmForm.B_VISSZAVON.Visible = True
                    Me.frmForm.B_GENERAL_KULD.Visible = True
                End If
                m_controlok = Nothing
            End If
        End If
    End Sub


#Region "LOV"

    Private Sub Crystal_lov(ByRef sender As Object, ByVal l_ertek As String, ByVal p_objtype As Integer, ByVal p_docentry As Integer)
        Dim p_oszlop_tipus(1) As LOV_OszlopTipus
        Dim p_form As LOV_Form
        Dim c As IFSZ_PUB_LOV
        Dim l_select As String
        Dim l_where As String

        l_where = "where objtype = " + p_objtype.ToString() + " and docentry = " + p_docentry.ToString
        If l_ertek <> "" Then
            l_where += " and upper(DOCNAME) like " & IFSZ_Globals.SQLConstantPrepare("%" + l_ertek.ToUpper() + "%") & " "
        End If

        p_oszlop_tipus(0).Title = "Név"
        p_oszlop_tipus(0).DbNev = "DOCNAME"
        p_oszlop_tipus(0).Tipus = "TEXT"
        p_oszlop_tipus(0).Description = "Név"
        p_oszlop_tipus(0).Visible = True
        p_oszlop_tipus(0).Width = 200
        p_oszlop_tipus(0).VNev = CType(sender, DataGridView).Item("DG1_CRYSTALNAME", CType(sender, DataGridView).CurrentRow.Index)

        p_oszlop_tipus(1).Title = "Kód"
        p_oszlop_tipus(1).DbNev = "DOCCODE"
        p_oszlop_tipus(1).Tipus = "TEXT"
        p_oszlop_tipus(1).Description = ""
        p_oszlop_tipus(1).Visible = True

        l_select = "select DOCNAME, DOCCODE from IFSZ_EDOC_CRYSTALS_V " & l_where & " order by DOCNAME"

        p_form.Title = "Nyomtatási képek"
        p_form.Width = 500
        p_form.Height = 400
        p_form.DefaultScrollIndex = 0
        c = New IFSZ_PUB_LOV(Me.frmForm, p_form, p_oszlop_tipus, l_select, , False)

    End Sub

#End Region

    Private Sub Generalas(ByVal p_id As Integer)
        Dim l_crystal As String
        Dim l_path As String = Me.frmForm.entity(0).GetAttribute("PATH")
        Try
            Dim l_tab As DataTable = DataProvider.EGetDataTable("select * from IFSZ_EMAILOUTLINE where EOH_ID = " + p_id.ToString)
            Dim l_count As Integer = 0
            If l_tab IsNot Nothing AndAlso l_tab.Rows.Count > 0 Then
                For Each l_row As DataRow In l_tab.Rows
                    If l_row("STATUS").ToString() = "R" AndAlso l_row("FILE").ToString() = "" Then
                        If l_row("CRYSTAL").ToString() = "" Then
                            Me.frmForm.show_error("Nincs megadva a nyomtatási formátum (" + l_row("DOCNUM").ToString() + ")")
                            Exit Sub
                        End If
                        l_count += 1
                    End If
                Next
            End If
            If l_count = 0 Then
                Me.frmForm.show_error("Nincs generálandó bizonylat")
            Else
                m_crystalok = New Dictionary(Of String, CrystalDecisions.CrystalReports.Engine.ReportDocument)
                m_progress_osszes = 0
                For Each l_row As DataRow In l_tab.Rows
                    If l_row("STATUS").ToString() = "R" AndAlso l_row("FILE").ToString() = "" Then
                        m_progress_osszes += m_pdf_suly
                        If Not m_crystalok.ContainsKey(l_row("CRYSTAL").ToString()) Then
                            m_crystalok.Add(l_row("CRYSTAL").ToString(), Nothing)
                            m_progress_osszes += m_crystal_suly
                        End If
                    End If
                Next
                m_crystalok = New Dictionary(Of String, CrystalDecisions.CrystalReports.Engine.ReportDocument)

                Dim l_ujcount As Integer = 0
                For Each l_row As DataRow In l_tab.Rows
                    If l_row("STATUS").ToString() = "R" AndAlso l_row("FILE").ToString() = "" Then
                        Try
                            l_crystal = Me.CrystalNyomtat(l_row("CRYSTAL"), l_row("DOCTYPE"), l_row("DOCENTRY"), l_row("DOCNUM"), l_path)
                            IFSZ_EMAILOUTLINE.Generalas(l_row("ID"), l_crystal)
                        Catch ex As Exception
                            l_ujcount += 1
                            If Me.frmForm.show_question("Hiba történt a nyomtatási kép előállítása közben. Folytatja a többivel? (" + ex.Message + ")") <> MsgBoxResult.Yes Then
                                Exit Sub
                            Else
                                Continue For
                            End If
                        End Try
                    End If
                Next
                If l_count = 0 Then
                    Me.frmForm.show_info(l_count.ToString() + " bizonylat legenerálva")
                ElseIf l_ujcount = 0 Then
                    Me.frmForm.show_info((l_count).ToString() + " bizonylat legenerálva")
                ElseIf l_ujcount = l_count Then
                    Me.frmForm.show_info(l_ujcount.ToString() + " bizonylat legenerálása nem sikerült")
                Else
                    Me.frmForm.show_info((l_count - l_ujcount).ToString() + " bizonylat legenerálása megtörtént. " + l_ujcount.ToString() + " generálása nem sikerült")
                End If
            End If
        Catch ex As Exception
            Me.frmForm.show_error(ex.Message)
        Finally
            m_progress_osszes = 0
            m_progress_akt = 0
            Me.ProgressFrissit()
            m_crystalok = New Dictionary(Of String, CrystalDecisions.CrystalReports.Engine.ReportDocument)
        End Try
    End Sub

    Private Sub GeneralasKuldes(ByVal p_id As Integer)
        Dim l_rc As DataRowCollection
        Dim l_path As String = Me.frmForm.entity(0).GetAttribute("PATH")
        Dim l_smtp_server, l_smtp_username, l_smtp_password, l_frommail As String
        Dim l_smtp_port As Integer
        Dim l_ssl As Boolean
        Dim l_count As Integer = 0
        Dim l_ind_pdf As Integer = 0
        Dim l_ind_token As Integer = 0
        Dim l_ind_sign As Integer = 0
        Dim l_ind_email As Integer = 0
        Dim l_row As DataRow
        Dim l_ret As String
        Dim l_cc, l_bcc As String
        Try

            If IFSZ_EMAILOUTHEAD.m_impersonated Then
                m_impersonator.BeginImpersonation()
            End If

            Dim l_tab As DataTable = DataProvider.EGetDataTable("select *, cast(null as nvarchar(255)) as ALAIRANDO, cast(null as nvarchar(255)) as ALAIRT, cast(null as nvarchar(255)) as TOKEN from IFSZ_EMAILOUTLINE where EOH_ID = " + p_id.ToString)
            Dim l_elso_probalkozas As Int16 = 0
            Dim l_to, l_crystal As String
            Dim l_tolist As System.Net.Mail.MailAddressCollection
            If l_tab IsNot Nothing AndAlso l_tab.Rows.Count > 0 Then
                For Each l_row In l_tab.Rows
                    If l_row("STATUS").ToString() = "R" Then
                        If l_row("CRYSTAL").ToString() = "" Then
                            Me.frmForm.show_error("Nincs megadva a nyomtatási formátum (" + l_row("DOCNUM").ToString() + ")")
                            Exit Sub
                        End If
                    End If
                Next
            End If

            l_count = IFSZ_EMAILOUTHEAD.ElkuldveCheck(p_id)

            If m_megallit OrElse m_abort Then
                Exit Sub
            End If

            If l_count = 0 Then
                Me.frmForm.show_info("A küldési bizonylat új státusza: Elküldve")
            ElseIf l_count < 0 Then
                Me.frmForm.show_info("Ez a küldési bizonylat már nem rögzítés alatti státuszú, újabb generálás nem lehetséges")
            Else
                l_cc = IFSZ_Globals.GetParameter("EBIZCC")
                If String.IsNullOrEmpty(l_cc) Then
                    l_cc = Nothing
                End If
                l_bcc = IFSZ_Globals.GetParameter("EBIZBCC")
                If String.IsNullOrEmpty(l_bcc) Then
                    l_bcc = Nothing
                End If
                'SMTP szerver megkeresése
                l_rc = DataProvider.GetDataRecord("select acc.*, " + QueryResource.SQL_dbopont + "IFSZ_GET_EDOC_FROMMAIL_F(null, null, ousr.internal_k) as FROMMAIL from OUSR join IFSZ_EMAILACCOUNTS acc on OUSR.U_EMAILOUT = cast(acc.ID as nvarchar) where OUSR.USER_CODE = " + IFSZ_Globals.SQLConstantPrepare(IFSZ_Globals.GetUserName))
                If l_rc Is Nothing OrElse l_rc.Count = 0 Then
                    Me.frmForm.show_error("Levél küldéshez állítsa be a felhasználóhoz a kimenő postafiókot. (Adminisztráció / Definíciók / Általános / Felhasználók - felhasználói panelén)")
                    Exit Sub
                Else
                    If l_rc(0)("SMTP_SERVER").ToString() = "" Then
                        Me.frmForm.show_error("Hibásan van beállítva a kimenő postafiók. Nincs megadva az SMTP szerver neve")
                        Exit Sub
                    End If
                    l_smtp_server = l_rc(0)("SMTP_SERVER")
                    If l_rc(0)("USERNAME").ToString() = "" Then
                        Me.frmForm.show_error("Hibásan van beállítva a kimenő postafiók. Nincs megadva a felhasználónév")
                        Exit Sub
                    End If
                    l_smtp_username = l_rc(0)("USERNAME")
                    If l_rc(0)("PASSWORD").ToString() = "" Then
                        Me.frmForm.show_error("Hibásan van beállítva a kimenő postafiók. Nincs megadva a jelszó")
                        Exit Sub
                    End If
                    l_smtp_password = IFSZ_EMAILACCOUNTS.JelszoVisszaKodol(l_rc(0)("PASSWORD"))
                    If IsDBNull(l_rc(0)("SMTP_PORT")) Then
                        Me.frmForm.show_error("Hibásan van beállítva a kimenő postafiók. Nincs megadva az SMTP szerver portszáma")
                        Exit Sub
                    End If
                    l_smtp_port = l_rc(0)("SMTP_PORT")
                    l_ssl = True
                    If l_rc(0)("SSL").ToString() = "N" Then
                        l_ssl = False
                    End If
                    If IsDBNull(l_rc(0)("FROMMAIL")) Then
                        'Ez azt jelenti, hogy TFCB-s módszer, bizonylatonként más feladó lehet, nem a felhasználó nevében küldjük
                        l_frommail = Nothing
                    Else
                        If l_rc(0)("FROMMAIL").ToString() = "" Then
                            Me.frmForm.show_error("Nincs megadva a felhasználó email címe")
                            Exit Sub
                        End If
                        l_frommail = l_rc(0)("FROMMAIL")
                    End If

                End If

                'SMTP teszt - bár ez csak az elérhetőséget fogja ellenőrizni. credentialst nem
                '    Egyelőre hagyjuk
                'If Not SmtpHelper.TestConnection(l_smtp_server, l_smtp_port) Then
                '    Me.frmForm.show_error("A kimenő postafiók nem érhető el. Kérem, ellenőrizze a beállításokat")
                '    Exit Sub
                'End If

                m_crystalok = New Dictionary(Of String, CrystalDecisions.CrystalReports.Engine.ReportDocument)
                m_progress_osszes = 0
                For Each l_row In l_tab.Rows
                    If m_megallit OrElse m_abort Then
                        Exit Sub
                    End If
                    If l_row("STATUS").ToString() = "R" Then
                        m_progress_osszes += m_pdf_suly + m_email_suly
                        If Not m_crystalok.ContainsKey(l_row("CRYSTAL").ToString()) Then
                            m_crystalok.Add(l_row("CRYSTAL").ToString(), Nothing)
                            m_progress_osszes += m_crystal_suly
                        End If
                    End If
                Next
                m_crystalok = New Dictionary(Of String, CrystalDecisions.CrystalReports.Engine.ReportDocument)

                Dim l_cikluskezd As DateTime = New DateTime(2000, 1, 1)
                Dim l_most As DateTime
                'A ciklus valójában négy ágon fog futni
                '- pdf generálás (l_ind_pdf jelzi, hogy melyik sornál jár - ez mindig megelőzi a többieket)
                '- pdf aláíráshoz tokenkérés (l_ind_token)
                '- pdf aláírás - token ellenőrzése (l_ind_sign)
                '- email küldés (l_ind_email)
                While l_tab.Rows.Count > l_ind_pdf OrElse l_tab.Rows.Count > l_ind_token OrElse l_tab.Rows.Count > l_ind_sign OrElse l_tab.Rows.Count > l_ind_email
                    If m_megallit Then
                        Exit While
                    End If
                    If m_abort Then
                        Exit Sub
                    End If
                    l_most = DateTime.Now()
                    If l_most.Subtract(l_cikluskezd).TotalMilliseconds < 300 Then
                        'Ha már rohadt gyorsan pörög a ciklus, akkor egy kicsit várjuk a checktoken-ek lekérdezésével, felesleges több ezerszer elküldeni ugyanazt
                        System.Threading.Thread.Sleep(100)
                        Continue While
                    End If
                    l_cikluskezd = l_most

                    'PDF
                    If l_ind_pdf < l_tab.Rows.Count Then
                        l_row = l_tab.Rows(l_ind_pdf)
                        If l_row("STATUS").ToString() <> "R" Then
                            'Csak akkor kell foglalkoznunk a sorral, ha rögzítés alatti
                            l_ind_pdf += 1

                        Else
                            'Rögzítés alatti - megnézzük, hogy lett-e már generálva pdf
                            Dim l_pdf_path, l_pdf_signed_path As String
                            If l_row("FILE").ToString() <> "" Then
                                l_pdf_path = l_row("FILE").ToString()
                                If l_pdf_path.EndsWith("_signed.pdf") Then
                                    'Már alá is lett írva
                                    l_pdf_signed_path = l_pdf_path
                                    l_row("ALAIRT") = l_pdf_path
                                    l_row("ALAIRANDO") = l_pdf_path
                                Else
                                    'Generálás megtörtént, de aláírva nem lett
                                    l_pdf_signed_path = System.IO.Path.GetDirectoryName(l_pdf_path) + "\" + System.IO.Path.GetFileNameWithoutExtension(l_pdf_path) + "_signed.pdf"
                                    If System.IO.File.Exists(l_pdf_signed_path) Then
                                        l_row("ALAIRT") = l_pdf_signed_path
                                    Else
                                        l_row("ALAIRANDO") = l_pdf_path
                                    End If
                                End If
                            End If

                            If IsDBNull(l_row("ALAIRANDO")) AndAlso IsDBNull(l_row("ALAIRT")) Then
                                'Nem lett még generálva pdf, ezért generálunk
                                Try
                                    l_crystal = Me.CrystalNyomtat(l_row("CRYSTAL"), l_row("DOCTYPE"), l_row("DOCENTRY"), l_row("DOCNUM"), l_path)
                                    l_row("ALAIRANDO") = l_crystal
                                Catch ex As Exception
                                    If Me.frmForm.show_question("Hiba történt a nyomtatási kép előállítása közben. Folytatja a többivel? (" + ex.Message + ")") <> MsgBoxResult.Yes Then
                                        Exit Sub
                                    Else
                                        l_row("ALAIRANDO") = ""
                                        l_row("ALAIRT") = ""
                                        l_ind_pdf += 1  'Ha nem léptetnénk, akkor örökké újra, meg újra megpróbálná ugyanezt
                                        Continue While
                                    End If
                                End Try
                                IFSZ_EMAILOUTLINE.Generalas(l_row("ID"), l_crystal)  'TODO: hibakezelés
                            End If

                            'If (String.IsNullOrEmpty(m_ebiz_srv) OrElse l_row("EBIZTIP").ToString() <> "H") AndAlso IsDBNull(l_row("ALAIRT")) Then
                            If (String.IsNullOrEmpty(m_ebiz_srv)) AndAlso IsDBNull(l_row("ALAIRT")) Then
                                'Csak H ebiztip esetén aláírunk, és ha be van állítva az Ebiz aláíró szolgáltatás, egyébként nem is fogunk aláírni semmit. Az ALAIRT mezőbe (amit el fogunk küldeni) betesszük ugyanazt, mint az ALAIRANDO-ban van
                                l_row("ALAIRT") = l_row("ALAIRANDO")
                            End If

                            l_ind_pdf += 1  'Kész van ennek a sornak a pdf-e, a következő cikluslépésben fogjuk folytatni a következővel
                        End If
                    End If

                    If l_ind_token < l_tab.Rows.Count Then
                        'aláírás tokenkérés
                        l_row = l_tab.Rows(l_ind_token)
                        If l_row("STATUS").ToString() <> "R" OrElse Not IsDBNull(l_row("ALAIRT")) Then
                            'Ezekkel nem foglalkozunk, vagy a státusza miatt, vagy azért, mert az ALAIRT mező már ki van töltve, vagyis már korábban elkészült a signed.pdf (vagy nem történik aláírás)
                            l_ind_token += 1

                        Else
                            'Rögzítés alatti, és még nem lett aláírva
                            If IsDBNull(l_row("ALAIRANDO")) Then
                                'Ha pdf sem lett legenerálva, akkor valószínűleg hiba történt, lépjünk tovább, hátha a következő sor már jó lesz
                                l_ind_token += 1
                            Else
                                If IsDBNull(l_row("TOKEN")) AndAlso l_ind_token < l_ind_sign + 10 Then  'Nagyon ne siessen előre, mert be fog telni a queue
                                    'Van pdf, de még tokent nem kaptunk: kérünk tokent
                                    Try
                                        l_row("TOKEN") = Me.SrvSign(l_row("ID"))
                                    Catch wex As WebException
                                        Dim l_hiba As String = ""
                                        If wex.Response IsNot Nothing Then
                                            If wex.Response.ContentLength > 0 Then
                                                Using stream As System.IO.Stream = wex.Response.GetResponseStream()
                                                    Using reader = New System.IO.StreamReader(stream)
                                                        l_hiba = reader.ReadToEnd()
                                                    End Using
                                                End Using
                                            End If
                                        End If
                                        If String.IsNullOrEmpty(l_hiba) Then
                                            l_hiba = "Hiba történt " + IFSZ_Globals.Az(l_row("ALAIRANDO")) + " fájl aláírása során. Folytatja a többivel? (" + wex.Message + ")"
                                        Else
                                            l_hiba = "Hiba történt " + IFSZ_Globals.Az(l_row("ALAIRANDO")) + " fájl aláírása során. Folytatja a többivel? (" + l_hiba + ")"
                                        End If
                                        If Me.frmForm.show_question(l_hiba) <> MsgBoxResult.Yes Then
                                            Exit Sub
                                        End If
                                    Catch ex As Exception
                                        If Me.frmForm.show_question("Hiba történt " + IFSZ_Globals.Az(l_row("ALAIRANDO")) + " fájl aláírása során. Folytatja a többivel? (" + ex.Message + ")") <> MsgBoxResult.Yes Then
                                            Exit Sub
                                        End If
                                    End Try
                                    l_ind_token += 1
                                Else
                                    'Ilyen nem lehetne - mi más töltené a TOKEN-t? De akkor is növelünk az indexen
                                    l_ind_token += 1
                                End If
                            End If
                        End If
                    End If

                    If l_ind_sign < l_tab.Rows.Count Then
                        'aláírás - aláírt fájlra várakozás
                        l_row = l_tab.Rows(l_ind_sign)
                        If l_row("STATUS").ToString() <> "R" OrElse Not IsDBNull(l_row("ALAIRT")) Then
                            'Ezekkel nem foglalkozunk, vagy a státusza miatt, vagy azért, mert az ALAIRT mező már ki van töltve, vagyis már korábban elkészült a signed.pdf (vagy nem történik aláírás)
                            l_ind_sign += 1

                        Else
                            'Rögzítés alatti, és még nem lett aláírva
                            If Not IsDBNull(l_row("TOKEN")) Then
                                'Csak az számít, ahol a token már ki van töltve
                                If l_row("TOKEN") = -1 Then
                                    'Ha -1 a token, akkor hiba történt a tokenkészítés közben - továbblépünk
                                    l_ind_sign += 1
                                Else
                                    Try
                                        l_ret = Me.CheckToken(l_row("TOKEN").ToString())
                                        If l_ret = "1" Then
                                            Dim l_fajl As String
                                            l_fajl = System.IO.Path.GetDirectoryName(l_row("ALAIRANDO").ToString()) + "\" + System.IO.Path.GetFileNameWithoutExtension(l_row("ALAIRANDO").ToString()) + "_signed.pdf"
                                            If System.IO.File.Exists(l_fajl) Then
                                                l_row("ALAIRT") = l_fajl
                                            Else
                                                l_fajl = System.IO.Path.GetDirectoryName(l_row("ALAIRANDO").ToString()) + "\" + System.IO.Path.GetFileNameWithoutExtension(l_row("ALAIRANDO").ToString()) + "_atc.pdf"
                                                If System.IO.File.Exists(l_fajl) Then
                                                    l_row("ALAIRT") = l_fajl
                                                Else
                                                    l_fajl = l_row("ALAIRANDO").ToString()
                                                    l_row("ALAIRT") = l_fajl
                                                End If
                                            End If
                                            l_ind_sign += 1
                                        End If
                                    Catch wex As WebException
                                        Dim l_hiba As String = ""
                                        If wex.Response IsNot Nothing Then
                                            If wex.Response.ContentLength > 0 Then
                                                Using stream As System.IO.Stream = wex.Response.GetResponseStream()
                                                    Using reader = New System.IO.StreamReader(stream)
                                                        l_hiba = reader.ReadToEnd()
                                                    End Using
                                                End Using
                                            End If
                                        End If
                                        If String.IsNullOrEmpty(l_hiba) Then
                                            l_hiba = "Hiba történt " + IFSZ_Globals.Az(l_row("ALAIRANDO")) + " fájl aláírása során. Folytatja a többivel? (" + wex.Message + ")"
                                        Else
                                            l_hiba = "Hiba történt " + IFSZ_Globals.Az(l_row("ALAIRANDO")) + " fájl aláírása során. Folytatja a többivel? (" + l_hiba + ")"
                                        End If
                                        If Me.frmForm.show_question(l_hiba) <> MsgBoxResult.Yes Then
                                            Exit Sub
                                        End If
                                        l_ind_sign += 1
                                    Catch ex As Exception
                                        If Me.frmForm.show_question("Hiba történt " + IFSZ_Globals.Az(l_row("ALAIRANDO")) + " fájl aláírása során. Folytatja a többivel? (" + ex.Message + ")") <> MsgBoxResult.Yes Then
                                            Exit Sub
                                        End If
                                        l_ind_sign += 1
                                    End Try
                                End If
                            End If

                        End If
                    End If

                    If l_ind_email < l_tab.Rows.Count Then
                        'email
                        l_row = l_tab.Rows(l_ind_email)
                        If l_row("STATUS").ToString() <> "R" Then
                            l_ind_email += 1
                        ElseIf Not IsDBNull(l_row("ALAIRT")) Then
                            If l_row("ALAIRT") = "" Then
                                l_ind_email += 1
                                Continue While
                            End If
                            l_crystal = l_row("ALAIRT")
                            l_rc = DataProvider.GetDataRecord("select cntct_name, cntct_email from IFSZ_EMAILOUTADDR where eol_id = " + l_row("ID").ToString())
                            If l_rc Is Nothing OrElse l_rc.Count = 0 Then
                                If Me.frmForm.show_question(l_row("DOCNUM").ToString() + " bizonylatnak nincs címzettje Folytatja a többivel?") <> MsgBoxResult.Yes Then
                                    Exit Sub
                                End If
                                l_ind_email += 1
                                Continue While
                            End If
                            l_tolist = New System.Net.Mail.MailAddressCollection()
                            For Each l_row2 As DataRow In l_rc
                                l_tolist.Add(New System.Net.Mail.MailAddress(l_row2("CNTCT_EMAIL").ToString(), l_row2("CNTCT_NAME").ToString(), Encoding.UTF8))
                            Next
                            SyncLock IFSZ_Globals.m_connLockObject
                                Try
                                    If IFSZ_Globals.m_Connection Is Nothing Then
                                        IFSZ_Globals.m_Connection = New ConnectionProvider
                                    Else
                                        IFSZ_Globals.m_Connection.BeginTransaction()
                                    End If

                                    Dim l_bizfrommail As String = l_frommail
                                    If l_bizfrommail Is Nothing Then
                                        l_bizfrommail = DataProvider.ExecuteScalarString("select " + QueryResource.SQL_dbopont + "IFSZ_GET_EDOC_FROMMAIL_F(" + l_row("DOCTYPE").ToString() + ", " + l_row("DOCENTRY").ToString() + ", ousr.internal_k) from OUSR where OUSR.USER_CODE = " + IFSZ_Globals.SQLConstantPrepare(IFSZ_Globals.GetUserName))
                                    End If
                                    If String.IsNullOrEmpty(l_bizfrommail) Then
                                        If IFSZ_Globals.m_Connection IsNot Nothing Then IFSZ_Globals.m_Connection.Rollback()
                                        IFSZ_Globals.m_Connection = Nothing
                                        If Me.frmForm.show_question(l_row("DOCNUM").ToString() + " bizonylathoz nem határozható meg a küldő címe. Folytatja a többivel?") <> MsgBoxResult.Yes Then
                                            Exit Sub
                                        Else
                                            l_ind_email += 1
                                            Continue While
                                        End If
                                    End If

                                    m_progress_felirat = l_row("DOCNUM").ToString() + " bizonylat küldése e-mail-ben"
                                    m_progress_akt += m_email_suly
                                    Me.ProgressFrissit()

                                    Dim l_hiba As String = IFSZ_EMAILOUTLINE.Kuldes(l_row("ID"), l_crystal)
                                    If Not String.IsNullOrEmpty(l_hiba) Then
                                        If IFSZ_Globals.m_Connection IsNot Nothing Then IFSZ_Globals.m_Connection.Rollback()
                                        IFSZ_Globals.m_Connection = Nothing
                                        If Me.frmForm.show_question(l_hiba + ". Folytatja a többivel?") <> MsgBoxResult.Yes Then
                                            Exit Sub
                                        Else
                                            l_ind_email += 1
                                            Continue While
                                        End If
                                    End If

                                    If l_elso_probalkozas = 0 Then l_elso_probalkozas = 1
                                    SmtpHelper.SendMail(
                                      l_UserName:=l_smtp_username _
                                    , l_Password:=l_smtp_password _
                                    , p_host:=l_smtp_server _
                                    , p_port:=l_smtp_port _
                                    , p_enablessl:=l_ssl _
                                    , p_frommail:=l_bizfrommail _
                                    , p_to:=Nothing _
                                    , p_subject:=l_row("MAIL_SUBJECT") _
                                    , p_body:=l_row("MAIL_BODY") _
                                    , p_isbodyhtml:=IIf(l_row("ISHTML").ToString().ToUpper() = "Y", True, False) _
                                    , p_fileattachment:=New String() {l_crystal} _
                                    , p_MailToList:=l_tolist _
                                    , p_req_read_receipt:=m_req_read_receipt _
                                    , p_req_delivery_receipt:=m_req_del_not _
                                    , l_MailCC:=l_cc _
                                    , l_MailBCC:=l_bcc
                                )
                                    l_elso_probalkozas = 2

                                    IFSZ_Globals.m_Connection.Commit()

                                Catch ex As Exception
                                    If IFSZ_Globals.m_Connection IsNot Nothing Then IFSZ_Globals.m_Connection.Rollback()
                                    IFSZ_Globals.m_Connection = Nothing
                                    'Az smtp teszt csak a szervert ellenőrzi. Ha a jelszóval van baj, az nem derül ki, csak az első küldéskor
                                    'Persze küldéskor talán más hiba is előfodulhat, ami csak az adott küldésre vonatkozik
                                    'Mindenesetre, ha ez a hiba az első küldésnél fordul elő, akkor szerver beállítási hibának tekintjük. Ha később, akkor nem
                                    If l_elso_probalkozas = 1 Then
                                        Me.frmForm.show_error("Levelezőszerver beállítási hiba: " + ex.Message())
                                        Exit Sub
                                    Else
                                        If Me.frmForm.show_question(l_row("DOCNUM").ToString() + " bizonylatot nem sikerült elküldeni. Folytatja a többivel? (" + ex.Message() + ")") <> MsgBoxResult.Yes Then
                                            Exit Sub
                                        Else
                                            l_ind_email += 1
                                            Continue While
                                        End If
                                    End If
                                Finally
                                    IFSZ_Globals.m_Connection = Nothing
                                End Try
                            End SyncLock
                            l_ind_email += 1

                        ElseIf l_ind_sign > l_ind_email Then
                            'Akkor jutunk ide, ha rögzítés alatti a sor, és az ALAIRT sincs kitöltve, de az l_ind_sign már előrébb járt - vagyis hiba volt az aláírásban. Nem baj, továbblépünk a következőre
                            l_ind_email += 1

                        End If

                    End If

                End While

                Try
                    Dim l_ujcount As Integer
                    l_ujcount = IFSZ_EMAILOUTHEAD.ElkuldveCheck(p_id)
                    If l_count = 0 Then
                        Me.frmForm.show_info(l_count.ToString() + " levél elküldése megtörtént. A küldési bizonylat új státusza: Elküldve")
                    ElseIf l_ujcount = 0 Then
                        Me.frmForm.show_info((l_count).ToString() + " levél elküldése megtörtént")
                    ElseIf l_ujcount = l_count Then
                        Me.frmForm.show_info(l_ujcount.ToString() + " levél elküldése nem sikerült")
                    Else
                        Me.frmForm.show_info((l_count - l_ujcount).ToString() + " levél elküldése megtörtént. " + l_ujcount.ToString() + " elküldése nem sikerült")
                    End If
                Catch ex As Exception
                    Me.frmForm.show_error("Hiba történt a küldési bizonylat fej státuszváltása során: " + ex.Message)
                End Try


            End If

        Catch ex As Exception
            Me.frmForm.show_error(ex.Message)
        Finally
            m_progress_osszes = 0
            m_progress_akt = 0
            Me.ProgressFrissit()
            m_crystalok = New Dictionary(Of String, CrystalDecisions.CrystalReports.Engine.ReportDocument)
            If IFSZ_EMAILOUTHEAD.m_impersonated Then
                m_impersonator.EndImpersonation()
            End If
        End Try
    End Sub

    Private Sub CrystalLetolt(ByVal p_crystalnev As String)        If m_crystalok.ContainsKey(p_crystalnev) Then
            Exit Sub
        End If        Dim l_fajlnev As String
        Try

            m_progress_felirat = p_crystalnev + " nyomtatási kép letöltése"
            Me.ProgressFrissit()

            'Crystal hívása
            Dim crxReport As New CrystalDecisions.CrystalReports.Engine.ReportDocument

            'Az adatbázisba mentett riport mentése átmeneti fájlba
#If HANADB Then
            Dim l_rdoc As DataRowCollection = DataProvider.GetDataRecord("select ""Template"" from rdoc where ""DocCode"" = " + IFSZ_Globals.SQLConstantPrepare(p_crystalnev) + " and ""Template"" is not null")
#Else
            Dim l_rdoc As DataRowCollection = DataProvider.GetDataRecord("select template from rdoc where doccode = " + IFSZ_Globals.SQLConstantPrepare(p_crystalnev) + " and ""Template"" is not null")
#End If
            If l_rdoc IsNot Nothing AndAlso l_rdoc.Count > 0 Then
                l_fajlnev = System.IO.Path.GetTempFileName
                Dim l_byteArray As Byte()                l_byteArray = CType(l_rdoc(0)("TEMPLATE"), Byte())                IFSZ_Globals.WriteFileFromByteArray(l_fajlnev, l_byteArray)
                crxReport.Load(l_fajlnev)

#If HANADB Then
                Dim crtableLogoninfos As New CrystalDecisions.Shared.TableLogOnInfos()
                Dim crtableLogoninfo As New CrystalDecisions.Shared.TableLogOnInfo()
                Dim crConnectionInfo As New CrystalDecisions.Shared.ConnectionInfo()
                Dim CrTables As CrystalDecisions.CrystalReports.Engine.Tables
                Dim CrTable As CrystalDecisions.CrystalReports.Engine.Table
                CrTables = crxReport.Database.Tables

                'Loop through each table in the report and apply the LogonInfo information
                For Each CrTable In CrTables
                    CrTable.LogOnInfo.ConnectionInfo.Password = ConnectionProvider.m_sdkpwd
                    CrTable.ApplyLogOnInfo(CrTable.LogOnInfo)
                Next

#Else
                Dim crtableLogoninfos As New CrystalDecisions.Shared.TableLogOnInfos()
                Dim crtableLogoninfo As New CrystalDecisions.Shared.TableLogOnInfo()
                'Dim crConnectionInfo As New CrystalDecisions.Shared.ConnectionInfo()
                Dim CrTables As CrystalDecisions.CrystalReports.Engine.Tables
                Dim CrTable As CrystalDecisions.CrystalReports.Engine.Table
                'Dim crTabConnInfo As New CrystalDecisions.Shared.TableLogOnInfo()
                CrTables = crxReport.Database.Tables

                'With crConnectionInfo
                '    .ServerName = CType(IFSZ_Globals.m_ParentAddOn, SBOAddOn).SboCompany.Server
                '    .DatabaseName = CType(IFSZ_Globals.m_ParentAddOn, SBOAddOn).SboCompany.CompanyDB
                '    .UserID = ConnectionProvider.m_sdkuser
                '    .Password = ConnectionProvider.m_sdkpwd
                'End With

                'With crTabConnInfo
                '    With .ConnectionInfo
                '        .ServerName = CType(IFSZ_Globals.m_ParentAddOn, SBOAddOn).SboCompany.Server
                '        .DatabaseName = CType(IFSZ_Globals.m_ParentAddOn, SBOAddOn).SboCompany.CompanyDB
                '        .UserID = ConnectionProvider.m_sdkuser
                '        .Password = ConnectionProvider.m_sdkpwd
                '    End With
                'End With

                'Loop through each table in the report and apply the LogonInfo information
                For Each CrTable In CrTables
                    Me.m_progress_felirat = "Kapcsolódási sztring alkalmazása: " + CrTable.Name
                    'm_progress_akt += 1
                    Me.ProgressFrissit()
                    'crtableLogoninfo = CrTable.LogOnInfo
                    'crtableLogoninfo.ConnectionInfo = crConnectionInfo
                    'CrTable.LogOnInfo.ConnectionInfo.ServerName = CType(IFSZ_Globals.m_ParentAddOn, SBOAddOn).SboCompany.Server

                    'For Each l_x As CrystalDecisions.Shared.NameValuePair2 In CrTable.LogOnInfo.ConnectionInfo.LogonProperties
                    '    If l_x.Name.GetType() Is GetType(String) Then
                    '        Select Case CType(l_x.Name, String)
                    '            Case "Company User Id"
                    '                l_x.Value = CType(IFSZ_Globals.m_ParentAddOn, SBOAddOn).SboCompany.UserName
                    '            Case "Database"
                    '                l_x.Value = CType(IFSZ_Globals.m_ParentAddOn, SBOAddOn).SboCompany.CompanyDB
                    '            Case "Server"
                    '                l_x.Value = CType(IFSZ_Globals.m_ParentAddOn, SBOAddOn).SboCompany.Server
                    '            Case "Server Type"
                    '                l_x.Value = CType(IFSZ_Globals.m_ParentAddOn, SBOAddOn).SboCompany.DbServerType
                    '        End Select
                    '    End If
                    'Next

                    CrTable.LogOnInfo.ConnectionInfo.DatabaseName = CType(IFSZ_Globals.m_ParentAddOn, SBOAddOn).SboCompany.CompanyDB
                    CrTable.LogOnInfo.ConnectionInfo.UserID = ConnectionProvider.m_sdkuser
                    CrTable.LogOnInfo.ConnectionInfo.Password = ConnectionProvider.m_sdkpwd
                    CrTable.ApplyLogOnInfo(CrTable.LogOnInfo)
                Next
#End If

                m_crystalok.Add(p_crystalnev, crxReport)

                m_progress_akt += m_crystal_suly
                Me.ProgressFrissit()

            End If

        Catch ex As Exception
            Throw
        Finally
            If Not String.IsNullOrEmpty(l_fajlnev) Then
                System.IO.File.Delete(l_fajlnev)
            End If
        End Try    End Sub

    Private Function CrystalNyomtat(ByVal p_crystalnev As String, ByVal p_objtype As Integer, ByVal p_docentry As Integer, ByVal p_docnum As String, ByVal p_path As String) As String
        Try

            'Crystal hívása
            Dim crxReport As New CrystalDecisions.CrystalReports.Engine.ReportDocument

            Me.CrystalLetolt(p_crystalnev)
            crxReport = m_crystalok(p_crystalnev)

            m_progress_felirat = p_docnum + " bizonylat generálása PDF fájlba"
            Me.ProgressFrissit()

            'crxReport.Load(l_fajlnev)
            crxReport.SetParameterValue("DocKey@", p_docentry)
            crxReport.SetParameterValue("ObjectId@", p_objtype)

            Dim l_pdfnev As String
            Dim l_cardcode As String = ""
            If m_file_formatum.ToUpper().Contains("<CARDCODE>") Then
                l_cardcode = DataProvider.ExecuteScalarString("select ""CardCode"" from IFSZ_DFEJ where ""DocEntry"" = " + IFSZ_Globals.SQLConstantPrepare(p_docentry) + " and ""ObjType"" = " + IFSZ_Globals.SQLConstantPrepare(p_objtype))
            End If
            Dim l_fdocnum = p_docnum
            'Ez kicseréli az invalid karaktereket:
            Dim regexSearch = New String(Path.GetInvalidFileNameChars()) & New String(Path.GetInvalidPathChars())
            Dim r = New Regex(String.Format("[{0}]", Regex.Escape(regexSearch)))
            l_fdocnum = r.Replace(l_fdocnum, "-")

            l_pdfnev = m_file_formatum.Replace("<docnum>", l_fdocnum).Replace("<DOCNUM>", l_fdocnum).Replace("<timestamp>", "<TIMESTAMP>").Replace("<TIMESTAMP>", IFSZ_Globals.GetServerDateTime().ToString("yyyyMMddHHmmss")).Replace("<cardcode>", l_cardcode).Replace("<CARDCODE>", l_cardcode).Replace("<CardCode>", l_cardcode)
            l_pdfnev = p_path + "\" + l_pdfnev + ".pdf"
            crxReport.ExportToDisk(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, l_pdfnev)

            m_progress_akt += m_pdf_suly
            Me.ProgressFrissit()

            Return l_pdfnev

            'Dim l_proc As System.Diagnostics.Process = System.Diagnostics.Process.Start(l_pdfnev)

            'If l_proc IsNot Nothing Then
            '    Win32Helper.SetForegroundWindow(l_proc.MainWindowHandle())
            'End If

        Catch ex As Exception
            Throw
        Finally
            'If Not String.IsNullOrEmpty(l_fajlnev) Then
            '    System.IO.File.Delete(l_fajlnev)
            'End If
        End Try        Return ""    End Function

    Private Function FejEngedelyez(Optional ByVal p_row As DataRow = Nothing) As Boolean
        If p_row Is Nothing Then
            p_row = Me.frmForm.getSelectedRow("IFSZ_EMAILOUTHEAD")
        End If
        If p_row Is Nothing Then
            Return False
        End If
        If p_row("STATUS").ToString() = "R" Then
            Me.frmForm.T_NOTE.ReadOnly = False
            'Me.frmForm.B_EMAILS.Enabled = True  'Majd tételtől függ
            Me.frmForm.B_TET_TOROL.Enabled = True
            Me.frmForm.B_KIVALASZT.Enabled = True
            Me.frmForm.B_VISSZAVON.Enabled = True
            Me.frmForm.B_GENERAL.Enabled = True
            Me.frmForm.B_GENERAL_KULD.Enabled = True
            Me.frmForm.controlColors(Me.frmForm.T_NOTE)
            Return True
        Else
            Me.frmForm.T_NOTE.ReadOnly = True
            Me.frmForm.B_EMAILS.Enabled = False
            Me.frmForm.B_TET_TOROL.Enabled = False
            Me.frmForm.B_KIVALASZT.Enabled = False
            Me.frmForm.B_VISSZAVON.Enabled = False
            Me.frmForm.B_GENERAL.Enabled = False
            Me.frmForm.B_GENERAL_KULD.Enabled = False
            Me.frmForm.controlColors(Me.frmForm.T_NOTE)
            Return False
        End If
    End Function

    Private Sub TetEngedelyez(ByVal p_fej_enged As Boolean, Optional ByVal p_row As DataRow = Nothing)
        Dim l_gridindex As Integer
        If p_row Is Nothing Then
            p_row = Me.frmForm.getSelectedRow("IFSZ_EMAILOUTLINE")
        End If
        If p_row Is Nothing Then
            Exit Sub
        End If
        l_gridindex = Me.frmForm.GetGridRowIndex(p_row)
        If Not p_fej_enged Then
            Me.frmForm.B_EMAILS.Enabled = False
            Me.frmForm.CellEditableEnabledByRowind(Me.frmForm.DataGridView1, l_gridindex, "DG1_CRYSTALNAME", False)
            Me.frmForm.CellEditableEnabledByRowind(Me.frmForm.DataGridView1, l_gridindex, "DG1_MAIL_SUBJECT", False)
            Me.frmForm.CellEditableEnabledByRowind(Me.frmForm.DataGridView1, l_gridindex, "DG1_MAIL_BODY", False)
        Else
            If p_row("STATUS").ToString() = "R" Then
                If m_cimzett_modosithato_e Then
                    Me.frmForm.B_EMAILS.Enabled = True
                End If
                Me.frmForm.CellEditableEnabledByRowind(Me.frmForm.DataGridView1, l_gridindex, "DG1_CRYSTALNAME", m_crystal_modosithato_e)
                Me.frmForm.CellEditableEnabledByRowind(Me.frmForm.DataGridView1, l_gridindex, "DG1_MAIL_SUBJECT", m_sablon_atirhato_e)
                Me.frmForm.CellEditableEnabledByRowind(Me.frmForm.DataGridView1, l_gridindex, "DG1_MAIL_BODY", m_sablon_atirhato_e)
            Else
                Me.frmForm.B_EMAILS.Enabled = False
                Me.frmForm.CellEditableEnabledByRowind(Me.frmForm.DataGridView1, l_gridindex, "DG1_CRYSTALNAME", False)
                Me.frmForm.CellEditableEnabledByRowind(Me.frmForm.DataGridView1, l_gridindex, "DG1_MAIL_SUBJECT", False)
                Me.frmForm.CellEditableEnabledByRowind(Me.frmForm.DataGridView1, l_gridindex, "DG1_MAIL_BODY", False)
            End If
        End If
    End Sub

    Private Sub ThreadGeneralasKuldes()
        Me.GeneralasKuldes(Me.frmForm.entity(0).GetAttribute("ID"))

        'Dim l_row As DataRow = Me.frmForm.getSelectedRow("IFSZ_EMAILOUTHEAD")
        'Dim l_rc As DataRowCollection = DataProvider.GetDataRecord(Me.m_frmView.getSqlQuery("IFSZ_EMAILOUTHEAD", "TABLE") + " where id = " + Me.frmForm.entity(0).GetAttribute("ID").ToString())
        'If l_rc IsNot Nothing AndAlso l_rc.Count > 0 Then
        '    For Each l_col As DataColumn In l_rc(0).Table.Columns
        '        If l_col.ColumnName.EndsWith("_MEAN") Then
        '            Dim l_domain_values As Collection = Me.frmForm.entity(0).GetAttributeDomain(l_col.ColumnName)
        '            If l_domain_values IsNot Nothing Then
        '                For Each l_temp As IFSZ_Domains.st_domain_values In l_domain_values
        '                    If l_temp.value = l_row(l_col.ColumnName.Replace("_MEAN", "")).ToString() Then
        '                        l_row(l_col.ColumnName) = l_temp.meaning
        '                        Exit For
        '                    End If
        '                Next
        '            End If
        '        Else
        '            l_row(l_col.ColumnName) = l_rc(0)(l_col.ColumnName)
        '        End If
        '    Next
        'End If
        'Me.frmForm.T_SENTTS.Invalidate()
        'Me.frmForm.p_dataset.Tables("IFSZ_EMAILOUTHEAD").AcceptChanges()
        If Not m_abort Then Me.Visszater(True)
    End Sub

    Private Sub ThreadGeneralas()
        Me.Generalas(Me.frmForm.entity(0).GetAttribute("ID"))

        'Dim l_row As DataRow = Me.frmForm.getSelectedRow("IFSZ_EMAILOUTHEAD")
        'Dim l_rc As DataRowCollection = DataProvider.GetDataRecord(Me.m_frmView.getSqlQuery("IFSZ_EMAILOUTHEAD", "TABLE") + " where id = " + Me.frmForm.entity(0).GetAttribute("ID").ToString())
        'If l_rc IsNot Nothing AndAlso l_rc.Count > 0 Then
        '    For Each l_col As DataColumn In l_rc(0).Table.Columns
        '        If l_col.ColumnName.EndsWith("_MEAN") Then
        '            Dim l_domain_values As Collection = Me.frmForm.entity(0).GetAttributeDomain(l_col.ColumnName)
        '            If l_domain_values IsNot Nothing Then
        '                For Each l_temp As IFSZ_Domains.st_domain_values In l_domain_values
        '                    If l_temp.value = l_row(l_col.ColumnName.Replace("_MEAN", "")).ToString() Then
        '                        l_row(l_col.ColumnName) = l_temp.meaning
        '                        Exit For
        '                    End If
        '                Next
        '            End If
        '        Else
        '            l_row(l_col.ColumnName) = l_rc(0)(l_col.ColumnName)
        '        End If
        '    Next
        'End If
        'Me.frmForm.p_dataset.Tables("IFSZ_EMAILOUTHEAD").AcceptChanges()
        If Not m_abort Then Me.Visszater(True)
    End Sub

    Delegate Sub ProgressFrissit_Callback()

    Private Sub ProgressFrissit()
        If m_abort Then
            Exit Sub
        End If
        If Me.frmForm.InvokeRequired() Then
            Dim d As New ProgressFrissit_Callback(AddressOf ProgressFrissit)
            Me.frmForm.Invoke(d)
        Else
            If m_progress_osszes > 0 AndAlso m_progress_osszes > m_progress_akt Then
                If Me.frmForm.T_PROGRESS.Visible = False Then
                    Me.frmForm.T_PROGRESS.Visible = True
                    Me.frmForm.ProgressBar1.Visible = True
                    Me.frmForm.B_EMAILS.Visible = False
                    Me.frmForm.B_GENERAL.Visible = False
                    Me.frmForm.B_VISSZAVON.Visible = False
                    Me.frmForm.B_GENERAL_KULD.Visible = False
                End If

                If String.IsNullOrEmpty(m_progress_felirat) Then
                    Me.frmForm.T_PROGRESS.Text = ""
                Else
                    Me.frmForm.T_PROGRESS.Text = m_progress_felirat
                End If
                Dim l_szazalek As Integer = 100D / CType(m_progress_osszes, Decimal) * CType(m_progress_akt, Decimal)
                If l_szazalek > 100 Then
                    Me.frmForm.ProgressBar1.Value = 100
                Else
                    Me.frmForm.ProgressBar1.Value = l_szazalek
                End If

            Else
                If Me.frmForm.T_PROGRESS.Visible = True Then
                    Me.frmForm.T_PROGRESS.Visible = False
                    Me.frmForm.ProgressBar1.Visible = False
                    Me.frmForm.B_EMAILS.Visible = True
                    Me.frmForm.B_GENERAL.Visible = True
                    Me.frmForm.B_VISSZAVON.Visible = True
                    Me.frmForm.B_GENERAL_KULD.Visible = True
                End If

            End If
        End If
    End Sub

    Private Sub GridBeallitas()
        Try
            Dim l_rc, l_rc2 As DataRowCollection
            Dim l_szint As Integer
            Dim l_szintwhere(2) As String

            For Each l_control As Control In Me.frmForm.Controls
                If l_control.GetType() Is GetType(DataGridView) Then

                    l_szintwhere(0) = "t1.szint = 0"
                    l_szintwhere(1) = "(t1.szint = 1 and t1.azonosito = " + IFSZ_Globals.SQLConstantPrepare(IFSZ_Globals.GetUserID.ToString()) + ")"
                    l_szintwhere(2) = "(t1.szint = 2 and t1.azonosito = " + IFSZ_Globals.SQLConstantPrepare(IFSZ_Globals.GetUserID.ToString()) + " and t1.azonosito2 = " + IFSZ_Globals.SQLConstantPrepare(Environment.MachineName) + ")"

#If HANADB Then
                    l_szint = DataProvider.ExecuteScalar(
                      "select ifnull(max(t1.szint), -1) from ifsz_grid_beallitasok t1 " +
                      "where t1.formnev = " + IFSZ_Globals.SqlConstantPrepare(Me.frmForm.m_Interim_SBO.FunctionCode) + " " +
                      "and t1.gridnev = " + IFSZ_Globals.SqlConstantPrepare(l_control.Name) + " " +
                      "and (" + l_szintwhere(0) + " or " + l_szintwhere(1) + " or " + l_szintwhere(2) + ")"
                    )
#Else
                    l_szint = DataProvider.ExecuteScalar(
                      "select isnull(max(szint), -1) from ifsz_grid_beallitasok t1 " +
                      "where t1.formnev = " + IFSZ_Globals.SQLConstantPrepare(Me.frmForm.m_Interim_SBO.FunctionCode) + " " +
                      "and t1.gridnev = " + IFSZ_Globals.SQLConstantPrepare(l_control.Name) + " " +
                      "and (" + l_szintwhere(0) + " or " + l_szintwhere(1) + " or " + l_szintwhere(2) + ")"
                    )
#End If

                    If l_szint > -1 Then
                        l_rc = DataProvider.EGetDataRecord(
                            "select * from ifsz_grid_beallitasok t1 " +
                            "where t1.formnev = " + IFSZ_Globals.SQLConstantPrepare(Me.frmForm.m_Interim_SBO.FunctionCode) + " " +
                            "and t1.gridnev = " + IFSZ_Globals.SQLConstantPrepare(l_control.Name) + " " +
                            "and " + l_szintwhere(l_szint) +
                            " union all " +
                            "select t0.* from ifsz_grid_beallitasok t0 " +
                            "left join ifsz_grid_beallitasok t1 on t0.formnev = t1.formnev and t0.gridnev = t1.gridnev and t0.oszlopnev = t1.oszlopnev and " + l_szintwhere(l_szint) + " " +
                            "where t0.formnev = " + IFSZ_Globals.SQLConstantPrepare(Me.frmForm.m_Interim_SBO.FunctionCode) + " " +
                            "and t0.gridnev = " + IFSZ_Globals.SQLConstantPrepare(l_control.Name) + " " +
                            "and t0.szint = 0 " +
                            "and t1.formnev is null "
                        )
                        If l_rc IsNot Nothing AndAlso l_rc.Count > 0 Then
                            For Each l_row As DataRow In l_rc
                                If CType(l_control, DataGridView).Columns.Contains(l_row("OSZLOPNEV")) Then
                                    Dim l_col As DataGridViewColumn = CType(l_control, DataGridView).Columns(l_row("OSZLOPNEV"))
                                    If l_row("SZELESSEG") <= 0 Then
                                        l_col.Visible = False
                                    Else
                                        l_col.Visible = True
                                        l_col.Width = l_row("SZELESSEG")
                                        l_col.DisplayIndex = l_row("DISPLAYINDEX")
                                        If l_row("FEJLEC").ToString() <> "" Then
                                            l_col.HeaderText = l_row("FEJLEC")
                                        Else
                                            If l_szint > 0 Then
                                                'A fejléc-et könnyen lehet, hogy csak 0-s szinten állítottuk be
                                                l_rc2 = DataProvider.EGetDataRecord(
                                                        "select * from ifsz_grid_beallitasok t1 " +
                                                        "where t1.formnev = " + IFSZ_Globals.SQLConstantPrepare(Me.frmForm.m_Interim_SBO.FunctionCode) + " " +
                                                        "and t1.gridnev = " + IFSZ_Globals.SQLConstantPrepare(l_control.Name) + " " +
                                                        "and t1.oszlopnev = " + IFSZ_Globals.SQLConstantPrepare(l_row("OSZLOPNEV")) + " " +
                                                        "and " + l_szintwhere(0)
                                                    )
                                                If l_rc2 IsNot Nothing AndAlso l_rc2.Count > 0 AndAlso l_rc2(0)("FEJLEC").ToString() <> "" Then
                                                    l_col.HeaderText = l_rc2(0)("FEJLEC")
                                                End If
                                            End If
                                        End If
                                    End If
                                End If
                            Next
                        End If
                    End If
                End If
            Next

        Catch ex As Exception
            Me.frmForm.show_error(ex.Message)
        End Try
    End Sub

    Public Sub GridBeallitasMentes(ByVal p_szint As Integer, Optional ByVal p_csaktorles As Boolean = False)

        Try
            Dim l_szintwhere As String
            Dim l_azonosito1, l_azonosito2 As Object
            Dim l_rc As DataRowCollection

            Select Case p_szint
                Case 1
                    l_szintwhere = "(t1.szint = 1 and t1.azonosito = " + IFSZ_Globals.SQLConstantPrepare(IFSZ_Globals.GetUserID.ToString()) + ")"
                    l_azonosito1 = IFSZ_Globals.GetUserID
                    l_azonosito2 = DBNull.Value
                Case 2
                    l_szintwhere = "(t1.szint = 2 and t1.azonosito = " + IFSZ_Globals.SQLConstantPrepare(IFSZ_Globals.GetUserID.ToString()) + " and t1.azonosito2 = " + IFSZ_Globals.SQLConstantPrepare(Environment.MachineName) + ")"
                    l_azonosito1 = IFSZ_Globals.GetUserID
                    l_azonosito2 = Environment.MachineName
                Case Else
                    Me.frmForm.show_error("Hibás szint érték!")
                    Exit Sub
            End Select

            'Töröljük a jelenlegi beállításokat
            DataProvider.EExecuteNonQuery(
                "delete from ifsz_grid_beallitasok " +
                "where formnev = " + IFSZ_Globals.SQLConstantPrepare(Me.frmForm.m_Interim_SBO.FunctionCode) + " " +
                "and gridnev = " + IFSZ_Globals.SQLConstantPrepare(Me.m_BeallitDataGrid.Name) + " " +
                "and " + l_szintwhere.Replace("t1.", "")
            )

            If Not p_csaktorles Then
                For Each l_column As DataGridViewColumn In Me.m_BeallitDataGrid.Columns
                    Dim l_szelesseg As Decimal
                    If l_column.Visible Then
                        l_szelesseg = l_column.Width
                    Else
                        l_szelesseg = 0
                    End If
                    DataProvider.EExecuteNonQuery(
                          "insert into ifsz_grid_beallitasok(szint, azonosito, azonosito2, formnev, gridnev, oszlopnev, displayindex, szelesseg) " +
                          "values (" + IFSZ_Globals.SQLConstantPrepare(p_szint) + ", " + IFSZ_Globals.SQLConstantPrepare(l_azonosito1) + ", " + IFSZ_Globals.SQLConstantPrepare(l_azonosito2) +
                          ", " + IFSZ_Globals.SQLConstantPrepare(Me.frmForm.m_Interim_SBO.FunctionCode) + " " +
                          ", " + IFSZ_Globals.SQLConstantPrepare(Me.m_BeallitDataGrid.Name) + " " +
                          ", " + IFSZ_Globals.SQLConstantPrepare(l_column.Name) + " " +
                          ", " + IFSZ_Globals.SQLConstantPrepare(l_column.DisplayIndex) + " " +
                          ", " + IFSZ_Globals.SQLConstantPrepare(l_szelesseg) + " " +
                          ")"
                        )
                Next

                l_rc = DataProvider.EGetDataRecord(
                    "select t0.oszlopnev " +
                    "from ifsz_grid_beallitasok t0 " +
                    "left join ifsz_grid_beallitasok t1 on t1.szint = " + IFSZ_Globals.SQLConstantPrepare(p_szint) + " " +
                        "and " + l_szintwhere + " and t0.formnev = t1.formnev and t0.gridnev = t1.gridnev and t0.oszlopnev = t1.oszlopnev " +
                    "where t0.formnev = " + IFSZ_Globals.SQLConstantPrepare(Me.frmForm.m_Interim_SBO.FunctionCode) + " " +
                    "and t0.gridnev = " + IFSZ_Globals.SQLConstantPrepare(Me.m_BeallitDataGrid.Name) + " " +
                    "and t0.szint = 0 and t1.szint is null"
                )
                If l_rc Is Nothing OrElse l_rc.Count > 0 Then
                    For Each l_row As DataRow In l_rc
                        DataProvider.EExecuteNonQuery(
                          "insert into ifsz_grid_beallitasok(szint, azonosito, azonosito2, formnev, gridnev, oszlopnev, displayindex, szelesseg) " +
                          "values (" + IFSZ_Globals.SQLConstantPrepare(p_szint) + ", " + IFSZ_Globals.SQLConstantPrepare(l_azonosito1) + ", " + IFSZ_Globals.SQLConstantPrepare(l_azonosito2) +
                          ", " + IFSZ_Globals.SQLConstantPrepare(Me.frmForm.m_Interim_SBO.FunctionCode) + " " +
                          ", " + IFSZ_Globals.SQLConstantPrepare(Me.m_BeallitDataGrid.Name) + " " +
                          ", " + IFSZ_Globals.SQLConstantPrepare(l_row("oszlopnev")) + " " +
                          ", 9999 " +
                          ", 0 " +
                          ")"
                        )
                    Next
                End If
            End If

        Catch ex As Exception
            Me.frmForm.show_error(ex.Message)
        End Try

    End Sub

    Private Sub GetNextFileName(ByRef p_fs As System.IO.FileStream, ByRef p_filename As String)
        Dim i, l_ind As Integer
        Dim l_path As String = System.IO.Path.GetTempPath()
        Dim l_name As String

        'Megpróbáljuk kitörölni a korábbiakat
        l_ind = -1
        For i = 0 To 100
            l_name = l_path + "IFSZ_ebiz" + i.ToString() + ".pdf"
            If Not System.IO.File.Exists(l_name) Then
                If l_ind = -1 Then
                    p_fs = System.IO.File.Create(l_name)
                    p_fs.Close()
                    p_filename = l_name
                    l_ind = i
                End If
            Else
                Try
                    Dim l_fajl As String = l_name
                    System.IO.File.Delete(l_fajl)
                    If l_ind = -1 Then
                        p_fs = System.IO.File.Create(l_name)
                        p_fs.Close()
                        p_filename = l_name
                        l_ind = i
                    End If
                Catch
                    l_ind = l_ind
                End Try            End If
        Next

        If l_ind = -1 Then
            Throw New Exception("Nem generálható átmeneti excel állomány")
        End If
    End Sub

#End Region

#Region "Public"

    Public Function Accept(ByVal pAcceptEvent As IFSZ_Types.PAcceptEvent, ByVal pOperationType As IFSZ_Types.DMLOperation, ByVal sender As Object) As Object Implements IFSZ_ICTRL.Accept

    End Function

    Delegate Sub Visszater_Callback(ByVal p_fej_is As Boolean)

    Public Sub Visszater(ByVal p_fej_is As Boolean)
        If Me.frmForm.InvokeRequired() Then
            Dim d As New Visszater_Callback(AddressOf Visszater)
            Me.frmForm.Invoke(d, New Object() {p_fej_is})
        Else
            'Nem tudom, miért nem frissíti
            Me.ControlokEnged()
            If Me.frmForm.BindingContext(Me.frmForm.p_dataset, "IFSZ_EMAILOUTHEAD").Position > -1 Then
                Dim l_row As DataRow = Me.frmForm.p_dataset.Tables("IFSZ_EMAILOUTHEAD").Rows(Me.frmForm.BindingContext(Me.frmForm.p_dataset, "IFSZ_EMAILOUTHEAD").Position)
                Dim l_rc As DataRowCollection = DataProvider.GetDataRecord(Me.m_frmView.getSqlQuery("IFSZ_EMAILOUTHEAD", "TABLE") + " where id = " + Me.frmForm.entity(0).GetAttribute("ID").ToString())
                If l_rc IsNot Nothing AndAlso l_rc.Count > 0 Then
                    For Each l_col As DataColumn In l_rc(0).Table.Columns
                        If l_col.ColumnName.EndsWith("_MEAN") Then
                            Dim l_domain_values As Collection = Me.frmForm.entity(0).GetAttributeDomain(l_col.ColumnName)
                            If l_domain_values IsNot Nothing Then
                                For Each l_temp As IFSZ_Domains.st_domain_values In l_domain_values
                                    If l_temp.value = l_row(l_col.ColumnName.Replace("_MEAN", "")).ToString() Then
                                        l_row(l_col.ColumnName) = l_temp.meaning
                                        Exit For
                                    End If
                                Next
                            End If
                        Else
                            l_row(l_col.ColumnName) = l_rc(0)(l_col.ColumnName)
                        End If
                    Next
                End If
                Me.frmForm.p_dataset.Tables("IFSZ_EMAILOUTHEAD").AcceptChanges()
            End If
            Me.get_DataTable("IFSZ_EMAILOUTLINE", "MASTER/DETAIL", Me.frmForm.BindingContext(Me.frmForm.p_dataset, "IFSZ_EMAILOUTHEAD"))
            Me.frmForm.BlockRefresh("IFSZ_EMAILOUTLINE")
            Dim l_eng As Boolean = Me.FejEngedelyez()
            For Each l_trow As DataRow In Me.frmForm.p_dataset.Tables("IFSZ_EMAILOUTLINE").Rows
                Me.TetEngedelyez(l_eng, l_trow)
            Next
            Me.TetEngedelyez(l_eng)
        End If
    End Sub

    Private Function SrvSign(ByVal p_id As Integer) As String
        Return SrvHivas(p_id.ToString, "SignEbizTet")
    End Function

    Private Function CheckToken(ByVal p_token As String) As String
        Return SrvHivas(p_token, "CheckSign")
    End Function

    Private Function SrvHivas(ByVal p_body As String, ByVal p_function As String) As String
        Dim l_request As HttpWebRequest

        l_request = WebRequest.Create(m_ebiz_srv.TrimEnd("/".ToCharArray()) + "/" + p_function)
        l_request.Method = "POST"
        l_request.ContentType = "application/json"
        l_request.Accept = "application/json"
        l_request.Expect = ""
        l_request.ContentLength = p_body.Length

        Dim l_stream As IO.Stream
        Try
            l_stream = l_request.GetRequestStream()
            Dim l_byteArray As Byte() = System.Text.Encoding.UTF8.GetBytes(p_body)
            l_stream.Write(l_byteArray, 0, l_byteArray.Length)
        Catch ex As Exception
            Throw
        Finally
            If l_stream IsNot Nothing Then
                l_stream.Close()
                l_stream.Dispose()
                l_stream = Nothing
            End If
        End Try

        Dim l_responseFromServer As String
        Dim l_response As HttpWebResponse
        Try
            l_response = l_request.GetResponse()
            l_stream = l_response.GetResponseStream()
            Dim l_reader As New System.IO.StreamReader(l_stream)
            l_responseFromServer = l_reader.ReadToEnd()
        Catch
            Throw
        Finally
            If l_response IsNot Nothing Then
                l_response.Close()
                l_response = Nothing
            End If
            If l_stream IsNot Nothing Then
                l_stream.Close()
                l_stream.Dispose()
                l_stream = Nothing
            End If
        End Try

        Return l_responseFromServer

    End Function


#End Region

End Class

