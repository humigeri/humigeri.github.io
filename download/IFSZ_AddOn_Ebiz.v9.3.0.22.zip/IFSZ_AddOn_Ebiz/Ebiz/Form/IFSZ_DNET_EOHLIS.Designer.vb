﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class IFSZ_DNET_EOHLIS
    'Inherits System.Windows.Forms.Form
    Inherits IFSZ_Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.OK = New System.Windows.Forms.Button()
        Me.MEGSE = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.DG1_ID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_DOCNUM = New IFSZ_AddOnBase.TextAndImageColumn()
        Me.DG1_USERCODE = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_SENTTS = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_STATUS_MEAN = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_PATH = New IFSZ_AddOnBase.TextAndImageColumn()
        Me.DG1_STATUS = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_STATUS_LANGVAL = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_NOTE = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.IFSZEOHLISViewBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.IFSZEOHLISViewBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'OK
        '
        Me.OK.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.OK.Location = New System.Drawing.Point(12, 478)
        Me.OK.Name = "OK"
        Me.OK.Size = New System.Drawing.Size(75, 23)
        Me.OK.TabIndex = 1044
        Me.OK.Text = "OK"
        Me.OK.UseVisualStyleBackColor = True
        '
        'MEGSE
        '
        Me.MEGSE.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.MEGSE.Location = New System.Drawing.Point(92, 478)
        Me.MEGSE.Name = "MEGSE"
        Me.MEGSE.Size = New System.Drawing.Size(75, 23)
        Me.MEGSE.TabIndex = 1043
        Me.MEGSE.Text = "Mégsem"
        Me.MEGSE.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DG1_ID, Me.DG1_DOCNUM, Me.DG1_USERCODE, Me.DG1_SENTTS, Me.DG1_STATUS_MEAN, Me.DG1_PATH, Me.DG1_STATUS, Me.DG1_STATUS_LANGVAL, Me.DG1_NOTE})
        Me.DataGridView1.DataSource = Me.IFSZEOHLISViewBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(15, 12)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(752, 460)
        Me.DataGridView1.TabIndex = 500
        '
        'DG1_ID
        '
        Me.DG1_ID.DataPropertyName = "ID"
        Me.DG1_ID.HeaderText = "ID"
        Me.DG1_ID.Name = "DG1_ID"
        Me.DG1_ID.Visible = False
        '
        'DG1_DOCNUM
        '
        Me.DG1_DOCNUM.DataPropertyName = "DOCNUM"
        DataGridViewCellStyle1.Padding = New System.Windows.Forms.Padding(11, 0, 0, 0)
        Me.DG1_DOCNUM.DefaultCellStyle = DataGridViewCellStyle1
        Me.DG1_DOCNUM.FormUID = Nothing
        Me.DG1_DOCNUM.HeaderText = "Bizonylatszám"
        Me.DG1_DOCNUM.Image = Global.IFSZ_AddOnBase.My.Resources.Resources.lefuras_be
        Me.DG1_DOCNUM.LinkObject = Nothing
        Me.DG1_DOCNUM.MenuUID = Nothing
        Me.DG1_DOCNUM.Name = "DG1_DOCNUM"
        Me.DG1_DOCNUM.ReadOnly = True
        Me.DG1_DOCNUM.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        '
        'DG1_USERCODE
        '
        Me.DG1_USERCODE.DataPropertyName = "USERCODE"
        Me.DG1_USERCODE.HeaderText = "Felh.kód"
        Me.DG1_USERCODE.Name = "DG1_USERCODE"
        Me.DG1_USERCODE.ReadOnly = True
        '
        'DG1_SENTTS
        '
        Me.DG1_SENTTS.DataPropertyName = "SENTTS"
        Me.DG1_SENTTS.HeaderText = "Küld.időpont"
        Me.DG1_SENTTS.Name = "DG1_SENTTS"
        Me.DG1_SENTTS.ReadOnly = True
        '
        'DG1_STATUS_MEAN
        '
        Me.DG1_STATUS_MEAN.DataPropertyName = "STATUS_MEAN"
        Me.DG1_STATUS_MEAN.HeaderText = "Státusz"
        Me.DG1_STATUS_MEAN.Name = "DG1_STATUS_MEAN"
        Me.DG1_STATUS_MEAN.ReadOnly = True
        Me.DG1_STATUS_MEAN.Width = 80
        '
        'DG1_PATH
        '
        Me.DG1_PATH.DataPropertyName = "PATH"
        DataGridViewCellStyle2.Padding = New System.Windows.Forms.Padding(11, 0, 0, 0)
        Me.DG1_PATH.DefaultCellStyle = DataGridViewCellStyle2
        Me.DG1_PATH.FormUID = Nothing
        Me.DG1_PATH.HeaderText = "Útvonal"
        Me.DG1_PATH.Image = Global.IFSZ_AddOnBase.My.Resources.Resources.lefuras_be
        Me.DG1_PATH.LinkObject = Nothing
        Me.DG1_PATH.MenuUID = Nothing
        Me.DG1_PATH.Name = "DG1_PATH"
        Me.DG1_PATH.ReadOnly = True
        Me.DG1_PATH.Width = 150
        '
        'DG1_STATUS
        '
        Me.DG1_STATUS.DataPropertyName = "STATUS"
        Me.DG1_STATUS.HeaderText = "STATUS"
        Me.DG1_STATUS.Name = "DG1_STATUS"
        Me.DG1_STATUS.Visible = False
        '
        'DG1_STATUS_LANGVAL
        '
        Me.DG1_STATUS_LANGVAL.DataPropertyName = "STATUS_LANGVAL"
        Me.DG1_STATUS_LANGVAL.HeaderText = "STATUS_LANGVAL"
        Me.DG1_STATUS_LANGVAL.Name = "DG1_STATUS_LANGVAL"
        Me.DG1_STATUS_LANGVAL.Visible = False
        '
        'DG1_NOTE
        '
        Me.DG1_NOTE.DataPropertyName = "NOTE"
        Me.DG1_NOTE.HeaderText = "Megjegyzés"
        Me.DG1_NOTE.Name = "DG1_NOTE"
        Me.DG1_NOTE.ReadOnly = True
        Me.DG1_NOTE.Width = 200
        '
        'IFSZEOHLISViewBindingSource
        '
        Me.IFSZEOHLISViewBindingSource.DataSource = GetType(IFSZ_AddOnBase.IFSZ_EOHLIS_View)
        '
        'IFSZ_DNET_EOHLIS
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(779, 513)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.OK)
        Me.Controls.Add(Me.MEGSE)
        Me.Name = "IFSZ_DNET_EOHLIS"
        Me.Text = "Küldési bizonylatok listája"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.IFSZEOHLISViewBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents OK As Button
    Friend WithEvents MEGSE As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents IFSZEOHLISViewBindingSource As BindingSource
    Friend WithEvents DG1_ID As DataGridViewTextBoxColumn
    Friend WithEvents DG1_DOCNUM As TextAndImageColumn
    Friend WithEvents DG1_USERCODE As DataGridViewTextBoxColumn
    Friend WithEvents DG1_SENTTS As DataGridViewTextBoxColumn
    Friend WithEvents DG1_STATUS_MEAN As DataGridViewTextBoxColumn
    Friend WithEvents DG1_PATH As TextAndImageColumn
    Friend WithEvents DG1_STATUS As DataGridViewTextBoxColumn
    Friend WithEvents DG1_STATUS_LANGVAL As DataGridViewTextBoxColumn
    Friend WithEvents DG1_NOTE As DataGridViewTextBoxColumn
End Class
