Public Class IFSZ_DNET_EOB
    Private p_IFSZ_EMAILOUTBODY As IFSZ_EMAILOUTBODY
    Private p_IFSZ_CRD_EMAILBODY As IFSZ_CRD_EMAILBODY

    Public Sub New()
        MyBase.New()
        Me.m_IFSZ_Globals = New IFSZ_Globals
        Me.controller = New IFSZ_EOB_Ctrl(Me)
        InitializeComponent()
        Me.LanguageUpdate()

        p_IFSZ_EMAILOUTBODY = New IFSZ_EMAILOUTBODY(Me.entity, Me, Me.m_IFSZ_Globals)
        p_IFSZ_CRD_EMAILBODY = New IFSZ_CRD_EMAILBODY(Me.entity, Me, Me.m_IFSZ_Globals)

        Me.DataGridView1.Tag = Me.entity(0)
        Me.DataGridView2.Tag = Me.entity(1)
    End Sub

    Sub New(ByRef p_ifsz_globals As IFSZ_Globals)
        MyBase.New()

        Me.m_IFSZ_Globals = p_ifsz_globals
        Me.controller = New IFSZ_EOB_Ctrl(Me)
        InitializeComponent()
        Me.LanguageUpdate()

        p_IFSZ_EMAILOUTBODY = New IFSZ_EMAILOUTBODY(Me.entity, Me, Me.m_IFSZ_Globals)
        p_IFSZ_CRD_EMAILBODY = New IFSZ_CRD_EMAILBODY(Me.entity, Me, Me.m_IFSZ_Globals)

        Me.DataGridView1.Tag = Me.entity(0)
        Me.DataGridView2.Tag = Me.entity(1)
    End Sub

    Sub New(ByRef p_parentAddon As SBOAddOn, ByRef p_Interim_SBO As IFSZ_Interim_SBO)
        MyBase.New(p_Interim_SBO)

        Me.m_IFSZ_Globals = New IFSZ_Globals
        Me.controller = New IFSZ_EOB_Ctrl(Me)
        InitializeComponent()
        Me.LanguageUpdate()

        p_IFSZ_EMAILOUTBODY = New IFSZ_EMAILOUTBODY(Me.entity, Me, Me.m_IFSZ_Globals)
        p_IFSZ_CRD_EMAILBODY = New IFSZ_CRD_EMAILBODY(Me.entity, Me, Me.m_IFSZ_Globals)

        Me.DataGridView1.Tag = Me.entity(0)
        Me.DataGridView2.Tag = Me.entity(1)

    End Sub

    Private Sub LanguageUpdate()
    End Sub

    Private Sub T_BODY_KeyDown(sender As Object, e As KeyEventArgs) Handles T_BODY.KeyDown
        If e.KeyCode = Keys.Down OrElse e.KeyCode = Keys.Up Then
            e.Handled = True
        End If
    End Sub
End Class
