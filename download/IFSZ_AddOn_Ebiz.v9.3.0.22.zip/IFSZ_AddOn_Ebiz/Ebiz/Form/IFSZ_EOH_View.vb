﻿'----------------------------------------------------------------------------'
'Generálva: 2020.03.22
'FormViewGenerator. Verzió: 1.0.7.0
'----------------------------------------------------------------------------'

Public Class IFSZ_EOH_View
    Inherits ObjectDataBinding.BaseClasses.FSBindingItem

#Region "Variables"

    Private p_ID As Integer
    Private p_DOCNUM As String
    Private p_USERCODE As String
    Private p_NOTE As String
    Private p_SENTTS As String
    Private p_STATUS As String
    Private p_PATH As String
    Private p_DOCTYPE As String
    Private p_CRYSTAL As String
    Private p_CRYSTALNAME As String
    Private p_MAIL_SUBJECT As String
    Private p_MAIL_BODY As String
    Private p_FILE As String
    Private p_EOH_ID As String
    Private p_LINENUM As String
    Private p_DOCENTRY As String
    Private p_CARDCODE As String
    Private p_CARDNAME As String
    Private p_ISHTML As String
    Private p_EBIZTIP As String
    Private p_EBIZTIP_LANGVAL As String
    Private p_EBIZTIP_MEAN As String

#End Region


#Region "Constructor"

    Public Sub New()

    End Sub

#End Region

#Region "Property"

    Public Property ID() As Integer
        Get
            Return p_ID
        End Get
        Set(ByVal value As Integer)
            p_ID = value
        End Set
    End Property

    Public Property DOCNUM() As String
        Get
            Return p_DOCNUM
        End Get
        Set(ByVal value As String)
            p_DOCNUM = value
        End Set
    End Property

    Public Property USERCODE() As String
        Get
            Return p_USERCODE
        End Get
        Set(ByVal value As String)
            p_USERCODE = value
        End Set
    End Property

    Public Property NOTE() As String
        Get
            Return p_NOTE
        End Get
        Set(ByVal value As String)
            p_NOTE = value
        End Set
    End Property

    Public Property SENTTS() As String
        Get
            Return p_SENTTS
        End Get
        Set(ByVal value As String)
            p_SENTTS = value
        End Set
    End Property

    Public Property STATUS() As String
        Get
            Return p_STATUS
        End Get
        Set(ByVal value As String)
            p_STATUS = value
        End Set
    End Property

    Public Property PATH() As String
        Get
            Return p_PATH
        End Get
        Set(ByVal value As String)
            p_PATH = value
        End Set
    End Property

    Public Property DOCTYPE() As String
        Get
            Return p_DOCTYPE
        End Get
        Set(ByVal value As String)
            p_DOCTYPE = value
        End Set
    End Property

    Public Property CRYSTAL() As String
        Get
            Return p_CRYSTAL
        End Get
        Set(ByVal value As String)
            p_CRYSTAL = value
        End Set
    End Property

    Public Property CRYSTALNAME() As String
        Get
            Return p_CRYSTALNAME
        End Get
        Set(ByVal value As String)
            p_CRYSTALNAME = value
        End Set
    End Property

    Public Property MAIL_SUBJECT() As String
        Get
            Return p_MAIL_SUBJECT
        End Get
        Set(ByVal value As String)
            p_MAIL_SUBJECT = value
        End Set
    End Property

    Public Property MAIL_BODY() As String
        Get
            Return p_MAIL_BODY
        End Get
        Set(ByVal value As String)
            p_MAIL_BODY = value
        End Set
    End Property

    Public Property FILE() As String
        Get
            Return p_FILE
        End Get
        Set(ByVal value As String)
            p_FILE = value
        End Set
    End Property

    Public Property EOH_ID() As String
        Get
            Return p_EOH_ID
        End Get
        Set(ByVal value As String)
            p_EOH_ID = value
        End Set
    End Property

    Public Property LINENUM() As String
        Get
            Return p_LINENUM
        End Get
        Set(ByVal value As String)
            p_LINENUM = value
        End Set
    End Property

    Public Property DOCENTRY() As String
        Get
            Return p_DOCENTRY
        End Get
        Set(ByVal value As String)
            p_DOCENTRY = value
        End Set
    End Property

    Public Property CARDCODE() As String
        Get
            Return p_CARDCODE
        End Get
        Set(ByVal value As String)
            p_CARDCODE = value
        End Set
    End Property

    Public Property CARDNAME() As String
        Get
            Return p_CARDNAME
        End Get
        Set(ByVal value As String)
            p_CARDNAME = value
        End Set
    End Property

    Public Property ISHTML() As String
        Get
            Return p_ISHTML
        End Get
        Set(ByVal value As String)
            p_ISHTML = value
        End Set
    End Property

    Public Property EBIZTIP() As String
        Get
            Return p_EBIZTIP
        End Get
        Set(ByVal value As String)
            p_EBIZTIP = value
        End Set
    End Property

    Public Property EBIZTIP_LANGVAL() As String
        Get
            Return p_EBIZTIP_LANGVAL
        End Get
        Set(ByVal value As String)
            p_EBIZTIP_LANGVAL = value
        End Set
    End Property

    Public Property EBIZTIP_MEAN() As String
        Get
            Return p_EBIZTIP_MEAN
        End Get
        Set(ByVal value As String)
            p_EBIZTIP_MEAN = value
        End Set
    End Property

#End Region

    Public Function getDataSet() As DataSet
        Dim sqlQuery As String = ""
        Dim dataSet As DataSet = New DataSet

        Try

            sqlQuery = sqlQuery & "select ID, DOCNUM, USERCODE, NOTE, SENTTS, STATUS, STATUS_LANGVAL, STATUS_MEAN, PATH from IFSZ_F_EOH_EOH_V where 1=2; "
            sqlQuery = sqlQuery & "select ID, DOCTYPE, DOCTYPE_LANGVAL, DOCTYPE_MEAN, CARDCODE, CARDNAME, CRYSTAL, CRYSTALNAME, MAIL_SUBJECT, MAIL_BODY, ""FILE"", ""STATUS"", STATUS_LANGVAL, STATUS_MEAN, EOH_ID, LINENUM, DOCENTRY, DOCNUM, EMAILS, SENTTS, ISHTML, EBIZTIP, EBIZTIP_LANGVAL, EBIZTIP_MEAN from IFSZ_F_EOH_EOL_V where 1=2 "


            ' Get a data set from the query
            dataSet = DataProvider.GetDataSet(sqlQuery.ToString())


            ' Create variables for data set tables
            Dim T1 As DataTable = dataSet.Tables(0)
            T1.TableName = "IFSZ_EMAILOUTHEAD"
            dataSet.Tables(0).TableName = "IFSZ_EMAILOUTHEAD"
            Dim T2 As DataTable = dataSet.Tables(1)
            T2.TableName = "IFSZ_EMAILOUTLINE"
            dataSet.Tables(1).TableName = "IFSZ_EMAILOUTLINE"


            Return dataSet

        Finally
            If (Not dataSet Is Nothing) Then
                'System.Runtime.InteropServices.Marshal.ReleaseComObject(dataSet)
                dataSet.Dispose()
            End If

        End Try
    End Function

    Public Function getSqlQuery(ByVal p_table As String, Optional ByVal p_tipus As String = "") As String
        Select Case p_table
            Case "IFSZ_EMAILOUTHEAD"
                Select Case p_tipus
                    Case "MASTER/DETAIL"
                        Return "select ID, DOCNUM, USERCODE, NOTE, SENTTS, STATUS, STATUS_LANGVAL, STATUS_MEAN, PATH from IFSZ_F_EOH_EOH_V "
                    Case "TABLE"
                        Return "select ID, DOCNUM, USERCODE, NOTE, SENTTS, STATUS, STATUS_LANGVAL, STATUS_MEAN, PATH from IFSZ_F_EOH_EOH_V "
                    Case Else
                        Return "select ID, DOCNUM, USERCODE, NOTE, SENTTS, STATUS, STATUS_LANGVAL, STATUS_MEAN, PATH from IFSZ_F_EOH_EOH_V "
                End Select
            Case "IFSZ_EMAILOUTLINE"
                Select Case p_tipus
                    Case "MASTER/DETAIL"
                        Return "select ID, DOCTYPE, DOCTYPE_LANGVAL, DOCTYPE_MEAN, CARDCODE, CARDNAME, CRYSTAL, CRYSTALNAME, MAIL_SUBJECT, MAIL_BODY, ""FILE"", ""STATUS"", STATUS_LANGVAL, STATUS_MEAN, EOH_ID, LINENUM, DOCENTRY, DOCNUM, EMAILS, SENTTS, ISHTML, EBIZTIP, EBIZTIP_LANGVAL, EBIZTIP_MEAN from IFSZ_F_EOH_EOL_V "
                    Case "TABLE"
                        Return "select ID, DOCTYPE, DOCTYPE_LANGVAL, DOCTYPE_MEAN, CARDCODE, CARDNAME, CRYSTAL, CRYSTALNAME, MAIL_SUBJECT, MAIL_BODY, ""FILE"", ""STATUS"", STATUS_LANGVAL, STATUS_MEAN, EOH_ID, LINENUM, DOCENTRY, DOCNUM, EMAILS, SENTTS, ISHTML, EBIZTIP, EBIZTIP_LANGVAL, EBIZTIP_MEAN from IFSZ_F_EOH_EOL_V "
                    Case Else
                        Return "select ID, DOCTYPE, DOCTYPE_LANGVAL, DOCTYPE_MEAN, CARDCODE, CARDNAME, CRYSTAL, CRYSTALNAME, MAIL_SUBJECT, MAIL_BODY, ""FILE"", ""STATUS"", STATUS_LANGVAL, STATUS_MEAN, EOH_ID, LINENUM, DOCENTRY, DOCNUM, EMAILS, SENTTS, ISHTML, EBIZTIP, EBIZTIP_LANGVAL, EBIZTIP_MEAN from IFSZ_F_EOH_EOL_V "
                End Select
            Case Else
                Return ""
        End Select
    End Function

End Class
