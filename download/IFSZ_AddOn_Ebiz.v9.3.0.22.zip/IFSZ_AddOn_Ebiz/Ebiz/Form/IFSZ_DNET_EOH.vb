﻿'----------------------------------------------------------------------------'
'Generálva: 2020.03.22
'FormViewGenerator. Verzió: 1.0.7.0
'----------------------------------------------------------------------------'

Public Class IFSZ_DNET_EOH

    Private p_IFSZ_EMAILOUTHEAD As IFSZ_EMAILOUTHEAD
    Private p_IFSZ_EMAILOUTLINE As IFSZ_EMAILOUTLINE

    Public Sub New()
        MyBase.New()
        Me.m_IFSZ_Globals = New IFSZ_Globals
        Me.controller = New IFSZ_EOH_Ctrl(Me)
        InitializeComponent()
        Me.LanguageUpdate()

        p_IFSZ_EMAILOUTHEAD = New IFSZ_EMAILOUTHEAD(Me.entity, Me, Me.m_IFSZ_Globals)
        p_IFSZ_EMAILOUTLINE = New IFSZ_EMAILOUTLINE(Me.entity, Me, Me.m_IFSZ_Globals)

        Me.DataGridView1.Tag = Me.entity(1)
    End Sub

    Sub New(ByRef p_ifsz_globals As IFSZ_Globals)
        MyBase.New()

        Me.m_IFSZ_Globals = p_ifsz_globals
        Me.controller = New IFSZ_EOH_Ctrl(Me)
        InitializeComponent()
        Me.LanguageUpdate()

        p_IFSZ_EMAILOUTHEAD = New IFSZ_EMAILOUTHEAD(Me.entity, Me, Me.m_IFSZ_Globals)
        p_IFSZ_EMAILOUTLINE = New IFSZ_EMAILOUTLINE(Me.entity, Me, Me.m_IFSZ_Globals)

        Me.DataGridView1.Tag = Me.entity(1)
    End Sub

    Sub New(ByRef p_parentAddon As SBOAddOn, ByRef p_Interim_SBO As IFSZ_Interim_SBO)
        MyBase.New(p_Interim_SBO)

        Me.m_IFSZ_Globals = New IFSZ_Globals
        Me.controller = New IFSZ_EOH_Ctrl(Me)
        InitializeComponent()
        Me.LanguageUpdate()

        p_IFSZ_EMAILOUTHEAD = New IFSZ_EMAILOUTHEAD(Me.entity, Me, Me.m_IFSZ_Globals)
        p_IFSZ_EMAILOUTLINE = New IFSZ_EMAILOUTLINE(Me.entity, Me, Me.m_IFSZ_Globals)

        Me.DataGridView1.Tag = Me.entity(1)

    End Sub

    Private Sub IFSZ_DNET_EOH_Activated(sender As Object, e As EventArgs) Handles Me.Activated
        If IFSZ_EOH_Ctrl.m_frissit Then
            IFSZ_EOH_Ctrl.m_frissit = False
            CType(Me.controller, IFSZ_EOH_Ctrl).Visszater(False)
        End If
    End Sub

    Private Sub LanguageUpdate()
    End Sub

    Private Sub PBx_T_PATH_Click(sender As Object, e As EventArgs) Handles PBx_T_PATH.Click
        If T_PATH.Text <> "" Then
            Try
                Dim l_proc As System.Diagnostics.Process = System.Diagnostics.Process.Start(T_PATH.Text)
                If l_proc IsNot Nothing Then
                    Win32Helper.SetForegroundWindow(l_proc.MainWindowHandle())
                End If

            Catch ex As Exception
                Me.show_info(ex.Message)
            End Try
        End If
    End Sub

    Private Sub MnuGridBeallitSetFho_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles MnuGridBeallitSetFho.Click
        CType(Me.controller, IFSZ_EOH_Ctrl).GridBeallitasMentes(1)
    End Sub

    Private Sub MnuGridBeallitSetMachine_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles MnuGridBeallitSetMachine.Click
        CType(Me.controller, IFSZ_EOH_Ctrl).GridBeallitasMentes(2)
    End Sub

    Private Sub MnuGridBeallitDelFho_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles MnuGridBeallitDelFho.Click
        CType(Me.controller, IFSZ_EOH_Ctrl).GridBeallitasMentes(1, True)
    End Sub

    Private Sub MnuGridBeallitDelMachine_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles MnuGridBeallitDelMachine.Click
        CType(Me.controller, IFSZ_EOH_Ctrl).GridBeallitasMentes(2, True)
    End Sub

End Class
