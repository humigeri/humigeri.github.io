﻿'----------------------------------------------------------------------------''Generálva: 2008.09.01'FormViewGenerator. Verzió: 1.0.4.0'----------------------------------------------------------------------------'Imports IFSZ_AddOnBase.IFSZ_TypesImports SystemImports System.IOImports System.TextPublic Class IFSZ_EOB_Ctrl    Implements IFSZ_ICTRL    Implements IIFSZ_FileDialogResult    Public Sub New()    End Sub    Public Sub New(ByRef frmMain As Object)        frmForm = frmMain        plSaveFileDialog = New IFSZ_FileDialog()        Me.m_frmView = New IFSZ_EOB_View()    End Sub    Private frmForm As IFSZ_DNET_EOB    Private plFileDialogOpen As Boolean = False    Private plSaveFileDialog As IFSZ_FileDialog    Private m_frmView As IFSZ_EOB_View    Private volt_form_event As Boolean = False    Private m_doctype_view As DataView    Public Sub Form_Event(ByVal pEvent As String, ByVal sender As Object, ByVal e As System.EventArgs) Implements IFSZ_ICTRL.Form_Event
        Dim p_relation As IFSZ_Types.Relations = New IFSZ_Types.Relations        If pEvent = "PreForm" Then

            Me.frmForm.T_NAME.Tag = Me.frmForm.entity(0)
            Me.frmForm.T_SUBJECT.Tag = Me.frmForm.entity(0)
            Me.frmForm.T_BODY.Tag = Me.frmForm.entity(0)

        ElseIf pEvent = "FormLoad" Then

            Me.frmForm.entity(0).NewRowEnabled = True
            Me.frmForm.entity(1).NewRowEnabled = True
            Me.frmForm.VirtualRowEnabled = True
                Me.frmForm.p_dataset = m_frmView.getDataSet

            ReDim Preserve p_relation.Tables(0)
            ReDim Preserve p_relation.Tables(0).PK_Columns(0)
            ReDim Preserve p_relation.Tables(0).FK_Columns(0)

            p_relation.Tables(0).Table = "IFSZ_CRD_EMAILBODY"
            p_relation.Tables(0).PK_Columns(0) = "ID"
            p_relation.Tables(0).FK_Columns(0) = "BODY"

            Me.frmForm.entity(0).ChildRelation = p_relation

            Me.frmForm.T_NAME.DataBindings.Add("TEXT", Me.frmForm.p_dataset, "IFSZ_EMAILOUTBODY.NAME", True, DataSourceUpdateMode.OnValidation)
            Me.frmForm.T_SUBJECT.DataBindings.Add("TEXT", Me.frmForm.p_dataset, "IFSZ_EMAILOUTBODY.SUBJECT", True, DataSourceUpdateMode.OnValidation)
            Me.frmForm.T_BODY.DataBindings.Add("TEXT", Me.frmForm.p_dataset, "IFSZ_EMAILOUTBODY.BODY", True, DataSourceUpdateMode.OnValidation)

            Me.frmForm.DataGridView1.DataSource = Me.frmForm.p_dataset
            Me.frmForm.DataGridView1.Name = "IFSZ_EMAILOUTBODY"
            Me.frmForm.DataGridView1.DataMember = "IFSZ_EMAILOUTBODY"

            Me.frmForm.DataGridView2.DataSource = Me.frmForm.p_dataset
            Me.frmForm.DataGridView2.Name = "IFSZ_CRD_EMAILBODY"
            Me.frmForm.DataGridView2.DataMember = "IFSZ_CRD_EMAILBODY"

            volt_form_event = True

        End If    End Sub    Public Function get_DataTable(ByVal p_TableName As String, Optional ByVal p_tipus As String = "", Optional ByVal sender As Object = Nothing, Optional ByVal p_where As String = "") As System.Data.DataTable Implements IFSZ_ICTRL.get_DataTable        Dim p_SqlQuery As String
        'Dim frm_view As IFSZ_EgyszBeszerTerv_View = New IFSZ_EgyszBeszerTerv_View()
        Dim i, j, p_pk_num As Integer
        'Dim p_relation As IFSZ_Types.Relations
        Dim p_table As IFSZ_Types.RelationTable
        'Dim p_pk_id, p_fk_id As String
        Dim l_datatable As DataTable        Select Case p_tipus            Case "MASTER/DETAIL"                For i = 0 To frmForm.entity.GetUpperBound(0)                    If frmForm.entity(i).TableName = sender.current.row.table.tablename() Then                        For Each p_table In frmForm.entity(i).ChildRelation.Tables                            If p_table.Table = p_TableName Then                                For p_pk_num = 0 To p_table.PK_Columns.GetUpperBound(0)                                    If p_pk_num = 0 Then                                        p_SqlQuery = Me.m_frmView.getSqlQuery(p_TableName, p_tipus) & "where " & p_table.FK_Columns(p_pk_num) & " = " & sender.current.row(p_table.PK_Columns(p_pk_num))                                    Else                                        p_SqlQuery = Me.m_frmView.getSqlQuery(p_TableName, p_tipus) & " and " & p_table.FK_Columns(p_pk_num) & " = " & sender.current.row(p_table.PK_Columns(p_pk_num))                                    End If                                Next                                For j = 0 To frmForm.entity.GetUpperBound(0)                                    If frmForm.entity(j).TableName = p_TableName Then                                        frmForm.entity(j).ChildWhere = p_SqlQuery.Substring(p_SqlQuery.ToUpper.IndexOf("WHERE") + 5, p_SqlQuery.Length - p_SqlQuery.ToUpper.IndexOf("WHERE") - 5).Trim                                        If frmForm.entity(j).DefaultWhere <> "" Then                                            p_SqlQuery = p_SqlQuery & " and " & frmForm.entity(j).DefaultWhere
                                            'p_SqlQuery = p_SqlQuery & " and " & frmForm.entity(i).DefaultWhere
                                        End If
                                        'frmForm.entity(j).ChildWhere = p_SqlQuery.Substring(p_SqlQuery.ToUpper.IndexOf("WHERE") + 5, p_SqlQuery.Length - p_SqlQuery.ToUpper.IndexOf("WHERE") - 5).Trim
                                    End If                                Next                            End If                        Next                    End If

                    'If frmForm.entity(i).TableName = p_TableName Then
                    '    p_SqlQuery = frm_view.getSqlQuery(p_TableName, p_tipus) & sender.current.row("ID")
                    '    frmForm.entity(i).ChildWhere = p_SqlQuery.Substring(p_SqlQuery.ToUpper.IndexOf("WHERE") + 5, p_SqlQuery.Length - p_SqlQuery.ToUpper.IndexOf("WHERE") - 5).Trim
                    'End If
                    'frmForm.entity(i).ChildWhere = p_SqlQuery.Substring(p_SqlQuery.ToUpper.IndexOf("WHERE") + 5, p_SqlQuery.Length - p_SqlQuery.ToUpper.IndexOf("WHERE") - 5).Trim
                Next                l_datatable = DataProvider.GetDataTable(p_SqlQuery)                Return l_datatable            Case "TABLE"                p_SqlQuery = Me.m_frmView.getSqlQuery(p_TableName, p_tipus)                If p_where = "" Then                    p_where = "1=1"                Else                    p_where = p_where.Replace("'False'", "'N'").Replace("'True'", "'Y'")                End If                For i = 0 To frmForm.entity.GetUpperBound(0)                    If frmForm.entity(i).TableName = p_TableName And frmForm.entity(i).DefaultWhere <> "" Then                        p_where = p_where & " and " & frmForm.entity(i).DefaultWhere                        If frmForm.entity(i).ChildWhere <> "" Then                            p_where = p_where & " and " & frmForm.entity(i).ChildWhere                        End If                    ElseIf frmForm.entity(i).TableName = p_TableName And frmForm.entity(i).ChildWhere <> "" Then                        p_where = p_where & " and " & frmForm.entity(i).ChildWhere                    End If                Next                p_SqlQuery = p_SqlQuery & " where " & p_where                l_datatable = DataProvider.GetDataTable(p_SqlQuery)                Return l_datatable            Case Else                l_datatable = DataProvider.GetDataTable(p_SqlQuery)                Return l_datatable        End Select    End Function

    '----------------------------------------------------------------------------
    '----------------------------------------------------------------------------
    'Item_Event
    '----------------------------------------------------------------------------
    '----------------------------------------------------------------------------
    Public Sub Item_Event(ByVal pEvent As IFSZ_Types.PItemEvent, ByVal sender As Object, ByVal e As System.EventArgs) Implements IFSZ_ICTRL.Item_Event

        If pEvent = PItemEvent.ItemValidate Then
            If Me.frmForm.getObjectName(sender, e) = "DG2_CARDCODE" Then
                Dim l_lookup_ertek As String = CType(e, System.Windows.Forms.DataGridViewCellValidatingEventArgs).FormattedValue.Replace("*", "%")
                If l_lookup_ertek.Length > 0 Then
                    Dim l_lov As Boolean = l_lookup_ertek.EndsWith("%")
                    If l_lov Then
                        l_lookup_ertek = l_lookup_ertek.Substring(0, l_lookup_ertek.Length - 1)
                    Else
                        Dim l_DataRowCollection As DataRowCollection = get_elso_Partner(l_lookup_ertek)
                        If l_DataRowCollection.Count = 0 Then
                            Me.frmForm.show_error(sender, "Nem létező érték", e)
                            Exit Sub
                        ElseIf l_DataRowCollection.Count = 1 OrElse (l_DataRowCollection.Count > 1 AndAlso l_DataRowCollection(0)("CARDNAME") = l_lookup_ertek) Then
                            Me.frmForm.entity(1).set_item("CARDCODE", l_DataRowCollection(0)("CARDCODE"))
                            Me.frmForm.entity(1).set_item("CARDNAME", l_DataRowCollection(0)("CARDNAME"))
                        Else
                            l_lov = True
                        End If
                    End If
                    If l_lov Then
                        CType(e, System.ComponentModel.CancelEventArgs).Cancel = True
                        Me.Partner_lov(sender, l_lookup_ertek, CType(e, System.Windows.Forms.DataGridViewCellValidatingEventArgs).RowIndex)
                    End If
                Else
                    Me.frmForm.entity(1).set_item("CARDCODE", DBNull.Value)
                    Me.frmForm.entity(1).set_item("CARDNAME", DBNull.Value)
                End If
            End If
            If Me.frmForm.getObjectName(sender, e) = "DG1_DOCTYPE_NAME" Then
                Dim l_lookup_ertek As String = CType(e, System.Windows.Forms.DataGridViewCellValidatingEventArgs).FormattedValue.Replace("*", "%")
                If l_lookup_ertek.Length > 0 Then
                    Dim l_lov As Boolean = l_lookup_ertek.EndsWith("%")
                    If l_lov Then
                        l_lookup_ertek = l_lookup_ertek.Substring(0, l_lookup_ertek.Length - 1)
                    Else
                        Dim l_DataRowCollection As DataRowCollection = get_elso_DocType(l_lookup_ertek)
                        If l_DataRowCollection.Count = 0 Then
                            Me.frmForm.show_error(sender, "Nem létező érték", e)
                            Exit Sub
                        ElseIf l_DataRowCollection.Count = 1 OrElse (l_DataRowCollection.Count > 1 AndAlso l_DataRowCollection(0)("NAME") = l_lookup_ertek) Then
                            Me.frmForm.entity(0).set_item("DOCTYPE", l_DataRowCollection(0)("CODE"))
                            Me.frmForm.entity(0).set_item("DOCTYPE_NAME", l_DataRowCollection(0)("NAME"))
                        Else
                            l_lov = True
                        End If
                    End If
                    If l_lov Then
                        CType(e, System.ComponentModel.CancelEventArgs).Cancel = True
                        Me.DocType_lov(sender, l_lookup_ertek, CType(e, System.Windows.Forms.DataGridViewCellValidatingEventArgs).RowIndex)
                    End If
                Else
                    Me.frmForm.entity(0).set_item("DOCTYPE", DBNull.Value)
                    Me.frmForm.entity(0).set_item("DOCTYPE_NAME", DBNull.Value)
                End If
            End If
            If Me.frmForm.getObjectName(sender, e) = "DG1_LANG_NAME" Then
                Dim l_lookup_ertek As String = CType(e, System.Windows.Forms.DataGridViewCellValidatingEventArgs).FormattedValue.Replace("*", "%")
                If l_lookup_ertek.Length > 0 Then
                    Dim l_lov As Boolean = l_lookup_ertek.EndsWith("%")
                    If l_lov Then
                        l_lookup_ertek = l_lookup_ertek.Substring(0, l_lookup_ertek.Length - 1)
                    Else
                        Dim l_DataRowCollection As DataRowCollection = get_elso_Lang(l_lookup_ertek)
                        If l_DataRowCollection.Count = 0 Then
                            Me.frmForm.show_error(sender, "Nem létező érték", e)
                            Exit Sub
                        ElseIf l_DataRowCollection.Count = 1 OrElse (l_DataRowCollection.Count > 1 AndAlso l_DataRowCollection(0)("NAME") = l_lookup_ertek) Then
                            Me.frmForm.entity(0).set_item("LANG", l_DataRowCollection(0)("CODE"))
                            Me.frmForm.entity(0).set_item("LANG_NAME", l_DataRowCollection(0)("NAME"))
                        Else
                            l_lov = True
                        End If
                    End If
                    If l_lov Then
                        CType(e, System.ComponentModel.CancelEventArgs).Cancel = True
                        Me.Lang_lov(sender, l_lookup_ertek, CType(e, System.Windows.Forms.DataGridViewCellValidatingEventArgs).RowIndex)
                    End If
                Else
                    Me.frmForm.entity(0).set_item("LANG", DBNull.Value)
                    Me.frmForm.entity(0).set_item("LANG_NAME", DBNull.Value)
                End If
            End If
        End If

        '----------------------------------------------------------------------------
        'Lefúrás
        '----------------------------------------------------------------------------
        If pEvent = PItemEvent.LinkPressed Then
            If sender.GetType() Is GetType(DataGridView) AndAlso sender.Name = "IFSZ_CRD_EMAILBODY" Then

                'Partner lefúrás
                Try
                    If sender.Columns(CType(e, DataGridViewCellMouseEventArgs).ColumnIndex).GetType.Name = "TextAndImageColumn" _
                               AndAlso CType(e, DataGridViewCellMouseEventArgs).RowIndex >= 0 _
                               AndAlso CType(e, DataGridViewCellMouseEventArgs).ColumnIndex = Me.frmForm.DataGridView2.Columns.Item("DG2_CARDCODE").Index _
                             Then

                        Try
                            Dim l_row As DataRowView = Me.frmForm.DataGridView2.Rows(CType(e, DataGridViewCellMouseEventArgs).RowIndex).DataBoundItem
                            If Not IFSZ_Globals.IsNull(l_row("CARDCODE")) _
                                Then
                                Me.frmForm.m_Interim_SBO.SBOLefur(SAPbouiCOM.BoLinkedObject.lf_BusinessPartner, l_row("CARDCODE"))
                            End If
                        Catch
                        Finally

                        End Try

                    End If
                Catch ex As Exception
                End Try

            End If

        End If

        If pEvent = PItemEvent.UserDeletingRow Then
            If sender.GetType() Is GetType(DataGridView) Then
                If CType(sender, DataGridView).Name = "IFSZ_EMAILOUTBODY" Then
                    Dim l_row As DataRow = Me.frmForm.getSelectedRow("IFSZ_EMAILOUTBODY")
                    If l_row IsNot Nothing AndAlso Not IsDBNull(l_row("ID")) Then
                        Dim l_id As Integer = l_row("ID")
                        If DataProvider.ExecuteScalar("select count(9) from ifsz_crd_emailbody where body = " + l_id.ToString()) > 0 Then
                            Me.frmForm.show_error("Először az összes ehhez a sablonhoz rendelt partnert törölnie kell az alsó blokkból, és aktualizálás után tudja törölni a sablont")
                            CType(e, System.Windows.Forms.DataGridViewRowCancelEventArgs).Cancel = True
                        End If
                    End If
                End If
            End If
        End If

        If pEvent = PItemEvent.UserDeletedRow Then
            If sender.GetType() Is GetType(DataGridView) Then
                Me.frmForm.AddVirtualRows(Me.frmForm.p_dataset.Tables(CType(sender, DataGridView).Name))
            End If
        End If

        If pEvent = PItemEvent.MultiLovSelected Then
            Dim p_row As DataRow
            Dim i As Integer = 0
            If CType(sender, DataSet).Tables.Item(0).TableName = "OCRD" Then
                Try
                    Me.frmForm.Cursor = Cursors.WaitCursor

                    For Each p_row In CType(sender, DataSet).Tables.Item(0).Rows
                        If i = 0 Then
                            Me.frmForm.entity(1).set_item("CARDCODE", p_row.Item("CARDCODE").ToString)
                            Me.frmForm.entity(1).set_item("CARDNAME", p_row.Item("CARDNAME").ToString)
                        Else
                            Me.frmForm.uj_sor(Me.frmForm.DataGridView2)

                            Me.frmForm.entity(1).set_item("CARDCODE", p_row.Item("CARDCODE").ToString)
                            Me.frmForm.entity(1).set_item("CARDNAME", p_row.Item("CARDNAME").ToString)

                        End If
                        i = 1
                    Next

                Catch ex As Exception
                    Me.frmForm.show_error(ex.Message)
                Finally
                    Me.frmForm.Cursor = Cursors.Default
                End Try

            End If

        End If

    End Sub






    '----------------------------------------------------------------------------
    '----------------------------------------------------------------------------
    'ItemEvent vége
    '----------------------------------------------------------------------------
    '----------------------------------------------------------------------------

#Region "Implements IIFSZ_FileDialogResult"

    Public Sub SetFajlNev(ByVal pFajlNev As String) Implements IIFSZ_FileDialogResult.SetFajlNev        plFileDialogOpen = False
        'ExportToCSV(pFajlNev)
    End Sub    Public Sub NemValasztott() Implements IIFSZ_FileDialogResult.NemValasztott        plFileDialogOpen = False    End Sub    Public Sub ShowFileDialog()        Me.plSaveFileDialog.InitialDirectory = IFSZ_Globals.GetMyProc.StartInfo.WorkingDirectory        Me.plSaveFileDialog.DefaultExt = ".csv"        Me.plSaveFileDialog.InitialFileName = "IFSZ_EOB_" + DateTime.Now().ToString("yyyyMMddHHmmss") + ".csv"        Me.plSaveFileDialog.SaveFileDialog(Me, IFSZ_Globals.GetMyProc)    End Sub    Public Function get_view() As Object Implements IFSZ_ICTRL.get_view    End Function








































#End Region
#Region "Private"

    Public Function get_elso_Partner(ByVal p_code As String) As DataRowCollection
        Dim l_query As String
        Dim l_rc As DataRowCollection

        l_query = "select " & IFSZ_Ebiz_Telepit.m_cardcode_select &
                  "where upper(ocrd.""CardCode"") = " & IFSZ_Globals.SQLConstantPrepare(p_code.ToUpper()) & " order by ocrd.""CardCode"""

        l_rc = DataProvider.GetDataRecord(l_query.ToString())
        If l_rc Is Nothing OrElse l_rc.Count = 0 Then
            l_query = "select top 2 " & IFSZ_Ebiz_Telepit.m_cardcode_select &
                  "where upper(ocrd.""CardName"") like " & IFSZ_Globals.SQLConstantPrepare("%" + p_code.ToUpper().Replace("*", "%") + "%") & " " &
                  "order by case when upper(ocrd.""CardName"") = " & IFSZ_Globals.SQLConstantPrepare(p_code.ToUpper()) & " then 1 else 2 end, ocrd.""CardName"""

            Return DataProvider.GetDataRecord(l_query.ToString())
        End If
        Return l_rc

    End Function

    Public Function get_elso_DocType(ByVal p_code As String) As DataRowCollection
        Dim l_query As String

        l_query = "select top 2 code, name from IFSZ_EDOC_TYPES_V " &
                  "where upper(name) like " & IFSZ_Globals.SQLConstantPrepare("%" + p_code.ToUpper().Replace("*", "%") + "%") & " order by case when upper(name) = " & IFSZ_Globals.SQLConstantPrepare(p_code.ToUpper()) & " then 1 else 2 end, name"

        Return DataProvider.GetDataRecord(l_query.ToString())

    End Function

    Public Function get_elso_Lang(ByVal p_code As String) As DataRowCollection
        Dim l_query As String

        l_query = "select top 2 ""Code"", ""Name"" from OLNG " &
                  "where upper(""Name"") like " & IFSZ_Globals.SQLConstantPrepare("%" + p_code.ToUpper().Replace("*", "%") + "%") & " order by case when upper(""Name"") = " & IFSZ_Globals.SQLConstantPrepare(p_code.ToUpper()) & " then 1 else 2 end, ""Name"""

        Return DataProvider.GetDataRecord(l_query.ToString())

    End Function







#Region "LOV"
    Private Sub Partner_lov(ByRef sender As Object, ByVal l_ertek As String, ByVal p_sor As Integer)
        Dim p_oszlop_tipus(5) As LOV_OszlopTipus
        Dim p_form As LOV_Form
        Dim c As IFSZ_PUB_LOV
        Dim l_select As String
        Dim l_where As String

        If l_ertek <> "" Then
            l_where = " and (upper(ocrd.""CardCode"") like " & IFSZ_Globals.SQLConstantPrepare("%" + l_ertek.ToUpper() + "%") & " " &
                      " or upper(ocrd.""CardName"") like " & IFSZ_Globals.SQLConstantPrepare("%" + l_ertek.ToUpper() + "%") & ") "
        End If

        p_oszlop_tipus(0).Title = "Név"
        p_oszlop_tipus(0).DbNev = "CardName"
        p_oszlop_tipus(0).Tipus = "TEXT"
        p_oszlop_tipus(0).Description = "Name"
        p_oszlop_tipus(0).Visible = True
        p_oszlop_tipus(0).Width = 200

        p_oszlop_tipus(1).Title = "Kód"
        p_oszlop_tipus(1).DbNev = "CardCode"
        p_oszlop_tipus(1).VNev = Me.frmForm.DataGridView2.Rows(p_sor).Cells("DG2_CARDCODE")
        p_oszlop_tipus(1).Tipus = "TEXT"
        p_oszlop_tipus(1).Description = ""
        p_oszlop_tipus(1).Visible = True
        p_oszlop_tipus(1).Link = True
        p_oszlop_tipus(1).LinkOsztaly = "IFSZ_AddOnBase.IFSZ_LinkObject"
        p_oszlop_tipus(1).MenuUID = 2561
        p_oszlop_tipus(1).FormUID = "134"

        p_oszlop_tipus(2).Title = "Típus"
        p_oszlop_tipus(2).DbNev = "tipus"
        p_oszlop_tipus(2).Tipus = "TEXT"
        p_oszlop_tipus(2).Description = "Típus"
        p_oszlop_tipus(2).Visible = True
        p_oszlop_tipus(2).Width = 70

        p_oszlop_tipus(3).Title = "Egyenleg"
        p_oszlop_tipus(3).DbNev = "egyenleg"
        p_oszlop_tipus(3).Tipus = "NUMBER"
        p_oszlop_tipus(3).Description = "Egyenleg"
        p_oszlop_tipus(3).Visible = True
        p_oszlop_tipus(3).Width = 70

        p_oszlop_tipus(4).Title = "Cím"
        p_oszlop_tipus(4).DbNev = "cim"
        p_oszlop_tipus(4).Tipus = "TEXT"
        p_oszlop_tipus(4).Description = "Address"
        p_oszlop_tipus(4).Visible = True
        p_oszlop_tipus(4).Width = 220

        p_oszlop_tipus(5).Title = "Szállítási cím"
        p_oszlop_tipus(5).DbNev = "ADDRESS2"
        p_oszlop_tipus(5).Tipus = "TEXT"
        p_oszlop_tipus(5).Description = "Szállítási cím"
        p_oszlop_tipus(5).Visible = True
        p_oszlop_tipus(5).Width = 220


        l_select = "select case ocrd.""CardType"" when 'C' then N'Vevő' when 'S' then N'Szállító' else N'Érdeklődő' end as TIPUS, " & IFSZ_Ebiz_Telepit.m_cardcode_select &
                  "where 1=1 " & l_where & " order by ocrd.""CardName"""

        p_form.Title = "Partnerek"
        p_form.Width = 800
        p_form.Height = 400
        p_form.DefaultScrollIndex = 0
        p_form.SENDER = "OCRD"
        c = New IFSZ_PUB_LOV(Me.frmForm, p_form, p_oszlop_tipus, l_select, , False, True)

    End Sub

    Private Sub DocType_lov(ByRef sender As Object, ByVal l_ertek As String, ByVal p_sor As Integer)
        Dim p_oszlop_tipus(1) As LOV_OszlopTipus
        Dim p_form As LOV_Form
        Dim c As IFSZ_PUB_LOV
        Dim l_select As String
        Dim l_where As String

        If Not String.IsNullOrEmpty(l_ertek) Then
            l_where = " where upper(NAME) like " & IFSZ_Globals.SQLConstantPrepare("%" + l_ertek.ToUpper() + "%") & " "
        End If

        p_oszlop_tipus(0).Title = "Név"
        p_oszlop_tipus(0).DbNev = "NAME"
        p_oszlop_tipus(0).VNev = Me.frmForm.DataGridView1.Rows(p_sor).Cells("DG1_DOCTYPE_NAME")
        p_oszlop_tipus(0).Tipus = "TEXT"
        p_oszlop_tipus(0).Description = "Name"
        p_oszlop_tipus(0).Visible = True
        p_oszlop_tipus(0).Width = 200

        p_oszlop_tipus(1).Title = "Kód"
        p_oszlop_tipus(1).DbNev = "CODE"
        p_oszlop_tipus(1).Tipus = "TEXT"
        p_oszlop_tipus(1).Description = ""
        p_oszlop_tipus(1).Visible = False

        l_select = "select code, name from IFSZ_EDOC_TYPES_V " & l_where & " order by NAME"

        p_form.Title = "Bizonylattípusok"
        p_form.Width = 300
        p_form.Height = 400
        p_form.DefaultScrollIndex = 0
        c = New IFSZ_PUB_LOV(Me.frmForm, p_form, p_oszlop_tipus, l_select, , False)

    End Sub

    Private Sub Lang_lov(ByRef sender As Object, ByVal l_ertek As String, ByVal p_sor As Integer)
        Dim p_oszlop_tipus(1) As LOV_OszlopTipus
        Dim p_form As LOV_Form
        Dim c As IFSZ_PUB_LOV
        Dim l_select As String
        Dim l_where As String

        If Not String.IsNullOrEmpty(l_ertek) Then
            l_where = " where upper(""Name"") like " & IFSZ_Globals.SQLConstantPrepare("%" + l_ertek.ToUpper() + "%") & " "
        End If

        p_oszlop_tipus(0).Title = "Név"
        p_oszlop_tipus(0).DbNev = "NAME"
        p_oszlop_tipus(0).VNev = Me.frmForm.DataGridView1.Rows(p_sor).Cells("DG1_LANG_NAME")
        p_oszlop_tipus(0).Tipus = "TEXT"
        p_oszlop_tipus(0).Description = "Name"
        p_oszlop_tipus(0).Visible = True
        p_oszlop_tipus(0).Width = 200

        p_oszlop_tipus(1).Title = "Kód"
        p_oszlop_tipus(1).DbNev = "CODE"
        p_oszlop_tipus(1).Tipus = "TEXT"
        p_oszlop_tipus(1).Description = ""
        p_oszlop_tipus(1).Visible = False

        l_select = "select ""Code"", ""Name"" from olng " & l_where & " order by ""Name"""

        p_form.Title = "Bizonylattípusok"
        p_form.Width = 300
        p_form.Height = 400
        p_form.DefaultScrollIndex = 0
        c = New IFSZ_PUB_LOV(Me.frmForm, p_form, p_oszlop_tipus, l_select, , False)

    End Sub




























#End Region
#End Region
#Region "Public"

#End Region
    Public Function Accept(ByVal pAcceptEvent As IFSZ_Types.PAcceptEvent, ByVal pOperationType As IFSZ_Types.DMLOperation, ByVal sender As Object) As Object Implements IFSZ_ICTRL.Accept    End FunctionEnd Class