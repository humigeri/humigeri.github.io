﻿'----------------------------------------------------------------------------'
'Generálva: 2020.03.22
'FormViewGenerator. Verzió: 1.0.7.0
'----------------------------------------------------------------------------'

Imports IFSZ_AddOnBase.IFSZ_Types
Imports System
Imports System.IO
Imports System.Text

Public Class IFSZ_EOHLIS_Ctrl
    Implements IFSZ_ICTRL
    Implements IIFSZ_FileDialogResult

    Public Sub New()

    End Sub

    Public Sub New(ByRef frmMain As Object)
        frmForm = frmMain
        plSaveFileDialog = New IFSZ_FileDialog()
        Me.m_frmView = New IFSZ_EOHLIS_View()
    End Sub

    Private frmForm As IFSZ_DNET_EOHLIS
    Private plFileDialogOpen As Boolean = False
    Private plSaveFileDialog As IFSZ_FileDialog
    Private m_frmView As IFSZ_EOHLIS_View

    Public Sub Form_Event(ByVal pEvent As String, ByVal sender As Object, ByVal e As System.EventArgs) Implements IFSZ_ICTRL.Form_Event
        Dim p_relation As IFSZ_Types.Relations = New IFSZ_Types.Relations
        If pEvent = "PreForm" Then

        ElseIf pEvent = "FormLoad" Then

            Me.frmForm.entity(0).NewRowEnabled = False

            Me.frmForm.p_dataset = m_frmView.getDataSet
            Me.frmForm.DataGridView1.DataSource = Me.frmForm.p_dataset
            Me.frmForm.DataGridView1.Name = "IFSZ_EMAILOUTHEAD"
            Me.frmForm.DataGridView1.DataMember = "IFSZ_EMAILOUTHEAD"

        ElseIf pEvent = "AfterFormLoad" Then
            If CType(Me.frmForm.m_Interim_SBO, IFSZ_EOHLIS).m_docentry > -1 Then
                Me.frmForm.entity(0).DefaultWhere = " STATUS <> 'C' AND ID IN (SELECT EOH_ID FROM IFSZ_EMAILOUTLINE WHERE DOCTYPE = " & IFSZ_Globals.SQLConstantPrepare(CType(Me.frmForm.m_Interim_SBO, IFSZ_EOHLIS).m_doctype) & " AND DOCENTRY = " & IFSZ_Globals.SQLConstantPrepare(CType(Me.frmForm.m_Interim_SBO, IFSZ_EOHLIS).m_docentry) & ")"
            End If
            Me.frmForm.BlockRefresh("IFSZ_EMAILOUTHEAD")

        End If
    End Sub

    Public Function get_DataTable(ByVal p_TableName As String, Optional ByVal p_tipus As String = "", Optional ByVal sender As Object = Nothing, Optional ByVal p_where As String = "") As System.Data.DataTable Implements IFSZ_ICTRL.get_DataTable
        Dim p_SqlQuery As String
        'Dim frm_view As IFSZ_EgyszBeszerTerv_View = New IFSZ_EgyszBeszerTerv_View()
        Dim i, j, p_pk_num As Integer
        'Dim p_relation As IFSZ_Types.Relations
        Dim p_table As IFSZ_Types.RelationTable
        'Dim p_pk_id, p_fk_id As String
        Dim l_datatable As DataTable
        Dim l_row As DataRow

        Select Case p_tipus
            Case "MASTER/DETAIL"
                For i = 0 To frmForm.entity.GetUpperBound(0)
                    If frmForm.entity(i).TableName = sender.current.row.table.tablename() Then
                        For Each p_table In frmForm.entity(i).ChildRelation.Tables
                            If p_table.Table = p_TableName Then
                                For p_pk_num = 0 To p_table.PK_Columns.GetUpperBound(0)
                                    If p_pk_num = 0 Then
                                        p_SqlQuery = Me.m_frmView.getSqlQuery(p_TableName, p_tipus) & "where " & p_table.FK_Columns(p_pk_num) & " = " & sender.current.row(p_table.PK_Columns(p_pk_num))
                                    Else
                                        p_SqlQuery = Me.m_frmView.getSqlQuery(p_TableName, p_tipus) & " and " & p_table.FK_Columns(p_pk_num) & " = " & sender.current.row(p_table.PK_Columns(p_pk_num))
                                    End If
                                Next
                                For j = 0 To frmForm.entity.GetUpperBound(0)
                                    If frmForm.entity(j).TableName = p_TableName Then
                                        frmForm.entity(j).ChildWhere = p_SqlQuery.Substring(p_SqlQuery.ToUpper.IndexOf("WHERE") + 5, p_SqlQuery.Length - p_SqlQuery.ToUpper.IndexOf("WHERE") - 5).Trim
                                        If frmForm.entity(j).DefaultWhere <> "" Then
                                            p_SqlQuery = p_SqlQuery & " and " & frmForm.entity(j).DefaultWhere
                                            'p_SqlQuery = p_SqlQuery & " and " & frmForm.entity(i).DefaultWhere
                                        End If
                                        'frmForm.entity(j).ChildWhere = p_SqlQuery.Substring(p_SqlQuery.ToUpper.IndexOf("WHERE") + 5, p_SqlQuery.Length - p_SqlQuery.ToUpper.IndexOf("WHERE") - 5).Trim
                                    End If
                                Next
                            End If
                        Next
                    End If

                    'If frmForm.entity(i).TableName = p_TableName Then
                    '    p_SqlQuery = frm_view.getSqlQuery(p_TableName, p_tipus) & sender.current.row("ID")
                    '    frmForm.entity(i).ChildWhere = p_SqlQuery.Substring(p_SqlQuery.ToUpper.IndexOf("WHERE") + 5, p_SqlQuery.Length - p_SqlQuery.ToUpper.IndexOf("WHERE") - 5).Trim
                    'End If
                    'frmForm.entity(i).ChildWhere = p_SqlQuery.Substring(p_SqlQuery.ToUpper.IndexOf("WHERE") + 5, p_SqlQuery.Length - p_SqlQuery.ToUpper.IndexOf("WHERE") - 5).Trim
                Next
                l_datatable = DataProvider.GetDataTable(p_SqlQuery)
                Return l_datatable
            Case "TABLE"
                p_SqlQuery = Me.m_frmView.getSqlQuery(p_TableName, p_tipus)
                If p_where = "" Then
                    p_where = "1=1"
                Else
                    p_where = p_where.Replace("'False'", "'N'").Replace("'True'", "'Y'")
                End If
                For i = 0 To frmForm.entity.GetUpperBound(0)
                    If frmForm.entity(i).TableName = p_TableName And frmForm.entity(i).DefaultWhere <> "" Then
                        p_where = p_where & " and " & frmForm.entity(i).DefaultWhere
                        If frmForm.entity(i).ChildWhere <> "" Then
                            p_where = p_where & " and " & frmForm.entity(i).ChildWhere
                        End If
                    ElseIf frmForm.entity(i).TableName = p_TableName And frmForm.entity(i).ChildWhere <> "" Then
                        p_where = p_where & " and " & frmForm.entity(i).ChildWhere
                    End If
                Next
                p_SqlQuery = p_SqlQuery & " where " & p_where
                If p_TableName = "IFSZ_EMAILOUTHEAD" Then
                    p_SqlQuery += " order by id desc"
                End If
                l_datatable = DataProvider.GetDataTable(p_SqlQuery)
                Return l_datatable
            Case Else
                l_datatable = DataProvider.GetDataTable(p_SqlQuery)
                Return l_datatable
        End Select

    End Function

    '----------------------------------------------------------------------------
    '----------------------------------------------------------------------------
    'Item_Event
    '----------------------------------------------------------------------------
    '----------------------------------------------------------------------------
    Public Sub Item_Event(ByVal pEvent As IFSZ_Types.PItemEvent, ByVal sender As Object, ByVal e As System.EventArgs) Implements IFSZ_ICTRL.Item_Event
        '----------------------------------------------------------------------------
        'Lefúrás
        '----------------------------------------------------------------------------
        If pEvent = PItemEvent.LinkPressed Then
            If sender.GetType() Is GetType(DataGridView) AndAlso sender.Name = "IFSZ_EMAILOUTHEAD" Then

                'Bizonylat lefúrás
                Try
                    If sender.Columns(CType(e, DataGridViewCellMouseEventArgs).ColumnIndex).GetType.Name = "TextAndImageColumn" _
                               AndAlso CType(e, DataGridViewCellMouseEventArgs).RowIndex >= 0 _
                               AndAlso CType(e, DataGridViewCellMouseEventArgs).ColumnIndex = Me.frmForm.DataGridView1.Columns.Item("DG1_DOCNUM").Index _
                             Then

                        Try
                            If Not IFSZ_Globals.IsNull(Me.frmForm.p_dataset.Tables(0).Rows(CType(e, DataGridViewCellMouseEventArgs).RowIndex)("ID")) _
                                Then
                                Dim l_form As New IFSZ_EOH(Me.frmForm.m_ParentAddon, "F_EOH", Me.frmForm.p_dataset.Tables(0).Rows(CType(e, DataGridViewCellMouseEventArgs).RowIndex)("ID"))
                                If Not l_form Is Nothing Then
                                    Me.frmForm.m_ParentAddon.SBOForms.Add(l_form, l_form.UniqueID)
                                End If
                            End If
                        Catch
                        Finally

                        End Try

                    End If
                Catch ex As Exception
                End Try

                'Fájl
                Try
                    If sender.Columns(CType(e, DataGridViewCellMouseEventArgs).ColumnIndex).GetType.Name = "TextAndImageColumn" _
                               AndAlso CType(e, DataGridViewCellMouseEventArgs).RowIndex >= 0 _
                               AndAlso CType(e, DataGridViewCellMouseEventArgs).ColumnIndex = Me.frmForm.DataGridView1.Columns.Item("DG1_PATH").Index _
                             Then

                        Try
                            If Not IFSZ_Globals.IsNull(Me.frmForm.p_dataset.Tables(0).Rows(CType(e, DataGridViewCellMouseEventArgs).RowIndex)("PATH")) _
                                Then
                                Dim l_proc As System.Diagnostics.Process = System.Diagnostics.Process.Start(Me.frmForm.p_dataset.Tables(0).Rows(CType(e, DataGridViewCellMouseEventArgs).RowIndex)("PATH"))
                                If l_proc IsNot Nothing Then
                                    Win32Helper.SetForegroundWindow(l_proc.MainWindowHandle())
                                End If
                            End If
                        Catch
                        Finally

                        End Try

                    End If
                Catch ex As Exception
                End Try

            End If

        End If

        If PItemEvent.BeforQueryEnter Then
            'Fejnél enter query:
            'Nem akarom, hogy rákérdezzen
            If Me.frmForm.p_dataset.HasChanges() Then
                Me.frmForm.p_dataset.RejectChanges()
            End If
        End If

    End Sub

    '----------------------------------------------------------------------------
    '----------------------------------------------------------------------------
    'ItemEvent vége
    '----------------------------------------------------------------------------
    '----------------------------------------------------------------------------

#Region "Implements IIFSZ_FileDialogResult"


    Public Sub SetFajlNev(ByVal pFajlNev As String) Implements IIFSZ_FileDialogResult.SetFajlNev
        plFileDialogOpen = False
        'ExportToCSV(pFajlNev)
    End Sub

    Public Sub NemValasztott() Implements IIFSZ_FileDialogResult.NemValasztott
        plFileDialogOpen = False
    End Sub

    Public Sub ShowFileDialog()

        Me.plSaveFileDialog.InitialDirectory = IFSZ_Globals.GetMyProc.StartInfo.WorkingDirectory
        Me.plSaveFileDialog.DefaultExt = ".csv"
        Me.plSaveFileDialog.InitialFileName = "IFSZ_EOHLIS_" + DateTime.Now().ToString("yyyyMMddHHmmss") + ".csv"

        Me.plSaveFileDialog.SaveFileDialog(Me, IFSZ_Globals.GetMyProc)

    End Sub


    Public Function get_view() As Object Implements IFSZ_ICTRL.get_view

    End Function

#End Region

#Region "Private"

#End Region

#Region "Public"

    Public Function Accept(ByVal pAcceptEvent As IFSZ_Types.PAcceptEvent, ByVal pOperationType As IFSZ_Types.DMLOperation, ByVal sender As Object) As Object Implements IFSZ_ICTRL.Accept

    End Function

#End Region

End Class

