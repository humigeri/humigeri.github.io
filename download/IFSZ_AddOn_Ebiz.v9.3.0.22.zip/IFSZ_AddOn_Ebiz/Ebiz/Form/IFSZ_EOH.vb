﻿'----------------------------------------------------------------------------'
'Generálva: 2020.03.22
'FormViewGenerator. Verzió: 1.0.7.0
'----------------------------------------------------------------------------'

Option Explicit On
Imports IFSZ_AddOnBase

Public Class IFSZ_EOH
    'Inherits IFSZ_Interim_SBO
    Inherits IFSZ_InterimBridge_SBO

    Public m_eoh_id As Integer = -1

    Public Sub New(
        ByRef ParentAddon As SBOAddOn,
        ByVal FunctionCode As String
    )
        MyBase.New(ParentAddon, FunctionCode)
        p_ParentAddon = ParentAddon
    End Sub
    Public Sub New(
        ByRef ParentAddon As SBOAddOn,
        ByVal FunctionCode As String,
        ByVal p_eoh_id As Integer
    )
        MyBase.New(ParentAddon, FunctionCode)
        p_ParentAddon = ParentAddon
        m_eoh_id = p_eoh_id
    End Sub
    Public Overrides Sub ConstructForm()
        oForm = New IFSZ_DNET_EOH(Me.p_ParentAddon, Me)
    End Sub
    Public Overrides Sub FORMEVENT(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        If pVal.Before_Action = False Then
        Else
            If pVal.EventType = SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE Then
                If oForm.Visible Then
                    BubbleEvent = False
                End If
            ElseIf pVal.EventType = SAPbouiCOM.BoEventTypes.et_CLICK Then
                oForm.Visible = False
            End If
        End If
    End Sub
    'Public Overrides Sub HANDLE_MENU_EVENTS(ByRef pVal As SAPbouiCOM.MenuEvent, ByRef BubbleEvent As Boolean)
    '    Dim i As Integer
    '    i = 0
    'End Sub
    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub
    Public Overrides Sub FormClose()
        If oForm IsNot Nothing Then
            CType(oForm.controller, IFSZ_EOH_Ctrl).m_abort = True
        End If
        MyBase.FormClose()
    End Sub
End Class
