﻿'----------------------------------------------------------------------------''Generálva: 2008.09.01'FormViewGenerator. Verzió: 1.0.4.0'----------------------------------------------------------------------------'Public Class IFSZ_EOB_View    Inherits ObjectDataBinding.BaseClasses.FSBindingItem

#Region "Variables"

    Private p_ID As Integer
    Private p_DOCTYPE As String
    Private p_DOCTYPE_NAME As String
    Private p_SUBJECT As String
    Private p_BODY As String
    Private p_NAME As String
    Private p_LANG As String
    Private p_LANG_NAME As String
    Private p_DEFAULTEMAIL As String
    Private p_DEFAULTEMAIL_LANGVAL As String
    Private p_DEFAULTEMAIL_MEAN As String
    Private p_CARDCODE As String
    Private p_CARDNAME As String
    Private p_ISHTML As String
    Private p_ISHTML_LANGVAL As String
    Private p_ISHTML_MEAN As String

#End Region


#Region "Constructor"

    Public Sub New()

    End Sub

#End Region

#Region "Property"

    Public Property ID() As Integer
        Get
            Return p_ID
        End Get
        Set(ByVal value As Integer)
            p_ID = value
        End Set
    End Property

    Public Property DOCTYPE() As String
        Get
            Return p_DOCTYPE
        End Get
        Set(ByVal value As String)
            p_DOCTYPE = value
        End Set
    End Property

    Public Property DOCTYPE_NAME() As String
        Get
            Return p_DOCTYPE_NAME
        End Get
        Set(ByVal value As String)
            p_DOCTYPE_NAME = value
        End Set
    End Property

    Public Property SUBJECT() As String
        Get
            Return p_SUBJECT
        End Get
        Set(ByVal value As String)
            p_SUBJECT = value
        End Set
    End Property

    Public Property BODY() As String
        Get
            Return p_BODY
        End Get
        Set(ByVal value As String)
            p_BODY = value
        End Set
    End Property

    Public Property NAME() As String
        Get
            Return p_NAME
        End Get
        Set(ByVal value As String)
            p_NAME = value
        End Set
    End Property

    Public Property LANG_NAME() As String
        Get
            Return p_LANG_NAME
        End Get
        Set(ByVal value As String)
            p_LANG_NAME = value
        End Set
    End Property

    Public Property LANG() As String
        Get
            Return p_LANG
        End Get
        Set(ByVal value As String)
            p_LANG = value
        End Set
    End Property

    Public Property DEFAULTEMAIL() As String
        Get
            Return p_DEFAULTEMAIL
        End Get
        Set(ByVal value As String)
            p_DEFAULTEMAIL = value
        End Set
    End Property

    Public Property DEFAULTEMAIL_LANGVAL() As String
        Get
            Return p_DEFAULTEMAIL_LANGVAL
        End Get
        Set(ByVal value As String)
            p_DEFAULTEMAIL_LANGVAL = value
        End Set
    End Property

    Public Property DEFAULTEMAIL_MEAN() As String
        Get
            Return p_DEFAULTEMAIL_MEAN
        End Get
        Set(ByVal value As String)
            p_DEFAULTEMAIL_MEAN = value
        End Set
    End Property

    Public Property CARDCODE() As String
        Get
            Return p_CARDCODE
        End Get
        Set(ByVal value As String)
            p_CARDCODE = value
        End Set
    End Property

    Public Property CARDNAME() As String
        Get
            Return p_CARDNAME
        End Get
        Set(ByVal value As String)
            p_CARDNAME = value
        End Set
    End Property

    Public Property ISHTML() As String
        Get
            Return p_ISHTML
        End Get
        Set(ByVal value As String)
            p_ISHTML = value
        End Set
    End Property

    Public Property ISHTML_LANGVAL() As String
        Get
            Return p_ISHTML_LANGVAL
        End Get
        Set(ByVal value As String)
            p_ISHTML_LANGVAL = value
        End Set
    End Property

    Public Property ISHTML_MEAN() As String
        Get
            Return p_ISHTML_MEAN
        End Get
        Set(ByVal value As String)
            p_ISHTML_MEAN = value
        End Set
    End Property

#End Region

    Public Function getDataSet() As DataSet
        Dim sqlQuery As String = ""
        Dim dataSet As DataSet = New DataSet

        Try

            sqlQuery = sqlQuery & "select ID, DOCTYPE, DOCTYPE_NAME, SUBJECT, BODY, NAME, LANG, LANG_NAME, DEFAULTEMAIL, DEFAULTEMAIL_LANGVAL, DEFAULTEMAIL_MEAN, ISHTML, ISHTML_LANGVAL, ISHTML_MEAN from IFSZ_F_EOB_EOB_V; "
            sqlQuery = sqlQuery & "select ID, CARDCODE, CARDNAME, BODY from IFSZ_F_EOB_CRD_V where 1=2 "


            ' Get a data set from the query
            dataSet = DataProvider.GetDataSet(sqlQuery.ToString())


            ' Create variables for data set tables
            Dim t0 As DataTable = dataSet.Tables(0)
            t0.TableName = "IFSZ_EMAILOUTBODY"
            dataSet.Tables(0).TableName = "IFSZ_EMAILOUTBODY"
            Dim t1 As DataTable = dataSet.Tables(1)
            t1.TableName = "IFSZ_CRD_EMAILBODY"
            dataSet.Tables(1).TableName = "IFSZ_CRD_EMAILBODY"


            Return dataSet

        Finally
            If (Not dataSet Is Nothing) Then
                'System.Runtime.InteropServices.Marshal.ReleaseComObject(dataSet)
                dataSet.Dispose()
            End If

        End Try
    End Function

    Public Function getSqlQuery(ByVal p_table As String, Optional ByVal p_tipus As String = "") As String
        Select Case p_table
            Case "IFSZ_EMAILOUTBODY"
                Select Case p_tipus
                    Case "MASTER/DETAIL"
                        Return "select ID, DOCTYPE, DOCTYPE_NAME, SUBJECT, BODY, NAME, LANG, LANG_NAME, DEFAULTEMAIL, DEFAULTEMAIL_LANGVAL, DEFAULTEMAIL_MEAN, ISHTML, ISHTML_LANGVAL, ISHTML_MEAN from IFSZ_F_EOB_EOB_V "
                    Case "TABLE"
                        Return "select ID, DOCTYPE, DOCTYPE_NAME, SUBJECT, BODY, NAME, LANG, LANG_NAME, DEFAULTEMAIL, DEFAULTEMAIL_LANGVAL, DEFAULTEMAIL_MEAN, ISHTML, ISHTML_LANGVAL, ISHTML_MEAN from IFSZ_F_EOB_EOB_V "
                    Case Else
                        Return "select ID, DOCTYPE, DOCTYPE_NAME, SUBJECT, BODY, NAME, LANG, LANG_NAME, DEFAULTEMAIL, DEFAULTEMAIL_LANGVAL, DEFAULTEMAIL_MEAN, ISHTML, ISHTML_LANGVAL, ISHTML_MEAN from IFSZ_F_EOB_EOB_V "
                End Select
            Case "IFSZ_CRD_EMAILBODY"
                Select Case p_tipus
                    Case "MASTER/DETAIL"
                        Return "select ID, CARDCODE, CARDNAME, BODY from IFSZ_F_EOB_CRD_V "
                    Case "TABLE"
                        Return "select ID, CARDCODE, CARDNAME, BODY from IFSZ_F_EOB_CRD_V "
                    Case Else
                        Return "select ID, CARDCODE, CARDNAME, BODY from IFSZ_F_EOB_CRD_V "
                End Select
            Case Else
                Return ""
        End Select
    End Function

End Class
