﻿'----------------------------------------------------------------------------'
'Generálva: 2019.08.08
'FormViewGenerator. Verzió: 1.0.7.0
'----------------------------------------------------------------------------'

Public Class IFSZ_SZLAKIV_View
    Inherits ObjectDataBinding.BaseClasses.FSBindingItem

#Region "Variables"

    Private p_ID As Integer
    Private p_DOCENTRY As String
    Private p_OBJTYPE As String
    Private p_DOCTYPE_NAME As String
    Private p_DOCNUM As String
    Private p_DOCDATE As String
    Private p_CARDCODE As String
    Private p_CARDNAME As String
    Private p_BIZOSSZ As String
    Private p_USERID As String
    Private p_USERNAME As String
    Private p_ABSENTRY As String
    Private p_MANBTCHNUM As String
    Private p_MANSERNUM As String
    Private p_BT_DISTNUMBER As String
    Private p_SR_DISTNUMBER As String
    Private p_MENNYISEG As String
    Private p_ERV_KEZD As String
    Private p_JELOL As String
    Private p_KESZLET As String

#End Region


#Region "Constructor"

    Public Sub New()

    End Sub

#End Region

#Region "Property"

    Public Property ID() As Integer
        Get
            Return p_ID
        End Get
        Set(ByVal value As Integer)
            p_ID = value
        End Set
    End Property

    Public Property DOCENTRY() As String
        Get
            Return p_DOCENTRY
        End Get
        Set(ByVal value As String)
            p_DOCENTRY = value
        End Set
    End Property

    Public Property OBJTYPE() As String
        Get
            Return p_OBJTYPE
        End Get
        Set(ByVal value As String)
            p_OBJTYPE = value
        End Set
    End Property

    Public Property DOCTYPE_NAME() As String
        Get
            Return p_DOCTYPE_NAME
        End Get
        Set(ByVal value As String)
            p_DOCTYPE_NAME = value
        End Set
    End Property

    Public Property DOCNUM() As String
        Get
            Return p_DOCNUM
        End Get
        Set(ByVal value As String)
            p_DOCNUM = value
        End Set
    End Property

    Public Property DOCDATE() As String
        Get
            Return p_DOCDATE
        End Get
        Set(ByVal value As String)
            p_DOCDATE = value
        End Set
    End Property

    Public Property CARDCODE() As String
        Get
            Return p_CARDCODE
        End Get
        Set(ByVal value As String)
            p_CARDCODE = value
        End Set
    End Property

    Public Property CARDNAME() As String
        Get
            Return p_CARDNAME
        End Get
        Set(ByVal value As String)
            p_CARDNAME = value
        End Set
    End Property

    Public Property BIZOSSZ() As String
        Get
            Return p_BIZOSSZ
        End Get
        Set(ByVal value As String)
            p_BIZOSSZ = value
        End Set
    End Property

    Public Property USERID() As String
        Get
            Return p_USERID
        End Get
        Set(ByVal value As String)
            p_USERID = value
        End Set
    End Property

    Public Property USERNAME() As String
        Get
            Return p_USERNAME
        End Get
        Set(ByVal value As String)
            p_USERNAME = value
        End Set
    End Property

    Public Property ABSENTRY() As String
        Get
            Return p_ABSENTRY
        End Get
        Set(ByVal value As String)
            p_ABSENTRY = value
        End Set
    End Property

    Public Property MANBTCHNUM() As String
        Get
            Return p_MANBTCHNUM
        End Get
        Set(ByVal value As String)
            p_MANBTCHNUM = value
        End Set
    End Property

    Public Property MANSERNUM() As String
        Get
            Return p_MANSERNUM
        End Get
        Set(ByVal value As String)
            p_MANSERNUM = value
        End Set
    End Property

    Public Property BT_DISTNUMBER() As String
        Get
            Return p_BT_DISTNUMBER
        End Get
        Set(ByVal value As String)
            p_BT_DISTNUMBER = value
        End Set
    End Property

    Public Property SR_DISTNUMBER() As String
        Get
            Return p_SR_DISTNUMBER
        End Get
        Set(ByVal value As String)
            p_SR_DISTNUMBER = value
        End Set
    End Property

    Public Property MENNYISEG() As String
        Get
            Return p_MENNYISEG
        End Get
        Set(ByVal value As String)
            p_MENNYISEG = value
        End Set
    End Property

    Public Property ERV_KEZD() As String
        Get
            Return p_ERV_KEZD
        End Get
        Set(ByVal value As String)
            p_ERV_KEZD = value
        End Set
    End Property

    Public Property JELOL() As String
        Get
            Return p_JELOL
        End Get
        Set(ByVal value As String)
            p_JELOL = value
        End Set
    End Property

    Public Property KESZLET() As String
        Get
            Return p_KESZLET
        End Get
        Set(ByVal value As String)
            p_KESZLET = value
        End Set
    End Property

#End Region

    Public Function getDataSet() As DataSet
        Dim sqlQuery As String = ""
        Dim dataSet As DataSet = New DataSet

        Try

            'sqlQuery = sqlQuery & "select ID, DOCENTRY, OBJTYPE, DOCTYPE_NAME, DOCNUM, DOCDATE, CARDCODE, CARDNAME, BIZOSSZ, USERID, USERNAME, JELOLN, PRINTEDVAL, PRINTED, MAIL_SUBJECT, MAIL_BODY, ISHTML, SABLON_ID, TAXDATE, VATDATE, DOCDUEDATE, CREATEDATE, SENDSTATUS, SENDSTATUSVAL from IFSZ_EDOC_SZLAKIV_TF(null, null, null, null) "
            sqlQuery = sqlQuery & "select * from IFSZ_EDOC_SZLAKIV_TF(null, null, null, null, null) "


            ' Get a data set from the query
            dataSet = DataProvider.GetDataSet(sqlQuery.ToString())


            ' Create variables for data set tables
            Dim SZLAKIVTable As DataTable = dataSet.Tables(0)
            SZLAKIVTable.TableName = "SZLAKIV"
            dataSet.Tables(0).TableName = "SZLAKIV"

            Return dataSet

        Finally
            If (Not dataSet Is Nothing) Then
                'System.Runtime.InteropServices.Marshal.ReleaseComObject(dataSet)
                dataSet.Dispose()
            End If

        End Try
    End Function

    Public Function getSqlQuery(ByVal p_table As String, Optional ByVal p_tipus As String = "") As String
        Return ""
    End Function

    Public Function getListaTab(ByVal p_datumszur As String, ByVal p_datumtol As DateTime, ByVal p_datumig As DateTime, ByVal p_eoh_id As Integer) As DataTable
        Dim l_sql As String
        Dim l_tab As DataTable
        Dim l_datumtols, l_datumigs As String

        If p_datumtol = IFSZ_Globals.NullDate() Then
            l_datumtols = "null"
        Else
            l_datumtols = IFSZ_Globals.SQLConstantPrepare(p_datumtol)
        End If
        If p_datumig = IFSZ_Globals.NullDate() Then
            l_datumigs = "null"
        Else
            l_datumigs = IFSZ_Globals.SQLConstantPrepare(p_datumig)
        End If

        'l_sql = "select ID, DOCENTRY, OBJTYPE, DOCTYPE_NAME, DOCNUM, DOCDATE, CARDCODE, CARDNAME, BIZOSSZ, USERID, USERNAME, JELOLN, PRINTEDVAL, PRINTED, MAIL_SUBJECT, MAIL_BODY, ISHTML, SABLON_ID, TAXDATE, VATDATE, DOCDUEDATE, CREATEDATE, SENDSTATUS, SENDSTATUSVAL from IFSZ_EDOC_SZLAKIV_TF(" + IFSZ_Globals.SQLConstantPrepare(p_datumszur) + ", " + l_datumtols + ", " + l_datumigs + ", " + p_eoh_id.ToString() + ")"
        l_sql = "select * from IFSZ_EDOC_SZLAKIV_TF(" + IFSZ_Globals.SQLConstantPrepare(p_datumszur) + ", " + l_datumtols + ", " + l_datumigs + ", " + p_eoh_id.ToString() + ", " + IFSZ_Globals.GetUserID.ToString() + ")"

        l_tab = DataProvider.EGetDataTable(l_sql)
        Return l_tab
    End Function

End Class
