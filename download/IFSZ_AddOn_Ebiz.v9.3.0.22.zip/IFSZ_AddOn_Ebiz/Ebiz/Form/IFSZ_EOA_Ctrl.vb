﻿'----------------------------------------------------------------------------'
'Generálva: 2020.03.22
'FormViewGenerator. Verzió: 1.0.7.0
'----------------------------------------------------------------------------'

Imports IFSZ_AddOnBase.IFSZ_Types
Imports System
Imports System.IO
Imports System.Text

Public Class IFSZ_EOA_Ctrl
    Implements IFSZ_ICTRL
    Implements IIFSZ_FileDialogResult

    Public Sub New()

    End Sub

    Public Sub New(ByRef frmMain As Object)
        frmForm = frmMain
        plSaveFileDialog = New IFSZ_FileDialog()
        Me.m_frmView = New IFSZ_EOA_View()
    End Sub

    Private frmForm As IFSZ_DNET_EOA
    Private plFileDialogOpen As Boolean = False
    Private plSaveFileDialog As IFSZ_FileDialog
    Private m_frmView As IFSZ_EOA_View

    Public Sub Form_Event(ByVal pEvent As String, ByVal sender As Object, ByVal e As System.EventArgs) Implements IFSZ_ICTRL.Form_Event
        Dim i As Integer
        Dim l_datarowcollection As DataRowCollection

        If pEvent = "FormLoad" Then

            Me.frmForm.entity(0).NewRowEnabled = True

            Me.frmForm.p_dataset = m_frmView.getDataSet

            Me.frmForm.DataGridView1.DataSource = Me.frmForm.p_dataset
            Me.frmForm.DataGridView1.Name = "IFSZ_EMAILACCOUNTS"
            Me.frmForm.DataGridView1.DataMember = "IFSZ_EMAILACCOUNTS"

        ElseIf pEvent = "PostCommit" Then

            Try
                Dim l_tab As DataTable = DataProvider.EGetDataTable(m_frmView.getSqlQuery("IFSZ_EMAILACCOUNTS", "TABLE"))
                Dim l_view As New DataView(l_tab, "", "ID", DataViewRowState.CurrentRows)
                Dim l_pos As Integer = -1
                For Each l_row As DataRow In Me.frmForm.p_dataset.Tables("IFSZ_EMAILACCOUNTS").Rows
                    If Not IsDBNull(l_row("ID")) Then
                        l_pos = l_view.Find(l_row("ID"))
                        If l_pos > -1 Then
                            For Each l_col As DataColumn In l_tab.Columns
                                If Not l_col.ColumnName.EndsWith("_LANGVAL") AndAlso Not l_col.ColumnName.EndsWith("_MEAN") Then
                                    l_row(l_col.ColumnName) = l_view(l_pos)(l_col.ColumnName)
                                End If
                            Next
                        End If
                    End If
                    l_row.AcceptChanges()
                Next
            Catch ex As Exception
                Me.frmForm.show_error("Hiba történt a fej adatok visszaolvasása során. " + ex.Message())
            End Try

        End If
    End Sub

    Public Function get_DataTable(ByVal p_TableName As String, Optional ByVal p_tipus As String = "", Optional ByVal sender As Object = Nothing, Optional ByVal p_where As String = "") As System.Data.DataTable Implements IFSZ_ICTRL.get_DataTable
        Dim p_SqlQuery As String
        'Dim frm_view As IFSZ_EgyszBeszerTerv_View = New IFSZ_EgyszBeszerTerv_View()
        Dim i, j, p_pk_num As Integer
        'Dim p_relation As IFSZ_Types.Relations
        Dim p_table As IFSZ_Types.RelationTable
        'Dim p_pk_id, p_fk_id As String
        Dim l_datatable As DataTable
        Dim l_row As DataRow

        Select Case p_tipus
            Case "MASTER/DETAIL"
                For i = 0 To frmForm.entity.GetUpperBound(0)
                    If frmForm.entity(i).TableName = sender.current.row.table.tablename() Then
                        For Each p_table In frmForm.entity(i).ChildRelation.Tables
                            If p_table.Table = p_TableName Then
                                For p_pk_num = 0 To p_table.PK_Columns.GetUpperBound(0)
                                    If p_pk_num = 0 Then
                                        p_SqlQuery = Me.m_frmView.getSqlQuery(p_TableName, p_tipus) & "where " & p_table.FK_Columns(p_pk_num) & " = " & sender.current.row(p_table.PK_Columns(p_pk_num))
                                    Else
                                        p_SqlQuery = Me.m_frmView.getSqlQuery(p_TableName, p_tipus) & " and " & p_table.FK_Columns(p_pk_num) & " = " & sender.current.row(p_table.PK_Columns(p_pk_num))
                                    End If
                                Next
                                For j = 0 To frmForm.entity.GetUpperBound(0)
                                    If frmForm.entity(j).TableName = p_TableName Then
                                        frmForm.entity(j).ChildWhere = p_SqlQuery.Substring(p_SqlQuery.ToUpper.IndexOf("WHERE") + 5, p_SqlQuery.Length - p_SqlQuery.ToUpper.IndexOf("WHERE") - 5).Trim
                                        If frmForm.entity(j).DefaultWhere <> "" Then
                                            p_SqlQuery = p_SqlQuery & " and " & frmForm.entity(j).DefaultWhere
                                            'p_SqlQuery = p_SqlQuery & " and " & frmForm.entity(i).DefaultWhere
                                        End If
                                        'frmForm.entity(j).ChildWhere = p_SqlQuery.Substring(p_SqlQuery.ToUpper.IndexOf("WHERE") + 5, p_SqlQuery.Length - p_SqlQuery.ToUpper.IndexOf("WHERE") - 5).Trim
                                    End If
                                Next
                            End If
                        Next
                    End If

                    'If frmForm.entity(i).TableName = p_TableName Then
                    '    p_SqlQuery = frm_view.getSqlQuery(p_TableName, p_tipus) & sender.current.row("ID")
                    '    frmForm.entity(i).ChildWhere = p_SqlQuery.Substring(p_SqlQuery.ToUpper.IndexOf("WHERE") + 5, p_SqlQuery.Length - p_SqlQuery.ToUpper.IndexOf("WHERE") - 5).Trim
                    'End If
                    'frmForm.entity(i).ChildWhere = p_SqlQuery.Substring(p_SqlQuery.ToUpper.IndexOf("WHERE") + 5, p_SqlQuery.Length - p_SqlQuery.ToUpper.IndexOf("WHERE") - 5).Trim
                Next
                l_datatable = DataProvider.GetDataTable(p_SqlQuery)
                Return l_datatable
            Case "TABLE"
                p_SqlQuery = Me.m_frmView.getSqlQuery(p_TableName, p_tipus)
                If p_where = "" Then
                    p_where = "1=1"
                Else
                    p_where = p_where.Replace("'False'", "'N'").Replace("'True'", "'Y'")
                End If
                For i = 0 To frmForm.entity.GetUpperBound(0)
                    If frmForm.entity(i).TableName = p_TableName And frmForm.entity(i).DefaultWhere <> "" Then
                        p_where = p_where & " and " & frmForm.entity(i).DefaultWhere
                        If frmForm.entity(i).ChildWhere <> "" Then
                            p_where = p_where & " and " & frmForm.entity(i).ChildWhere
                        End If
                    ElseIf frmForm.entity(i).TableName = p_TableName And frmForm.entity(i).ChildWhere <> "" Then
                        p_where = p_where & " and " & frmForm.entity(i).ChildWhere
                    End If
                Next
                p_SqlQuery = p_SqlQuery & " where " & p_where
                l_datatable = DataProvider.GetDataTable(p_SqlQuery)
                Return l_datatable
            Case Else
                l_datatable = DataProvider.GetDataTable(p_SqlQuery)
                Return l_datatable
        End Select

    End Function

    '----------------------------------------------------------------------------
    '----------------------------------------------------------------------------
    'Item_Event
    '----------------------------------------------------------------------------
    '----------------------------------------------------------------------------
    Public Sub Item_Event(ByVal pEvent As IFSZ_Types.PItemEvent, ByVal sender As Object, ByVal e As System.EventArgs) Implements IFSZ_ICTRL.Item_Event
        'Dim i As Integer
        '----------------------------------------------------------------------------
        'ItemClick esemény
        '----------------------------------------------------------------------------
        If pEvent = PItemEvent.ItemClick Then
            If sender.GetType() Is GetType(Button) Then
                If CType(sender, Button).Name = "B_JELSZO" Then
                    Dim l_row As DataRow = Me.frmForm.getSelectedRow("IFSZ_EMAILACCOUNTS")
                    If l_row IsNot Nothing AndAlso Not IsDBNull(l_row("ID")) Then
                        Dim l_layout As st_IFSZ_InputBoxLayout
                        Dim l_regi, l_uj1, l_uj2, l_max As Integer
                        If l_row("PASSWORD").ToString = "" Then
                            l_layout = New st_IFSZ_InputBoxLayout("Jelszó", New String() {"Új jelszó", "Új jelszó mégegyszer"})
                            l_layout.Fields(0).FieldType = en_IFSZ_InputBoxFieldType.Password_
                            l_layout.Fields(1).FieldType = en_IFSZ_InputBoxFieldType.Password_
                            l_regi = -1
                            l_uj1 = 0
                            l_uj2 = 1
                            l_max = 1
                        Else
                            l_layout = New st_IFSZ_InputBoxLayout("Jelszó", New String() {"Régi jelszó", "Új jelszó", "Új jelszó mégegyszer"})
                            l_layout.Fields(0).FieldType = en_IFSZ_InputBoxFieldType.Password_
                            l_layout.Fields(1).FieldType = en_IFSZ_InputBoxFieldType.Password_
                            l_layout.Fields(2).FieldType = en_IFSZ_InputBoxFieldType.Password_
                            l_regi = 0
                            l_uj1 = 1
                            l_uj2 = 2
                            l_max = 2
                        End If
                        Dim l_ret As String()
                        l_ret = IFSZ_InputBox.Show(l_layout)
                        If l_ret IsNot Nothing AndAlso l_ret.GetUpperBound(0) = l_max Then
                            If l_regi > -1 AndAlso String.IsNullOrEmpty(l_ret(l_regi)) Then
                                Me.frmForm.show_error("A régi jelszót meg kell adnia")
                                Exit Sub
                            End If
                            If l_uj1 > -1 AndAlso String.IsNullOrEmpty(l_ret(l_uj1)) Then
                                Me.frmForm.show_error("Az új jelszót meg kell adnia")
                                Exit Sub
                            End If
                            If l_uj2 > -1 AndAlso String.IsNullOrEmpty(l_ret(l_uj2)) Then
                                Me.frmForm.show_error("Az ismételt új jelszót meg kell adnia")
                                Exit Sub
                            End If
                            If l_regi > -1 Then
                                If IFSZ_EMAILACCOUNTS.JelszoKodol(l_ret(l_regi)) <> l_row("OLD_PASSWORD").ToString() AndAlso l_ret(l_regi) <> l_row("OLD_PASSWORD").ToString() Then
                                    Me.frmForm.show_error("Hibás régi jelszót adott meg")
                                    Exit Sub
                                End If
                            End If
                            If l_ret(l_uj1) <> l_ret(l_uj2) Then
                                Me.frmForm.show_error("Nem egyezik a két új jelszó")
                                Exit Sub
                            End If
                            l_row("PASSWORD") = IFSZ_EMAILACCOUNTS.JelszoKodol(l_ret(l_uj1))
                            Me.frmForm.GombValtas(Gomb.Aktualizal)
                        End If
                    End If
                End If

                If CType(sender, Button).Name = "B_TESZT" Then
                    Dim l_row As DataRow = Me.frmForm.getSelectedRow("IFSZ_EMAILACCOUNTS")
                    If l_row Is Nothing OrElse IsDBNull(l_row("ID")) Then
                        Exit Sub
                    End If
                    Dim l_layout As st_IFSZ_InputBoxLayout
                    Dim l_ret As String()
                    l_layout = New st_IFSZ_InputBoxLayout("Teszt email küldése", New String() {"Feladó e-mail:", "Címzett e-mail cím"})
                    l_ret = IFSZ_InputBox.Show(l_layout)
                    If l_ret IsNot Nothing AndAlso l_ret.GetUpperBound(0) = 1 Then
                        If Not String.IsNullOrEmpty(l_ret(0)) Then
                            Try
                                Dim l_smtp_server, l_smtp_username, l_smtp_password, l_frommail As String
                                Dim l_smtp_port As Integer
                                Dim l_ssl As Boolean
                                If l_row("SMTP_SERVER").ToString() = "" Then
                                    Me.frmForm.show_error("Hibásan van beállítva a kimenő postafiók. Nincs megadva az SMTP szerver neve")
                                    Exit Sub
                                End If
                                l_smtp_server = l_row("SMTP_SERVER")
                                If l_row("USERNAME").ToString() = "" Then
                                    Me.frmForm.show_error("Hibásan van beállítva a kimenő postafiók. Nincs megadva a felhasználónév")
                                    Exit Sub
                                End If
                                l_smtp_username = l_row("USERNAME")
                                If l_row("PASSWORD").ToString() = "" Then
                                    Me.frmForm.show_error("Hibásan van beállítva a kimenő postafiók. Nincs megadva a jelszó")
                                    Exit Sub
                                End If
                                l_smtp_password = IFSZ_EMAILACCOUNTS.JelszoVisszaKodol(l_row("PASSWORD"))
                                If IsDBNull(l_row("SMTP_PORT")) Then
                                    Me.frmForm.show_error("Hibásan van beállítva a kimenő postafiók. Nincs megadva az SMTP szerver portszáma")
                                    Exit Sub
                                End If
                                l_smtp_port = l_row("SMTP_PORT")
                                l_ssl = True
                                If l_row("SSL").ToString() = "N" Then
                                    l_ssl = False
                                End If

                                l_frommail = l_ret(0)

                                SmtpHelper.SendMail(
                                          l_UserName:=l_smtp_username _
                                        , l_Password:=l_smtp_password _
                                        , p_host:=l_smtp_server _
                                        , p_port:=l_smtp_port _
                                        , p_enablessl:=l_ssl _
                                        , p_frommail:=l_frommail _
                                        , p_to:=l_ret(1) _
                                        , p_subject:="eBiz teszt e-mail" _
                                        , p_body:="eBiz teszt e-mail" _
                                        , p_isbodyhtml:=False
                                    )

                                Me.frmForm.show_info("A levél sikeresen elküdve")

                            Catch ex As Exception
                                Me.frmForm.show_error("Nem sikerült a teszt levél kiküldése: " + ex.Message())
                            End Try
                        End If
                    End If

                End If

            End If
        End If

        '----------------------------------------------------------------------------
        'Item validálás esemény
        '----------------------------------------------------------------------------
        If pEvent = PItemEvent.ItemValidate Then
            If sender.Name = "" Then
            End If
        End If

    End Sub

    '----------------------------------------------------------------------------
    '----------------------------------------------------------------------------
    'ItemEvent vége
    '----------------------------------------------------------------------------
    '----------------------------------------------------------------------------

#Region "Implements IIFSZ_FileDialogResult"


    Public Sub SetFajlNev(ByVal pFajlNev As String) Implements IIFSZ_FileDialogResult.SetFajlNev
        plFileDialogOpen = False
        'ExportToCSV(pFajlNev)
    End Sub

    Public Sub NemValasztott() Implements IIFSZ_FileDialogResult.NemValasztott
        plFileDialogOpen = False
    End Sub

    Public Sub ShowFileDialog()

        Me.plSaveFileDialog.InitialDirectory = IFSZ_Globals.GetMyProc.StartInfo.WorkingDirectory
        Me.plSaveFileDialog.DefaultExt = ".csv"
        Me.plSaveFileDialog.InitialFileName = "IFSZ_EOA_" + DateTime.Now().ToString("yyyyMMddHHmmss") + ".csv"

        Me.plSaveFileDialog.SaveFileDialog(Me, IFSZ_Globals.GetMyProc)

    End Sub


    Public Function get_view() As Object Implements IFSZ_ICTRL.get_view

    End Function

#End Region

#Region "Private"

#Region "LOV"

#End Region

#End Region

#Region "Public"

    Public Function Accept(ByVal pAcceptEvent As IFSZ_Types.PAcceptEvent, ByVal pOperationType As IFSZ_Types.DMLOperation, ByVal sender As Object) As Object Implements IFSZ_ICTRL.Accept

    End Function

#End Region

End Class

