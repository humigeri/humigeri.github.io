<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class IFSZ_DNET_EOA
    'Inherits System.Windows.Forms.Form
    Inherits IFSZ_Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.MEGSE = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.DG1_ID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_NAME = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_SMTP_SERVER = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_SMTP_PORT = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_USERNAME = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_SSL = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.IFSZEOAViewBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.OK = New System.Windows.Forms.Button()
        Me.B_JELSZO = New System.Windows.Forms.Button()
        Me.B_TESZT = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.IFSZEOAViewBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MEGSE
        '
        Me.MEGSE.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.MEGSE.Location = New System.Drawing.Point(93, 426)
        Me.MEGSE.Name = "MEGSE"
        Me.MEGSE.Size = New System.Drawing.Size(75, 23)
        Me.MEGSE.TabIndex = 1010
        Me.MEGSE.Text = "M�gsem"
        Me.MEGSE.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DG1_ID, Me.DG1_NAME, Me.DG1_SMTP_SERVER, Me.DG1_SMTP_PORT, Me.DG1_USERNAME, Me.DG1_SSL})
        Me.DataGridView1.DataSource = Me.IFSZEOAViewBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(13, 12)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersWidth = 18
        Me.DataGridView1.Size = New System.Drawing.Size(715, 408)
        Me.DataGridView1.TabIndex = 60
        '
        'DG1_ID
        '
        Me.DG1_ID.DataPropertyName = "ID"
        Me.DG1_ID.Frozen = True
        Me.DG1_ID.HeaderText = "ID"
        Me.DG1_ID.Name = "DG1_ID"
        Me.DG1_ID.ReadOnly = True
        Me.DG1_ID.Visible = False
        '
        'DG1_NAME
        '
        Me.DG1_NAME.DataPropertyName = "NAME"
        Me.DG1_NAME.HeaderText = "Megnevez�s"
        Me.DG1_NAME.Name = "DG1_NAME"
        Me.DG1_NAME.Width = 150
        '
        'DG1_SMTP_SERVER
        '
        Me.DG1_SMTP_SERVER.DataPropertyName = "SMTP_SERVER"
        Me.DG1_SMTP_SERVER.HeaderText = "SMTP szerver"
        Me.DG1_SMTP_SERVER.Name = "DG1_SMTP_SERVER"
        Me.DG1_SMTP_SERVER.Width = 150
        '
        'DG1_SMTP_PORT
        '
        Me.DG1_SMTP_PORT.DataPropertyName = "SMTP_PORT"
        Me.DG1_SMTP_PORT.HeaderText = "SMTP port"
        Me.DG1_SMTP_PORT.Name = "DG1_SMTP_PORT"
        Me.DG1_SMTP_PORT.Width = 150
        '
        'DG1_USERNAME
        '
        Me.DG1_USERNAME.DataPropertyName = "USERNAME"
        Me.DG1_USERNAME.HeaderText = "SMTP felhaszn�l�n�v"
        Me.DG1_USERNAME.Name = "DG1_USERNAME"
        Me.DG1_USERNAME.Width = 150
        '
        'DG1_SSL
        '
        Me.DG1_SSL.DataPropertyName = "SSL_MEAN"
        Me.DG1_SSL.HeaderText = "SSL?"
        Me.DG1_SSL.Name = "DG1_SSL"
        Me.DG1_SSL.Width = 60
        '
        'IFSZEOAViewBindingSource
        '
        Me.IFSZEOAViewBindingSource.DataSource = GetType(IFSZ_AddOnBase.IFSZ_EOA_View)
        '
        'OK
        '
        Me.OK.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.OK.Location = New System.Drawing.Point(13, 426)
        Me.OK.Name = "OK"
        Me.OK.Size = New System.Drawing.Size(75, 23)
        Me.OK.TabIndex = 1042
        Me.OK.Text = "OK"
        Me.OK.UseVisualStyleBackColor = True
        '
        'B_JELSZO
        '
        Me.B_JELSZO.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.B_JELSZO.Location = New System.Drawing.Point(653, 426)
        Me.B_JELSZO.Name = "B_JELSZO"
        Me.B_JELSZO.Size = New System.Drawing.Size(75, 23)
        Me.B_JELSZO.TabIndex = 1043
        Me.B_JELSZO.Text = "Jelsz�"
        Me.B_JELSZO.UseVisualStyleBackColor = True
        '
        'B_TESZT
        '
        Me.B_TESZT.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.B_TESZT.Location = New System.Drawing.Point(497, 426)
        Me.B_TESZT.Name = "B_TESZT"
        Me.B_TESZT.Size = New System.Drawing.Size(75, 23)
        Me.B_TESZT.TabIndex = 1044
        Me.B_TESZT.Text = "Teszt email"
        Me.B_TESZT.UseVisualStyleBackColor = True
        '
        'IFSZ_DNET_EOA
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(740, 461)
        Me.Controls.Add(Me.B_TESZT)
        Me.Controls.Add(Me.B_JELSZO)
        Me.Controls.Add(Me.OK)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.MEGSE)
        Me.Name = "IFSZ_DNET_EOA"
        Me.Text = "Kimen� levelek postafi�k be�ll�t�sai"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.IFSZEOAViewBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents MEGSE As System.Windows.Forms.Button
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents IFSZEOAViewBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents OK As System.Windows.Forms.Button
    Friend WithEvents DG1_DocNum As IFSZ_AddOnBase.TextAndImageColumn
    Friend WithEvents DG1_DocDate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DG1_DocDueDate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DG1_CardCode As IFSZ_AddOnBase.TextAndImageColumn
    Friend WithEvents DG1_CardName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DG1_DocTotal As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DG1_OpenTotal As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DG1_ToPay As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DG1_DocCur As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DG1_NumAtCard As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DG1_Comments As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DG1_PeyMethod As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents B_JELSZO As Button
    Friend WithEvents DG1_ID As DataGridViewTextBoxColumn
    Friend WithEvents DG1_NAME As DataGridViewTextBoxColumn
    Friend WithEvents DG1_SMTP_SERVER As DataGridViewTextBoxColumn
    Friend WithEvents DG1_SMTP_PORT As DataGridViewTextBoxColumn
    Friend WithEvents DG1_USERNAME As DataGridViewTextBoxColumn
    Friend WithEvents DG1_SSL As DataGridViewComboBoxColumn
    Friend WithEvents B_TESZT As Button
End Class
