<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _Partial Class IFSZ_DNET_EOB    'Inherits System.Windows.Forms.Form
    Inherits IFSZ_Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _    Protected Overrides Sub Dispose(ByVal disposing As Boolean)        If disposing AndAlso components IsNot Nothing Then            components.Dispose()        End If        MyBase.Dispose(disposing)    End Sub    'Required by the Windows Form Designer    Private components As System.ComponentModel.IContainer    'NOTE: The following procedure is required by the Windows Form Designer    'It can be modified using the Windows Form Designer.      'Do not modify it using the code editor.    <System.Diagnostics.DebuggerStepThrough()> _    Private Sub InitializeComponent()        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.IFSZKODViewBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.OK = New System.Windows.Forms.Button()
        Me.MEGSE = New System.Windows.Forms.Button()
        Me.DataGridView2 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG2_CARDCODE = New IFSZ_AddOnBase.TextAndImageColumn()
        Me.DG2_CARDNAME = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.T_NAME = New System.Windows.Forms.TextBox()
        Me.T_SUBJECT = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.T_BODY = New System.Windows.Forms.TextBox()
        Me.DG1_ID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_DOCTYPE = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_NAME = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_DOCTYPE_NAME = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_SUBJECT = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_BODY = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_ISHTML = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_ISHTML_LANGVAL = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_ISHTML_MEAN = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.DG1_LANG_NAME = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_LANG = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_DEFAULTEMAIL = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_DEFAULTEMAIL_MEAN = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.DG1_DEFAULTEMAIL_LANGVAL = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.IFSZKODViewBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridView1.AutoGenerateColumns = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DG1_ID, Me.DG1_DOCTYPE, Me.DG1_NAME, Me.DG1_DOCTYPE_NAME, Me.DG1_SUBJECT, Me.DG1_BODY, Me.DG1_ISHTML, Me.DG1_ISHTML_LANGVAL, Me.DG1_ISHTML_MEAN, Me.DG1_LANG_NAME, Me.DG1_LANG, Me.DG1_DEFAULTEMAIL, Me.DG1_DEFAULTEMAIL_MEAN, Me.DG1_DEFAULTEMAIL_LANGVAL})
        Me.DataGridView1.DataSource = Me.IFSZKODViewBindingSource
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView1.DefaultCellStyle = DataGridViewCellStyle2
        Me.DataGridView1.Location = New System.Drawing.Point(12, 12)
        Me.DataGridView1.Name = "DataGridView1"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.DataGridView1.Size = New System.Drawing.Size(1018, 189)
        Me.DataGridView1.TabIndex = 1
        '
        'IFSZKODViewBindingSource
        '
        Me.IFSZKODViewBindingSource.DataSource = GetType(IFSZ_AddOnBase.IFSZ_EOB_View)
        '
        'OK
        '
        Me.OK.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.OK.Location = New System.Drawing.Point(12, 515)
        Me.OK.Name = "OK"
        Me.OK.Size = New System.Drawing.Size(75, 23)
        Me.OK.TabIndex = 1001
        Me.OK.Text = "OK"
        Me.OK.UseVisualStyleBackColor = True
        '
        'MEGSE
        '
        Me.MEGSE.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.MEGSE.Location = New System.Drawing.Point(93, 515)
        Me.MEGSE.Name = "MEGSE"
        Me.MEGSE.Size = New System.Drawing.Size(75, 23)
        Me.MEGSE.TabIndex = 1002
        Me.MEGSE.Text = "M�gse"
        Me.MEGSE.UseVisualStyleBackColor = True
        '
        'DataGridView2
        '
        Me.DataGridView2.AllowUserToAddRows = False
        Me.DataGridView2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.DataGridView2.AutoGenerateColumns = False
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView2.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView2.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DG2_CARDCODE, Me.DG2_CARDNAME})
        Me.DataGridView2.DataSource = Me.IFSZKODViewBindingSource
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView2.DefaultCellStyle = DataGridViewCellStyle6
        Me.DataGridView2.Location = New System.Drawing.Point(12, 207)
        Me.DataGridView2.Name = "DataGridView2"
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView2.RowHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.DataGridView2.Size = New System.Drawing.Size(499, 302)
        Me.DataGridView2.TabIndex = 100
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "ID"
        Me.DataGridViewTextBoxColumn1.HeaderText = "ID"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.Visible = False
        '
        'DG2_CARDCODE
        '
        Me.DG2_CARDCODE.DataPropertyName = "CARDCODE"
        DataGridViewCellStyle5.Padding = New System.Windows.Forms.Padding(11, 0, 0, 0)
        Me.DG2_CARDCODE.DefaultCellStyle = DataGridViewCellStyle5
        Me.DG2_CARDCODE.FormUID = Nothing
        Me.DG2_CARDCODE.HeaderText = "�P.k�d"
        Me.DG2_CARDCODE.Image = Global.IFSZ_AddOnBase.My.Resources.Resources.lefuras_be
        Me.DG2_CARDCODE.LinkObject = Nothing
        Me.DG2_CARDCODE.MenuUID = Nothing
        Me.DG2_CARDCODE.Name = "DG2_CARDCODE"
        Me.DG2_CARDCODE.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        '
        'DG2_CARDNAME
        '
        Me.DG2_CARDNAME.DataPropertyName = "CARDNAME"
        Me.DG2_CARDNAME.HeaderText = "�P.neve"
        Me.DG2_CARDNAME.Name = "DG2_CARDNAME"
        Me.DG2_CARDNAME.ReadOnly = True
        Me.DG2_CARDNAME.Width = 330
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(517, 210)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(61, 13)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Sablon k�d"
        '
        'T_NAME
        '
        Me.T_NAME.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.T_NAME.Location = New System.Drawing.Point(590, 207)
        Me.T_NAME.Name = "T_NAME"
        Me.T_NAME.Size = New System.Drawing.Size(440, 20)
        Me.T_NAME.TabIndex = 6
        '
        'T_SUBJECT
        '
        Me.T_SUBJECT.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.T_SUBJECT.Location = New System.Drawing.Point(590, 233)
        Me.T_SUBJECT.Name = "T_SUBJECT"
        Me.T_SUBJECT.Size = New System.Drawing.Size(440, 20)
        Me.T_SUBJECT.TabIndex = 1004
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(517, 236)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(67, 13)
        Me.Label2.TabIndex = 1003
        Me.Label2.Text = "E-mail t�rgya"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(679, 256)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(103, 13)
        Me.Label3.TabIndex = 1005
        Me.Label3.Text = "E-mail sz�vegt�rzse:"
        '
        'T_BODY
        '
        Me.T_BODY.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.T_BODY.Location = New System.Drawing.Point(520, 272)
        Me.T_BODY.Multiline = True
        Me.T_BODY.Name = "T_BODY"
        Me.T_BODY.Size = New System.Drawing.Size(506, 266)
        Me.T_BODY.TabIndex = 1006
        '
        'DG1_ID
        '
        Me.DG1_ID.DataPropertyName = "ID"
        Me.DG1_ID.HeaderText = "ID"
        Me.DG1_ID.Name = "DG1_ID"
        Me.DG1_ID.Visible = False
        '
        'DG1_DOCTYPE
        '
        Me.DG1_DOCTYPE.DataPropertyName = "DOCTYPE"
        Me.DG1_DOCTYPE.HeaderText = "DOCTYPE"
        Me.DG1_DOCTYPE.Name = "DG1_DOCTYPE"
        Me.DG1_DOCTYPE.Visible = False
        '
        'DG1_NAME
        '
        Me.DG1_NAME.DataPropertyName = "NAME"
        Me.DG1_NAME.HeaderText = "Sablon k�d"
        Me.DG1_NAME.Name = "DG1_NAME"
        '
        'DG1_DOCTYPE_NAME
        '
        Me.DG1_DOCTYPE_NAME.DataPropertyName = "DOCTYPE_NAME"
        Me.DG1_DOCTYPE_NAME.HeaderText = "Bizonylatt�pus"
        Me.DG1_DOCTYPE_NAME.Name = "DG1_DOCTYPE_NAME"
        Me.DG1_DOCTYPE_NAME.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        '
        'DG1_SUBJECT
        '
        Me.DG1_SUBJECT.DataPropertyName = "SUBJECT"
        Me.DG1_SUBJECT.HeaderText = "E-mail t�rgya"
        Me.DG1_SUBJECT.Name = "DG1_SUBJECT"
        Me.DG1_SUBJECT.Width = 200
        '
        'DG1_BODY
        '
        Me.DG1_BODY.DataPropertyName = "BODY"
        Me.DG1_BODY.HeaderText = "E-mail sz�vegt�rzse"
        Me.DG1_BODY.Name = "DG1_BODY"
        Me.DG1_BODY.Width = 300
        '
        'DG1_ISHTML
        '
        Me.DG1_ISHTML.DataPropertyName = "ISHTML"
        Me.DG1_ISHTML.HeaderText = "ISHTML"
        Me.DG1_ISHTML.Name = "DG1_ISHTML"
        Me.DG1_ISHTML.Visible = False
        '
        'DG1_ISHTML_LANGVAL
        '
        Me.DG1_ISHTML_LANGVAL.DataPropertyName = "ISHTML_LANGVAL"
        Me.DG1_ISHTML_LANGVAL.HeaderText = "ISHTML_LANGVAL"
        Me.DG1_ISHTML_LANGVAL.Name = "DG1_ISHTML_LANGVAL"
        Me.DG1_ISHTML_LANGVAL.Visible = False
        '
        'DG1_ISHTML_MEAN
        '
        Me.DG1_ISHTML_MEAN.DataPropertyName = "ISHTML_MEAN"
        Me.DG1_ISHTML_MEAN.HeaderText = "HTML?"
        Me.DG1_ISHTML_MEAN.Name = "DG1_ISHTML_MEAN"
        Me.DG1_ISHTML_MEAN.Width = 50
        '
        'DG1_LANG_NAME
        '
        Me.DG1_LANG_NAME.DataPropertyName = "LANG_NAME"
        Me.DG1_LANG_NAME.HeaderText = "Nyelv"
        Me.DG1_LANG_NAME.Name = "DG1_LANG_NAME"
        '
        'DG1_LANG
        '
        Me.DG1_LANG.DataPropertyName = "LANG"
        Me.DG1_LANG.HeaderText = "LANG"
        Me.DG1_LANG.Name = "DG1_LANG"
        Me.DG1_LANG.Visible = False
        '
        'DG1_DEFAULTEMAIL
        '
        Me.DG1_DEFAULTEMAIL.DataPropertyName = "DEFAULTEMAIL"
        Me.DG1_DEFAULTEMAIL.HeaderText = "DEFAULTEMAIL"
        Me.DG1_DEFAULTEMAIL.Name = "DG1_DEFAULTEMAIL"
        Me.DG1_DEFAULTEMAIL.Visible = False
        '
        'DG1_DEFAULTEMAIL_MEAN
        '
        Me.DG1_DEFAULTEMAIL_MEAN.DataPropertyName = "DEFAULTEMAIL_MEAN"
        Me.DG1_DEFAULTEMAIL_MEAN.HeaderText = "Alap�rtelmezett?"
        Me.DG1_DEFAULTEMAIL_MEAN.Name = "DG1_DEFAULTEMAIL_MEAN"
        Me.DG1_DEFAULTEMAIL_MEAN.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DG1_DEFAULTEMAIL_MEAN.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DG1_DEFAULTEMAIL_MEAN.Width = 90
        '
        'DG1_DEFAULTEMAIL_LANGVAL
        '
        Me.DG1_DEFAULTEMAIL_LANGVAL.DataPropertyName = "DEFAULTEMAIL_LANGVAL"
        Me.DG1_DEFAULTEMAIL_LANGVAL.HeaderText = "DEFAULTEMAIL_LANGVAL"
        Me.DG1_DEFAULTEMAIL_LANGVAL.Name = "DG1_DEFAULTEMAIL_LANGVAL"
        Me.DG1_DEFAULTEMAIL_LANGVAL.Visible = False
        '
        'IFSZ_DNET_EOB
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1038, 550)
        Me.Controls.Add(Me.T_BODY)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.T_SUBJECT)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.T_NAME)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.DataGridView2)
        Me.Controls.Add(Me.MEGSE)
        Me.Controls.Add(Me.OK)
        Me.Controls.Add(Me.DataGridView1)
        Me.Name = "IFSZ_DNET_EOB"
        Me.Text = "E-mail sablonok"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.IFSZKODViewBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView    Friend WithEvents IFSZKODViewBindingSource As System.Windows.Forms.BindingSource    Friend WithEvents OK As System.Windows.Forms.Button    Friend WithEvents MEGSE As System.Windows.Forms.Button    Friend WithEvents KODDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn    Friend WithEvents MEGNEVEZESDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn    Friend WithEvents ERVENYESEDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn    Friend WithEvents MEGJEGYZESDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn    Friend WithEvents TIPUSDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridView2 As DataGridView
    Friend WithEvents Label1 As Label
    Friend WithEvents T_NAME As TextBox
    Friend WithEvents T_SUBJECT As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents T_BODY As TextBox
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DG2_CARDCODE As TextAndImageColumn
    Friend WithEvents DG2_CARDNAME As DataGridViewTextBoxColumn
    Friend WithEvents DG1_ID As DataGridViewTextBoxColumn
    Friend WithEvents DG1_DOCTYPE As DataGridViewTextBoxColumn
    Friend WithEvents DG1_NAME As DataGridViewTextBoxColumn
    Friend WithEvents DG1_DOCTYPE_NAME As DataGridViewTextBoxColumn
    Friend WithEvents DG1_SUBJECT As DataGridViewTextBoxColumn
    Friend WithEvents DG1_BODY As DataGridViewTextBoxColumn
    Friend WithEvents DG1_ISHTML As DataGridViewTextBoxColumn
    Friend WithEvents DG1_ISHTML_LANGVAL As DataGridViewTextBoxColumn
    Friend WithEvents DG1_ISHTML_MEAN As DataGridViewComboBoxColumn
    Friend WithEvents DG1_LANG_NAME As DataGridViewTextBoxColumn
    Friend WithEvents DG1_LANG As DataGridViewTextBoxColumn
    Friend WithEvents DG1_DEFAULTEMAIL As DataGridViewTextBoxColumn
    Friend WithEvents DG1_DEFAULTEMAIL_MEAN As DataGridViewComboBoxColumn
    Friend WithEvents DG1_DEFAULTEMAIL_LANGVAL As DataGridViewTextBoxColumn
End Class