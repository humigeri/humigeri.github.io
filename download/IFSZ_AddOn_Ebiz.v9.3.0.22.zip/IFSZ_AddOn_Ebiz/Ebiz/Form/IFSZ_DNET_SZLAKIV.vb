Public Class IFSZ_DNET_SZLAKIV

    Private p_DUAL As IFSZ_VIEW_DUAL

    Sub New()
        MyBase.New()

        Me.m_IFSZ_Globals = New IFSZ_Globals
        Me.controller = New IFSZ_SZLAKIV_Ctrl(Me)
        InitializeComponent()
        Me.LanguageUpdate()
        p_DUAL = New IFSZ_VIEW_DUAL(Me.entity, Me, Me.m_IFSZ_Globals)
        Me.DataGridView1.Tag = p_DUAL
        Me.entity(0).TableName = "SZLAKIV"
    End Sub

    Sub New(ByRef p_ifsz_globals As IFSZ_Globals)
        MyBase.New()

        Me.m_IFSZ_Globals = p_ifsz_globals
        Me.controller = New IFSZ_SZLAKIV_Ctrl(Me)
        InitializeComponent()
        Me.LanguageUpdate()
        p_DUAL = New IFSZ_VIEW_DUAL(Me.entity, Me, Me.m_IFSZ_Globals)
        Me.DataGridView1.Tag = p_DUAL
        Me.entity(0).TableName = "SZLAKIV"
    End Sub

    Sub New(ByRef p_parentAddon As SBOAddOn, ByRef p_Interim_SBO As IFSZ_Interim_SBO)
        MyBase.New(p_Interim_SBO)

        Me.m_IFSZ_Globals = New IFSZ_Globals
        Me.controller = New IFSZ_SZLAKIV_Ctrl(Me)
        InitializeComponent()
        Me.LanguageUpdate()
        p_DUAL = New IFSZ_VIEW_DUAL(Me.entity, Me, Me.m_IFSZ_Globals)
        Me.DataGridView1.Tag = p_DUAL
        Me.entity(0).TableName = "SZLAKIV"
    End Sub

    Private Sub LanguageUpdate()

    End Sub

    Private Sub MnuGridBeallitSetFho_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles MnuGridBeallitSetFho.Click
        CType(Me.controller, IFSZ_SZLAKIV_Ctrl).GridBeallitasMentes(1)
    End Sub

    Private Sub MnuGridBeallitSetMachine_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles MnuGridBeallitSetMachine.Click
        CType(Me.controller, IFSZ_SZLAKIV_Ctrl).GridBeallitasMentes(2)
    End Sub

    Private Sub MnuGridBeallitDelFho_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles MnuGridBeallitDelFho.Click
        CType(Me.controller, IFSZ_SZLAKIV_Ctrl).GridBeallitasMentes(1, True)
    End Sub

    Private Sub MnuGridBeallitDelMachine_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles MnuGridBeallitDelMachine.Click
        CType(Me.controller, IFSZ_SZLAKIV_Ctrl).GridBeallitasMentes(2, True)
    End Sub

End Class
