﻿'----------------------------------------------------------------------------''Generálva: 2008.09.01'FormViewGenerator. Verzió: 1.0.4.0'----------------------------------------------------------------------------'Imports IFSZ_AddOnBase.IFSZ_TypesImports SystemImports System.IOImports System.TextPublic Class IFSZ_EOAD_Ctrl    Implements IFSZ_ICTRL    Implements IIFSZ_FileDialogResult    Public Sub New()    End Sub    Public Sub New(ByRef frmMain As Object)        frmForm = frmMain        plSaveFileDialog = New IFSZ_FileDialog()        Me.m_frmView = New IFSZ_EOAD_View()    End Sub    Public Sub New(ByRef frmMain As Object, ByVal p_eol_id As Integer)        frmForm = frmMain        plSaveFileDialog = New IFSZ_FileDialog()        Me.m_frmView = New IFSZ_EOAD_View()        Me.m_eol_id = p_eol_id    End Sub    Private frmForm As IFSZ_DNET_EOAD    Private plFileDialogOpen As Boolean = False    Private plSaveFileDialog As IFSZ_FileDialog    Private m_frmView As IFSZ_EOAD_View    Private volt_form_event As Boolean = False    Private m_eol_id As String = ""    Public Sub Form_Event(ByVal pEvent As String, ByVal sender As Object, ByVal e As System.EventArgs) Implements IFSZ_ICTRL.Form_Event        If pEvent = "FormLoad" Then            Me.frmForm.entity(0).NewRowEnabled = True            Me.frmForm.VirtualRowEnabled = True            Me.frmForm.p_dataset = m_frmView.getDataSet            Me.frmForm.DataGridView1.DataSource = Me.frmForm.p_dataset            Me.frmForm.DataGridView1.Name = "IFSZ_EMAILOUTADDR"            Me.frmForm.DataGridView1.DataMember = "IFSZ_EMAILOUTADDR"            volt_form_event = True            def_where()        End If    End Sub    Public Function get_DataTable(ByVal p_TableName As String, Optional ByVal p_tipus As String = "", Optional ByVal sender As Object = Nothing, Optional ByVal p_where As String = "") As System.Data.DataTable Implements IFSZ_ICTRL.get_DataTable        Dim p_SqlQuery As String
        'Dim frm_view As IFSZ_EgyszBeszerTerv_View = New IFSZ_EgyszBeszerTerv_View()
        Dim i, j, p_pk_num As Integer
        'Dim p_relation As IFSZ_Types.Relations
        Dim p_table As IFSZ_Types.RelationTable
        'Dim p_pk_id, p_fk_id As String
        Dim l_datatable As DataTable        Select Case p_tipus            Case "MASTER/DETAIL"                For i = 0 To frmForm.entity.GetUpperBound(0)                    If frmForm.entity(i).TableName = sender.current.row.table.tablename() Then                        For Each p_table In frmForm.entity(i).ChildRelation.Tables                            If p_table.Table = p_TableName Then                                For p_pk_num = 0 To p_table.PK_Columns.GetUpperBound(0)                                    If p_pk_num = 0 Then                                        p_SqlQuery = Me.m_frmView.getSqlQuery(p_TableName, p_tipus) & "where " & p_table.FK_Columns(p_pk_num) & " = " & sender.current.row(p_table.PK_Columns(p_pk_num))                                    Else                                        p_SqlQuery = Me.m_frmView.getSqlQuery(p_TableName, p_tipus) & " and " & p_table.FK_Columns(p_pk_num) & " = " & sender.current.row(p_table.PK_Columns(p_pk_num))                                    End If                                Next                                For j = 0 To frmForm.entity.GetUpperBound(0)                                    If frmForm.entity(j).TableName = p_TableName Then                                        frmForm.entity(j).ChildWhere = p_SqlQuery.Substring(p_SqlQuery.ToUpper.IndexOf("WHERE") + 5, p_SqlQuery.Length - p_SqlQuery.ToUpper.IndexOf("WHERE") - 5).Trim                                        If frmForm.entity(j).DefaultWhere <> "" Then                                            p_SqlQuery = p_SqlQuery & " and " & frmForm.entity(j).DefaultWhere
                                            'p_SqlQuery = p_SqlQuery & " and " & frmForm.entity(i).DefaultWhere
                                        End If
                                        'frmForm.entity(j).ChildWhere = p_SqlQuery.Substring(p_SqlQuery.ToUpper.IndexOf("WHERE") + 5, p_SqlQuery.Length - p_SqlQuery.ToUpper.IndexOf("WHERE") - 5).Trim
                                    End If                                Next                            End If                        Next                    End If

                    'If frmForm.entity(i).TableName = p_TableName Then
                    '    p_SqlQuery = frm_view.getSqlQuery(p_TableName, p_tipus) & sender.current.row("ID")
                    '    frmForm.entity(i).ChildWhere = p_SqlQuery.Substring(p_SqlQuery.ToUpper.IndexOf("WHERE") + 5, p_SqlQuery.Length - p_SqlQuery.ToUpper.IndexOf("WHERE") - 5).Trim
                    'End If
                    'frmForm.entity(i).ChildWhere = p_SqlQuery.Substring(p_SqlQuery.ToUpper.IndexOf("WHERE") + 5, p_SqlQuery.Length - p_SqlQuery.ToUpper.IndexOf("WHERE") - 5).Trim
                Next                l_datatable = DataProvider.GetDataTable(p_SqlQuery)                Return l_datatable            Case "TABLE"                p_SqlQuery = Me.m_frmView.getSqlQuery(p_TableName, p_tipus)                If p_where = "" Then                    p_where = "1=1"                Else                    p_where = p_where.Replace("'False'", "'N'").Replace("'True'", "'Y'")                End If                For i = 0 To frmForm.entity.GetUpperBound(0)                    If frmForm.entity(i).TableName = p_TableName And frmForm.entity(i).DefaultWhere <> "" Then                        p_where = p_where & " and " & frmForm.entity(i).DefaultWhere                        If frmForm.entity(i).ChildWhere <> "" Then                            p_where = p_where & " and " & frmForm.entity(i).ChildWhere                        End If                    ElseIf frmForm.entity(i).TableName = p_TableName And frmForm.entity(i).ChildWhere <> "" Then                        p_where = p_where & " and " & frmForm.entity(i).ChildWhere                    End If                Next                p_SqlQuery = p_SqlQuery & " where " & p_where                l_datatable = DataProvider.GetDataTable(p_SqlQuery)                Return l_datatable            Case Else                l_datatable = DataProvider.GetDataTable(p_SqlQuery)                Return l_datatable        End Select    End Function

    '----------------------------------------------------------------------------
    '----------------------------------------------------------------------------
    'Item_Event
    '----------------------------------------------------------------------------
    '----------------------------------------------------------------------------
    Public Sub Item_Event(ByVal pEvent As IFSZ_Types.PItemEvent, ByVal sender As Object, ByVal e As System.EventArgs) Implements IFSZ_ICTRL.Item_Event
        'Dim i As Integer
        '----------------------------------------------------------------------------
        'ItemClick esemény
        '----------------------------------------------------------------------------
        'If pEvent = PItemEvent.ItemClick Then
        'End If
        If pEvent = PItemEvent.KeyPressed Then            If CType(e, System.Windows.Forms.KeyEventArgs).KeyCode = Keys.F8 Then
                'Dim i As Integer
                'i = 0
                def_where()            End If        End If

        If pEvent = PItemEvent.CreateRow Then
            Me.frmForm.entity(0).set_item("EOL_ID", m_eol_id)
        End If

        If pEvent = PItemEvent.ItemValidate Then
            If sender.GetType Is GetType(DataGridView) Then
                If Me.frmForm.DataGridView1.Columns.Item(CType(e, System.Windows.Forms.DataGridViewCellValidatingEventArgs).ColumnIndex).DataPropertyName.ToUpper() = "CNTCT_EMAIL" Then
                    Dim l_ertek As String = CType(e, System.Windows.Forms.DataGridViewCellValidatingEventArgs).FormattedValue
                    If Not String.IsNullOrEmpty(l_ertek) Then
                        Dim l_regexp As New System.Text.RegularExpressions.Regex("^[a-z0-9]+([-+._][a-z0-9]+){0,2}@.*?(\.(a(?:[cdefgilmnoqrstuwxz]|ero|(?:rp|si)a)|b(?:[abdefghijmnorstvwyz]iz)|c(?:[acdfghiklmnoruvxyz]|at|o(?:m|op))|d[ejkmoz]|e(?:[ceghrstu]|du)|f[ijkmor]|g(?:[abdefghilmnpqrstuwy]|ov)|h[kmnrtu]|i(?:[delmnoqrst]|n(?:fo|t))|j(?:[emop]|obs)|k[eghimnprwyz]|l[abcikrstuvy]|m(?:[acdeghklmnopqrstuvwxyz]|il|obi|useum)|n(?:[acefgilopruz]|ame|et)|o(?:m|rg)|p(?:[aefghklmnrstwy]|ro)|qa|r[eosuw]|s[abcdeghijklmnortuvyz]|t(?:[cdfghjklmnoprtvwz]|(?:rav)?el)|u[agkmsyz]|v[aceginu]|w[fs]|y[etu]|z[amw])\b){1,2}$")
                        If Not l_regexp.IsMatch(l_ertek) Then
                            Me.frmForm.show_error(sender, "Nem megfelelő emal formátum", e)
                        End If
                    End If
                End If
            End If
        End If

    End Sub



    '----------------------------------------------------------------------------
    '----------------------------------------------------------------------------
    'ItemEvent vége
    '----------------------------------------------------------------------------
    '----------------------------------------------------------------------------

#Region "Implements IIFSZ_FileDialogResult"

    Public Sub SetFajlNev(ByVal pFajlNev As String) Implements IIFSZ_FileDialogResult.SetFajlNev        plFileDialogOpen = False
        'ExportToCSV(pFajlNev)
    End Sub    Public Sub NemValasztott() Implements IIFSZ_FileDialogResult.NemValasztott        plFileDialogOpen = False    End Sub    Public Sub ShowFileDialog()        Me.plSaveFileDialog.InitialDirectory = IFSZ_Globals.GetMyProc.StartInfo.WorkingDirectory        Me.plSaveFileDialog.DefaultExt = ".csv"        Me.plSaveFileDialog.InitialFileName = "IFSZ_EOAD_" + DateTime.Now().ToString("yyyyMMddHHmmss") + ".csv"        Me.plSaveFileDialog.SaveFileDialog(Me, IFSZ_Globals.GetMyProc)    End Sub    Public Function get_view() As Object Implements IFSZ_ICTRL.get_view    End Function



















#End Region
#Region "Private"
#Region "LOV"
#End Region
#End Region
#Region "Public"
    Public Sub def_where()        Me.frmForm.entity(0).DefaultWhere = "EOL_ID = " & Me.m_eol_id.ToString
        If volt_form_event Then
            Me.frmForm.BlockRefresh("IFSZ_EMAILOUTADDR")
        End If    End Sub



#End Region
    Public Function Accept(ByVal pAcceptEvent As IFSZ_Types.PAcceptEvent, ByVal pOperationType As IFSZ_Types.DMLOperation, ByVal sender As Object) As Object Implements IFSZ_ICTRL.Accept    End FunctionEnd Class