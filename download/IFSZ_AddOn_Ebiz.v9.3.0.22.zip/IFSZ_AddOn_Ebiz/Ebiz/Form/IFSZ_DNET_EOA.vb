﻿'----------------------------------------------------------------------------'
'Generálva: 2020.03.22
'FormViewGenerator. Verzió: 1.0.7.0
'----------------------------------------------------------------------------'

Public Class IFSZ_DNET_EOA

    Private p_IFSZ_EMAILACCOUNTS As IFSZ_EMAILACCOUNTS

    Public Sub New()
        MyBase.New()
        Me.m_IFSZ_Globals = New IFSZ_Globals
        Me.controller = New IFSZ_EOA_Ctrl(Me)
        InitializeComponent()
        Me.LanguageUpdate()

        p_IFSZ_EMAILACCOUNTS = New IFSZ_EMAILACCOUNTS(Me.entity, Me, Me.m_IFSZ_Globals)

        Me.DataGridView1.Tag = Me.entity(0)
    End Sub

    Sub New(ByRef p_ifsz_globals As IFSZ_Globals)
        MyBase.New()

        Me.m_IFSZ_Globals = p_ifsz_globals
        Me.controller = New IFSZ_EOA_Ctrl(Me)
        InitializeComponent()
        Me.LanguageUpdate()

        p_IFSZ_EMAILACCOUNTS = New IFSZ_EMAILACCOUNTS(Me.entity, Me, Me.m_IFSZ_Globals)

        Me.DataGridView1.Tag = Me.entity(0)
    End Sub

    Sub New(ByRef p_parentAddon As SBOAddOn, ByRef p_Interim_SBO As IFSZ_Interim_SBO)
        MyBase.New(p_Interim_SBO)

        Me.m_IFSZ_Globals = New IFSZ_Globals
        Me.controller = New IFSZ_EOA_Ctrl(Me)
        InitializeComponent()
        Me.LanguageUpdate()

        p_IFSZ_EMAILACCOUNTS = New IFSZ_EMAILACCOUNTS(Me.entity, Me, Me.m_IFSZ_Globals)

        Me.DataGridView1.Tag = Me.entity(0)

    End Sub

    Private Sub LanguageUpdate()
    End Sub

End Class
