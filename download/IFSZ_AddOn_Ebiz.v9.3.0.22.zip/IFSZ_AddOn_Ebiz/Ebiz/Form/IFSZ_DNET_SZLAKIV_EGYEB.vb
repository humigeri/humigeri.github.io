﻿Imports System.ComponentModel

Public Class IFSZ_DNET_SZLAKIV_EGYEB

    Public TextBoxBackColorR As Integer = 253
    Public TextBoxBackColorG As Integer = 253
    Public TextBoxBackColorB As Integer = 243

    Public ReadOnlyBackColorR As Integer = 239
    Public ReadOnlyBackColorG As Integer = 235
    Public ReadOnlyBackColorB As Integer = 222

    Public FormBackColorR As Integer = 222
    Public FormBackColorG As Integer = 223
    Public FormBackColorB As Integer = 206

    Private m_felt_view As DataView
    Public m_felt_tab As DataTable
    Private resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(IFSZ_Form))

    Public Sub New(ByVal p_felt_tab As DataTable)

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        m_felt_tab = p_felt_tab.Copy()
        m_felt_view = New DataView(m_felt_tab, "", "IND", DataViewRowState.CurrentRows)
        Me.DataGridView1.DataSource = m_felt_view


        For Each l_col As DataGridViewColumn In Me.DataGridView1.Columns
            If l_col.Name = "COLUMNTITLE" Then
                l_col.Width = 170
                l_col.Visible = True
                l_col.ReadOnly = True
                l_col.HeaderText = "Oszlop"

            ElseIf l_col.Name = "SZUR" Then
                l_col.Width = 300
                l_col.Visible = True
                l_col.ReadOnly = False
                l_col.HeaderText = "Szűrés"
            Else
                l_col.Visible = False
            End If
        Next

        For Each l_row As DataGridViewRow In Me.DataGridView1.Rows
            Me.RowColor(l_row)
        Next

        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)

    End Sub

    Private Sub B_OK_Click(sender As Object, e As EventArgs) Handles B_OK.Click
        leokez()
    End Sub

    Private Sub B_MEGSEM_Click(sender As Object, e As EventArgs) Handles B_MEGSEM.Click
        Me.DialogResult = DialogResult.Cancel
        Me.Close()
    End Sub

    Friend Sub RowColor(ByVal p_ctrl As DataGridViewRow)
        Dim p_cell As DataGridViewCell

        If p_ctrl.ReadOnly = True Then
            For Each p_cell In CType(p_ctrl, DataGridViewRow).Cells
                If p_cell.Visible Then

                    p_cell.Style.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(222, Byte), Integer))
                    'p_column.DefaultCellStyle.ForeColor = Color.Black
                End If
            Next

        Else
            For Each p_cell In CType(p_ctrl, DataGridViewRow).Cells
                If p_cell.Visible Then
                    If p_ctrl.DataGridView.Columns.Item(p_cell.ColumnIndex).ReadOnly = True Then
                        'p_cell.Style.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(222, Byte), Integer))
                        'p_cell.Style.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(222, Byte), Integer))
                        p_cell.Style.BackColor = System.Drawing.Color.FromArgb(CType(CType(ReadOnlyBackColorR, Byte), Integer), CType(CType(ReadOnlyBackColorG, Byte), Integer), CType(CType(ReadOnlyBackColorB, Byte), Integer))
                        'p_column.DefaultCellStyle.ForeColor = Color.Black
                    Else
                        'p_cell.Style.BackColor = System.Drawing.Color.FromArgb(CType(CType(253, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(243, Byte), Integer))
                        p_cell.Style.BackColor = System.Drawing.Color.FromArgb(CType(CType(TextBoxBackColorR, Byte), Integer), CType(CType(TextBoxBackColorG, Byte), Integer), CType(CType(TextBoxBackColorB, Byte), Integer))
                        p_cell.Style.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(156, Byte), Integer))
                        p_cell.Style.SelectionForeColor = Color.Black
                    End If
                End If
            Next

        End If

    End Sub

    Private Sub PB_TOROL_Click(sender As Object, e As EventArgs) Handles PB_TOROL.Click
        For Each l_row As DataRow In m_felt_tab.Rows
            l_row("SZUR") = DBNull.Value
        Next
    End Sub

    Private Sub DataGridView1_KeyDown(sender As Object, e As KeyEventArgs) Handles DataGridView1.KeyDown
        If e.KeyData = Keys.Enter Then
            e.Handled = True
            leokez()
        End If
    End Sub

    Private Sub leokez()
        m_felt_tab.AcceptChanges()
        Me.DialogResult = DialogResult.OK
        Me.Close()
    End Sub

End Class