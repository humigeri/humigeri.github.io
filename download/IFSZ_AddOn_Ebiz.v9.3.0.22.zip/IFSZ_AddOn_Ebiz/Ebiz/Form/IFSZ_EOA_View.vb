﻿'----------------------------------------------------------------------------'
'Generálva: 2020.03.22
'FormViewGenerator. Verzió: 1.0.7.0
'----------------------------------------------------------------------------'

Public Class IFSZ_EOA_View
    Inherits ObjectDataBinding.BaseClasses.FSBindingItem

#Region "Variables"

    Private p_ID As Integer
    Private p_NAME As String
    Private p_SMTP_SERVER As String
    Private p_SMTP_PORT As String
    Private p_USERNAME As String
    Private p_PASSWORD As String
    Private p_SSL As String
    Private p_SSL_LANGVAL As String
    Private p_SSL_MEAN As String

#End Region


#Region "Constructor"

    Public Sub New()

    End Sub

#End Region

#Region "Property"

    Public Property ID() As Integer
        Get
            Return p_ID
        End Get
        Set(ByVal value As Integer)
            p_ID = value
        End Set
    End Property

    Public Property NAME() As String
        Get
            Return p_NAME
        End Get
        Set(ByVal value As String)
            p_NAME = value
        End Set
    End Property

    Public Property SMTP_SERVER() As String
        Get
            Return p_SMTP_SERVER
        End Get
        Set(ByVal value As String)
            p_SMTP_SERVER = value
        End Set
    End Property

    Public Property SMTP_PORT() As String
        Get
            Return p_SMTP_PORT
        End Get
        Set(ByVal value As String)
            p_SMTP_PORT = value
        End Set
    End Property

    Public Property USERNAME() As String
        Get
            Return p_USERNAME
        End Get
        Set(ByVal value As String)
            p_USERNAME = value
        End Set
    End Property

    Public Property PASSWORD() As String
        Get
            Return p_PASSWORD
        End Get
        Set(ByVal value As String)
            p_PASSWORD = value
        End Set
    End Property

    Public Property SSL() As String
        Get
            Return p_SSL
        End Get
        Set(ByVal value As String)
            p_SSL = value
        End Set
    End Property

    Public Property SSL_LANGVAL() As String
        Get
            Return p_SSL_LANGVAL
        End Get
        Set(ByVal value As String)
            p_SSL_LANGVAL = value
        End Set
    End Property

    Public Property SSL_MEAN() As String
        Get
            Return p_SSL_MEAN
        End Get
        Set(ByVal value As String)
            p_SSL_MEAN = value
        End Set
    End Property

#End Region

    Public Function getDataSet() As DataSet
        Dim sqlQuery As String = ""
        Dim dataSet As DataSet = New DataSet

        Try

            sqlQuery = sqlQuery & "select ID, NAME, SMTP_SERVER, SMTP_PORT, USERNAME, PASSWORD, PASSWORD AS OLD_PASSWORD, SSL, SSL_LANGVAL, SSL_MEAN from IFSZ_F_EOA_EOA_V "


            ' Get a data set from the query
            dataSet = DataProvider.GetDataSet(sqlQuery.ToString())


            ' Create variables for data set tables
            Dim Table As DataTable = dataSet.Tables(0)
            Table.TableName = "IFSZ_EMAILACCOUNTS"
            dataSet.Tables(0).TableName = "IFSZ_EMAILACCOUNTS"


            Return dataSet

        Finally
            If (Not dataSet Is Nothing) Then
                'System.Runtime.InteropServices.Marshal.ReleaseComObject(dataSet)
                dataSet.Dispose()
            End If

        End Try
    End Function

    Public Function getSqlQuery(ByVal p_table As String, Optional ByVal p_tipus As String = "") As String
        Select Case p_table
            Case "IFSZ_EMAILACCOUNTS"
                Select Case p_tipus
                    Case "MASTER/DETAIL"
                        Return "select ID, NAME, SMTP_SERVER, SMTP_PORT, USERNAME, PASSWORD, PASSWORD AS OLD_PASSWORD, SSL, SSL_LANGVAL, SSL_MEAN from IFSZ_F_EOA_EOA_V "
                    Case "TABLE"
                        Return "select ID, NAME, SMTP_SERVER, SMTP_PORT, USERNAME, PASSWORD, PASSWORD AS OLD_PASSWORD, SSL, SSL_LANGVAL, SSL_MEAN from IFSZ_F_EOA_EOA_V "
                    Case Else
                        Return "select ID, NAME, SMTP_SERVER, SMTP_PORT, USERNAME, PASSWORD, PASSWORD AS OLD_PASSWORD, SSL, SSL_LANGVAL, SSL_MEAN from IFSZ_F_EOA_EOA_V "
                End Select
            Case Else
                Return ""
        End Select
    End Function

End Class
