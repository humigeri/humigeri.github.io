﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class IFSZ_DNET_SZLAKIV_EGYEB
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.B_OK = New System.Windows.Forms.Button()
        Me.B_MEGSEM = New System.Windows.Forms.Button()
        Me.PB_TOROL = New System.Windows.Forms.PictureBox()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PB_TOROL, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(13, 13)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(534, 392)
        Me.DataGridView1.TabIndex = 0
        '
        'B_OK
        '
        Me.B_OK.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.B_OK.Location = New System.Drawing.Point(13, 411)
        Me.B_OK.Name = "B_OK"
        Me.B_OK.Size = New System.Drawing.Size(75, 23)
        Me.B_OK.TabIndex = 1
        Me.B_OK.Text = "OK"
        Me.B_OK.UseVisualStyleBackColor = True
        '
        'B_MEGSEM
        '
        Me.B_MEGSEM.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.B_MEGSEM.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.B_MEGSEM.Location = New System.Drawing.Point(94, 411)
        Me.B_MEGSEM.Name = "B_MEGSEM"
        Me.B_MEGSEM.Size = New System.Drawing.Size(75, 23)
        Me.B_MEGSEM.TabIndex = 2
        Me.B_MEGSEM.Text = "Mégsem"
        Me.B_MEGSEM.UseVisualStyleBackColor = True
        '
        'PB_TOROL
        '
        Me.PB_TOROL.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PB_TOROL.BackgroundImage = Global.IFSZ_AddOnBase.My.Resources.Resources.action_stop
        Me.PB_TOROL.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.PB_TOROL.InitialImage = Global.IFSZ_AddOnBase.My.Resources.Resources.action_stop
        Me.PB_TOROL.Location = New System.Drawing.Point(511, 411)
        Me.PB_TOROL.Name = "PB_TOROL"
        Me.PB_TOROL.Size = New System.Drawing.Size(36, 23)
        Me.PB_TOROL.TabIndex = 3
        Me.PB_TOROL.TabStop = False
        '
        'IFSZ_DNET_SZLAKIV_EGYEB
        '
        Me.AcceptButton = Me.B_OK
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.B_MEGSEM
        Me.ClientSize = New System.Drawing.Size(559, 446)
        Me.Controls.Add(Me.PB_TOROL)
        Me.Controls.Add(Me.B_MEGSEM)
        Me.Controls.Add(Me.B_OK)
        Me.Controls.Add(Me.DataGridView1)
        Me.Name = "IFSZ_DNET_SZLAKIV_EGYEB"
        Me.Text = "Szűrési feltételek"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PB_TOROL, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents B_OK As Button
    Friend WithEvents B_MEGSEM As Button
    Friend WithEvents PB_TOROL As PictureBox
End Class
