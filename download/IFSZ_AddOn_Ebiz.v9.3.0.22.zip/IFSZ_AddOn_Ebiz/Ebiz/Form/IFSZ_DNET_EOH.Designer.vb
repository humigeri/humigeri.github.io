﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class IFSZ_DNET_EOH
    'Inherits System.Windows.Forms.Form
    Inherits IFSZ_Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.OK = New System.Windows.Forms.Button()
        Me.MEGSE = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.T_USERCODE = New System.Windows.Forms.TextBox()
        Me.T_DOCNUM = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.T_SENTTS = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.T_NOTE = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.T_STATUS = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.T_PATH = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.IFSZEOHViewBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.B_KIVALASZT = New System.Windows.Forms.Button()
        Me.B_EMAILS = New System.Windows.Forms.Button()
        Me.B_GENERAL = New System.Windows.Forms.Button()
        Me.B_GENERAL_KULD = New System.Windows.Forms.Button()
        Me.B_TET_TOROL = New System.Windows.Forms.Button()
        Me.B_VISSZAVON = New System.Windows.Forms.Button()
        Me.PBx_T_PATH = New System.Windows.Forms.PictureBox()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.T_PROGRESS = New System.Windows.Forms.TextBox()
        Me.GridBeallitMenu = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.MnuGridBeallitSetFho = New System.Windows.Forms.ToolStripMenuItem()
        Me.MnuGridBeallitSetMachine = New System.Windows.Forms.ToolStripMenuItem()
        Me.MnuGridBeallitDelFho = New System.Windows.Forms.ToolStripMenuItem()
        Me.MnuGridBeallitDelMachine = New System.Windows.Forms.ToolStripMenuItem()
        Me.DG1_ID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_EOH_ID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_LINENUM = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_DOCTYPE = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_DOCTYPE_LANGVAL = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_DOCTYPE_MEAN = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_DOCENTRY = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_DOCNUM = New IFSZ_AddOnBase.TextAndImageColumn()
        Me.DG1_CARDCODE = New IFSZ_AddOnBase.TextAndImageColumn()
        Me.DG1_CARDNAME = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_CRYSTAL = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_CRYSTALNAME = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_EMAILS = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_FILE = New IFSZ_AddOnBase.TextAndImageColumn()
        Me.DG1_MAIL_SUBJECT = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_MAIL_BODY = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_EBIZTIP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_EBIZTIP_LANGVAL = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_EBIZTIP_MEAN = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_STATUS = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_STATUS_LANGVAL = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_STATUS_MEAN = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DG1_SENTTS = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.IFSZEOHViewBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PBx_T_PATH, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GridBeallitMenu.SuspendLayout()
        Me.SuspendLayout()
        '
        'OK
        '
        Me.OK.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.OK.Location = New System.Drawing.Point(12, 478)
        Me.OK.Name = "OK"
        Me.OK.Size = New System.Drawing.Size(75, 23)
        Me.OK.TabIndex = 1044
        Me.OK.Text = "OK"
        Me.OK.UseVisualStyleBackColor = True
        '
        'MEGSE
        '
        Me.MEGSE.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.MEGSE.Location = New System.Drawing.Point(92, 478)
        Me.MEGSE.Name = "MEGSE"
        Me.MEGSE.Size = New System.Drawing.Size(75, 23)
        Me.MEGSE.TabIndex = 1043
        Me.MEGSE.Text = "Mégsem"
        Me.MEGSE.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 15)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(63, 13)
        Me.Label1.TabIndex = 1045
        Me.Label1.Text = "Felhasználó"
        '
        'T_USERCODE
        '
        Me.T_USERCODE.Location = New System.Drawing.Point(81, 12)
        Me.T_USERCODE.Name = "T_USERCODE"
        Me.T_USERCODE.ReadOnly = True
        Me.T_USERCODE.Size = New System.Drawing.Size(100, 20)
        Me.T_USERCODE.TabIndex = 10
        '
        'T_DOCNUM
        '
        Me.T_DOCNUM.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.T_DOCNUM.Location = New System.Drawing.Point(918, 12)
        Me.T_DOCNUM.Name = "T_DOCNUM"
        Me.T_DOCNUM.ReadOnly = True
        Me.T_DOCNUM.Size = New System.Drawing.Size(100, 20)
        Me.T_DOCNUM.TabIndex = 20
        '
        'Label2
        '
        Me.Label2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(839, 15)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(73, 13)
        Me.Label2.TabIndex = 1047
        Me.Label2.Text = "Bizonylatszám"
        '
        'T_SENTTS
        '
        Me.T_SENTTS.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.T_SENTTS.Location = New System.Drawing.Point(709, 12)
        Me.T_SENTTS.Name = "T_SENTTS"
        Me.T_SENTTS.ReadOnly = True
        Me.T_SENTTS.Size = New System.Drawing.Size(100, 20)
        Me.T_SENTTS.TabIndex = 30
        '
        'Label3
        '
        Me.Label3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(618, 15)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(85, 13)
        Me.Label3.TabIndex = 1049
        Me.Label3.Text = "Küldés időpontja"
        '
        'T_NOTE
        '
        Me.T_NOTE.Location = New System.Drawing.Point(81, 38)
        Me.T_NOTE.Name = "T_NOTE"
        Me.T_NOTE.Size = New System.Drawing.Size(353, 20)
        Me.T_NOTE.TabIndex = 40
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(12, 41)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(63, 13)
        Me.Label4.TabIndex = 1051
        Me.Label4.Text = "Megjegyzés"
        '
        'T_STATUS
        '
        Me.T_STATUS.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.T_STATUS.Location = New System.Drawing.Point(918, 38)
        Me.T_STATUS.Name = "T_STATUS"
        Me.T_STATUS.ReadOnly = True
        Me.T_STATUS.Size = New System.Drawing.Size(100, 20)
        Me.T_STATUS.TabIndex = 50
        '
        'Label5
        '
        Me.Label5.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(869, 41)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(42, 13)
        Me.Label5.TabIndex = 1053
        Me.Label5.Text = "Státusz"
        '
        'T_PATH
        '
        Me.T_PATH.Location = New System.Drawing.Point(81, 64)
        Me.T_PATH.Name = "T_PATH"
        Me.T_PATH.ReadOnly = True
        Me.T_PATH.Size = New System.Drawing.Size(353, 20)
        Me.T_PATH.TabIndex = 60
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(12, 67)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(44, 13)
        Me.Label6.TabIndex = 1055
        Me.Label6.Text = "Útvonal"
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToOrderColumns = True
        Me.DataGridView1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DG1_ID, Me.DG1_EOH_ID, Me.DG1_LINENUM, Me.DG1_DOCTYPE, Me.DG1_DOCTYPE_LANGVAL, Me.DG1_DOCTYPE_MEAN, Me.DG1_DOCENTRY, Me.DG1_DOCNUM, Me.DG1_CARDCODE, Me.DG1_CARDNAME, Me.DG1_CRYSTAL, Me.DG1_CRYSTALNAME, Me.DG1_EMAILS, Me.DG1_FILE, Me.DG1_MAIL_SUBJECT, Me.DG1_MAIL_BODY, Me.DG1_EBIZTIP, Me.DG1_EBIZTIP_LANGVAL, Me.DG1_EBIZTIP_MEAN, Me.DG1_STATUS, Me.DG1_STATUS_LANGVAL, Me.DG1_STATUS_MEAN, Me.DG1_SENTTS})
        Me.DataGridView1.DataSource = Me.IFSZEOHViewBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(15, 100)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(1003, 372)
        Me.DataGridView1.TabIndex = 500
        '
        'IFSZEOHViewBindingSource
        '
        Me.IFSZEOHViewBindingSource.DataSource = GetType(IFSZ_AddOnBase.IFSZ_EOH_View)
        '
        'B_KIVALASZT
        '
        Me.B_KIVALASZT.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.B_KIVALASZT.Location = New System.Drawing.Point(686, 67)
        Me.B_KIVALASZT.Name = "B_KIVALASZT"
        Me.B_KIVALASZT.Size = New System.Drawing.Size(123, 23)
        Me.B_KIVALASZT.TabIndex = 100
        Me.B_KIVALASZT.Text = "Tételek hozzáadása"
        Me.B_KIVALASZT.UseVisualStyleBackColor = True
        '
        'B_EMAILS
        '
        Me.B_EMAILS.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.B_EMAILS.Location = New System.Drawing.Point(210, 478)
        Me.B_EMAILS.Name = "B_EMAILS"
        Me.B_EMAILS.Size = New System.Drawing.Size(100, 23)
        Me.B_EMAILS.TabIndex = 1100
        Me.B_EMAILS.Text = "Címzettek"
        Me.B_EMAILS.UseVisualStyleBackColor = True
        '
        'B_GENERAL
        '
        Me.B_GENERAL.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.B_GENERAL.Enabled = False
        Me.B_GENERAL.Location = New System.Drawing.Point(893, 478)
        Me.B_GENERAL.Name = "B_GENERAL"
        Me.B_GENERAL.Size = New System.Drawing.Size(125, 23)
        Me.B_GENERAL.TabIndex = 1057
        Me.B_GENERAL.Text = "Csak generálás"
        Me.B_GENERAL.UseVisualStyleBackColor = True
        '
        'B_GENERAL_KULD
        '
        Me.B_GENERAL_KULD.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.B_GENERAL_KULD.Location = New System.Drawing.Point(355, 478)
        Me.B_GENERAL_KULD.Name = "B_GENERAL_KULD"
        Me.B_GENERAL_KULD.Size = New System.Drawing.Size(125, 23)
        Me.B_GENERAL_KULD.TabIndex = 1060
        Me.B_GENERAL_KULD.Text = "Generálás és küldés"
        Me.B_GENERAL_KULD.UseVisualStyleBackColor = True
        '
        'B_TET_TOROL
        '
        Me.B_TET_TOROL.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.B_TET_TOROL.Location = New System.Drawing.Point(511, 67)
        Me.B_TET_TOROL.Name = "B_TET_TOROL"
        Me.B_TET_TOROL.Size = New System.Drawing.Size(122, 23)
        Me.B_TET_TOROL.TabIndex = 90
        Me.B_TET_TOROL.Text = "Összes tétel törlése"
        Me.B_TET_TOROL.UseVisualStyleBackColor = True
        '
        'B_VISSZAVON
        '
        Me.B_VISSZAVON.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.B_VISSZAVON.Location = New System.Drawing.Point(918, 67)
        Me.B_VISSZAVON.Name = "B_VISSZAVON"
        Me.B_VISSZAVON.Size = New System.Drawing.Size(100, 23)
        Me.B_VISSZAVON.TabIndex = 1090
        Me.B_VISSZAVON.Text = "Visszavonás"
        Me.B_VISSZAVON.UseVisualStyleBackColor = True
        '
        'PBx_T_PATH
        '
        Me.PBx_T_PATH.Image = Global.IFSZ_AddOnBase.My.Resources.Resources.lefuras_be
        Me.PBx_T_PATH.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PBx_T_PATH.Location = New System.Drawing.Point(64, 71)
        Me.PBx_T_PATH.Margin = New System.Windows.Forms.Padding(5)
        Me.PBx_T_PATH.Name = "PBx_T_PATH"
        Me.PBx_T_PATH.Size = New System.Drawing.Size(13, 9)
        Me.PBx_T_PATH.TabIndex = 1101
        Me.PBx_T_PATH.TabStop = False
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ProgressBar1.Location = New System.Drawing.Point(184, 494)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(834, 23)
        Me.ProgressBar1.TabIndex = 1102
        Me.ProgressBar1.Visible = False
        '
        'T_PROGRESS
        '
        Me.T_PROGRESS.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.T_PROGRESS.Location = New System.Drawing.Point(184, 478)
        Me.T_PROGRESS.Name = "T_PROGRESS"
        Me.T_PROGRESS.ReadOnly = True
        Me.T_PROGRESS.Size = New System.Drawing.Size(834, 20)
        Me.T_PROGRESS.TabIndex = 1103
        Me.T_PROGRESS.Visible = False
        '
        'GridBeallitMenu
        '
        Me.GridBeallitMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MnuGridBeallitSetFho, Me.MnuGridBeallitSetMachine, Me.MnuGridBeallitDelFho, Me.MnuGridBeallitDelMachine})
        Me.GridBeallitMenu.Name = "GridBeallitMenu"
        Me.GridBeallitMenu.Size = New System.Drawing.Size(347, 92)
        '
        'MnuGridBeallitSetFho
        '
        Me.MnuGridBeallitSetFho.Name = "MnuGridBeallitSetFho"
        Me.MnuGridBeallitSetFho.Size = New System.Drawing.Size(346, 22)
        Me.MnuGridBeallitSetFho.Text = "Oszlopbeálltások mentése (felhasználó szintű)"
        '
        'MnuGridBeallitSetMachine
        '
        Me.MnuGridBeallitSetMachine.Name = "MnuGridBeallitSetMachine"
        Me.MnuGridBeallitSetMachine.Size = New System.Drawing.Size(346, 22)
        Me.MnuGridBeallitSetMachine.Text = "Oszlopbeállítások mentése (felhasználó+gép szintű)"
        '
        'MnuGridBeallitDelFho
        '
        Me.MnuGridBeallitDelFho.Name = "MnuGridBeallitDelFho"
        Me.MnuGridBeallitDelFho.Size = New System.Drawing.Size(346, 22)
        Me.MnuGridBeallitDelFho.Text = "Oszlopbeállítások törlése (felhasználó szintű)"
        '
        'MnuGridBeallitDelMachine
        '
        Me.MnuGridBeallitDelMachine.Name = "MnuGridBeallitDelMachine"
        Me.MnuGridBeallitDelMachine.Size = New System.Drawing.Size(346, 22)
        Me.MnuGridBeallitDelMachine.Text = "Oszlopbeállítások törlése (felhasználó+gép szintű)"
        '
        'DG1_ID
        '
        Me.DG1_ID.DataPropertyName = "ID"
        Me.DG1_ID.HeaderText = "ID"
        Me.DG1_ID.Name = "DG1_ID"
        Me.DG1_ID.Visible = False
        '
        'DG1_EOH_ID
        '
        Me.DG1_EOH_ID.DataPropertyName = "EOH_ID"
        Me.DG1_EOH_ID.HeaderText = "EOH_ID"
        Me.DG1_EOH_ID.Name = "DG1_EOH_ID"
        Me.DG1_EOH_ID.Visible = False
        '
        'DG1_LINENUM
        '
        Me.DG1_LINENUM.DataPropertyName = "LINENUM"
        Me.DG1_LINENUM.HeaderText = "Sor"
        Me.DG1_LINENUM.Name = "DG1_LINENUM"
        Me.DG1_LINENUM.ReadOnly = True
        Me.DG1_LINENUM.Width = 40
        '
        'DG1_DOCTYPE
        '
        Me.DG1_DOCTYPE.DataPropertyName = "DOCTYPE"
        Me.DG1_DOCTYPE.HeaderText = "DOCTYPE"
        Me.DG1_DOCTYPE.Name = "DG1_DOCTYPE"
        Me.DG1_DOCTYPE.Visible = False
        '
        'DG1_DOCTYPE_LANGVAL
        '
        Me.DG1_DOCTYPE_LANGVAL.DataPropertyName = "DOCTYPE_LANGVAL"
        Me.DG1_DOCTYPE_LANGVAL.HeaderText = "DOCTYPE_LANGVAL"
        Me.DG1_DOCTYPE_LANGVAL.Name = "DG1_DOCTYPE_LANGVAL"
        Me.DG1_DOCTYPE_LANGVAL.Visible = False
        '
        'DG1_DOCTYPE_MEAN
        '
        Me.DG1_DOCTYPE_MEAN.DataPropertyName = "DOCTYPE_MEAN"
        Me.DG1_DOCTYPE_MEAN.HeaderText = "Biz.típus"
        Me.DG1_DOCTYPE_MEAN.Name = "DG1_DOCTYPE_MEAN"
        Me.DG1_DOCTYPE_MEAN.ReadOnly = True
        '
        'DG1_DOCENTRY
        '
        Me.DG1_DOCENTRY.DataPropertyName = "DOCENTRY"
        Me.DG1_DOCENTRY.HeaderText = "DOCENTRY"
        Me.DG1_DOCENTRY.Name = "DG1_DOCENTRY"
        Me.DG1_DOCENTRY.Visible = False
        '
        'DG1_DOCNUM
        '
        Me.DG1_DOCNUM.DataPropertyName = "DOCNUM"
        DataGridViewCellStyle1.Padding = New System.Windows.Forms.Padding(11, 0, 0, 0)
        Me.DG1_DOCNUM.DefaultCellStyle = DataGridViewCellStyle1
        Me.DG1_DOCNUM.FormUID = Nothing
        Me.DG1_DOCNUM.HeaderText = "Bizonylatszám"
        Me.DG1_DOCNUM.Image = Global.IFSZ_AddOnBase.My.Resources.Resources.lefuras_be
        Me.DG1_DOCNUM.LinkObject = Nothing
        Me.DG1_DOCNUM.MenuUID = Nothing
        Me.DG1_DOCNUM.Name = "DG1_DOCNUM"
        Me.DG1_DOCNUM.ReadOnly = True
        Me.DG1_DOCNUM.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        '
        'DG1_CARDCODE
        '
        Me.DG1_CARDCODE.DataPropertyName = "CARDCODE"
        DataGridViewCellStyle2.Padding = New System.Windows.Forms.Padding(11, 0, 0, 0)
        Me.DG1_CARDCODE.DefaultCellStyle = DataGridViewCellStyle2
        Me.DG1_CARDCODE.FormUID = Nothing
        Me.DG1_CARDCODE.HeaderText = "ÜP.kód"
        Me.DG1_CARDCODE.Image = Global.IFSZ_AddOnBase.My.Resources.Resources.lefuras_be
        Me.DG1_CARDCODE.LinkObject = Nothing
        Me.DG1_CARDCODE.MenuUID = Nothing
        Me.DG1_CARDCODE.Name = "DG1_CARDCODE"
        Me.DG1_CARDCODE.ReadOnly = True
        Me.DG1_CARDCODE.Width = 80
        '
        'DG1_CARDNAME
        '
        Me.DG1_CARDNAME.DataPropertyName = "CARDNAME"
        Me.DG1_CARDNAME.HeaderText = "ÜP.neve"
        Me.DG1_CARDNAME.Name = "DG1_CARDNAME"
        Me.DG1_CARDNAME.ReadOnly = True
        Me.DG1_CARDNAME.Width = 200
        '
        'DG1_CRYSTAL
        '
        Me.DG1_CRYSTAL.DataPropertyName = "CRYSTAL"
        Me.DG1_CRYSTAL.HeaderText = "CRYSTAL"
        Me.DG1_CRYSTAL.Name = "DG1_CRYSTAL"
        Me.DG1_CRYSTAL.Visible = False
        '
        'DG1_CRYSTALNAME
        '
        Me.DG1_CRYSTALNAME.DataPropertyName = "CRYSTALNAME"
        Me.DG1_CRYSTALNAME.HeaderText = "Nyomt.formátum"
        Me.DG1_CRYSTALNAME.Name = "DG1_CRYSTALNAME"
        Me.DG1_CRYSTALNAME.Width = 160
        '
        'DG1_EMAILS
        '
        Me.DG1_EMAILS.DataPropertyName = "EMAILS"
        Me.DG1_EMAILS.HeaderText = "E-mail"
        Me.DG1_EMAILS.Name = "DG1_EMAILS"
        Me.DG1_EMAILS.ReadOnly = True
        Me.DG1_EMAILS.Width = 200
        '
        'DG1_FILE
        '
        Me.DG1_FILE.DataPropertyName = "FILE"
        DataGridViewCellStyle3.Padding = New System.Windows.Forms.Padding(11, 0, 0, 0)
        Me.DG1_FILE.DefaultCellStyle = DataGridViewCellStyle3
        Me.DG1_FILE.FormUID = Nothing
        Me.DG1_FILE.HeaderText = "Fájl"
        Me.DG1_FILE.Image = Global.IFSZ_AddOnBase.My.Resources.Resources.lefuras_be
        Me.DG1_FILE.LinkObject = Nothing
        Me.DG1_FILE.MenuUID = Nothing
        Me.DG1_FILE.Name = "DG1_FILE"
        Me.DG1_FILE.ReadOnly = True
        Me.DG1_FILE.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        '
        'DG1_MAIL_SUBJECT
        '
        Me.DG1_MAIL_SUBJECT.DataPropertyName = "MAIL_SUBJECT"
        Me.DG1_MAIL_SUBJECT.HeaderText = "Email tárgya"
        Me.DG1_MAIL_SUBJECT.Name = "DG1_MAIL_SUBJECT"
        '
        'DG1_MAIL_BODY
        '
        Me.DG1_MAIL_BODY.DataPropertyName = "MAIL_BODY"
        Me.DG1_MAIL_BODY.HeaderText = "Email szövegtörzse"
        Me.DG1_MAIL_BODY.Name = "DG1_MAIL_BODY"
        Me.DG1_MAIL_BODY.Width = 300
        '
        'DG1_EBIZTIP
        '
        Me.DG1_EBIZTIP.DataPropertyName = "EBIZTIP"
        Me.DG1_EBIZTIP.HeaderText = "EBIZTIP"
        Me.DG1_EBIZTIP.Name = "DG1_EBIZTIP"
        Me.DG1_EBIZTIP.Visible = False
        '
        'DG1_EBIZTIP_LANGVAL
        '
        Me.DG1_EBIZTIP_LANGVAL.DataPropertyName = "EBIZTIP_LANGVAL"
        Me.DG1_EBIZTIP_LANGVAL.HeaderText = "EBIZTIP_LANGVAL"
        Me.DG1_EBIZTIP_LANGVAL.Name = "DG1_EBIZTIP_LANGVAL"
        Me.DG1_EBIZTIP_LANGVAL.Visible = False
        '
        'DG1_EBIZTIP_MEAN
        '
        Me.DG1_EBIZTIP_MEAN.DataPropertyName = "EBIZTIP_MEAN"
        Me.DG1_EBIZTIP_MEAN.HeaderText = "eBiz típus"
        Me.DG1_EBIZTIP_MEAN.Name = "DG1_EBIZTIP_MEAN"
        Me.DG1_EBIZTIP_MEAN.ReadOnly = True
        Me.DG1_EBIZTIP_MEAN.Width = 120
        '
        'DG1_STATUS
        '
        Me.DG1_STATUS.DataPropertyName = "STATUS"
        Me.DG1_STATUS.HeaderText = "STATUS"
        Me.DG1_STATUS.Name = "DG1_STATUS"
        Me.DG1_STATUS.Visible = False
        '
        'DG1_STATUS_LANGVAL
        '
        Me.DG1_STATUS_LANGVAL.DataPropertyName = "STATUS_LANGVAL"
        Me.DG1_STATUS_LANGVAL.HeaderText = "STATUS_LANGVAL"
        Me.DG1_STATUS_LANGVAL.Name = "DG1_STATUS_LANGVAL"
        Me.DG1_STATUS_LANGVAL.Visible = False
        '
        'DG1_STATUS_MEAN
        '
        Me.DG1_STATUS_MEAN.DataPropertyName = "STATUS_MEAN"
        Me.DG1_STATUS_MEAN.HeaderText = "Státusz"
        Me.DG1_STATUS_MEAN.Name = "DG1_STATUS_MEAN"
        Me.DG1_STATUS_MEAN.ReadOnly = True
        Me.DG1_STATUS_MEAN.Width = 80
        '
        'DG1_SENTTS
        '
        Me.DG1_SENTTS.DataPropertyName = "SENTTS"
        Me.DG1_SENTTS.HeaderText = "Küld.időpont"
        Me.DG1_SENTTS.Name = "DG1_SENTTS"
        Me.DG1_SENTTS.ReadOnly = True
        '
        'IFSZ_DNET_EOH
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1030, 513)
        Me.Controls.Add(Me.PBx_T_PATH)
        Me.Controls.Add(Me.B_VISSZAVON)
        Me.Controls.Add(Me.B_TET_TOROL)
        Me.Controls.Add(Me.B_GENERAL_KULD)
        Me.Controls.Add(Me.B_GENERAL)
        Me.Controls.Add(Me.B_EMAILS)
        Me.Controls.Add(Me.B_KIVALASZT)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.T_PATH)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.T_STATUS)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.T_NOTE)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.T_SENTTS)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.T_DOCNUM)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.T_USERCODE)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.OK)
        Me.Controls.Add(Me.MEGSE)
        Me.Controls.Add(Me.T_PROGRESS)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Name = "IFSZ_DNET_EOH"
        Me.Text = "Küldési bizonylat"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.IFSZEOHViewBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PBx_T_PATH, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GridBeallitMenu.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents OK As Button
    Friend WithEvents MEGSE As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents T_USERCODE As TextBox
    Friend WithEvents T_DOCNUM As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents T_SENTTS As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents T_NOTE As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents T_STATUS As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents T_PATH As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents IFSZEOHViewBindingSource As BindingSource
    Friend WithEvents B_KIVALASZT As Button
    Friend WithEvents B_EMAILS As Button
    Friend WithEvents B_GENERAL As Button
    Friend WithEvents B_GENERAL_KULD As Button
    Friend WithEvents B_TET_TOROL As Button
    Friend WithEvents B_VISSZAVON As Button
    Friend WithEvents PBx_T_PATH As PictureBox
    Friend WithEvents ProgressBar1 As ProgressBar
    Friend WithEvents T_PROGRESS As TextBox
    Friend WithEvents GridBeallitMenu As ContextMenuStrip
    Friend WithEvents MnuGridBeallitSetFho As ToolStripMenuItem
    Friend WithEvents MnuGridBeallitSetMachine As ToolStripMenuItem
    Friend WithEvents MnuGridBeallitDelFho As ToolStripMenuItem
    Friend WithEvents MnuGridBeallitDelMachine As ToolStripMenuItem
    Friend WithEvents DG1_ID As DataGridViewTextBoxColumn
    Friend WithEvents DG1_EOH_ID As DataGridViewTextBoxColumn
    Friend WithEvents DG1_LINENUM As DataGridViewTextBoxColumn
    Friend WithEvents DG1_DOCTYPE As DataGridViewTextBoxColumn
    Friend WithEvents DG1_DOCTYPE_LANGVAL As DataGridViewTextBoxColumn
    Friend WithEvents DG1_DOCTYPE_MEAN As DataGridViewTextBoxColumn
    Friend WithEvents DG1_DOCENTRY As DataGridViewTextBoxColumn
    Friend WithEvents DG1_DOCNUM As TextAndImageColumn
    Friend WithEvents DG1_CARDCODE As TextAndImageColumn
    Friend WithEvents DG1_CARDNAME As DataGridViewTextBoxColumn
    Friend WithEvents DG1_CRYSTAL As DataGridViewTextBoxColumn
    Friend WithEvents DG1_CRYSTALNAME As DataGridViewTextBoxColumn
    Friend WithEvents DG1_EMAILS As DataGridViewTextBoxColumn
    Friend WithEvents DG1_FILE As TextAndImageColumn
    Friend WithEvents DG1_MAIL_SUBJECT As DataGridViewTextBoxColumn
    Friend WithEvents DG1_MAIL_BODY As DataGridViewTextBoxColumn
    Friend WithEvents DG1_EBIZTIP As DataGridViewTextBoxColumn
    Friend WithEvents DG1_EBIZTIP_LANGVAL As DataGridViewTextBoxColumn
    Friend WithEvents DG1_EBIZTIP_MEAN As DataGridViewTextBoxColumn
    Friend WithEvents DG1_STATUS As DataGridViewTextBoxColumn
    Friend WithEvents DG1_STATUS_LANGVAL As DataGridViewTextBoxColumn
    Friend WithEvents DG1_STATUS_MEAN As DataGridViewTextBoxColumn
    Friend WithEvents DG1_SENTTS As DataGridViewTextBoxColumn
End Class
