﻿Public Class IFSZ_Ebiz_Telepit

    Public Shared m_cardcode_select As String =
        " ocrd.""CardCode"" as CARDCODE, ocrd.""CardName"" as CARDNAME, case when ocrd.""BalanceFC"" = 0 then ocrd.""Balance"" else ocrd.""BalanceFC"" end as EGYENLEG, " +
        QueryResource.SQL_isnull("ocrd.""Address""", "''") + " " + QueryResource.SQL_Konkat + " N' ' + " + QueryResource.SQL_isnull("ocrd.""ZipCode""", "''") + " + N' ' + " + QueryResource.SQL_isnull("ocrd.""City""", "''") + " + N' ' + " + QueryResource.SQL_isnull("ocry.""Name""", "N''") + " as ADDRESS, " +
        QueryResource.SQL_isnull("ocrd.""MailAddres""", "''") + " " + QueryResource.SQL_Konkat + " N' ' + " + QueryResource.SQL_isnull("ocrd.""MailZipCod""", "''") + " + N' ' + " + QueryResource.SQL_isnull("ocrd.""MailCity""", "''") + " + N' ' + " + QueryResource.SQL_isnull("ocry2.""Name""", "N''") + " as ADDRESS2 " +
        " from OCRD left join ocry on ocrd.""Country"" = ocry.""Code"" left join ocry ocry2 on ocrd.""MailCountr"" = ocry2.""Code"" "

    Public Shared Function TelepitEbiz(ByRef p_telepit_e As Boolean, ByRef p_addon As IFSZ_Addon_Keret) As Boolean
        Dim l_eredmeny As Integer = -1

        Dim oRecordSet As SAPbobsCOM.Recordset

#If HANADB Then
        Try
            oRecordSet = p_addon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            oRecordSet.DoQuery("select 1 from ""@IFSZ_PARAMETERS"" where ""Name"" = N'EBIZINST'")
            If oRecordSet.RecordCount = 0 Then
                p_addon.SqlScript("insert into ""@IFSZ_PARAMETERS"" (""Code"", ""Name"", ""U_Value"", ""U_Comment"") values (N'EBIZINST', N'EBIZINST', 'N', N'eBiz modul telepíthető-e')")
            End If
        Catch ex As Exception
            MsgBox(ex.Message())
        Finally
            IFSZ_Globals.ReleaseObject(oRecordSet)
        End Try
#Else
        p_addon.SqlScript("if not exists(select 1 from [@IFSZ_PARAMETERS] where Name = N'EBIZINST') insert into [@IFSZ_PARAMETERS] (Code, Name, U_Value, U_Comment) values (N'EBIZINST', N'EBIZINST', 'N', N'eBiz modul telepíthető-e')")
#End If

        If Not p_addon.UserTableExists("IFSZ_EMAILACCOUNTS") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                p_addon.AddUDT("IFSZ_EMAILACCOUNTS", "Postafiók beállítások")
            End If
        End If
        If Not p_addon.UserFieldExists("@IFSZ_EMAILACCOUNTS", "NAME") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                p_addon.AddUDF("IFSZ_EMAILACCOUNTS", "NAME", "Név", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, 50, 50, Nothing, Nothing, Nothing)
            End If
        End If
        If Not p_addon.UserFieldExists("@IFSZ_EMAILACCOUNTS", "SMTP_SERVER") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                p_addon.AddUDF("IFSZ_EMAILACCOUNTS", "SMTP_SERVER", "SMTP szerver", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, 50, 50, Nothing, Nothing, Nothing)
            End If
        End If
        If Not p_addon.UserFieldExists("@IFSZ_EMAILACCOUNTS", "SMTP_PORT") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                p_addon.AddUDF("IFSZ_EMAILACCOUNTS", "SMTP_PORT", "SMTP port", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Numeric, SAPbobsCOM.BoFldSubTypes.st_None, 7, 7, Nothing, Nothing, Nothing)
            End If
        End If
        If Not p_addon.UserFieldExists("@IFSZ_EMAILACCOUNTS", "USERNAME") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                p_addon.AddUDF("IFSZ_EMAILACCOUNTS", "USERNAME", "Felhasználónév", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, 50, 50, Nothing, Nothing, Nothing)
            End If
        End If
        If Not p_addon.UserFieldExists("@IFSZ_EMAILACCOUNTS", "PASSWORD") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                p_addon.AddUDF("IFSZ_EMAILACCOUNTS", "PASSWORD", "Jelszó", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, 254, 254, Nothing, Nothing, Nothing)
            End If
        End If
        If Not p_addon.UserFieldExists("@IFSZ_EMAILACCOUNTS", "SSL") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                Dim l_vvs As New ArrayList(1)
                l_vvs.Add(New validvalue("I", "Igen"))
                l_vvs.Add(New validvalue("N", "Nem"))
                p_addon.AddUDF("IFSZ_EMAILACCOUNTS", "SSL", "SSL?", SAPbobsCOM.BoYesNoEnum.tYES, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, 1, 1, "I", l_vvs, Nothing)
            End If
        End If

        If Not p_addon.UserFieldExists("OUSR", "EMAILOUT") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                p_addon.AddUDF("OUSR", "EMAILOUT", "Kimenő postafiók", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, 50, 50, Nothing, Nothing, "IFSZ_EMAILACCOUNTS")
            End If
        End If

        If Not p_addon.UserTableExists("IFSZ_EMAILOUTBODY") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                p_addon.AddUDT("IFSZ_EMAILOUTBODY", "Kimenő e-mail sablonok")
            End If
        End If

        If Not p_addon.UserFieldExists("@IFSZ_EMAILOUTBODY", "DOCTYPE") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                Dim l_vvs As New ArrayList(2)
                l_vvs.Add(New validvalue("13", "Kimenő számla"))
                l_vvs.Add(New validvalue("14", "Kimenő Jóváírás"))
                l_vvs.Add(New validvalue("165", "Kimenő számla"))
                l_vvs.Add(New validvalue("15", "Szállítás"))
                l_vvs.Add(New validvalue("16", "Vevői visszáru"))
                l_vvs.Add(New validvalue("163", "Beszerzési helyesbítő számla "))
                l_vvs.Add(New validvalue("164", "Beszerzési hely szla vissza"))
                l_vvs.Add(New validvalue("166", "Ki.helyesbszla visszavonása"))
                l_vvs.Add(New validvalue("17", "Vevői rendelés"))
                l_vvs.Add(New validvalue("18", "Bejövő számla"))
                l_vvs.Add(New validvalue("19", "Beszerzési jóváírás "))
                l_vvs.Add(New validvalue("20", "Árubeérkezés"))
                l_vvs.Add(New validvalue("203", "Értékesítési előleg"))
                l_vvs.Add(New validvalue("204", "Beszerzési előleg"))
                l_vvs.Add(New validvalue("21", "Szállítói visszáru"))
                l_vvs.Add(New validvalue("22", "Megrendelés"))
                l_vvs.Add(New validvalue("23", "Ajánlat"))
                l_vvs.Add(New validvalue("59", "Anyagbevételezés"))
                l_vvs.Add(New validvalue("60", "Anyagkiadás"))
                l_vvs.Add(New validvalue("67", "Áttárolás"))
                p_addon.AddUDF("IFSZ_EMAILOUTBODY", "DOCTYPE", "Biz.tipus", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, 10, 10, "13", l_vvs, Nothing)
            End If
        End If
        If Not p_addon.UserFieldExists("@IFSZ_EMAILOUTBODY", "NAME") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                p_addon.AddUDF("IFSZ_EMAILOUTBODY", "NAME", "Sablon kód", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, 50, 50, Nothing, Nothing, Nothing)
            End If
        End If
        If Not p_addon.UserFieldExists("@IFSZ_EMAILOUTBODY", "SUBJECT") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                p_addon.AddUDF("IFSZ_EMAILOUTBODY", "SUBJECT", "Levél tárgya", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, 100, 100, Nothing, Nothing, Nothing)
            End If
        End If
        If Not p_addon.UserFieldExists("@IFSZ_EMAILOUTBODY", "BODY") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                p_addon.AddUDF("IFSZ_EMAILOUTBODY", "BODY", "Levél törzse", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Memo, SAPbobsCOM.BoFldSubTypes.st_None, 4000, 4000, Nothing, Nothing, Nothing)
            End If
        End If
        If Not p_addon.UserFieldExists("@IFSZ_EMAILOUTBODY", "LANG") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                p_addon.AddUDF("IFSZ_EMAILOUTBODY", "LANG", "Levél nyelve", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Numeric, SAPbobsCOM.BoFldSubTypes.st_None, 10, 10, Nothing, Nothing, Nothing)
            End If
        End If
        If Not p_addon.UserFieldExists("@IFSZ_EMAILOUTBODY", "DEFAULTEMAIL") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                Dim l_vvs As New ArrayList(1)
                l_vvs.Add(New validvalue("N", "Nem"))
                l_vvs.Add(New validvalue("Y", "Igen"))
                p_addon.AddUDF("IFSZ_EMAILOUTBODY", "DEFAULTEMAIL", "Alapértelmezett?", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, 1, 1, "N", l_vvs, Nothing)
            End If
        End If
        If Not p_addon.UserFieldExists("@IFSZ_EMAILOUTBODY", "ISHTML") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                Dim l_vvs As New ArrayList(1)
                l_vvs.Add(New validvalue("N", "Nem"))
                l_vvs.Add(New validvalue("Y", "Igen"))
                p_addon.AddUDF("IFSZ_EMAILOUTBODY", "ISHTML", "HTML", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, 1, 1, "N", l_vvs, Nothing)
            End If
        End If

        If Not p_addon.UserTableExists("IFSZ_CRD_EMAILBODY") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                p_addon.AddUDT("IFSZ_CRD_EMAILBODY", "Partner e-mail sablonjai")
            End If
        End If

        If Not p_addon.UserFieldExists("@IFSZ_CRD_EMAILBODY", "CARDCODE") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                p_addon.AddUDF("IFSZ_CRD_EMAILBODY", "CARDCODE", "ÜP.kód", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, 50, 50, Nothing, Nothing, Nothing)
            End If
        End If
        If Not p_addon.UserFieldExists("@IFSZ_CRD_EMAILBODY", "BODY") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                p_addon.AddUDF("IFSZ_CRD_EMAILBODY", "BODY", "Sablon kód", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, 50, 50, Nothing, Nothing, "IFSZ_EMAILOUTBODY")
            End If
        End If

        If Not p_addon.UserTableExists("IFSZ_EMAILOUTHEAD") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                p_addon.AddUDT("IFSZ_EMAILOUTHEAD", "Küldési bizonylat")
            End If
        End If

        If Not p_addon.UserFieldExists("@IFSZ_EMAILOUTHEAD", "DOCNUM") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                p_addon.AddUDF("IFSZ_EMAILOUTHEAD", "DOCNUM", "Bizonylatszám", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, 20, 20, Nothing, Nothing, Nothing)
            End If
        End If
        If Not p_addon.UserFieldExists("@IFSZ_EMAILOUTHEAD", "USERCODE") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                p_addon.AddUDF("IFSZ_EMAILOUTHEAD", "USERCODE", "Felhasználókód", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, 20, 20, Nothing, Nothing, Nothing)
            End If
        End If
        If Not p_addon.UserFieldExists("@IFSZ_EMAILOUTHEAD", "NOTE") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                p_addon.AddUDF("IFSZ_EMAILOUTHEAD", "NOTE", "Megjegyzés", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, 254, 254, Nothing, Nothing, Nothing)
            End If
        End If
        If Not p_addon.UserFieldExists("@IFSZ_EMAILOUTHEAD", "SENTTS") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                p_addon.AddUDF("IFSZ_EMAILOUTHEAD", "SENTTS", "Dátum", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Date, SAPbobsCOM.BoFldSubTypes.st_None, 20, 20, Nothing, Nothing, Nothing)
            End If
        End If
        If Not p_addon.UserFieldExists("@IFSZ_EMAILOUTHEAD", "STATUS") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                Dim l_vvs As New ArrayList(2)
                l_vvs.Add(New validvalue("R", "Rögzített"))
                l_vvs.Add(New validvalue("S", "Elküldött"))
                l_vvs.Add(New validvalue("C", "Visszavont"))
                p_addon.AddUDF("IFSZ_EMAILOUTHEAD", "STATUS", "Státusz", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, 1, 1, "R", l_vvs, Nothing)
            End If
        End If
        If Not p_addon.UserFieldExists("@IFSZ_EMAILOUTHEAD", "PATH") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                p_addon.AddUDF("IFSZ_EMAILOUTHEAD", "PATH", "Útvonal", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, 254, 254, Nothing, Nothing, Nothing)
            End If
        End If

        If Not p_addon.UserTableExists("IFSZ_EMAILOUTLINE") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                p_addon.AddUDT("IFSZ_EMAILOUTLINE", "Küldési bizonylat tétel")
            End If
        End If

        If Not p_addon.UserFieldExists("@IFSZ_EMAILOUTLINE", "EOH_ID") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                p_addon.AddUDF("IFSZ_EMAILOUTLINE", "EOH_ID", "Fej azon", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Numeric, SAPbobsCOM.BoFldSubTypes.st_None, 11, 11, Nothing, Nothing, Nothing)
            End If
        End If
        If Not p_addon.UserFieldExists("@IFSZ_EMAILOUTLINE", "LINENUM") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                p_addon.AddUDF("IFSZ_EMAILOUTLINE", "LINENUM", "Sorszám", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Numeric, SAPbobsCOM.BoFldSubTypes.st_None, 11, 11, Nothing, Nothing, Nothing)
            End If
        End If
        If Not p_addon.UserFieldExists("@IFSZ_EMAILOUTLINE", "DOCTYPE") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                p_addon.AddUDF("IFSZ_EMAILOUTLINE", "DOCTYPE", "Bizonylatfajta", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Numeric, SAPbobsCOM.BoFldSubTypes.st_None, 10, 10, Nothing, Nothing, Nothing)
            End If
        End If
        If Not p_addon.UserFieldExists("@IFSZ_EMAILOUTLINE", "DOCENTRY") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                p_addon.AddUDF("IFSZ_EMAILOUTLINE", "DOCENTRY", "Bizonylat ID", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Numeric, SAPbobsCOM.BoFldSubTypes.st_None, 11, 11, Nothing, Nothing, Nothing)
            End If
        End If
        If Not p_addon.UserFieldExists("@IFSZ_EMAILOUTLINE", "DOCNUM") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                p_addon.AddUDF("IFSZ_EMAILOUTLINE", "DOCNUM", "Bizonylatszám", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, 50, 50, Nothing, Nothing, Nothing)
            End If
        End If
        If Not p_addon.UserFieldExists("@IFSZ_EMAILOUTLINE", "CRYSTAL") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                p_addon.AddUDF("IFSZ_EMAILOUTLINE", "CRYSTAL", "Riport neve", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, 50, 50, Nothing, Nothing, Nothing)
            End If
        End If
        If Not p_addon.UserFieldExists("@IFSZ_EMAILOUTLINE", "MAIL_SUBJECT") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                p_addon.AddUDF("IFSZ_EMAILOUTLINE", "MAIL_SUBJECT", "Tárgy", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, 100, 100, Nothing, Nothing, Nothing)
            End If
        End If
        If Not p_addon.UserFieldExists("@IFSZ_EMAILOUTLINE", "MAIL_BODY") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                p_addon.AddUDF("IFSZ_EMAILOUTLINE", "MAIL_BODY", "Törzs", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Memo, SAPbobsCOM.BoFldSubTypes.st_None, 4000, 4000, Nothing, Nothing, Nothing)
            End If
        End If
        If Not p_addon.UserFieldExists("@IFSZ_EMAILOUTLINE", "FILE") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                p_addon.AddUDF("IFSZ_EMAILOUTLINE", "FILE", "Fájlnév", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, 254, 254, Nothing, Nothing, Nothing)
            End If
        End If
        If Not p_addon.UserFieldExists("@IFSZ_EMAILOUTLINE", "STATUS") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                Dim l_vvs As New ArrayList(2)
                l_vvs.Add(New validvalue("R", "Rögzített"))
                l_vvs.Add(New validvalue("S", "Elküldött"))
                l_vvs.Add(New validvalue("C", "Visszavont"))
                p_addon.AddUDF("IFSZ_EMAILOUTLINE", "STATUS", "Sor státusz", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, 1, 1, "R", l_vvs, Nothing)
            End If
        End If
        If Not p_addon.UserFieldExists("@IFSZ_EMAILOUTLINE", "SENTTS") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                p_addon.AddUDF("IFSZ_EMAILOUTLINE", "SENTTS", "Dátum", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Date, SAPbobsCOM.BoFldSubTypes.st_None, 20, 20, Nothing, Nothing, Nothing)
            End If
        End If
        If Not p_addon.UserFieldExists("@IFSZ_EMAILOUTLINE", "ISHTML") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                Dim l_vvs As New ArrayList(1)
                l_vvs.Add(New validvalue("N", "Nem"))
                l_vvs.Add(New validvalue("Y", "Igen"))
                p_addon.AddUDF("IFSZ_EMAILOUTLINE", "ISHTML", "HTML", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, 1, 1, "N", l_vvs, Nothing)
            End If
        End If
        If Not p_addon.UserFieldExists("@IFSZ_EMAILOUTLINE", "MD5_FILE") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                p_addon.AddUDF("IFSZ_EMAILOUTLINE", "MD5_FILE", "File MD5 Checksum", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, 254, 254, Nothing, Nothing, Nothing)
            End If
        End If
        If Not p_addon.UserFieldExists("@IFSZ_EMAILOUTLINE", "MD5_SIGNED") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                p_addon.AddUDF("IFSZ_EMAILOUTLINE", "MD5_SIGNED", "Signed PDF MD5 Checksum", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, 254, 254, Nothing, Nothing, Nothing)
            End If
        End If

        If Not p_addon.UserTableExists("IFSZ_EMAILOUTADDR") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                p_addon.AddUDT("IFSZ_EMAILOUTADDR", "Küldés címzettek")
            End If
        End If

        If Not p_addon.UserFieldExists("@IFSZ_EMAILOUTADDR", "EOL_ID") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                p_addon.AddUDF("IFSZ_EMAILOUTADDR", "EOL_ID", "Tétel azon", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Numeric, SAPbobsCOM.BoFldSubTypes.st_None, 11, 11, Nothing, Nothing, Nothing)
            End If
        End If
        If Not p_addon.UserFieldExists("@IFSZ_EMAILOUTADDR", "CNTCT_NAME") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                p_addon.AddUDF("IFSZ_EMAILOUTADDR", "CNTCT_NAME", "Név", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, 100, 100, Nothing, Nothing, Nothing)
            End If
        End If
        If Not p_addon.UserFieldExists("@IFSZ_EMAILOUTADDR", "CNTCT_EMAIL") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                p_addon.AddUDF("IFSZ_EMAILOUTADDR", "CNTCT_EMAIL", "Email", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, 100, 100, Nothing, Nothing, Nothing)
            End If
        End If

        If Not p_addon.UserFieldExists("OCPR", "EBIZNAME") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = CType(IFSZ_Globals.m_ParentAddOn, SBOAddOn).SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                p_addon.AddUDF("OCPR", "EBIZNAME", "E-biz címzett név", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, 100, 100, Nothing, Nothing, Nothing)
            End If
        End If

        If Not p_addon.UserFieldExists("OCRD", "EBIZTIP") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = CType(IFSZ_Globals.m_ParentAddOn, SBOAddOn).SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                Dim l_vvs As New ArrayList(3)
                l_vvs.Add(New validvalue("P", "Papír alapú"))
                l_vvs.Add(New validvalue("F", "Papír alapú - PDF"))
                l_vvs.Add(New validvalue("E", "Elektronikus - nem hitelesített PDF"))
                l_vvs.Add(New validvalue("H", "Elektronikus - hitelesített PDF"))
                p_addon.AddUDF("OCRD", "EBIZTIP", "eBiz Típus", SAPbobsCOM.BoYesNoEnum.tYES, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, 1, 1, "P", l_vvs, Nothing)
            End If
        End If

        If Not p_addon.UserFieldExists("OINV", "EBIZTIP") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = CType(IFSZ_Globals.m_ParentAddOn, SBOAddOn).SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                Dim l_vvs As New ArrayList(3)
                l_vvs.Add(New validvalue("P", "Papír alapú"))
                l_vvs.Add(New validvalue("F", "Papír alapú - PDF"))
                l_vvs.Add(New validvalue("E", "Elektronikus - nem hitelesített PDF"))
                l_vvs.Add(New validvalue("H", "Elektronikus - hitelesített PDF"))
                p_addon.AddUDF("OINV", "EBIZTIP", "eBiz Típus", SAPbobsCOM.BoYesNoEnum.tYES, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, 1, 1, "P", l_vvs, Nothing)
            End If
        End If

        If Not p_addon.UserFieldExists("@IFSZ_EMAILOUTLINE", "EBIZTIP") Then
            If Not p_telepit_e Then
                If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                l_eredmeny = CType(IFSZ_Globals.m_ParentAddOn, SBOAddOn).SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
            End If
            If l_eredmeny = 2 Then
                Return True  'Talán False-nak kellene lennie, de mindegy
            ElseIf l_eredmeny = 1 Then
                p_telepit_e = True
                Dim l_vvs As New ArrayList(3)
                l_vvs.Add(New validvalue("P", "Papír alapú"))
                l_vvs.Add(New validvalue("F", "Papír alapú - PDF"))
                l_vvs.Add(New validvalue("E", "Elektronikus - nem hitelesített PDF"))
                l_vvs.Add(New validvalue("H", "Elektronikus - hitelesített PDF"))
                p_addon.AddUDF("@IFSZ_EMAILOUTLINE", "EBIZTIP", "eBiz Típus", SAPbobsCOM.BoYesNoEnum.tYES, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, 1, 1, "P", l_vvs, Nothing)
            End If
        End If

#If HANADB Then
        Try
            oRecordSet = p_addon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            oRecordSet.DoQuery("select 1 from ""@IFSZ_PARAMETERS"" where ""Name"" = N'EBIZPATH'")
            If oRecordSet.RecordCount = 0 Then
                p_addon.SqlScript("insert into ""@IFSZ_PARAMETERS"" (""Code"", ""Name"", ""U_Value"", ""U_Comment"") values (N'EBIZPATH', N'EBIZPATH', '', N'Kimenő nyomtatási képek fájl generálási helye')")
                p_addon.SqlScript("insert into ""@IFSZ_PARAMETERS"" (""Code"", ""Name"", ""U_Value"", ""U_Comment"") values (N'EBIZTEMPLMOD', N'EBIZTEMPLMOD', 'I', N'Email sablon által megadott tárgy és szövegtörzs módosítható-e kiküldés előtt?')")
                p_addon.SqlScript("insert into ""@IFSZ_PARAMETERS"" (""Code"", ""Name"", ""U_Value"", ""U_Comment"") values (N'EBIZSRV', N'EBIZSRV', '', N'Hitelesítést végző szolgáltatás címe')")
                p_addon.SqlScript("insert into ""@IFSZ_PARAMETERS"" (""Code"", ""Name"", ""U_Value"", ""U_Comment"") values (N'EBIZATC', N'EBIZATC', 'N', N'Csatoljuk-e a pdf-hez a számlához csatolt dolgokat?')")
            End If
        Catch ex As Exception
            MsgBox(ex.Message())
        Finally
            IFSZ_Globals.ReleaseObject(oRecordSet)
        End Try
        Try
            oRecordSet = p_addon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            oRecordSet.DoQuery("select 1 from ""@IFSZ_PARAMETERS"" where ""Name"" = N'EBIZRRR'")
            If oRecordSet.RecordCount = 0 Then
                p_addon.SqlScript("insert into ""@IFSZ_PARAMETERS"" (""Code"", ""Name"", ""U_Value"", ""U_Comment"") values (N'EBIZRRR', N'EBIZRRR', 'I', N'Küldjünk-e visszaigazolási kérelmet az email-lel? (I=Igen)')")
                p_addon.SqlScript("insert into ""@IFSZ_PARAMETERS"" (""Code"", ""Name"", ""U_Value"", ""U_Comment"") values (N'EBIZDSN', N'EBIZDSN', 'I', N'Küldjünk-e megérkezésről visszaigazolási kérelmet az email-lel? (I=Igen)')")
            End If
        Catch ex As Exception
            MsgBox(ex.Message())
        Finally
            IFSZ_Globals.ReleaseObject(oRecordSet)
        End Try
        Try
            oRecordSet = p_addon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            oRecordSet.DoQuery("select 1 from ""@IFSZ_PARAMETERS"" where ""Name"" = N'EBIZCC'")
            If oRecordSet.RecordCount = 0 Then
                p_addon.SqlScript("insert into ""@IFSZ_PARAMETERS"" (""Code"", ""Name"", ""U_Value"", ""U_Comment"") values (N'EBIZCC', N'EBIZCC', '', N'Az eBiz-zel elküldött levelek ""Másolat"" mezőjébe ez kerül')")
                p_addon.SqlScript("insert into ""@IFSZ_PARAMETERS"" (""Code"", ""Name"", ""U_Value"", ""U_Comment"") values (N'EBIZBCC', N'EBIZBCC', '', N'Az eBiz-zel elküldött levelek ""Titkos másolat"" mezőjébe ez kerül')")
            End If
        Catch ex As Exception
            MsgBox(ex.Message())
        Finally
            IFSZ_Globals.ReleaseObject(oRecordSet)
        End Try
#Else
        p_addon.SqlScript("if not exists(select 1 from [@IFSZ_PARAMETERS] where Name = N'EBIZPATH') insert into [@IFSZ_PARAMETERS] (Code, Name, U_Value, U_Comment) values (N'EBIZPATH', N'EBIZPATH', '', N'Kimenő nyomtatási képek fájl generálási helye')")
        p_addon.SqlScript("if not exists(select 1 from [@IFSZ_PARAMETERS] where Name = N'EBIZTEMPLMOD') insert into [@IFSZ_PARAMETERS] (Code, Name, U_Value, U_Comment) values (N'EBIZTEMPLMOD', N'EBIZTEMPLMOD', 'I', N'Email sablon által megadott tárgy és szövegtörzs módosítható-e kiküldés előtt?')")
        p_addon.SqlScript("if not exists(select 1 from [@IFSZ_PARAMETERS] where Name = N'EBIZSRV') insert into [@IFSZ_PARAMETERS] (Code, Name, U_Value, U_Comment) values (N'EBIZSRV', N'EBIZSRV', '', N'Hitelesítést végző szolgáltatás címe')")
        p_addon.SqlScript("if not exists(select 1 from [@IFSZ_PARAMETERS] where Name = N'EBIZATC') insert into [@IFSZ_PARAMETERS] (Code, Name, U_Value, U_Comment) values (N'EBIZATC', N'EBIZATC', 'N', N'Csatoljuk-e a pdf-hez a számlához csatolt dolgokat?')")
        p_addon.SqlScript("if not exists(select 1 from [@IFSZ_PARAMETERS] where Name = N'EBIZRRR') insert into [@IFSZ_PARAMETERS] (Code, Name, U_Value, U_Comment) values (N'EBIZRRR', N'EBIZRRR', 'I', N'Küldjünk-e olvasási visszaigazolási kérelmet az email-lel? (I=Igen)')")
        p_addon.SqlScript("if not exists(select 1 from [@IFSZ_PARAMETERS] where Name = N'EBIZDSN') insert into [@IFSZ_PARAMETERS] (Code, Name, U_Value, U_Comment) values (N'EBIZDSN', N'EBIZDSN', 'I', N'Küldjünk-e megérkezésről visszaigazolási kérelmet az email-lel? (I=Igen)')")
        p_addon.SqlScript("if not exists(select 1 from [@IFSZ_PARAMETERS] where Name = N'EBIZCC') insert into [@IFSZ_PARAMETERS] (Code, Name, U_Value, U_Comment) values (N'EBIZCC', N'EBIZCC', '', N'Az eBiz-zel elküldött levelek ""Másolat"" mezőjébe ez kerül')")
        p_addon.SqlScript("if not exists(select 1 from [@IFSZ_PARAMETERS] where Name = N'EBIZBCC') insert into [@IFSZ_PARAMETERS] (Code, Name, U_Value, U_Comment) values (N'EBIZBCC', N'EBIZBCC', '', N'Az eBiz-zel elküldött levelek ""Titkos másolat"" mezőjébe ez kerül')")
#End If

        Try
            oRecordSet = p_addon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            oRecordSet.DoQuery("select 1 from ""@IFSZ_PARAMETERS"" where ""Name"" = N'EBIZPATH_DOMAIN'")
            If oRecordSet.RecordCount = 0 Then
                p_addon.SqlScript("insert into ""@IFSZ_PARAMETERS"" (""Code"", ""Name"", ""U_Value"", ""U_Comment"") values (N'EBIZPATH_DOMAIN', N'EBIZPATH_DOMAIN', '', N'Az eBiz útvonal eléréséhez használt domain')")
                p_addon.SqlScript("insert into ""@IFSZ_PARAMETERS"" (""Code"", ""Name"", ""U_Value"", ""U_Comment"") values (N'EBIZPATH_USER', N'EBIZPATH_USER', '', N'Az eBiz útvonal eléréséhez használt felhasználónév')")
                p_addon.SqlScript("insert into ""@IFSZ_PARAMETERS"" (""Code"", ""Name"", ""U_Value"", ""U_Comment"") values (N'EBIZPATH_PASSWORD', N'EBIZPATH_PASSWORD', '', N'Az eBiz útvonal eléréséhez használt jelszó')")
            End If
        Catch ex As Exception
            MsgBox(ex.Message())
        Finally
            IFSZ_Globals.ReleaseObject(oRecordSet)
        End Try
        Try
            oRecordSet = p_addon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            oRecordSet.DoQuery("select 1 from ""@IFSZ_PARAMETERS"" where ""Name"" = N'EBIZXMLPATH'")
            If oRecordSet.RecordCount = 0 Then
                p_addon.SqlScript("insert into ""@IFSZ_PARAMETERS"" (""Code"", ""Name"", ""U_Value"", ""U_Comment"") values (N'EBIZXMLPATH', N'EBIZXMLPATH', '', N'Kimenő nyomtatási képek online számla xml folder')")
            End If
        Catch ex As Exception
            MsgBox(ex.Message())
        Finally
            IFSZ_Globals.ReleaseObject(oRecordSet)
        End Try
        Try
            oRecordSet = p_addon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            oRecordSet.DoQuery("select ""U_Value"" from ""@IFSZ_PARAMETERS"" where ""Name"" = N'EBIZJOGMOD'")
            If oRecordSet.RecordCount = 0 Then
                p_addon.SqlScript("insert into ""@IFSZ_PARAMETERS"" (""Code"", ""Name"", ""U_Value"", ""U_Comment"") values (N'EBIZJOGMOD', N'EBIZJOGMOD', 'ADDON', N'Milyen módszerű jogosultságkezelés legyen. (ADDON, SBO)')")
                IFSZ_Addon.m_JogSboUserPerm = False
            Else
                Dim l_ertek As String = oRecordSet.Fields.Item(0).Value.ToString()
                If l_ertek IsNot Nothing AndAlso (l_ertek.ToUpper() = "SBO" OrElse l_ertek.ToUpper() = "SB1" OrElse l_ertek.ToUpper() = "SAP") Then
                    IFSZ_Addon.m_JogSboUserPerm = True
                Else
                    IFSZ_Addon.m_JogSboUserPerm = False
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message())
        Finally
            IFSZ_Globals.ReleaseObject(oRecordSet)
        End Try

        p_addon.AddFunction("F_EOA", "Postafiókok", "IFSZ_EOA", "Kimenő levélküldés")
        p_addon.AddFunction("F_EOB", "E-mail sablonok", "IFSZ_EOB", "Kimenő levélküldés")
        p_addon.AddFunction("F_EOH", "Küldési bizonylat", "IFSZ_EOH", "Kimenő levélküldés")
        p_addon.AddFunction("F_EOHLIS", "Küldési bizonylat lista", "IFSZ_EOHLIS", "Kimenő levélküldés")
        p_addon.AddFunction("F_SZLKIV", "Bizonylatok listája", "IFSZ_SZLAKIV", "Kimenő levélküldés")

        '9.3.8 - 9.3.9: A jelszó mező hossza megnövekedett, mert bevezettük a titkosítást
        'Dim oRecordSet As SAPbobsCOM.Recordset
        Try
            oRecordSet = p_addon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            oRecordSet.DoQuery("select 1 from CUFD where ""TableID"" = N'@IFSZ_EMAILACCOUNTS' and ""AliasID"" = N'PASSWORD' and ""SizeID"" = 50")
            If oRecordSet.RecordCount > 0 Then
                IFSZ_Globals.ReleaseObject(oRecordSet)
                If Not p_telepit_e Then
                    If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                    l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
                End If
                If l_eredmeny = 2 Then
                    Return True  'Talán False-nak kellene lennie, de mindegy
                ElseIf l_eredmeny = 1 Then
                    p_telepit_e = True
                    'Ez csak aktualizálni fogja
                    p_addon.AddUDF("IFSZ_EMAILACCOUNTS", "PASSWORD", "Jelszó", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, 254, 254, Nothing, Nothing, Nothing)
                    'És át is állítjuk a jelszavakat
                    oRecordSet = p_addon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                    oRecordSet.DoQuery("select ""Code"", U_PASSWORD from ""@IFSZ_EMAILACCOUNTS""")
                    If oRecordSet.RecordCount > 0 Then
                        While Not oRecordSet.EoF
                            If oRecordSet.Fields.Item("U_PASSWORD").Value.ToString() <> "" Then
                                p_addon.SqlScript("update ""@IFSZ_EMAILACCOUNTS"" set U_PASSWORD = " + IFSZ_Globals.SQLConstantPrepare(IFSZ_EMAILACCOUNTS.JelszoKodol(oRecordSet.Fields.Item("U_PASSWORD").Value.ToString())) + " where ""Code"" = " + IFSZ_Globals.SQLConstantPrepare(oRecordSet.Fields.Item("Code").Value.ToString()))
                            End If
                            oRecordSet.MoveNext()
                        End While
                    End If
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message())
        Finally
            IFSZ_Globals.ReleaseObject(oRecordSet)
        End Try

        '9.3.13 email body meghosszabbodott
        Try
            oRecordSet = p_addon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            oRecordSet.DoQuery("select 1 from CUFD where ""TableID"" = N'@IFSZ_EMAILOUTLINE' and ""AliasID"" = N'MAIL_BODY' and ""TypeID"" <> 'M'")
            If oRecordSet.RecordCount > 0 Then
                IFSZ_Globals.ReleaseObject(oRecordSet)
                If Not p_telepit_e Then
                    If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                    l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
                End If
                If l_eredmeny = 2 Then
                    Return True  'Talán False-nak kellene lennie, de mindegy
                ElseIf l_eredmeny = 1 Then
                    p_telepit_e = True
                    'Tempet hoz létre
                    p_addon.AddUDF("IFSZ_EMAILOUTBODY", "BODY_TEMP", "Levél törzse", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Memo, SAPbobsCOM.BoFldSubTypes.st_None, 4000, 4000, Nothing, Nothing, Nothing)
                    p_addon.AddUDF("IFSZ_EMAILOUTLINE", "MAIL_BODY_TEMP", "Törzs", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Memo, SAPbobsCOM.BoFldSubTypes.st_None, 4000, 4000, Nothing, Nothing, Nothing)
                    'Átmásoljuk
                    oRecordSet = p_addon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                    oRecordSet.DoQuery("update ""@IFSZ_EMAILOUTBODY"" set U_BODY_TEMP = U_BODY")
                    oRecordSet.DoQuery("update ""@IFSZ_EMAILOUTLINE"" set U_MAIL_BODY_TEMP = U_MAIL_BODY")
                    IFSZ_Globals.ReleaseObject(oRecordSet)
                    'Eredetit eldobja
                    p_addon.RemoveUDF("IFSZ_EMAILOUTBODY", "BODY")
                    p_addon.RemoveUDF("IFSZ_EMAILOUTLINE", "MAIL_BODY")
                    'Új típussal létrehozzuk
                    p_addon.AddUDF("IFSZ_EMAILOUTBODY", "BODY", "Levél törzse", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Memo, SAPbobsCOM.BoFldSubTypes.st_None, 4000, 4000, Nothing, Nothing, Nothing)
                    p_addon.AddUDF("IFSZ_EMAILOUTLINE", "MAIL_BODY", "Törzs", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Memo, SAPbobsCOM.BoFldSubTypes.st_None, 4000, 4000, Nothing, Nothing, Nothing)
                    'Visszamásoljuk
                    oRecordSet = p_addon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                    oRecordSet.DoQuery("update ""@IFSZ_EMAILOUTBODY"" set U_BODY = U_BODY_TEMP")
                    oRecordSet.DoQuery("update ""@IFSZ_EMAILOUTLINE"" set U_MAIL_BODY = U_MAIL_BODY_TEMP")
                    IFSZ_Globals.ReleaseObject(oRecordSet)
                    'Tempet eldobja
                    p_addon.RemoveUDF("IFSZ_EMAILOUTBODY", "BODY_TEMP")
                    p_addon.RemoveUDF("IFSZ_EMAILOUTLINE", "MAIL_BODY_TEMP")
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message())
        Finally
            IFSZ_Globals.ReleaseObject(oRecordSet)
        End Try

        '9.3.16 FILE meghosszabbodott
        Try
            oRecordSet = p_addon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            oRecordSet.DoQuery("select 1 from CUFD where ""TableID"" = N'@IFSZ_EMAILOUTLINE' and ""AliasID"" = N'FILE' and ""SizeID"" <> 254")
            If oRecordSet.RecordCount > 0 Then
                IFSZ_Globals.ReleaseObject(oRecordSet)
                If Not p_telepit_e Then
                    If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                    l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
                End If
                If l_eredmeny = 2 Then
                    Return True  'Talán False-nak kellene lennie, de mindegy
                ElseIf l_eredmeny = 1 Then
                    p_telepit_e = True
                    'Ez csak aktualizálni fogja
                    p_addon.AddUDF("IFSZ_EMAILOUTLINE", "FILE", "Fájlnév", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, 254, 254, Nothing, Nothing, Nothing)
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message())
        Finally
            IFSZ_Globals.ReleaseObject(oRecordSet)
        End Try

        '9.3.18 Új paraméterek
        Try
            oRecordSet = p_addon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            oRecordSet.DoQuery("select 1 from ""@IFSZ_PARAMETERS"" where ""Name"" = N'EBIZADDRMOD'")
            If oRecordSet.RecordCount = 0 Then
                p_addon.SqlScript("insert into ""@IFSZ_PARAMETERS"" (""Code"", ""Name"", ""U_Value"", ""U_Comment"") values (N'EBIZADDRMOD', N'EBIZADDRMOD', 'I', N'eBiz levélküldésnél címzettet lehet-e módosítani')")
                p_addon.SqlScript("insert into ""@IFSZ_PARAMETERS"" (""Code"", ""Name"", ""U_Value"", ""U_Comment"") values (N'EBIZPRINTLAYOUTMOD', N'EBIZPRINTLAYOUTMOD', 'I', N'eBiz levélküldésnél a nyomtatási kép formátumát lehet-e módosítani')")
                p_addon.SqlScript("insert into ""@IFSZ_PARAMETERS"" (""Code"", ""Name"", ""U_Value"", ""U_Comment"") values (N'EBIZFILENAME', N'EBIZFILENAME', '', N'eBiz generált pdf fájl nevének formátuma')")
                'A szerepeket is felvesszük
                oRecordSet.DoQuery("select ""Code"" from ""@IFSZ_ROLES"" where ""Name"" = N'EBIZADDRMOD'")
                If oRecordSet.RecordCount = 0 Then
                    Dim l_rolecode As Integer
#If HANADB Then
                oRecordSet.DoQuery("select " + QueryResource.SQL_isnull("MAX(cast(""Code"" as int))", "0") + "+1 from ""@IFSZ_ROLES"" where ""Code"" like_regexpr '^\s*[0-9]+\s*$'")
#Else
                    oRecordSet.DoQuery("select isnull(MAX(cast(code as int)), 0)+1 from [@IFSZ_ROLES] where isnumeric(code) = 1")
#End If
                    If oRecordSet.RecordCount > 0 Then
                        l_rolecode = oRecordSet.Fields.Item(0).Value
                        oRecordSet.DoQuery("INSERT INTO ""@IFSZ_ROLES""(""Code"", ""Name"", ""U_IsValid"", ""U_Comment"") " +
                                       "VALUES(" + IFSZ_Globals.SQLConstantPrepare(l_rolecode.ToString().PadLeft(8, "0")) + ", N'EBIZADDRMOD','Y', N'eBiz levélküldésnél címzettet lehet-e módosítani')")
                    End If
                End If

                oRecordSet.DoQuery("select ""Code"" from ""@IFSZ_ROLES"" where ""Name"" = N'EBIZPRINTLAYOUTMOD'")
                If oRecordSet.RecordCount = 0 Then
                    Dim l_rolecode As Integer
#If HANADB Then
                oRecordSet.DoQuery("select " + QueryResource.SQL_isnull("MAX(cast(""Code"" as int))", "0") + "+1 from ""@IFSZ_ROLES"" where ""Code"" like_regexpr '^\s*[0-9]+\s*$'")
#Else
                    oRecordSet.DoQuery("select isnull(MAX(cast(code as int)), 0)+1 from [@IFSZ_ROLES] where isnumeric(code) = 1")
#End If
                    If oRecordSet.RecordCount > 0 Then
                        l_rolecode = oRecordSet.Fields.Item(0).Value
                        oRecordSet.DoQuery("INSERT INTO ""@IFSZ_ROLES""(""Code"", ""Name"", ""U_IsValid"", ""U_Comment"") " +
                                       "VALUES(" + IFSZ_Globals.SQLConstantPrepare(l_rolecode.ToString().PadLeft(8, "0")) + ", N'EBIZPRINTLAYOUTMOD','Y', N'eBiz levélküldésnél a nyomtatási kép formátumát lehet-e módosítani')")
                    End If
                End If

                oRecordSet.DoQuery("select ""Code"" from ""@IFSZ_ROLES"" where ""Name"" = N'EBIZTEMPLMOD'")
                If oRecordSet.RecordCount = 0 Then
                    Dim l_rolecode As Integer
#If HANADB Then
                oRecordSet.DoQuery("select " + QueryResource.SQL_isnull("MAX(cast(""Code"" as int))", "0") + "+1 from ""@IFSZ_ROLES"" where ""Code"" like_regexpr '^\s*[0-9]+\s*$'")
#Else
                    oRecordSet.DoQuery("select isnull(MAX(cast(code as int)), 0)+1 from [@IFSZ_ROLES] where isnumeric(code) = 1")
#End If
                    If oRecordSet.RecordCount > 0 Then
                        l_rolecode = oRecordSet.Fields.Item(0).Value
                        oRecordSet.DoQuery("INSERT INTO ""@IFSZ_ROLES""(""Code"", ""Name"", ""U_IsValid"", ""U_Comment"") " +
                                       "VALUES(" + IFSZ_Globals.SQLConstantPrepare(l_rolecode.ToString().PadLeft(8, "0")) + ", N'EBIZTEMPLMOD','Y', N'eBiz levélküldésnél a sablonszöveget lehet-e módosítani')")
                    End If
                End If

            End If
        Catch ex As Exception
            MsgBox(ex.Message())
        Finally
            IFSZ_Globals.ReleaseObject(oRecordSet)
        End Try

        '9.3.20 Új paraméterek
        Try
            oRecordSet = p_addon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            oRecordSet.DoQuery("select 1 from ""@IFSZ_PARAMETERS"" where ""Name"" = N'EBIZARCH'")
            If oRecordSet.RecordCount = 0 Then
                p_addon.SqlScript("insert into ""@IFSZ_PARAMETERS"" (""Code"", ""Name"", ""U_Value"", ""U_Comment"") values (N'EBIZARCH', N'EBIZARCH', '', N'eBiz archiv adatbázis')")
            End If
            oRecordSet.DoQuery("select 1 from ""@IFSZ_PARAMETERS"" where ""Name"" = N'EBIZARCHFRQ'")
            If oRecordSet.RecordCount = 0 Then
                p_addon.SqlScript("insert into ""@IFSZ_PARAMETERS"" (""Code"", ""Name"", ""U_Value"", ""U_Comment"") values (N'EBIZARCHFRQ', N'EBIZARCHFRQ', '', N'eBiz archiv adatbázis ellenőrzés percenként')")
                p_addon.SqlScript("insert into ""@IFSZ_PARAMETERS"" (""Code"", ""Name"", ""U_Value"", ""U_Comment"") values (N'EBIZARCHCHK', N'EBIZARCHCHK', '', N'eBiz archiv adatbázis fájlok ellenőrzése')")
            End If
        Catch ex As Exception
            MsgBox(ex.Message())
        Finally
            IFSZ_Globals.ReleaseObject(oRecordSet)
        End Try

        '9.3.22 Az emailoutline.u_docnum karakteres lehet, korábban numerikus volt
        Try
            oRecordSet = p_addon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            oRecordSet.DoQuery("select 1 from CUFD where ""TableID"" = N'@IFSZ_EMAILOUTLINE' and ""AliasID"" = N'DOCNUM' and ""TypeID"" <> 'A'")
            If oRecordSet.RecordCount > 0 Then
                IFSZ_Globals.ReleaseObject(oRecordSet)
                If Not p_telepit_e Then
                    If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                    l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
                End If
                If l_eredmeny = 2 Then
                    Return True  'Talán False-nak kellene lennie, de mindegy
                ElseIf l_eredmeny = 1 Then
                    p_telepit_e = True
                    'Tempet hoz létre
                    p_addon.AddUDF("IFSZ_EMAILOUTLINE", "DOCNUM_TEMP", "Bizonylatszám", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, 50, 50, Nothing, Nothing, Nothing)
                    'Átmásoljuk
                    oRecordSet = p_addon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                    oRecordSet.DoQuery("update ""@IFSZ_EMAILOUTLINE"" set U_DOCNUM_TEMP = cast(U_DOCNUM as nvarchar)")
                    IFSZ_Globals.ReleaseObject(oRecordSet)
                    'Eredetit eldobja
                    p_addon.RemoveUDF("IFSZ_EMAILOUTLINE", "DOCNUM")
                    'Új típussal létrehozzuk
                    p_addon.AddUDF("IFSZ_EMAILOUTLINE", "DOCNUM", "Bizonylatszám", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, 50, 50, Nothing, Nothing, Nothing)
                    'Visszamásoljuk
                    oRecordSet = p_addon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                    oRecordSet.DoQuery("update ""@IFSZ_EMAILOUTLINE"" set U_DOCNUM = U_DOCNUM_TEMP")
                    IFSZ_Globals.ReleaseObject(oRecordSet)
                    'Tempet eldobja
                    p_addon.RemoveUDF("IFSZ_EMAILOUTLINE", "DOCNUM_TEMP")
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message())
        Finally
            IFSZ_Globals.ReleaseObject(oRecordSet)
        End Try

        'Az emailoutline.u_doctype lehetséges értékei bővülnek
        Try
            oRecordSet = p_addon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            oRecordSet.DoQuery("select 1 from CUFD join UFD1 on cufd.""TableID"" = ufd1.""TableID"" and cufd.""FieldID"" = ufd1.""FieldID"" and ufd1.""FldValue"" = '203' where cufd.""TableID"" = N'@IFSZ_EMAILOUTBODY' and cufd.""AliasID"" = N'DOCTYPE'")
            If oRecordSet.RecordCount = 0 Then
                IFSZ_Globals.ReleaseObject(oRecordSet)
                If Not p_telepit_e Then
                    If Not IFSZ_Ebiz_Telepit.CheckTelepitJog(p_addon) Then Return False
                    l_eredmeny = IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ AddOn. Telepítsük?", 2, "Igen", "Nem")
                End If
                If l_eredmeny = 2 Then
                    Return True  'Talán False-nak kellene lennie, de mindegy
                ElseIf l_eredmeny = 1 Then
                    p_telepit_e = True
                    'Tempet hoz létre
                    p_addon.AddUDF("IFSZ_EMAILOUTBODY", "DOCTYPE_TEMP", "Biz.tipus", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, 10, 10, Nothing, Nothing, Nothing)
                    'Átmásoljuk
                    oRecordSet = p_addon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                    oRecordSet.DoQuery("update ""@IFSZ_EMAILOUTBODY"" set U_DOCTYPE_TEMP = U_DOCTYPE")
                    IFSZ_Globals.ReleaseObject(oRecordSet)
                    'Eredetit eldobja
                    p_addon.RemoveUDF("IFSZ_EMAILOUTBODY", "DOCTYPE")
                    'Új típussal létrehozzuk
                    Dim l_vvs As New ArrayList(2)
                    l_vvs.Add(New validvalue("13", "Kimenő számla"))
                    l_vvs.Add(New validvalue("14", "Kimenő Jóváírás"))
                    l_vvs.Add(New validvalue("165", "Kimenő számla"))
                    l_vvs.Add(New validvalue("15", "Szállítás"))
                    l_vvs.Add(New validvalue("16", "Vevői visszáru"))
                    l_vvs.Add(New validvalue("163", "Beszerzési helyesbítő számla "))
                    l_vvs.Add(New validvalue("164", "Beszerzési hely szla vissza"))
                    l_vvs.Add(New validvalue("166", "Ki.helyesbszla visszavonása"))
                    l_vvs.Add(New validvalue("17", "Vevői rendelés"))
                    l_vvs.Add(New validvalue("18", "Bejövő számla"))
                    l_vvs.Add(New validvalue("19", "Beszerzési jóváírás "))
                    l_vvs.Add(New validvalue("20", "Árubeérkezés"))
                    l_vvs.Add(New validvalue("203", "Értékesítési előleg"))
                    l_vvs.Add(New validvalue("204", "Beszerzési előleg"))
                    l_vvs.Add(New validvalue("21", "Szállítói visszáru"))
                    l_vvs.Add(New validvalue("22", "Megrendelés"))
                    l_vvs.Add(New validvalue("23", "Ajánlat"))
                    l_vvs.Add(New validvalue("59", "Anyagbevételezés"))
                    l_vvs.Add(New validvalue("60", "Anyagkiadás"))
                    l_vvs.Add(New validvalue("67", "Áttárolás"))
                    p_addon.AddUDF("IFSZ_EMAILOUTBODY", "DOCTYPE", "Biz.tipus", SAPbobsCOM.BoYesNoEnum.tNO, SAPbobsCOM.BoFieldTypes.db_Alpha, SAPbobsCOM.BoFldSubTypes.st_None, 10, 10, "13", l_vvs, Nothing)
                    'Visszamásoljuk
                    oRecordSet = p_addon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                    oRecordSet.DoQuery("update ""@IFSZ_EMAILOUTBODY"" set U_DOCTYPE = U_DOCTYPE_TEMP")
                    IFSZ_Globals.ReleaseObject(oRecordSet)
                    'Tempet eldobja
                    p_addon.RemoveUDF("IFSZ_EMAILOUTBODY", "DOCTYPE_TEMP")
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message())
        Finally
            IFSZ_Globals.ReleaseObject(oRecordSet)
        End Try

        Return True

    End Function

    Private Shared Function CheckTelepitJog(ByRef p_addon As IFSZ_Addon_Keret) As Boolean
        Dim oRecordSet As SAPbobsCOM.Recordset
        oRecordSet = p_addon.SboCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        'Superuser-e
        oRecordSet.DoQuery(QueryResource.GetQuery("Base_IFSZ_AddOn_SBO", "ousr1", IFSZ_Globals.GetUserID))
        If oRecordSet.RecordCount <> 0 AndAlso oRecordSet.Fields.Item(0).Value.ToString() = "Y" Then
            'Paraméter engedi-e
            oRecordSet.DoQuery("select count(9) from ""@IFSZ_PARAMETERS"" where ""Name"" = 'EBIZINST' and upper(""U_Value"") in ('I', 'Y')")
            If oRecordSet.RecordCount <> 0 AndAlso oRecordSet.Fields.Item(0).Value > 0 Then
                Return True
            End If

        End If

        IFSZ_Globals.m_ParentAddOn.SboApplication.MessageBox("Még nincs, vagy nincs teljesen telepítve az IFSZ eBiz AddOn. Kérem, szóljon a rendszergazdának. Az AddOn befejezi futását")
        Return False

    End Function

End Class
