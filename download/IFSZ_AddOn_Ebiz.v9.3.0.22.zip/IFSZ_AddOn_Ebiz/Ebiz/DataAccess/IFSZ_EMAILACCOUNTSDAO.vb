﻿'----------------------------------------------------------------------------'
'GENERÁLT FÁJL!!!!
'A konstruktor "End_Sub"-jáig ne módosíts, mert az felül lesz írva!!!!!!!!!!
'----------------------------------------------------------------------------'
'Generálva: 2021.01.23
'DataAccessGenerator2 mssql számára. Verzió: 1.1.13.0
'
'dataaccessgenerator2 mssql xml EMAILOUT C:\svn\gergo\modulok\IFSZ_AddOn_Ebiz\IFSZ_AddOn_Ebiz\Ebiz\DataAccess IFSZ_EMAILACCOUNTS
'
'Paraméterek:
'Adatbázis típus: mssql
'Generálási forrás: xml
'Workarea/Xml File név: H:\SBO\Fejlesztes\Work\Repository\XmlRepository.xml
'Alkalmazásrendszer: EMAILOUT
'Könyvtár: C:\svn\gergo\modulok\IFSZ_AddOn_Ebiz\IFSZ_AddOn_Ebiz\Ebiz\DataAccess\
'Tábla neve: IFSZ_EMAILACCOUNTS
'
'
'----------------------------------------------------------------------------'

Imports System
Imports System.Collections
Imports System.Text

Public Class IFSZ_EMAILACCOUNTSDAO
    Inherits IFSZ_DataAccessBase

#Region "Konstruktor"

    Sub New()
        Me.m_TablaNev = "IFSZ_EMAILACCOUNTS"

        ReDim Me.m_oszlopok(6)

        Dim i As Integer = 0
        Me.m_oszlopok(i) = New st_OszlopDAO("ID", enOszlopDAOTipus.Double_)
        i += 1
        Me.m_oszlopok(i) = New st_OszlopDAO("NAME", enOszlopDAOTipus.String_)
        i += 1
        Me.m_oszlopok(i) = New st_OszlopDAO("SMTP_SERVER", enOszlopDAOTipus.String_)
        i += 1
        Me.m_oszlopok(i) = New st_OszlopDAO("SMTP_PORT", enOszlopDAOTipus.Double_)
        i += 1
        Me.m_oszlopok(i) = New st_OszlopDAO("USERNAME", enOszlopDAOTipus.String_)
        i += 1
        Me.m_oszlopok(i) = New st_OszlopDAO("PASSWORD", enOszlopDAOTipus.String_)
        i += 1
        Me.m_oszlopok(i) = New st_OszlopDAO("SSL", enOszlopDAOTipus.String_)

        Init()

    End Sub

    Public Sub Init()
        Me.UDT = True
    End Sub

#End Region

#Region "Variables"

#End Region

#Region "Overrides"

#End Region

End Class
