﻿'----------------------------------------------------------------------------'
'GENERÁLT FÁJL!!!!
'A konstruktor "End_Sub"-jáig ne módosíts, mert az felül lesz írva!!!!!!!!!!
'----------------------------------------------------------------------------'
'Generálva: 2020.04.14
'DataAccessGenerator2 mssql számára. Verzió: 1.1.13.0
'
'dataaccessgenerator2 mssql xml EMAILOUT E:\svn\gergo\modulok\IFSZ_AddOn_Edoc\IFSZ_AddOn_Edoc\Edoc\DataAccess IFSZ_EMAILOUTBODY
'
'Paraméterek:
'Adatbázis típus: mssql
'Generálási forrás: xml
'Workarea/Xml File név: H:\SBO\Fejlesztes\Work\Repository\XmlRepository.xml
'Alkalmazásrendszer: EMAILOUT
'Könyvtár: E:\svn\gergo\modulok\IFSZ_AddOn_Edoc\IFSZ_AddOn_Edoc\Edoc\DataAccess\
'Tábla neve: IFSZ_EMAILOUTBODY
'
'
'----------------------------------------------------------------------------'

Imports System
Imports System.Collections
Imports System.Text

Public Class IFSZ_EMAILOUTBODYDAO
    Inherits IFSZ_DataAccessBase

#Region "Konstruktor"

    Sub New()
        Me.m_TablaNev = "IFSZ_EMAILOUTBODY"

        ReDim Me.m_oszlopok(7)

        Dim i As Integer = 0
        Me.m_oszlopok(i) = New st_OszlopDAO("ID", enOszlopDAOTipus.Double_)
        i += 1
        Me.m_oszlopok(i) = New st_OszlopDAO("DOCTYPE", enOszlopDAOTipus.String_)
        i += 1
        Me.m_oszlopok(i) = New st_OszlopDAO("SUBJECT", enOszlopDAOTipus.String_)
        i += 1
        Me.m_oszlopok(i) = New st_OszlopDAO("BODY", enOszlopDAOTipus.String_)
        i += 1
        Me.m_oszlopok(i) = New st_OszlopDAO("NAME", enOszlopDAOTipus.String_)
        i += 1
        Me.m_oszlopok(i) = New st_OszlopDAO("LANG", enOszlopDAOTipus.Double_)
        i += 1
        Me.m_oszlopok(i) = New st_OszlopDAO("DEFAULTEMAIL", enOszlopDAOTipus.String_)
        i += 1
        Me.m_oszlopok(i) = New st_OszlopDAO("ISHTML", enOszlopDAOTipus.String_)

        Init()

    End Sub

    Public Sub Init()
        Me.UDT = True
        For i As Integer = 0 To m_oszlopok.Length - 1
            If m_oszlopok(i).Nev = "BODY" Then
                m_oszlopok(i).UpdWhere_e = False
                m_oszlopok(i).Delete_e = False
            End If
        Next
    End Sub

#End Region

#Region "Variables"

#End Region

#Region "Overrides"

#End Region

End Class
