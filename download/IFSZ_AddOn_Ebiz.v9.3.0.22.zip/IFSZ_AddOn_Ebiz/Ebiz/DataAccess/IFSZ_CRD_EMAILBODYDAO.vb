﻿'----------------------------------------------------------------------------'
'GENERÁLT FÁJL!!!!
'A konstruktor "End_Sub"-jáig ne módosíts, mert az felül lesz írva!!!!!!!!!!
'----------------------------------------------------------------------------'
'Generálva: 2020.04.09
'DataAccessGenerator2 mssql számára. Verzió: 1.1.13.0
'
'dataaccessgenerator2 mssql xml EMAILOUT E:\svn\gergo\modulok\IFSZ_AddOn_Edoc\IFSZ_AddOn_Edoc\Edoc\DataAccess IFSZ_CRD_EMAILBODY
'
'Paraméterek:
'Adatbázis típus: mssql
'Generálási forrás: xml
'Workarea/Xml File név: H:\SBO\Fejlesztes\Work\Repository\XmlRepository.xml
'Alkalmazásrendszer: EMAILOUT
'Könyvtár: E:\svn\gergo\modulok\IFSZ_AddOn_Edoc\IFSZ_AddOn_Edoc\Edoc\DataAccess\
'Tábla neve: IFSZ_CRD_EMAILBODY
'
'
'----------------------------------------------------------------------------'

Imports System
Imports System.Collections
Imports System.Text

Public Class IFSZ_CRD_EMAILBODYDAO
    Inherits IFSZ_DataAccessBase

#Region "Konstruktor"

    Sub New()
        Me.m_TablaNev = "IFSZ_CRD_EMAILBODY"

        ReDim Me.m_oszlopok(2)

        Dim i As Integer = 0
        Me.m_oszlopok(i) = New st_OszlopDAO("ID", enOszlopDAOTipus.Double_)
        i += 1
        Me.m_oszlopok(i) = New st_OszlopDAO("CARDCODE", enOszlopDAOTipus.String_)
        i += 1
        Me.m_oszlopok(i) = New st_OszlopDAO("BODY", enOszlopDAOTipus.String_)

        Init()

    End Sub

    Public Sub Init()
        Me.UDT = True
    End Sub

#End Region

#Region "Variables"

#End Region

#Region "Overrides"

#End Region

End Class
