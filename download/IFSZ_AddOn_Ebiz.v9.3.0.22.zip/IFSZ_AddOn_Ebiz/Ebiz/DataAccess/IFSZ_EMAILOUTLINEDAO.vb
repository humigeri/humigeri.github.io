﻿'----------------------------------------------------------------------------'
'GENERÁLT FÁJL!!!!
'A konstruktor "End_Sub"-jáig ne módosíts, mert az felül lesz írva!!!!!!!!!!
'----------------------------------------------------------------------------'
'Generálva: 2021.12.21
'DataAccessGenerator2 mssql számára. Verzió: 1.1.13.0
'
'dataaccessgenerator2 mssql xml EMAILOUT C:\svn\gergo\modulok\IFSZ_AddOn_Ebiz\IFSZ_AddOn_Ebiz\Ebiz\DataAccess IFSZ_EMAILOUTLINE
'
'Paraméterek:
'Adatbázis típus: mssql
'Generálási forrás: xml
'Workarea/Xml File név: H:\SBO\Fejlesztes\Work\Repository\XmlRepository.xml
'Alkalmazásrendszer: EMAILOUT
'Könyvtár: C:\svn\gergo\modulok\IFSZ_AddOn_Ebiz\IFSZ_AddOn_Ebiz\Ebiz\DataAccess\
'Tábla neve: IFSZ_EMAILOUTLINE
'
'
'----------------------------------------------------------------------------'

Imports System
Imports System.Collections
Imports System.Text

Public Class IFSZ_EMAILOUTLINEDAO
    Inherits IFSZ_DataAccessBase

#Region "Konstruktor"

    Sub New()
        Me.m_TablaNev = "IFSZ_EMAILOUTLINE"

        ReDim Me.m_oszlopok(15)

        Dim i As Integer = 0
        Me.m_oszlopok(i) = New st_OszlopDAO("ID", enOszlopDAOTipus.Double_)
        i += 1
        Me.m_oszlopok(i) = New st_OszlopDAO("DOCTYPE", enOszlopDAOTipus.Double_)
        i += 1
        Me.m_oszlopok(i) = New st_OszlopDAO("CRYSTAL", enOszlopDAOTipus.String_)
        i += 1
        Me.m_oszlopok(i) = New st_OszlopDAO("MAIL_SUBJECT", enOszlopDAOTipus.String_)
        i += 1
        Me.m_oszlopok(i) = New st_OszlopDAO("MAIL_BODY", enOszlopDAOTipus.String_)
        i += 1
        Me.m_oszlopok(i) = New st_OszlopDAO("FILE", enOszlopDAOTipus.String_)
        i += 1
        Me.m_oszlopok(i) = New st_OszlopDAO("STATUS", enOszlopDAOTipus.String_)
        i += 1
        Me.m_oszlopok(i) = New st_OszlopDAO("EOH_ID", enOszlopDAOTipus.Double_)
        i += 1
        Me.m_oszlopok(i) = New st_OszlopDAO("LINENUM", enOszlopDAOTipus.Double_)
        i += 1
        Me.m_oszlopok(i) = New st_OszlopDAO("DOCENTRY", enOszlopDAOTipus.Double_)
        i += 1
        Me.m_oszlopok(i) = New st_OszlopDAO("DOCNUM", enOszlopDAOTipus.Double_)
        i += 1
        Me.m_oszlopok(i) = New st_OszlopDAO("SENTTS", enOszlopDAOTipus.Date_)
        i += 1
        Me.m_oszlopok(i) = New st_OszlopDAO("ISHTML", enOszlopDAOTipus.String_)
        i += 1
        Me.m_oszlopok(i) = New st_OszlopDAO("EBIZTIP", enOszlopDAOTipus.String_)
        i += 1
        Me.m_oszlopok(i) = New st_OszlopDAO("MD5_FILE", enOszlopDAOTipus.String_)
        i += 1
        Me.m_oszlopok(i) = New st_OszlopDAO("MD5_SIGNED", enOszlopDAOTipus.String_)

        Init()

    End Sub

    Public Sub Init()
        Me.UDT = True
        For i As Integer = 0 To m_oszlopok.Length - 1
            If m_oszlopok(i).Nev = "MAIL_BODY" Then
                m_oszlopok(i).UpdWhere_e = False
                m_oszlopok(i).Delete_e = False
            End If
        Next
    End Sub

#End Region

#Region "Variables"

#End Region

#Region "Overrides"

#End Region

End Class
