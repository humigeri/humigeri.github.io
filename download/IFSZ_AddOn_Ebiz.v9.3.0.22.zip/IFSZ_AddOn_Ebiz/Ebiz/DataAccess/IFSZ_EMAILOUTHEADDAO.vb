﻿'----------------------------------------------------------------------------'
'GENERÁLT FÁJL!!!!
'A konstruktor "End_Sub"-jáig ne módosíts, mert az felül lesz írva!!!!!!!!!!
'----------------------------------------------------------------------------'
'Generálva: 2020.03.22
'DataAccessGenerator2 mssql számára. Verzió: 1.1.13.0
'
'dataaccessgenerator2 mssql xml EMAILOUT E:\svn\gergo\TFCB\IFSZ_AddOn_TFCB\IFSZ_AddOn_TFCB\DataAccess IFSZ_EMAILOUTHEAD
'
'Paraméterek:
'Adatbázis típus: mssql
'Generálási forrás: xml
'Workarea/Xml File név: H:\SBO\Fejlesztes\Work\Repository\XmlRepository.xml
'Alkalmazásrendszer: EMAILOUT
'Könyvtár: E:\svn\gergo\TFCB\IFSZ_AddOn_TFCB\IFSZ_AddOn_TFCB\DataAccess\
'Tábla neve: IFSZ_EMAILOUTHEAD
'
'
'----------------------------------------------------------------------------'

Imports System
Imports System.Collections
Imports System.Text

Public Class IFSZ_EMAILOUTHEADDAO
    Inherits IFSZ_DataAccessBase

#Region "Konstruktor"

    Sub New()
        Me.m_TablaNev = "IFSZ_EMAILOUTHEAD"

        ReDim Me.m_oszlopok(6)

        Dim i As Integer = 0
        Me.m_oszlopok(i) = New st_OszlopDAO("ID", enOszlopDAOTipus.Double_)
        i += 1
        Me.m_oszlopok(i) = New st_OszlopDAO("DOCNUM", enOszlopDAOTipus.String_)
        i += 1
        Me.m_oszlopok(i) = New st_OszlopDAO("USERCODE", enOszlopDAOTipus.String_)
        i += 1
        Me.m_oszlopok(i) = New st_OszlopDAO("NOTE", enOszlopDAOTipus.String_)
        i += 1
        Me.m_oszlopok(i) = New st_OszlopDAO("SENTTS", enOszlopDAOTipus.Date_)
        i += 1
        Me.m_oszlopok(i) = New st_OszlopDAO("STATUS", enOszlopDAOTipus.String_)
        i += 1
        Me.m_oszlopok(i) = New st_OszlopDAO("PATH", enOszlopDAOTipus.String_)

        Init()

    End Sub

    Public Sub Init()
        Me.UDT = True
    End Sub

#End Region

#Region "Variables"

#End Region

#Region "Overrides"

#End Region

End Class
