﻿Public Class QueryResource

    Private Shared m_res As Dictionary(Of String, DataTable)

    ''' <summary>
    ''' Visszaadja a resource fájlból az adott sql-t a beállított adatbázis típus szerint
    ''' </summary>
    ''' <param name="p_tipus">Az xml fájlt azonosítja, ahol keressük az sql-t. Minden modulnak külön csoportja van, így van: Base_IFSZ_AddOn_SBO, Base_IFSZ_Keretrendszer, Penztar, stb.</param>
    ''' <param name="p_kod">Az sql kódja</param>
    ''' <param name="p_2">paraméter 2 (/*2*/-et cseréljük le az sql-ben az SQLConstantPrepare használatával</param>
    ''' <param name="p_3">paraméter 3 (/*3*/-et cseréljük le az sql-ben az SQLConstantPrepare használatával</param>
    ''' <param name="p_4">paraméter 4 (/*4*/-et cseréljük le az sql-ben az SQLConstantPrepare használatával</param>
    ''' <param name="p_5">paraméter 5 (/*5*/-et cseréljük le az sql-ben az SQLConstantPrepare használatával</param>
    ''' <param name="p_6">paraméter 6 (/*6*/-et cseréljük le az sql-ben az SQLConstantPrepare használatával</param>
    ''' <param name="p_7">paraméter 7 (/*7*/-et cseréljük le az sql-ben az SQLConstantPrepare használatával</param>
    ''' <param name="p_8">paraméter 8 (/*8*/-et cseréljük le az sql-ben az SQLConstantPrepare használatával</param>
    ''' <param name="p_9">paraméter 9 (/*9*/-et cseréljük le az sql-ben az SQLConstantPrepare használatával</param>
    ''' <param name="p_10">paraméter 10 (/*10*/-et cseréljük le az sql-ben az SQLConstantPrepare használatával</param>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared ReadOnly Property GetQuery( _
      ByVal p_tipus As String _
    , ByVal p_kod As String _
    , Optional p_1 As Object = Nothing _
    , Optional p_2 As Object = Nothing _
    , Optional p_3 As Object = Nothing _
    , Optional p_4 As Object = Nothing _
    , Optional p_5 As Object = Nothing _
    , Optional p_6 As Object = Nothing _
    , Optional p_7 As Object = Nothing _
    , Optional p_8 As Object = Nothing _
    , Optional p_9 As Object = Nothing _
    , Optional p_10 As Object = Nothing _
    ) As String
        Get
            Try
                Dim l_dbtip As String
                Dim l_tipus As String
#If HANADB Then
                l_dbtip = "HANA"
#Else
                l_dbtip = "SQL"
#End If
                l_tipus = l_dbtip + "Resource_" + p_tipus
                If m_res Is Nothing Then
                    m_res = New Dictionary(Of String, DataTable)
                End If
                If Not m_res.ContainsKey(l_tipus) Then
                    m_res(l_tipus) = New DataTable()
                    m_res(l_tipus).Columns.Add("Name", GetType(String))
                    m_res(l_tipus).Columns.Add("Sql", GetType(String))

                    Dim l_xml As System.Xml.XmlDocument = New System.Xml.XmlDocument()
                    l_xml.Load(New System.IO.StringReader(My.Resources.ResourceManager.GetObject(l_tipus)))
                    Dim l_nodelist As Xml.XmlNodeList

                    l_nodelist = l_xml.SelectNodes("/root/data")

                    For Each l_node As Xml.XmlNode In l_nodelist
                        Dim l_name, l_sql As String
                        If l_node.Attributes IsNot Nothing Then
                            For Each l_attr As Xml.XmlAttribute In l_node.Attributes
                                If l_attr.Name = "name" Then
                                    l_name = l_attr.Value
                                End If
                            Next
                            If l_node.HasChildNodes Then
                                For Each l_node2 As Xml.XmlNode In l_node.ChildNodes
                                    If l_node2.Name = "value" Then
                                        l_sql = l_node2.InnerText
                                    End If
                                Next
                            End If
                            If Not String.IsNullOrEmpty(l_name) AndAlso Not String.IsNullOrEmpty(l_sql) Then
                                Dim l_row As DataRow
                                l_row = m_res(l_tipus).NewRow()
                                l_row("Name") = l_name
                                l_row("Sql") = l_sql
                                m_res(l_tipus).Rows.Add(l_row)
                            End If
                        End If
                    Next
                    m_res(l_tipus).AcceptChanges()

                End If

                Dim l_view As DataView
                l_view = New DataView(m_res(l_tipus), "Name = " + IFSZ_Globals.DataViewConstantPrepare(p_kod), "", DataViewRowState.CurrentRows)
                If l_view IsNot Nothing AndAlso l_view.Count > 0 Then
                    Dim l_ret As String = l_view(0)("Sql")
                    If p_1 IsNot Nothing Then
                        l_ret = l_ret.Replace("/*1*/", IFSZ_Globals.SqlConstantPrepare(p_1))
                    Else
                        l_ret = l_ret.Replace("/*1*/", "null")
                    End If
                    If p_2 IsNot Nothing Then
                        l_ret = l_ret.Replace("/*2*/", IFSZ_Globals.SqlConstantPrepare(p_2))
                    Else
                        l_ret = l_ret.Replace("/*2*/", "null")
                    End If
                    If p_3 IsNot Nothing Then
                        l_ret = l_ret.Replace("/*3*/", IFSZ_Globals.SqlConstantPrepare(p_3))
                    Else
                        l_ret = l_ret.Replace("/*3*/", "null")
                    End If
                    If p_4 IsNot Nothing Then
                        l_ret = l_ret.Replace("/*4*/", IFSZ_Globals.SqlConstantPrepare(p_4))
                    Else
                        l_ret = l_ret.Replace("/*4*/", "null")
                    End If
                    If p_5 IsNot Nothing Then
                        l_ret = l_ret.Replace("/*5*/", IFSZ_Globals.SqlConstantPrepare(p_5))
                    Else
                        l_ret = l_ret.Replace("/*5*/", "null")
                    End If
                    If p_6 IsNot Nothing Then
                        l_ret = l_ret.Replace("/*6*/", IFSZ_Globals.SqlConstantPrepare(p_6))
                    Else
                        l_ret = l_ret.Replace("/*6*/", "null")
                    End If
                    If p_7 IsNot Nothing Then
                        l_ret = l_ret.Replace("/*7*/", IFSZ_Globals.SqlConstantPrepare(p_7))
                    Else
                        l_ret = l_ret.Replace("/*7*/", "null")
                    End If
                    If p_8 IsNot Nothing Then
                        l_ret = l_ret.Replace("/*8*/", IFSZ_Globals.SqlConstantPrepare(p_8))
                    Else
                        l_ret = l_ret.Replace("/*8*/", "null")
                    End If
                    If p_9 IsNot Nothing Then
                        l_ret = l_ret.Replace("/*9*/", IFSZ_Globals.SqlConstantPrepare(p_9))
                    Else
                        l_ret = l_ret.Replace("/*9*/", "null")
                    End If
                    If p_10 IsNot Nothing Then
                        l_ret = l_ret.Replace("/*10*/", IFSZ_Globals.SqlConstantPrepare(p_10))
                    Else
                        l_ret = l_ret.Replace("/*10*/", "null")
                    End If
                    Return l_ret
                Else
                    Throw New Exception("Nem található a " + p_tipus + "." + p_kod + " query")
                End If

            Catch ex As Exception
                Throw New Exception("Nem található a " + p_tipus + "." + p_kod + " query")
            End Try
        End Get
    End Property

    ''' <summary>
    ''' Az sql-ben található oszlop, vagy táblanevet készíti elő
    '''  HANA-ban körbeveszi "-ekkel, mssql-ben pedig []-be teszi
    ''' </summary>
    ''' <param name="p_colname"></param>
    ''' <param name="p_tabname"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Function AzonPrep(ByVal p_colname As String, Optional p_tabname As String = "") As String
#If HANADB Then
        Return IIf(p_tabname = "", "", """" + p_tabname + """.") + """" + p_colname + """"
#Else
        Return IIf(p_tabname = "", "", "[" + p_tabname + "].") + "[" + p_colname + "]"
#End If
    End Function

    ''' <summary>
    ''' Ahol mssql-ben getdate()-et használunk, ott tegyük be ezt a függvényt, mert HANA esetén az annak megfelelő current_timestamp-et fogja visszaadni
    ''' </summary>
    ''' <returns></returns>
    Public Shared Function SQL_getdate() As String
#If HANADB Then
        Return "current_timestamp"
#Else
        Return "getdate()"
#End If
    End Function

    ''' <summary>
    ''' Ahol mssql-ben isnull(...-t használunk, ott tegyük be ezt a függvényt, mert HANA esetén az annak megfelelő ifnull-t fogja visszaadni
    ''' paraméterként az isnull két paraméterét várjuk, mindkettő olyan formában, ahogy az az sql szövegébe kerül, vagyis ez string - előtte sqlconstantprepare-ezzük
    ''' </summary>
    ''' <param name="p1"></param>
    ''' <param name="p2"></param>
    ''' <returns></returns>
    Public Shared Function SQL_isnull(ByVal p1 As String, ByVal p2 As String) As String
#If HANADB Then
        Return "ifnull(" + p1 + ", " + p2 + ")"
#Else
        Return "isnull(" + p1 + ", " + p2 + ")"
#End If
    End Function

    ''' <summary>
    ''' Az sql konkatenáció jele. (mssql: +, hana: || )
    ''' </summary>
    ''' <returns></returns>
    Public Shared Function SQL_Konkat() As String
#If HANADB Then
        Return "||"
#Else
        Return "+"
#End If
    End Function

    ''' <summary>
    ''' MSSQL: with (nolock)
    ''' HANA: semmi, mivel hanában nincs ilyen
    ''' </summary>
    ''' <returns></returns>
    Public Shared Function SQL_WithNolock() As String
#If HANADB Then
        Return " "
#Else
        Return " with (nolock) "
#End If
    End Function

    ''' <summary>
    ''' MSSQL: semmi, ott tábla nélküli selectnél elhagyható a from
    ''' HANA: from dummy
    ''' </summary>
    ''' <returns></returns>
    Public Shared Function SQL_FromDummy() As String
#If HANADB Then
        Return " from dummy "
#Else
        Return " "
#End If
    End Function

    ''' <summary>
    ''' Napok hozzáadásához sql kódot készít. Két paraméter a dátum, és a napok száma, amit hozzáadunk. Mindkettő string, abban a formában van, ahogy az sql-ben szerepelnie kell - ezért konstans esetén SQLConstantPrepare-ezzünk
    ''' MSSQL: dateadd(day, ..., ...)
    ''' HANA: add_days(..., ...)
    ''' </summary>
    ''' <param name="p_datum"></param>
    ''' <param name="p_napok"></param>
    ''' <returns></returns>
    Public Shared Function SQL_AddDays(ByVal p_datum As String, ByVal p_napok As String) As String
#If HANADB Then
        Return "add_days(" + p_datum + ", " + p_napok + ")"
#Else
        Return "dateadd(day, " + p_napok + ", " + p_datum + ")"
#End If
    End Function

    ''' <summary>
    ''' Hónapok hozzáadásához sql kódot készít. Két paraméter a dátum, és a hónapok száma, amit hozzáadunk. Mindkettő string, abban a formában van, ahogy az sql-ben szerepelnie kell - ezért konstans esetén SQLConstantPrepare-ezzünk
    ''' MSSQL: dateadd(month, ..., ...)
    ''' HANA: add_months(..., ...)
    ''' </summary>
    ''' <param name="p_datum"></param>
    ''' <param name="p_napok"></param>
    ''' <returns></returns>
    Public Shared Function SQL_AddMonths(ByVal p_datum As String, ByVal p_napok As String) As String
#If HANADB Then
        Return "add_months(" + p_datum + ", " + p_napok + ")"
#Else
        Return "dateadd(month, " + p_napok + ", " + p_datum + ")"
#End If
    End Function

    ''' <summary>
    ''' Évek hozzáadásához sql kódot készít. Két paraméter a dátum, és az évek száma, amit hozzáadunk. Mindkettő string, abban a formában van, ahogy az sql-ben szerepelnie kell - ezért konstans esetén SQLConstantPrepare-ezzünk
    ''' MSSQL: dateadd(year, ..., ...)
    ''' HANA: add_years(..., ...)
    ''' </summary>
    ''' <param name="p_datum"></param>
    ''' <param name="p_napok"></param>
    ''' <returns></returns>
    Public Shared Function SQL_AddYears(ByVal p_datum As String, ByVal p_napok As String) As String
#If HANADB Then
        Return "add_years(" + p_datum + ", " + p_napok + ")"
#Else
        Return "dateadd(year, " + p_napok + ", " + p_datum + ")"
#End If
    End Function

    ''' <summary>
    ''' Dátumból hónapon belüli napok számának kiszedéséhez sql kódot készít. Paraméter a dátum, aminek típussa string, abban a formában van, ahogy az sql-ben szerepelnie kell - ezért konstans esetén SQLConstantPrepare-ezzünk
    ''' MSSQL: day(...)
    ''' HANA: dayofmonth(...)
    ''' </summary>
    ''' <param name="p_datum"></param>
    ''' <returns></returns>
    Public Shared Function SQL_DayOfMonth(ByVal p_datum As String) As String
#If HANADB Then
        Return "dayofmonth(" + p_datum + ")"
#Else
        Return "day(" + p_datum + ")"
#End If
    End Function

    ''' <summary>
    ''' MSSQL: dbo.
    ''' HANA: semmi
    ''' </summary>
    ''' <returns></returns>
    Public Shared Function SQL_dbopont() As String
#If HANADB Then
        Return ""
#Else
        Return "dbo."
#End If
    End Function

    ''' <summary>
    ''' Abban az esetben, ha dátumra konvertálni az sql szövegében kell. (Pl. karakteres oszlopot kell dátumra konvertálni)
    ''' Paraméterként azt a formátumot kell megadni, ahogy mssql-ben használjuk
    ''' </summary>
    ''' <param name="p_ertek">A sztring, abban a formában, ahogy az sql-ben szerepel. (Pl. oszlopnév lehet, vagy külső konstans esetén SQLConstantPrepare-rel előkészített érték</param>
    ''' <param name="p_format">formátum, pl.: 112, 121, stb...</param>
    ''' <returns></returns>
    Public Shared Function SQL_convert_datetime(ByVal p_ertek As String, ByVal p_format As Integer) As String
#If HANADB Then
        Select Case p_format
            Case 1
                Return "TO_DATE(" + p_ertek + ", 'MM/DD/YY')"
            Case 101
                Return "TO_DATE(" + p_ertek + ", 'MM/DD/YYYY')"
            Case 2
                Return "TO_DATE(" + p_ertek + ", 'YY.MM.DD')"
            Case 102
                Return "TO_DATE(" + p_ertek + ", 'YYYY.MM.DD')"
            Case 3
                Return "TO_DATE(" + p_ertek + ", 'DD/MM/YY')"
            Case 103
                Return "TO_DATE(" + p_ertek + ", 'DD/MM/YYYY')"
            Case 4
                Return "TO_DATE(" + p_ertek + ", 'DD.MM.YY')"
            Case 104
                Return "TO_DATE(" + p_ertek + ", 'DD.MM.YYYY')"
            Case 5
                Return "TO_DATE(" + p_ertek + ", 'DD-MM-YY')"
            Case 105
                Return "TO_DATE(" + p_ertek + ", 'DD-MM-YYYY')"
            Case 10
                Return "TO_DATE(" + p_ertek + ", 'MM-DD-YY')"
            Case 110
                Return "TO_DATE(" + p_ertek + ", 'MM-DD-YYYY')"
            Case 11
                Return "TO_DATE(" + p_ertek + ", 'YY/MM/DD')"
            Case 111
                Return "TO_DATE(" + p_ertek + ", 'YYYY/MM/DD')"
            Case 12
                Return "TO_DATE(" + p_ertek + ", 'YYMMDD')"
            Case 112
                Return "TO_DATE(" + p_ertek + ", 'YYYYMMDD')"
            Case 20, 120
                Return "TO_DATE(" + p_ertek + ", 'YYYY-MM-DD HH24:MI:SS')"
            Case 21, 121
                Return "TO_DATE(" + p_ertek + ", 'YYYY-MM-DD HH24:MI:SS.FF3')"
            Case Else
                Return p_ertek
        End Select
#Else
        Return "convert(datetime, " + p_ertek + ", " + p_format.ToString() + ")"
#End If
    End Function

    ''' <summary>
    ''' Abban az esetben, ha dátumra konvertálni az sql szövegében kell. (Pl. karakteres oszlopot kell dátumra konvertálni)
    ''' Paraméterként azt a formátumot kell megadni, ahogy mssql-ben használjuk
    ''' </summary>
    ''' <param name="p_ertek">A sztring, abban a formában, ahogy az sql-ben szerepel. (Pl. oszlopnév lehet, vagy külső konstans esetén SQLConstantPrepare-rel előkészített érték</param>
    ''' <param name="p_format">formátum, pl.: 112, 121, stb...</param>
    ''' <returns></returns>
    Public Shared Function SQL_date_convert_varchar(ByVal p_ertek As String, ByVal p_format As Integer) As String
#If HANADB Then
        Select Case p_format
            Case 1
                Return "TO_CHAR(" + p_ertek + ", 'MM/DD/YY')"
            Case 101
                Return "TO_CHAR(" + p_ertek + ", 'MM/DD/YYYY')"
            Case 2
                Return "TO_CHAR(" + p_ertek + ", 'YY.MM.DD')"
            Case 102
                Return "TO_CHAR(" + p_ertek + ", 'YYYY.MM.DD')"
            Case 3
                Return "TO_CHAR(" + p_ertek + ", 'DD/MM/YY')"
            Case 103
                Return "TO_CHAR(" + p_ertek + ", 'DD/MM/YYYY')"
            Case 4
                Return "TO_CHAR(" + p_ertek + ", 'DD.MM.YY')"
            Case 104
                Return "TO_CHAR(" + p_ertek + ", 'DD.MM.YYYY')"
            Case 5
                Return "TO_CHAR(" + p_ertek + ", 'DD-MM-YY')"
            Case 105
                Return "TO_CHAR(" + p_ertek + ", 'DD-MM-YYYY')"
            Case 10
                Return "TO_CHAR(" + p_ertek + ", 'MM-DD-YY')"
            Case 110
                Return "TO_CHAR(" + p_ertek + ", 'MM-DD-YYYY')"
            Case 11
                Return "TO_CHAR(" + p_ertek + ", 'YY/MM/DD')"
            Case 111
                Return "TO_CHAR(" + p_ertek + ", 'YYYY/MM/DD')"
            Case 12
                Return "TO_CHAR(" + p_ertek + ", 'YYMMDD')"
            Case 112
                Return "TO_CHAR(" + p_ertek + ", 'YYYYMMDD')"
            Case 20, 120
                Return "TO_CHAR(" + p_ertek + ", 'YYYY-MM-DD HH24:MI:SS')"
            Case 21, 121
                Return "TO_CHAR(" + p_ertek + ", 'YYYY-MM-DD HH24:MI:SS.FF3')"
            Case Else
                Return p_ertek
        End Select
#Else
        Return "convert(varchar, " + p_ertek + ", " + p_format.ToString() + ")"
#End If
    End Function

    Public Shared Function SQL_length(ByVal p_par As String)
#If HANADB Then
        Return " length(" + p_par + ") "
#Else
        Return " len(" + p_par + ") "
#End If
    End Function

    Public Shared Function SQL_charindex(ByVal p_needle As String, ByVal p_haystack As String)
#If HANADB Then
        Return " locate(" + p_haystack + ", " + p_needle + ") "
#Else
        Return " charindex(" + p_needle + ", " + p_haystack + ") "
#End If
    End Function

    ''' <summary>
    ''' MSSQL: DB_NAME()
    ''' HANA: CURRENT_SCHEMA
    ''' </summary>
    ''' <returns></returns>
    Public Shared Function SQL_dbname() As String
#If HANADB Then
        Return " CURRENT_SCHEMA "
#Else
        Return " DB_NAME() "
#End If
    End Function

End Class
