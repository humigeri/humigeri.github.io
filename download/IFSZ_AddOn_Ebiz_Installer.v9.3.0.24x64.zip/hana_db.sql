create view IFSZ_EDOC_TYPES_V AS
select N'13' as CODE
     , N'Kimen� sz�mla' as NAME
	 , N'INV' as RTYPPRE
	 , N'KSZ' as SHORTNAME
from dummy
union all
select N'14' as CODE
     , N'�rt�kes�t�si j�v��r�s' as NAME
	 , N'RIN' as RTYPPRE
	 , N'KJ' as SHORTNAME
from dummy
/*union all
select N'165' as CODE
     , N'Kimen� helyesb�t� sz�mla' as NAME
	 , N'CSI' as RTYPPRE
	 , N'KH' as SHORTNAME
from dummy
union all
select N'166' as CODE
     , N'Kimen� helyesb�t� visszavon�sa' as NAME
	 , N'CSV' as RTYPPRE
	 , N'KHV' as SHORTNAME
from dummy
union all
select N'15' as CODE
     , N'Sz�ll�t�s' as NAME
	 , N'ODLN' as RTYPPRE
	 , N'SZ' as SHORTNAME
from dummy
union all
select N'16' as CODE
     , N'Vev�i vissz�ru' as NAME
	 , N'ORDN' as RTYPPRE
	 , N'VV' as SHORTNAME
from dummy
union all
select N'163' as CODE
     , N'Beszerz�si helyesb�to sz�mla ' as NAME
	 , N'OCPI' as RTYPPRE
	 , N'BH' as SHORTNAME
from dummy
union all
select N'164' as CODE
     , N'Beszerz�si hely szla vissza' as NAME
	 , N'OCPV' as RTYPPRE
	 , N'BHV' as SHORTNAME
from dummy
union all
select N'17' as CODE
     , N'Vev�i rendel�s' as NAME
	 , N'ORDR' as RTYPPRE
	 , N'RD' as SHORTNAME
from dummy
union all
select N'18' as CODE
     , N'Bej�v� sz�mla' as NAME
	 , N'OPCH' as RTYPPRE
	 , N'SS' as SHORTNAME
from dummy
union all
select N'19' as CODE
     , N'Beszerz�si j�v��r�s ' as NAME
	 , N'ORPC' as RTYPPRE
	 , N'SJ' as SHORTNAME
from dummy
union all
select N'20' as CODE
     , N'�rube�rkez�s' as NAME
	 , N'OPDN' as RTYPPRE
	 , N'�B' as SHORTNAME
from dummy
union all
select N'203' as CODE
     , N'�rt�kes�t�si el�leg' as NAME
	 , N'ODPI' as RTYPPRE
	 , N'KE' as SHORTNAME
from dummy
union all
select N'204' as CODE
     , N'Beszerz�si el�leg' as NAME
	 , N'ODPO' as RTYPPRE
	 , N'BE' as SHORTNAME
from dummy
union all
select N'21' as CODE
     , N'Sz�ll�t�i vissz�ru' as NAME
	 , N'ORPD' as RTYPPRE
	 , N'SV' as SHORTNAME
from dummy
union all
select N'22' as CODE
     , N'Megrendel�s' as NAME
	 , N'OPOR' as RTYPPRE
	 , N'MR' as SHORTNAME
from dummy
union all
select N'23' as CODE
     , N'Aj�nlat' as NAME
	 , N'OQUT' as RTYPPRE
	 , N'AJ' as SHORTNAME
from dummy
union all
select N'59' as CODE
     , N'Anyagbev�telez�s' as NAME
	 , N'OIGN' as RTYPPRE
	 , N'AB' as SHORTNAME
from dummy
union all
select N'60' as CODE
     , N'Anyagkiad�s' as NAME
	 , N'OIGE' as RTYPPRE
	 , N'AK' as SHORTNAME
from dummy
union all
select N'67' as CODE
     , N'�tt�rol�s' as NAME
	 , N'OWTR' as RTYPPRE
	 , N'�T' as SHORTNAME
from dummy
*/;

create view IFSZ_F_EOA_EOA_V as
select "Code" as ID
     , U_NAME as NAME
	 , U_SMTP_SERVER as SMTP_SERVER
	 , U_SMTP_PORT as SMTP_PORT
	 , U_USERNAME as USERNAME
	 , U_PASSWORD as PASSWORD
	 , U_SSL as SSL
	 , '' as SSL_LANGVAL
	 , '' as SSL_MEAN
  from "@IFSZ_EMAILACCOUNTS"
;

create view IFSZ_F_EOB_EOB_V as
select t."Code" as ID
  , t.U_DOCTYPE as DOCTYPE
  , dt.NAME as DOCTYPE_NAME
  , t.U_NAME as "NAME"
  , t.U_SUBJECT as "SUBJECT"
  , t.U_BODY as BODY
  , t.U_LANG as LANG
  , OLNG."Name" as LANG_NAME
  , t.U_DEFAULTEMAIL as DEFAULTEMAIL
  , '' as DEFAULTEMAIL_LANGVAL
  , '' as DEFAULTEMAIL_MEAN
  , t.U_ISHTML as ISHTML
  , '' as ISHTML_LANGVAL
  , '' as ISHTML_MEAN
  from "@IFSZ_EMAILOUTBODY" t
  left join OLNG on t.U_LANG = OLNG."Code"
  left join IFSZ_EDOC_TYPES_V dt on t.U_DOCTYPE = dt.CODE
;

create view IFSZ_F_EOB_CRD_V as
select t."Code" as ID
  , t.U_CARDCODE as CARDCODE
  , ocrd."CardName" as CARDNAME
  , t.U_BODY as BODY
  from "@IFSZ_CRD_EMAILBODY" t
  left join OCRD on t.U_CARDCODE = OCRD."CardCode"
;

create view IFSZ_F_EOH_EOH_V as
select "Code" as ID
  , U_DOCNUM as DOCNUM
  , U_USERCODE as USERCODE
  , U_NOTE as NOTE
  , U_SENTTS as SENTTS
  , U_STATUS as "STATUS"
  , N'' as STATUS_LANGVAL
  , N'' as STATUS_MEAN
  , U_PATH as "PATH"
  from "@IFSZ_EMAILOUTHEAD"
;

create view IFSZ_F_EOH_EOL_V as
select "Code" as ID
  , eol.U_EOH_ID as EOH_ID
  , eol.U_LINENUM as LINENUM
  , eol.U_DOCTYPE as DOCTYPE
  , N'' as DOCTYPE_LANGVAL
  , N'' as DOCTYPE_MEAN
  , eol.U_DOCENTRY as DOCENTRY
  , eol.U_DOCNUM as DOCNUM
  , eol.U_CRYSTAL as CRYSTAL
  , rdoc."DocName" as CRYSTALNAME
  , eol.U_MAIL_SUBJECT as MAIL_SUBJECT
  , eol.U_MAIL_BODY as MAIL_BODY
  , eol.U_FILE as "FILE"
  , eol.U_STATUS as "STATUS"
  , N'' as STATUS_LANGVAL
  , N'' as STATUS_MEAN
  , (select string_agg(a.U_CNTCT_EMAIL, ',' order by a."Code")
         from "@IFSZ_EMAILOUTADDR" a
        where a.U_EOL_ID = eol."Code"
	) as EMAILS
  , f."CardCode" as CARDCODE
  , f."CardName" as CARDNAME
  , eol.U_SENTTS as SENTTS
  , "U_ISHTML" as "ISHTML"
  , eol."U_EBIZTIP" as  "EBIZTIP"
  , N'' as EBIZTIP_LANGVAL
  , N'' as EBIZTIP_MEAN
 from "@IFSZ_EMAILOUTLINE" eol
 left join RDOC on eol.U_CRYSTAL = rdoc."DocCode"
 left join IFSZ_DFEJ f on eol.U_DOCTYPE = f."ObjType" and eol.U_DOCENTRY = f."DocEntry"
;

create view IFSZ_F_EOAD_EOAD_V as
  select "Code" as ID, "U_CNTCT_NAME" as "CNTCT_NAME", "U_CNTCT_EMAIL" as "CNTCT_EMAIL", "U_EOL_ID" as "EOL_ID" from "@IFSZ_EMAILOUTADDR"
;

create view "IFSZ_EMAILACCOUNTS" as select "Code" as ID, "U_NAME" as "NAME", "U_SMTP_SERVER" as "SMTP_SERVER", "U_SMTP_PORT" as "SMTP_PORT", "U_USERNAME" as "USERNAME", "U_PASSWORD" as "PASSWORD", "U_SSL" as "SSL" from "@IFSZ_EMAILACCOUNTS"
;

create view "IFSZ_EMAILOUTADDR" as select "Code" as ID, "U_CNTCT_NAME" as "CNTCT_NAME", "U_CNTCT_EMAIL" as "CNTCT_EMAIL", "U_EOL_ID" as "EOL_ID" from "@IFSZ_EMAILOUTADDR"
;

create view "IFSZ_EMAILOUTBODY" as select "Code" as ID, "U_DOCTYPE" as "DOCTYPE", "U_SUBJECT" as "SUBJECT", "U_BODY" as "BODY", "U_NAME" as "NAME", "U_LANG" as "LANG", "U_DEFAULTEMAIL" as "DEFAULTEMAIL", "U_ISHTML" as "ISHTML" from "@IFSZ_EMAILOUTBODY"
;

create view "IFSZ_EMAILOUTHEAD" as select "Code" as ID, "U_DOCNUM" as "DOCNUM", "U_USERCODE" as "USERCODE", "U_NOTE" as "NOTE", "U_SENTTS" as "SENTTS", "U_STATUS" as "STATUS", "U_PATH" as "PATH" from "@IFSZ_EMAILOUTHEAD"
;

create view "IFSZ_EMAILOUTLINE" as select "Code" as ID, "U_DOCTYPE" as "DOCTYPE", "U_CRYSTAL" as "CRYSTAL", "U_MAIL_SUBJECT" as "MAIL_SUBJECT", "U_MAIL_BODY" as "MAIL_BODY", "U_FILE" as "FILE", "U_STATUS" as "STATUS", "U_EOH_ID" as "EOH_ID", "U_LINENUM" as "LINENUM", "U_DOCENTRY" as "DOCENTRY", "U_DOCNUM" as "DOCNUM", "U_SENTTS" as "SENTTS", "U_ISHTML" as "ISHTML", "U_EBIZTIP" as "EBIZTIP", "U_MD5_FILE" as "MD5_FILE", "U_MD5_SIGNED" as "MD5_SIGNED" from "@IFSZ_EMAILOUTLINE"
;

create view "IFSZ_CRD_EMAILBODY" as select "Code" as ID, "U_CARDCODE" as "CARDCODE", "U_BODY" as "BODY" from "@IFSZ_CRD_EMAILBODY"
;

CREATE VIEW IFSZ_EDOC_ADDRESSES_V as
select f."DocEntry" as DOCENTRY, f."ObjType" as OBJTYPE, f."DocNum" as DOCNUM, ocpr."CardCode" as CARDCODE, ocpr.U_EBIZNAME, ocpr."E_MailL" as EMAIL
  from IFSZ_DFEJ f
  join ocpr on f."CardCode" = ocpr."CardCode" and ifnull(ocpr."E_MailL", '') <> '' and ifnull(ocpr.U_EBIZNAME, '') <> ''
;

create VIEW IFSZ_EDOC_CRYSTALS_V as
select f."DocEntry" as DOCENTRY, f."ObjType" as OBJTYPE, f."DocNum" as DOCNUM, rdoc."DocCode" DOCCODE, rdoc."DocName" DOCNAME
  from IFSZ_DFEJ f
  join IFSZ_EDOC_TYPES_V et on cast(f."ObjType" as nvarchar) = et.CODE
  join rdoc on et.rtyppre
                   ||
                   CASE when f."ObjType" in (163, 164, 165, 166) then -- Helyesb�t� sz�ml�k eset�n nem 1/2 a k�d, hanem 3/4
                       case when f."DocType" = 'I'
                            then N'4'
                            else N'3'
                       end
                   else
                       case when f."DocType" = 'I'
                            then N'2'
                            else N'1'
                       end
                   end = rdoc."TypeCode" and rdoc."Template" is not null
;

create function IFSZ_OSSZEG_FORMAZ_F(
  IN p_osszeg decimal(19,6)
, IN p_penznem nvarchar(10)
) returns l_ret nvarchar(100) as
  l_osszegs nvarchar(100);
  l_osszegint bigint;
  l_len int;
  l_tsep char(1);
  l_dsep char(1);
  l_dec int;
begin
  SELECT "Decimals"
    INTO l_dec
    FROM OCRN
   WHERE "CurrCode" = :p_penznem
  ;
  SELECT ifnull("ThousSep", N'')
       , LENGTH(ifnull("ThousSep", N'')) + 3
       , "DecSep"
	   , CASE WHEN :l_dec = -1 THEN ifnull("SumDec", 0) ELSE :l_dec END
	INTO l_tsep
	   , l_len
	   , l_dsep
	   , l_dec
    FROM OADM
  ;
  p_osszeg := round(:p_osszeg, :l_dec);
  l_osszegint := floor(:p_osszeg);
  l_ret := right( N'000000000000' || cast(:l_osszegint as nvarchar), 12 );
  l_ret := SUBSTRING(:l_ret, 1, 3) || :l_tsep || SUBSTRING(:l_ret, 4, 3) || :l_tsep || SUBSTRING(:l_ret, 7, 3) || :l_tsep || SUBSTRING(:l_ret, 10, 3);
  if :l_ret like N'000' || :l_tsep || N'%' then
    l_ret := SUBSTRING(:l_ret, 1+:l_len, 255);
  end if;
  if :l_ret like N'000' || :l_tsep || N'%' then
    l_ret := SUBSTRING(:l_ret, 1+:l_len, 255);
  end if;
  if :l_ret like N'000' || :l_tsep || N'%' then
    l_ret := SUBSTRING(:l_ret, 1+:l_len, 255);
  end if;
  if :l_ret = N'000' || :l_tsep || N'%' then
    l_ret := '0';
  else
    if :l_ret like N'00%' then
	  l_ret = SUBSTRING(:l_ret, 3, 255);
	end if;
    if :l_ret like N'0%' then
	  l_ret = SUBSTRING(:l_ret, 2, 255);
	end if;
  end if;
  if :l_dec > 0 then
    l_ret := :l_ret || :l_dsep || left( cast( cast( (:p_osszeg -  :l_osszegint) * 10000000000 as bigint) as nvarchar), :l_dec );
  end if;
  l_ret := :l_ret || N' ' || :p_penznem;
end;
;

create function IFSZ_EDOC_SZLAKIV_TF(
  IN p_datefilter nvarchar(20)
, IN p_date_from datetime
, IN p_date_to datetime
, IN p_eoh_id int
, IN p_userid int
) returns table (
  ID bigint
, DOCENTRY int
, OBJTYPE nvarchar(20)
, DOCTYPE_NAME nvarchar(29)
, DOCNUM nvarchar(50)
, DOCDATE timestamp
, TAXDATE timestamp
, VATDATE timestamp
, DOCDUEDATE timestamp
, CREATEDATE timestamp
, CARDCODE nvarchar(15)
, CARDNAME nvarchar(100)
, BIZOSSZ nvarchar(100)
, BIZOSSZ_ERTEK decimal(21,6)
, BIZOSSZ_DEV nvarchar(3)
, USERID smallint
, USERNAME nvarchar(155)
, MAIL_SUBJECT nvarchar(100)
, MAIL_BODY nvarchar(254)
, ISHTML char(1)
, SABLON_ID int
, JELOLN int
, PRINTED nvarchar(1)
, PRINTEDVAL nvarchar(4)
, SENDSTATUS nvarchar(1)
, SENDSTATUSVAL nvarchar(10)
, EBIZTIP char(1)
, EBIZTIP_DISP nvarchar(255)
--, "Ad�sz�m" nvarchar(50)
) AS
  l_cegnev nvarchar(100);
  l_fhonev nvarchar(100);
BEGIN
  select ifnull(min("PrintHeadr"), '')
    into l_cegnev
    from OADM
  ;
  select ifnull(min(U_NAME), '')
    into l_fhonev
    from OUSR
   where INTERNAL_K = :p_userid
  ;

  return
    select row_number() over (order by f."DocDate", f."ObjType", f."DocEntry") as ID
         , f."DocEntry" as DOCENTRY, f."ObjType" as OBJTYPE, et."NAME" as DOCTYPE_NAME, f."Szamlaszam" as DOCNUM, f."DocDate" as DOCDATE, f."TaxDate" as TAXDATE, f."VatDate" as VATDATE, f."DocDueDate" as DOCDUEDATE, f."CreateDate" as CREATEDATE, f."CardCode" as CARDCODE, f."CardName" as CARDNAME
		 , cast(null as nvarchar(100)) as BIZOSSZ, case when f."DocTotalFC" = 0 then f."DocTotal" else f."DocTotalFC" end as BIZOSSZ_ERTEK, f."DocCur" as BIZOSSZ_DEV, f."UserSign" as USERID, ousr.U_NAME as USERNAME
	     , ifnull( ifnull(eob1.U_SUBJECT, eob2.U_SUBJECT), eob3.U_SUBJECT ) as MAIL_SUBJECT
		 , ifnull( ifnull(eob1.U_BODY, eob2.U_BODY), eob3.U_BODY ) as MAIL_BODY
		 , ifnull( ifnull(eob1.U_ISHTML, eob2.U_ISHTML), eob3.U_ISHTML ) as ISHTML, cast( ifnull( ifnull(eob1."Code", eob2."Code"), eob3."Code" ) as integer) as SABLON_ID
		 , 0 as JELOLN, f."Printed" as PRINTED, CASE when f."Printed" = 'Y' then N'Igen' else N'Nem' end as PRINTEDVAL
		 , (select ifnull( MAX(eol.U_STATUS), N'-' ) from "@IFSZ_EMAILOUTLINE" eol join "@IFSZ_EMAILOUTHEAD" eoh on eol.U_EOH_ID = eoh."Code" and eoh.U_STATUS <> 'C' where eol.U_DOCTYPE = f."ObjType" and eol.U_DOCENTRY = f."DocEntry") SENDSTATUS
		 , (select
               CASE ifnull( MAX(eol.U_STATUS), N'-' )
	                         WHEN 'S' THEN N'Kik�ldve'
							 WHEN 'R' THEN N'R�gz�tve'
							 ELSE N''
						   END
              from "@IFSZ_EMAILOUTLINE" eol join "@IFSZ_EMAILOUTHEAD" eoh on eol.U_EOH_ID = eoh."Code" and eoh.U_STATUS <> 'C' where eol.U_DOCTYPE = f."ObjType" and eol.U_DOCENTRY = f."DocEntry"
           ) SENDSTATUSVAL
         , cast(f.U_EBIZTIP as char(1)) as EBIZTIP
         , cast(UFD1_EBIZTIP."Descr" as nvarchar(255)) as EBIZTIP_DISP
--		 , f."LicTradNum"
      from NAVO_SZLFEJ f
	  join IFSZ_EDOC_TYPES_V et on f."ObjType" = et.code
	  left join "@IFSZ_EMAILOUTLINE" eol on cast(f."ObjType" as nvarchar) = eol.U_DOCTYPE and f."DocEntry" = eol.U_DOCENTRY and eol.u_eoh_id = :p_eoh_id
	  left join ousr on f."UserSign" = ousr.internal_k
	  left join (
	        select eob.U_DOCTYPE, ceb.U_CARDCODE, eob.U_SUBJECT, eob.U_BODY, eob.U_ISHTML, ceb."Code"
			  from "@IFSZ_CRD_EMAILBODY" ceb
			  join "@IFSZ_EMAILOUTBODY" eob on ceb.U_BODY = eob."Code"
		  ) eob1 on eob1.U_DOCTYPE = f."ObjType" and f."CardCode" = eob1.U_CARDCODE
	  left join "@IFSZ_EMAILOUTBODY" eob2 on f."LangCode" = eob2.U_LANG and eob2.U_DOCTYPE = f."ObjType" and eob2.U_DEFAULTEMAIL = 'Y'
	  left join "@IFSZ_EMAILOUTBODY" eob3 on eob3.U_LANG is null and eob3.U_DOCTYPE = f."ObjType" and eob3.U_DEFAULTEMAIL = 'Y'
	  left join CUFD CUFD_EBIZTIP on CUFD_EBIZTIP."TableID" = N'OINV' and CUFD_EBIZTIP."AliasID" = N'EBIZTIP'
	  left join UFD1 UFD1_EBIZTIP on UFD1_EBIZTIP."TableID" = CUFD_EBIZTIP."TableID" and UFD1_EBIZTIP."FieldID" = CUFD_EBIZTIP."FieldID" and UFD1_EBIZTIP."FldValue" = f.U_EBIZTIP
     where (
	         (:p_datefilter = 'K'
	            and f."DocDate" >= :p_date_from
	            and f."DocDate" <= ifnull(:p_date_to, f."DocDate")
	         )
			 or 
	         (:p_datefilter = 'L'
	            and f."CreateDate" >= :p_date_from
	            and f."CreateDate" <= ifnull(:p_date_to, f."CreateDate")
	         )
		  )
	   and eol."Code" is null
       and :p_date_from is not null
    ;

END;

create function IFSZ_GET_DEF_CRYSTAL_LAYOUT_F(
  IN p_objtype int
, IN p_docentry int
, IN p_userid int
) returns l_doccode nvarchar(100) as
  l_rtyp nvarchar(100);
begin

  select RTYPPRE
    into l_rtyp
    from IFSZ_EDOC_TYPES_V
   where CODE = :p_objtype
  ;
  select :l_rtyp
             ||
             CASE when "ObjType" in (163, 164, 165, 166) then -- Helyesb�t� sz�ml�k eset�n nem 1/2 a k�d, hanem 3/4
                 case when "DocType" = 'I'
                      then N'4'
                      else N'3'
                 end
             else
                 case when "DocType" = 'I'
                      then N'2'
                      else N'1'
                 end
             end

    into l_rtyp
    from IFSZ_DFEJ
   where "DocEntry" = :p_docentry
     and "ObjType" = :p_objtype
  ;
  -- 1: Van-e olyan, hogy user �s cardcode is
  select min(rdoc."DocCode")
    into l_doccode
    from rdfl
	join ocrd on rdfl."CardCode" = ocrd."CardCode"
	join ousr on rdfl."UserId" = ousr.internal_k
	join rdoc on rdfl."DfltReport" = rdoc."DocCode" and rdoc."Template" is not null
   where rdfl."DoumntDode" = :l_rtyp
  ;
  -- 2: Van-e olyan, hogy cardcode �s all users
  if :l_doccode is null then
    select min(rdoc."DocCode")
      into l_doccode
      from rdfl
	  join ocrd on rdfl."CardCode" = ocrd."CardCode"
	  join rdoc on rdfl."DfltReport" = rdoc."DocCode" and rdoc."Template" is not null
     where rdfl."DoumntDode" = :l_rtyp
    --   and rdfl."UserId" = -1
    ;
  end if;
  -- 3: Van-e olyan, hogy user �s minden partner
  if :l_doccode is null then
    select min(rdoc."DocCode")
      into l_doccode
      from rdfl
	  join ousr on rdfl."UserId" = ousr.internal_k
	  join rdoc on rdfl."DfltReport" = rdoc."DocCode" and rdoc."Template" is not null
     where rdfl."DoumntDode" = :l_rtyp
    --   and rdfl."CardCode" = '-1'
    ;
  end if;
  -- 4: Az alapbe�ll�t�s
  if :l_doccode is null then
    select min(rdoc."DocCode")
      into l_doccode
      from rtyp
	  join rdoc on rtyp.deflt_rep = rdoc."DocCode" and rdoc."Template" is not null
     where code = :l_rtyp
    ;
  end if;
END
;

create function IFSZ_GET_EDOC_FROMMAIL_F(
  IN p_objtype int
, IN p_docentry int
, IN p_userid int
) returns l_ret nvarchar(100) as
begin
  -- �ltal�ban:
  select ifnull(min(ousr."E_Mail"), N'')
    into l_ret
    from OUSR
   where INTERNAL_K = :p_userid
  ;

end
;

CREATE VIEW IFSZ_EBIZ_ATC_V as
  select eol."Code", "trgtPath", "FileName", "FileExt", "Line"
    from "@IFSZ_EMAILOUTLINE" eol
	join IFSZ_DFEJ df on eol.U_DOCTYPE = df."ObjType" and eol.U_DOCENTRY = df."DocEntry"
	join atc1 on df."AtcEntry" = ATC1."AbsEntry"
;


CREATE TABLE IFSZ_GRID_BEALLITASOK (
     SZINT NVARCHAR(50) CS_STRING NOT NULL,
	 AZONOSITO NVARCHAR(50) CS_STRING,
	 AZONOSITO2 NVARCHAR(50) CS_STRING,
	 FORMNEV NVARCHAR(50) CS_STRING NOT NULL,
	 GRIDNEV NVARCHAR(100) CS_STRING NOT NULL,
	 OSZLOPNEV NVARCHAR(100) CS_STRING NOT NULL,
	 DISPLAYINDEX INT CS_INT NOT NULL,
	 SZELESSEG INT CS_INT NOT NULL,
	 FEJLEC NVARCHAR(255) CS_STRING ) 
;

-- Arch�v adatb�zis:
-- create column table IFSZ_EMAILOUTLINE(DB nvarchar(255) not null, ID int not null, FILE_PATH nvarchar(255) not null, MD5_SIGNED nvarchar(255) not null, FILE_BIN image, constraint IFSZ_EMAILOUTLINE_PK primary key clustered(db, id)) -- TODO Han�s�tani