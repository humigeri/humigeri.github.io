create view IFSZ_EDOC_TYPES_V AS
select N'13' as CODE
     , N'Kimen� sz�mla' as NAME
	 , N'INV' as RTYPPRE
	 , N'KSZ' as SHORTNAME
union all
select N'14' as CODE
     , N'�rt�kes�t�si j�v��r�s' as NAME
	 , N'RIN' as RTYPPRE
	 , N'KJ' as SHORTNAME
/*union all
select N'165' as CODE
     , N'Kimen� helyesb�t� sz�mla' as NAME
	 , N'CSI' as RTYPPRE
	 , N'KH' as SHORTNAME
union all
select N'166' as CODE
     , N'Kimen� helyesb�t� visszavon�sa' as NAME
	 , N'CSV' as RTYPPRE
	 , N'KHV' as SHORTNAME
union all
select N'15' as CODE
     , N'Sz�ll�t�s' as NAME
	 , N'ODLN' as RTYPPRE
	 , N'SZ' as SHORTNAME
union all
select N'16' as CODE
     , N'Vev�i vissz�ru' as NAME
	 , N'ORDN' as RTYPPRE
	 , N'VV' as SHORTNAME
union all
select N'163' as CODE
     , N'Beszerz�si helyesb�to sz�mla ' as NAME
	 , N'OCPI' as RTYPPRE
	 , N'BH' as SHORTNAME
union all
select N'164' as CODE
     , N'Beszerz�si hely szla vissza' as NAME
	 , N'OCPV' as RTYPPRE
	 , N'BHV' as SHORTNAME
union all
select N'17' as CODE
     , N'Vev�i rendel�s' as NAME
	 , N'ORDR' as RTYPPRE
	 , N'RD' as SHORTNAME
union all
select N'18' as CODE
     , N'Bej�v� sz�mla' as NAME
	 , N'OPCH' as RTYPPRE
	 , N'SS' as SHORTNAME
union all
select N'19' as CODE
     , N'Beszerz�si j�v��r�s ' as NAME
	 , N'ORPC' as RTYPPRE
	 , N'SJ' as SHORTNAME
union all
select N'20' as CODE
     , N'�rube�rkez�s' as NAME
	 , N'OPDN' as RTYPPRE
	 , N'�B' as SHORTNAME
union all
select N'203' as CODE
     , N'�rt�kes�t�si el�leg' as NAME
	 , N'ODPI' as RTYPPRE
	 , N'KE' as SHORTNAME
union all
select N'204' as CODE
     , N'Beszerz�si el�leg' as NAME
	 , N'ODPO' as RTYPPRE
	 , N'BE' as SHORTNAME
union all
select N'21' as CODE
     , N'Sz�ll�t�i vissz�ru' as NAME
	 , N'ORPD' as RTYPPRE
	 , N'SV' as SHORTNAME
union all
select N'22' as CODE
     , N'Megrendel�s' as NAME
	 , N'OPOR' as RTYPPRE
	 , N'MR' as SHORTNAME
union all
select N'23' as CODE
     , N'Aj�nlat' as NAME
	 , N'OQUT' as RTYPPRE
	 , N'AJ' as SHORTNAME
union all
select N'59' as CODE
     , N'Anyagbev�telez�s' as NAME
	 , N'OIGN' as RTYPPRE
	 , N'AB' as SHORTNAME
union all
select N'60' as CODE
     , N'Anyagkiad�s' as NAME
	 , N'OIGE' as RTYPPRE
	 , N'AK' as SHORTNAME
union all
select N'67' as CODE
     , N'�tt�rol�s' as NAME
	 , N'OWTR' as RTYPPRE
	 , N'�T' as SHORTNAME
*/
GO

create view IFSZ_F_EOA_EOA_V as
select "Code" as ID
     , U_NAME as NAME
	 , U_SMTP_SERVER as SMTP_SERVER
	 , U_SMTP_PORT as SMTP_PORT
	 , U_USERNAME as USERNAME
	 , U_PASSWORD as PASSWORD
	 , U_SSL as SSL
	 , '' as SSL_LANGVAL
	 , '' as SSL_MEAN
  from "@IFSZ_EMAILACCOUNTS"
GO

create view IFSZ_F_EOB_EOB_V as
select t."Code" as ID
  , t.U_DOCTYPE as DOCTYPE
  , dt.NAME as DOCTYPE_NAME
  , t.U_NAME as "NAME"
  , t.U_SUBJECT as "SUBJECT"
  , t.U_BODY as BODY
  , t.U_LANG as LANG
  , OLNG."Name" as LANG_NAME
  , t.U_DEFAULTEMAIL as DEFAULTEMAIL
  , '' as DEFAULTEMAIL_LANGVAL
  , '' as DEFAULTEMAIL_MEAN
  , t.U_ISHTML as ISHTML
  , '' as ISHTML_LANGVAL
  , '' as ISHTML_MEAN
  from "@IFSZ_EMAILOUTBODY" t
  left join OLNG on t.U_LANG = OLNG."Code"
  left join IFSZ_EDOC_TYPES_V dt on t.U_DOCTYPE = dt.CODE
GO

create view IFSZ_F_EOB_CRD_V as
select t."Code" as ID
  , t.U_CARDCODE as CARDCODE
  , ocrd."CardName" as CARDNAME
  , t.U_BODY as BODY
  from "@IFSZ_CRD_EMAILBODY" t
  left join OCRD on t.U_CARDCODE = OCRD."CardCode"
GO

create view IFSZ_F_EOH_EOH_V as
select "Code" as ID
  , U_DOCNUM as DOCNUM
  , U_USERCODE as USERCODE
  , U_NOTE as NOTE
  , U_SENTTS as SENTTS
  , U_STATUS as "STATUS"
  , N'' as STATUS_LANGVAL
  , N'' as STATUS_MEAN
  , U_PATH as "PATH"
  from "@IFSZ_EMAILOUTHEAD"
GO

create view IFSZ_F_EOH_EOL_V as
select "Code" as ID
  , eol.U_EOH_ID as EOH_ID
  , eol.U_LINENUM as LINENUM
  , eol.U_DOCTYPE as DOCTYPE
  , N'' as DOCTYPE_LANGVAL
  , N'' as DOCTYPE_MEAN
  , eol.U_DOCENTRY as DOCENTRY
  , eol.U_DOCNUM as DOCNUM
  , eol.U_CRYSTAL as CRYSTAL
  , rdoc."DocName" as CRYSTALNAME
  , eol.U_MAIL_SUBJECT as MAIL_SUBJECT
  , eol.U_MAIL_BODY as MAIL_BODY
  , eol.U_FILE as "FILE"
  , eol.U_STATUS as "STATUS"
  , N'' as STATUS_LANGVAL
  , N'' as STATUS_MEAN
  , stuff(
      (select ',' + a.U_CNTCT_EMAIL
         from "@IFSZ_EMAILOUTADDR" a
        where a.U_EOL_ID = eol."Code"
        order by a."Code" for xml path('')
	  )
    , 1, 1, '') as EMAILS
  , f."CardCode" as CARDCODE
  , f."CardName" as CARDNAME
  , eol.U_SENTTS as SENTTS
  , "U_ISHTML" as "ISHTML"
  , "U_EBIZTIP" as  "EBIZTIP"
  , N'' as EBIZTIP_LANGVAL
  , N'' as EBIZTIP_MEAN
 from "@IFSZ_EMAILOUTLINE" eol
 left join RDOC on eol.U_CRYSTAL = rdoc."DocCode"
 left join IFSZ_DFEJ f on eol.U_DOCTYPE = f."ObjType" and eol.U_DOCENTRY = f."DocEntry"
GO

create view IFSZ_F_EOAD_EOAD_V as
  select "Code" as ID, "U_CNTCT_NAME" as "CNTCT_NAME", "U_CNTCT_EMAIL" as "CNTCT_EMAIL", "U_EOL_ID" as "EOL_ID" from "@IFSZ_EMAILOUTADDR"
GO

create view "IFSZ_EMAILACCOUNTS" as select "Code" as ID, "U_NAME" as "NAME", "U_SMTP_SERVER" as "SMTP_SERVER", "U_SMTP_PORT" as "SMTP_PORT", "U_USERNAME" as "USERNAME", "U_PASSWORD" as "PASSWORD", "U_SSL" as "SSL" from "@IFSZ_EMAILACCOUNTS"
GO

create view "IFSZ_EMAILOUTADDR" as select "Code" as ID, "U_CNTCT_NAME" as "CNTCT_NAME", "U_CNTCT_EMAIL" as "CNTCT_EMAIL", "U_EOL_ID" as "EOL_ID" from "@IFSZ_EMAILOUTADDR"
GO

create view "IFSZ_EMAILOUTBODY" as select "Code" as ID, "U_DOCTYPE" as "DOCTYPE", "U_SUBJECT" as "SUBJECT", "U_BODY" as "BODY", "U_NAME" as "NAME", "U_LANG" as "LANG", "U_DEFAULTEMAIL" as "DEFAULTEMAIL", "U_ISHTML" as "ISHTML" from "@IFSZ_EMAILOUTBODY"
GO

create view "IFSZ_EMAILOUTHEAD" as select "Code" as ID, "U_DOCNUM" as "DOCNUM", "U_USERCODE" as "USERCODE", "U_NOTE" as "NOTE", "U_SENTTS" as "SENTTS", "U_STATUS" as "STATUS", "U_PATH" as "PATH" from "@IFSZ_EMAILOUTHEAD"
GO

create view "IFSZ_EMAILOUTLINE" as select "Code" as ID, "U_DOCTYPE" as "DOCTYPE", "U_CRYSTAL" as "CRYSTAL", "U_MAIL_SUBJECT" as "MAIL_SUBJECT", "U_MAIL_BODY" as "MAIL_BODY", "U_FILE" as "FILE", "U_STATUS" as "STATUS", "U_EOH_ID" as "EOH_ID", "U_LINENUM" as "LINENUM", "U_DOCENTRY" as "DOCENTRY", "U_DOCNUM" as "DOCNUM", "U_SENTTS" as "SENTTS", "U_ISHTML" as "ISHTML", "U_EBIZTIP" as "EBIZTIP", "U_MD5_FILE" as "MD5_FILE", "U_MD5_SIGNED" as "MD5_SIGNED" from "@IFSZ_EMAILOUTLINE"
GO

create view "IFSZ_CRD_EMAILBODY" as select "Code" as ID, "U_CARDCODE" as "CARDCODE", "U_BODY" as "BODY" from "@IFSZ_CRD_EMAILBODY"
GO

create function IFSZ_OSSZEG_FORMAZ_F(
  @p_osszeg decimal(19,6)
, @p_penznem nvarchar(10)
) returns nvarchar(100) as
begin
  declare @l_osszegs nvarchar(100), @l_ret nvarchar(100), @l_osszegint bigint, @len int;
  declare @tsep char(1), @dsep char(1), @dec int;
  SELECT @dec  = "Decimals"
    FROM OCRN
   WHERE "CurrCode" = @p_penznem
  ;
  SELECT @tsep = isnull("ThousSep", N'')
       , @len  = LEN(isnull("ThousSep", N'')) + 3
       , @dsep = "DecSep"
	   , @dec  = CASE WHEN @dec = -1 THEN ISNULL("SumDec", 0) ELSE @dec END
    FROM OADM
  ;
  set @p_osszeg = round(@p_osszeg, @dec);
  set @l_osszegint = floor(@p_osszeg);
  set @l_ret = right( N'000000000000' + cast(@l_osszegint as nvarchar), 12 );
  set @l_ret = SUBSTRING(@l_ret, 1, 3) + @tsep + SUBSTRING(@l_ret, 4, 3) + @tsep + SUBSTRING(@l_ret, 7, 3) + @tsep + SUBSTRING(@l_ret, 10, 3);
  if @l_ret like N'000' + @tsep + N'%'
    set @l_ret = SUBSTRING(@l_ret, 1+@len, 255);
  if @l_ret like N'000' + @tsep + N'%'
    set @l_ret = SUBSTRING(@l_ret, 1+@len, 255);
  if @l_ret like N'000' + @tsep + N'%'
    set @l_ret = SUBSTRING(@l_ret, 1+@len, 255);
  if @l_ret = N'000' + @tsep + N'%'
  begin
    set @l_ret = '0';
  end
  else
  begin
    if @l_ret like N'00%'
	  set @l_ret = SUBSTRING(@l_ret, 3, 255);
    if @l_ret like N'0%'
	  set @l_ret = SUBSTRING(@l_ret, 2, 255);
  end
  if @dec > 0
  begin
    set @l_ret = @l_ret + @dsep + left( cast( cast( (@p_osszeg -  @l_osszegint) * 10000000000 as bigint) as nvarchar), @dec );
  end
  return @l_ret + N' ' + @p_penznem;
end;
go

create function IFSZ_DATUM_FORMAZ_F(
  @p_datum datetime
) returns nvarchar(100) as
begin
  declare @dateformat int;
  SELECT @dateformat = "DateFormat"
    FROM OADM
  ;
  if @dateformat = 0
    return replace(CONVERT(nvarchar, @p_datum, 4), N'.', N'/');
  if @dateformat = 1
    return CONVERT(nvarchar, @p_datum, 104);
  if @dateformat = 2
    return CONVERT(nvarchar, @p_datum, 1);
  if @dateformat = 3
    return CONVERT(nvarchar, @p_datum, 101);
  if @dateformat = 4
    return replace(CONVERT(nvarchar, @p_datum, 102), N'.', N'/');
  if @dateformat = 5
    return replace(CONVERT(nvarchar, @p_datum, 104), N'.', N'/');
  if @dateformat = 6
    return CONVERT(nvarchar, @p_datum, 2);

  return null;  
end;
GO

create function IFSZ_EDOC_SZLAKIV_TF(
  @p_datefilter nvarchar(20)
, @p_date_from datetime
, @p_date_to datetime
, @p_eoh_id int
, @p_userid int
) returns @ret table (
  ID int
, DOCENTRY int
, OBJTYPE int
, DOCTYPE_NAME nvarchar(100)
, DOCNUM nvarchar(50)
, DOCDATE datetime
, TAXDATE datetime
, VATDATE datetime
, DOCDUEDATE datetime
, CREATEDATE datetime
, CARDCODE nvarchar(50)
, CARDNAME nvarchar(100)
, BIZOSSZ nvarchar(100)
, BIZOSSZ_ERTEK decimal(19,6)
, BIZOSSZ_DEV nvarchar(3)
, USERID int
, USERNAME nvarchar(255)
, MAIL_SUBJECT nvarchar(255)
, MAIL_BODY nvarchar(2000)
, ISHTML char(1)
, SABLON_ID int
, JELOLN smallint
, PRINTEDVAL char(1)
, PRINTED nvarchar(20)
, SENDSTATUS char(1)
, SENDSTATUSVAL nvarchar(50)
, EBIZTIP char(1)
, EBIZTIP_DISP nvarchar(255)
--, "Ad�sz�m" nvarchar(50)
) AS
BEGIN
  declare @cegnev nvarchar(100), @fhonev nvarchar(100);
  select @cegnev = isnull(min("PrintHeadr"), '')
    from OADM
  ;
  select @fhonev = isnull(min(U_NAME), '')
    from OUSR
   where INTERNAL_K = @p_userid
  ;

  if @p_date_from is not null
  begin
  
    insert into @ret(
        ID, DOCENTRY, OBJTYPE, DOCTYPE_NAME, DOCNUM, DOCDATE, TAXDATE, VATDATE, DOCDUEDATE, CREATEDATE, CARDCODE, CARDNAME
	  , BIZOSSZ_ERTEK, BIZOSSZ_DEV, USERID, USERNAME
  	  , MAIL_SUBJECT, MAIL_BODY, ISHTML, SABLON_ID, JELOLN, PRINTEDVAL, PRINTED, SENDSTATUS, SENDSTATUSVAL, EBIZTIP, EBIZTIP_DISP
--	  , "Ad�sz�m"
    )
    select row_number() over (order by f.docdate, f.objtype, f.docentry)
         , f.docentry, f.objtype, et."NAME", f.Szamlaszam, f.docdate, f.TaxDate, f.VatDate, f.DocDueDate, f.CreateDate, f.CardCode, f.CardName
		 , case when f."DocTotalFC" = 0 then f."DocTotal" else f."DocTotalFC" end as BIZOSSZ_ERTEK, f."DocCur" as BIZOSSZ_DEV, f."UserSign", ousr.U_NAME
	     , isnull( isnull(eob1.U_SUBJECT, eob2.U_SUBJECT), eob3.U_SUBJECT )
		 , isnull( isnull(eob1.U_BODY, eob2.U_BODY), eob3.U_BODY )
		 , isnull( isnull(eob1.U_ISHTML, eob2.U_ISHTML), eob3.U_ISHTML ), isnull( isnull(eob1."Code", eob2."Code"), eob3."Code" )
		 , 0, f.Printed, CASE when f.Printed = 'Y' then N'Igen' else N'Nem' end
		 , (select ISNULL( MAX(eol.U_STATUS), N'-' ) from "@IFSZ_EMAILOUTLINE" eol join "@IFSZ_EMAILOUTHEAD" eoh on eol.U_EOH_ID = eoh."Code" and eoh.U_STATUS <> 'C' where eol.U_DOCTYPE = f."ObjType" and eol.U_DOCENTRY = f."DocEntry") SENDSTATUS
		 , (select
               CASE ISNULL( MAX(eol.U_STATUS), N'-' )
	                         WHEN 'S' THEN N'Kik�ldve'
							 WHEN 'R' THEN N'R�gz�tve'
							 ELSE N''
						   END
              from "@IFSZ_EMAILOUTLINE" eol join "@IFSZ_EMAILOUTHEAD" eoh on eol.U_EOH_ID = eoh."Code" and eoh.U_STATUS <> 'C' where eol.U_DOCTYPE = f."ObjType" and eol.U_DOCENTRY = f."DocEntry"
           ) SENDSTATUSVAL
		 , f.U_EBIZTIP as EBIZTIP
		 , UFD1_EBIZTIP."Descr" as EBIZTIP_DISP
--		 , f."LicTradNum"
      from NAVO_SZLFEJ f
	  join IFSZ_EDOC_TYPES_V et on f."ObjType" = et.code
	  left join "@IFSZ_EMAILOUTLINE" eol on cast(f."ObjType" as nvarchar) = eol.U_DOCTYPE and f."DocEntry" = eol.U_DOCENTRY and eol.u_eoh_id = @p_eoh_id
	  left join ousr on f."UserSign" = ousr.internal_k
	  left join (
	        select eob.U_DOCTYPE, ceb.U_CARDCODE, eob.U_SUBJECT, eob.U_BODY, eob.U_ISHTML, ceb."Code"
			  from "@IFSZ_CRD_EMAILBODY" ceb
			  join "@IFSZ_EMAILOUTBODY" eob on ceb.U_BODY = eob."Code"
		  ) eob1 on eob1.U_DOCTYPE = f."ObjType" and f."CardCode" = eob1.U_CARDCODE
	  left join "@IFSZ_EMAILOUTBODY" eob2 on f."LangCode" = eob2.U_LANG and eob2.U_DOCTYPE = f."ObjType" and eob2.U_DEFAULTEMAIL = 'Y'
	  left join "@IFSZ_EMAILOUTBODY" eob3 on eob3.U_LANG is null and eob3.U_DOCTYPE = f."ObjType" and eob3.U_DEFAULTEMAIL = 'Y'
	  left join CUFD CUFD_EBIZTIP on CUFD_EBIZTIP."TableID" = N'OINV' and CUFD_EBIZTIP."AliasID" = N'EBIZTIP'
	  left join UFD1 UFD1_EBIZTIP on UFD1_EBIZTIP."TableID" = CUFD_EBIZTIP."TableID" and UFD1_EBIZTIP."FieldID" = CUFD_EBIZTIP."FieldID" and UFD1_EBIZTIP."FldValue" = f.U_EBIZTIP
     where (
	         (@p_datefilter = 'K'
	            and f."DocDate" >= @p_date_from
	            and f."DocDate" <= isnull(@p_date_to, f."DocDate")
	         )
			 or 
	         (@p_datefilter = 'L'
	            and f."CreateDate" >= @p_date_from
	            and f."CreateDate" <= isnull(@p_date_to, f."CreateDate")
	         )
		  )
	   and eol."Code" is null
    ;
--	update @ret
--	   set SENDSTATUSVAL = CASE SENDSTATUS
--	                         WHEN 'S' THEN N'Kik�ldve'
--							 WHEN 'R' THEN N'R�gz�tve'
--							 ELSE N''
--						   END
--    ;
  end

  return;
END
GO

create function IFSZ_GET_DEF_CRYSTAL_LAYOUT_F(
  @p_objtype int
, @p_docentry int
, @p_userid int
) returns nvarchar(100) as
begin
  declare @l_rtyp as nvarchar(100);
  declare @l_doccode as nvarchar(100);

  select @l_rtyp = RTYPPRE
    from IFSZ_EDOC_TYPES_V
   where CODE = @p_objtype
  ;
  select @l_rtyp = @l_rtyp
                   +
                   CASE when "ObjType" in (163, 164, 165, 166) then -- Helyesb�t� sz�ml�k eset�n nem 1/2 a k�d, hanem 3/4
                       case when "DocType" = 'I'
                            then N'4'
                            else N'3'
                       end
                   else
                       case when "DocType" = 'I'
                            then N'2'
                            else N'1'
                       end
                   end
    from IFSZ_DFEJ
   where "DocEntry" = @p_docentry
     and "ObjType" = @p_objtype
  ;
  -- 1: Van-e olyan, hogy user �s cardcode is
  select @l_doccode = min(rdoc."DocCode")
    from rdfl
	join ocrd on rdfl."CardCode" = ocrd."CardCode"
	join ousr on rdfl."UserId" = ousr.internal_k
	join rdoc on rdfl."DfltReport" = rdoc."DocCode" and rdoc."Template" is not null
   where rdfl."DoumntDode" = @l_rtyp
  ;
  -- 2: Van-e olyan, hogy cardcode �s all users
  if @l_doccode is null
    select @l_doccode = min(rdoc."DocCode")
      from rdfl
	  join ocrd on rdfl."CardCode" = ocrd."CardCode"
	  join rdoc on rdfl."DfltReport" = rdoc."DocCode" and rdoc."Template" is not null
     where rdfl."DoumntDode" = @l_rtyp
    --   and rdfl."UserId" = -1
    ;
  -- 3: Van-e olyan, hogy user �s minden partner
  if @l_doccode is null
    select @l_doccode = min(rdoc."DocCode")
      from rdfl
	  join ousr on rdfl."UserId" = ousr.internal_k
	  join rdoc on rdfl."DfltReport" = rdoc."DocCode" and rdoc."Template" is not null
     where rdfl."DoumntDode" = @l_rtyp
    --   and rdfl."CardCode" = '-1'
    ;
  -- 4: Az alapbe�ll�t�s
  if @l_doccode is null
    select @l_doccode = min(rdoc."DocCode")
      from rtyp
	  join rdoc on rtyp.deflt_rep = rdoc."DocCode" and rdoc."Template" is not null
     where code = @l_rtyp
    ;
  return @l_doccode;
END
GO

CREATE VIEW IFSZ_EDOC_ADDRESSES_V as
select f."DocEntry" as DOCENTRY, f."ObjType" as OBJTYPE, f."DocNum" as DOCNUM, ocpr."CardCode" as CARDCODE, ocpr.U_EBIZNAME, ocpr."E_MailL" as EMAIL
  from IFSZ_DFEJ f
  join ocpr on f."CardCode" = ocpr."CardCode" and isnull(ocpr."E_MailL", '') <> '' and isnull(ocpr.U_EBIZNAME, '') <> ''
GO

CREATE VIEW IFSZ_EDOC_CRYSTALS_V as
select f."DocEntry" as DOCENTRY, f."ObjType" as OBJTYPE, f."DocNum" as DOCNUM, rdoc.DocCode DOCCODE, rdoc.DocName DOCNAME
  from IFSZ_DFEJ f
  join IFSZ_EDOC_TYPES_V et on cast(f.ObjType as nvarchar) = et.CODE
  join rdoc on et.rtyppre
                 +
                   CASE when f."ObjType" in (163, 164, 165, 166) then -- Helyesb�t� sz�ml�k eset�n nem 1/2 a k�d, hanem 3/4
                       case when f."DocType" = 'I'
                            then N'4'
                            else N'3'
                       end
                   else
                       case when f."DocType" = 'I'
                            then N'2'
                            else N'1'
                       end
                   end = rdoc.TypeCode and rdoc.Template is not null
GO

create function IFSZ_GET_EDOC_FROMMAIL_F(
  @p_objtype int
, @p_docentry int
, @p_userid int
) returns nvarchar(100) as
begin
  declare @l_ret nvarchar(100);
  -- �ltal�ban:
  select @l_ret = isnull(min(ousr."E_Mail"), N'')
    from OUSR
   where INTERNAL_K = @p_userid
  ;
  --TFCB-n�l
 -- if @p_docentry is null
 --   return null;
 -- else
 -- begin
 --   select @l_ret = isnull(min(ousr."E_Mail"), @l_ret)
	--  from IFSZ_DTETEL d
	--  left join IFSZ_ING_STR isr on d."OcrCode" = dbo.ifsz_get_isr_prccode_f( isr.id )  -- prccode_f kellene?
 --     left join ousr on isr.property_manager_userid = ousr.internal_k
	-- where d.ObjType = @p_objtype
	--   and d.DocEntry = @p_docentry
	--;
 -- end

  return @l_ret;

end
GO

CREATE VIEW IFSZ_EBIZ_ATC_V as
  select eol."Code", "trgtPath", "FileName", "FileExt", "Line"
    from "@IFSZ_EMAILOUTLINE" eol
	join IFSZ_DFEJ df on eol.U_DOCTYPE = df."ObjType" and eol.U_DOCENTRY = df."DocEntry"
	join atc1 on df."AtcEntry" = ATC1."AbsEntry"
  ;
GO

CREATE NONCLUSTERED INDEX IX1_IFSZ_CRD_EMAILBODY ON dbo.[@IFSZ_CRD_EMAILBODY]
	(
	U_CARDCODE
	) INCLUDE (U_BODY)
    WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

/*
CREATE TABLE [dbo].[IFSZ_GRID_BEALLITASOK](
	[SZINT] [nvarchar](50) NOT NULL,
	[AZONOSITO] [nvarchar](50) NULL,
	[AZONOSITO2] [nvarchar](50) NULL,
	[FORMNEV] [nvarchar](50) NOT NULL,
	[GRIDNEV] [nvarchar](100) NOT NULL,
	[OSZLOPNEV] [nvarchar](100) NOT NULL,
	[DISPLAYINDEX] [int] NOT NULL,
	[SZELESSEG] [int] NOT NULL
) ON [PRIMARY]
GO
*/
ALTER TABLE IFSZ_GRID_BEALLITASOK
  ADD [FEJLEC] [nvarchar](255) NULL
GO

-- Arch�v adatb�zis:
/*
 create table IFSZ_EMAILOUTLINE(DB nvarchar(255) not null, ID int not null, FILE_PATH nvarchar(255) not null, MD5_SIGNED nvarchar(255) not null, FILE_BIN image, constraint IFSZ_EMAILOUTLINE_PK primary key clustered(db, id))
 
 

alter table IFSZ_EMAILOUTLINE
  add CHECKRESULT int NOT NULL DEFAULT 0
    , CHECKTIME datetime NULL
GO

alter table IFSZ_EMAILOUTLINE
  add constraint IFSZ_EMAILOUTLINE_DF1 default getdate() for CHECKTIME
GO

create index IFSZ_EMAILOUTLINE_I1 on IFSZ_EMAILOUTLINE (DB, CHECKRESULT)
GO

create index IFSZ_EMAILOUTLINE_I2 on IFSZ_EMAILOUTLINE (DB, CHECKTIME)
GO


*/

EXEC sp_refreshview IFSZ_DCIM;
 EXEC sp_refreshview IFSZ_DFEJ;
 EXEC sp_refreshview IFSZ_DFEJC;
 EXEC sp_refreshview IFSZ_DTETEL;
 EXEC sp_refreshview IFSZ_SZLFEJ;
 EXEC sp_refreshview IFSZ_SZLTETEL;
 EXEC sp_refreshview NAVO_SZLFEJ;
 EXEC sp_refreshview NAVO_SZLTETEL;
 EXEC sp_refreshview NAVO_SZLCIM;


 -- HG 20191214 szerintem ezeknek ez a nev�k, legal�bbis a lov�szn�l ez volt:
 EXEC sp_refreshview IFSZ_SZLFEJ_V;
 EXEC sp_refreshview IFSZ_SZLTETEL_V;