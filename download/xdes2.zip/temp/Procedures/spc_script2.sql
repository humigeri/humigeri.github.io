CREATE VIEW SPC_WEB_OCRD_V AS
SELECT        OCRD.CardCode
, OCRD.CardName, OCRD.City, OCRD.Address, OCRD.SlpCode, N'' as U_vezeto, OCRG.GroupName
FROM          OCRD inner join oslp on ocrd.SlpCode = OSLP.SlpCode
inner join ocrg (NOLOCK) on ocrd.groupcode = ocrg.groupcode
WHERE        (CardType = 'C') AND (validFor = 'Y')
and SUBSTRING(OCRD.CardCode,1,1) = 'V'

GO

CREATE VIEW SPC_WEB_OINV_V ( ID,
	 MANUALNUM,
	 CARDCODE,
	 CARDNAME,
	 DOCDATE,
	 DOCDUEDATE,
	 DOCTOTAL,
	 NETTOTOTAL,
	 PAIDTODATE,
	 VATSUM,
	 NUMATCARD,
	 SLPCODE,
	 SLPNAME,
	 CNTCTCODE,
	 SHIPTOCODE,
	 COMMENTS,
	 U_vezeto ) AS SELECT
	 oinv.DocEntry ID ,
	 oinv.DocNum ,
	 ocrd.CardCode ,
	 ocrd.CardName ,
	 DocDate ,
	 DocDueDate ,
	 DocTotal ,
	 DocTotal,
	 PaidToDate ,
	 VatSum ,
	 null NumAtCard ,
	 OINV.SlpCode ,
	 oslp.SlpName ,
	 null CntctCode ,
	 ShipToCode ,
	 Comments ,
	 N'' as U_vezeto
FROM OINV 
left join OCRD ocrd on OINV.CardCode = ocrd.CardCode 
left join oslp oslp on oslp.SlpCode = OINV.SlpCode 
where oinv.DocDate>=getdate()-360

GO

CREATE VIEW SPC_WEB_ORDR_V ( 
	 ID,
	 DOCNUM,
	 CARDCODE,
	 CARDNAME,
	 DOCDATE,
	 DOCDUEDATE,
	 DOCTOTAL,
	 NETTOTOTAL,
	 VATSUM,
	 NUMATCARD,
	 SLPNAME,
	 CNTCTCODE,
	 SHIPTOCODE,
	 COMMENTS,
	 TRANSZFERALVA,
	 TRANSZFERDATUM,
	 TIPUS,
	 DOCSTATUS,
	 SLPCODE,
	 GROUPNUM,
	 SORREND
	) AS SELECT
	 1000000 + ordr.DocEntry ID ,
	 ordr.DocNum ,
	 ocrd.CardCode ,
	 ocrd.CardName ,
	 DocDate ,
	 DocDueDate ,
	 DocTotal ,
	 DocTotal-VatSum ,
	 VatSum ,
	 ordr.NumAtCard ,
	 oslp.SlpName ,
	 null CntctCode ,
	 ShipToCode ,
	 Comments ,
	 NULL ,
	 NULL ,
	 'S',
	 'C',
	 oslp.SlpCode,
	 ORDR.GroupNum,
	 2
			FROM ORDR 
			join OCRD ocrd on ordr.CardCode = ocrd.CardCode 
			join OSLP on OSLP.SlpCode = OCRD.SlpCode
	where ORDR.DocDate>=GETDATE()-90

GO

CREATE VIEW SPC_WEB_RDR1_V ( 
     ID,
	 ORDR_ID,
	 LINENUM,
	 ITEMCODE,
	 ITEMNAME,
	 QUANTITY,
	 PRICE,
	 PRICEAFVAT,
	 LINETOTAL,
	 BRUTTOTOTAL,
	 COMMENTS,
	 TIPUS,
	 RATE,
	 CODEBARS, u_oitm_kisker_szorzo, u_kisker_szorzo, U_kisker_me ) AS 
	 select
	 rdr1.DocEntry+LineNum ID,
	 1000000 + rdr1.DocEntry ORDR_ID,
	 LineNum,
	 rdr1.ItemCode,
	 oitm.ItemName,
	 Quantity,
	 Price,
	 PriceAfVAT,
	 LineTotal,
	 LineTotal*(100+isnull(nullif(rdr1.Rate,0),27))/100,
	 rdr1.FreeTxt,
	 'S',
	 rdr1.Rate,
	 oitm.CodeBars,
	 1,
	 rdr1.Quantity/
	 1,
	 OITM.U_kisker_me
			FROM rdr1 
			left join OITM on oitm.ItemCode = rdr1.ItemCode 
			inner join ovtg on oitm.VatGourpSa = ovtg.Code

GO
