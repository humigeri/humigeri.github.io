﻿USE [KHAZ_PROD]
GO
/****** Object:  StoredProcedure [dbo].[SPC_MINAR_MOD_P]    Script Date: 2022. 08. 10. 8:18:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER proc [dbo].[SPC_MINAR_MOD_P](
  @p_itemcode nvarchar(200)
, @p_cardcode nvarchar(200)
, @p_linenum int
, @p_uj_ar decimal(19,6)
, @username nvarchar(50)
) as
begin

  declare @l_regi_ar decimal(19,6), @l_todate datetime, @l_fromdate datetime, @l_uj_linenum int, @l_mai_nap datetime;

  -- Lekérdezzük a régi árat és az időszak végét
  select @l_regi_ar = MIN( "Price" )
       , @l_todate  = MIN( "ToDate" )
	   , @l_fromdate  = MIN( "FromDate" )
    from SPP1
   where "ItemCode" = @p_itemcode
     and "CardCode" = @p_cardcode
     and LINENUM    = @p_linenum
  ;
  select @l_uj_linenum = MAX( "LINENUM" )
    from SPP1
   where "ItemCode" = @p_itemcode
     and "CardCode" = @p_cardcode
  ;

  select @l_mai_nap = getdate();

	if @l_fromdate>@l_mai_nap
	begin
	    insert into ARHIV.dbo.jn_spp1(
				"JN_OP"			 , "JN_SQL"				, JN_DATETIME			, JN_USER
			  , JN_TYPE          , VALLALAT
			  ,	"ItemCode"       , "CardCode"           , LINENUM               , "Price"
			  , "Currency"       , "Discount"           , "ListNum"             , "FromDate"
			  , "ToDate"         , "AutoUpdt"           , "Expand"              , "U_3x"
			  , "U_kot_ar"       , "U_Figyelmeztetes"   , "U_Szarmaztatott"     
			) select
			    'UPD'            , NULL			    	, getdate()				, @username
			  , 'EREDETI'		 , DB_NAME()
			  ,	"ItemCode"       , "CardCode"           , LINENUM               , "Price"
			  , "Currency"       , "Discount"           , "ListNum"             , "FromDate"
			  , "ToDate"         , "AutoUpdt"           , "Expand"              , "U_3x"
			  , "U_kot_ar"       , "U_Figyelmeztetes"   , "U_Szarmaztatott"     
			  from spp1
			 where CardCode = @p_cardcode and ItemCode = @p_itemcode
			   and LINENUM    =  @p_linenum
			;
		update SPP1
		set Price = @p_uj_ar
		where "ItemCode" = @p_itemcode
			and "CardCode" = @p_cardcode
			and LINENUM    = @p_linenum
		;
		insert into ARHIV.dbo.jn_spp1(
				"JN_OP"			 , "JN_SQL"				, JN_DATETIME			, JN_USER
			  , JN_TYPE          , VALLALAT
			  ,	"ItemCode"       , "CardCode"           , LINENUM               , "Price"
			  , "Currency"       , "Discount"           , "ListNum"             , "FromDate"
			  , "ToDate"         , "AutoUpdt"           , "Expand"              , "U_3x"
			  , "U_kot_ar"       , "U_Figyelmeztetes"   , "U_Szarmaztatott"     
			) select
			    'UPD'            , NULL			    	, getdate()				, @username
			  , 'UJ'     		 , DB_NAME()
			  ,	"ItemCode"       , "CardCode"           , LINENUM               , "Price"
			  , "Currency"       , "Discount"           , "ListNum"             , "FromDate"
			  , "ToDate"         , "AutoUpdt"           , "Expand"              , "U_3x"
			  , "U_kot_ar"       , "U_Figyelmeztetes"   , "U_Szarmaztatott"     
			  from spp1
			 where CardCode = @p_cardcode and ItemCode = @p_itemcode
			   and LINENUM    =  @p_linenum
			;
	end
	else
	begin
		  if @l_regi_ar is not null
		  begin
			insert into ARHIV.dbo.jn_spp1(
					"JN_OP"			 , "JN_SQL"				, JN_DATETIME			, JN_USER
					, JN_TYPE		 , VALLALAT
				  ,	"ItemCode"       , "CardCode"           , LINENUM               , "Price"
				  , "Currency"       , "Discount"           , "ListNum"             , "FromDate"
				  , "ToDate"         , "AutoUpdt"           , "Expand"              , "U_3x"
				  , "U_kot_ar"       , "U_Figyelmeztetes"   , "U_Szarmaztatott"     
				) select
				    'UPD'			 , NULL					, getdate()				, @username
				  , 'EREDETI'	     , DB_NAME()
				  ,	"ItemCode"       , "CardCode"           , LINENUM               , "Price"
				  , "Currency"       , "Discount"           , "ListNum"             , "FromDate"
				  , "ToDate"         , "AutoUpdt"           , "Expand"              , "U_3x"
				  , "U_kot_ar"       , "U_Figyelmeztetes"   , "U_Szarmaztatott"     
				  from spp1
				 where CardCode = @p_cardcode and ItemCode = @p_itemcode
				   and LINENUM    =  @p_linenum
				;
			update SPP1
			   set "ToDate" = CAST( getdate() as date ) --DATEADD( day, -1, CAST( getdate() as date ) )
			 where "ItemCode" = @p_itemcode
			   and "CardCode" = @p_cardcode
			   and LINENUM    = @p_linenum
			;
			insert into ARHIV.dbo.jn_spp1(
					"JN_OP"			 , "JN_SQL"				, JN_DATETIME			, JN_USER
				  , JN_TYPE		     , VALLALAT
				  ,	"ItemCode"       , "CardCode"           , LINENUM               , "Price"
				  , "Currency"       , "Discount"           , "ListNum"             , "FromDate"
				  , "ToDate"         , "AutoUpdt"           , "Expand"              , "U_3x"
				  , "U_kot_ar"       , "U_Figyelmeztetes"   , "U_Szarmaztatott"     
				) select
				    'UPD'			 , NULL					, getdate()				, @username
				  , 'UJ'			 , DB_NAME()
				  ,	"ItemCode"       , "CardCode"           , LINENUM               , "Price"
				  , "Currency"       , "Discount"           , "ListNum"             , "FromDate"
				  , "ToDate"         , "AutoUpdt"           , "Expand"              , "U_3x"
				  , "U_kot_ar"       , "U_Figyelmeztetes"   , "U_Szarmaztatott"     
				  from spp1
				 where CardCode = @p_cardcode and ItemCode = @p_itemcode
				   and LINENUM    =  @p_linenum
				;
			insert into SPP1(
				"ItemCode"       , "CardCode"           , LINENUM               , "Price"
			  , "Currency"       , "Discount"           , "ListNum"             , "FromDate"
			  , "ToDate"         , "AutoUpdt"           , "Expand"              , "U_3x"
			  , "U_kot_ar"       , "U_Figyelmeztetes"   , "U_Szarmaztatott"     , "U_arlista"
			) select
				"ItemCode"       , "CardCode"           , @l_uj_linenum + 1     , @p_uj_ar
			  , "Currency"       , "Discount"           , "ListNum"             , DATEADD( day, 1, CAST( getdate() as date ) ) -- CAST( getdate() as date )
			  , @l_todate        , "AutoUpdt"           , "Expand"              , "U_3x"
			  , "U_kot_ar"       , "U_Figyelmeztetes"   , "U_Szarmaztatott"     , 'I'
			  from spp1
			 where "ItemCode" = @p_itemcode
			   and "CardCode" = @p_cardcode
			   and LINENUM    = @p_linenum
			;
			
			insert into ARHIV.dbo.jn_spp1(
					"JN_OP"			 , "JN_SQL"				, JN_DATETIME			, JN_USER
				  , JN_TYPE		     , VALLALAT
				  ,	"ItemCode"       , "CardCode"           , LINENUM               , "Price"
				  , "Currency"       , "Discount"           , "ListNum"             , "FromDate"
				  , "ToDate"         , "AutoUpdt"           , "Expand"              , "U_3x"
				  , "U_kot_ar"       , "U_Figyelmeztetes"   , "U_Szarmaztatott"     
				) select
				    'INS'			 , NULL					, getdate()				, @username
				  , 'UJ'			 , DB_NAME()
				  ,	"ItemCode"       , "CardCode"           , LINENUM               , "Price"
				  , "Currency"       , "Discount"           , "ListNum"             , "FromDate"
				  , "ToDate"         , "AutoUpdt"           , "Expand"              , "U_3x"
				  , "U_kot_ar"       , "U_Figyelmeztetes"   , "U_Szarmaztatott"     
				  from spp1
				 where CardCode = @p_cardcode and ItemCode = @p_itemcode
				   and LINENUM    =  @l_uj_linenum + 1
				;
		  end;
  end;

end;
