CREATE TABLE [dbo].[SPC_DOMAINS](
	[ID] [int] NOT NULL,
	[TIPUS] [nvarchar](30) NOT NULL,
	[MEGNEVEZES] [nvarchar](100) NOT NULL,
	[MEGJEGYZES] [ntext] NULL,
	[KOD] [nvarchar](50) NOT NULL,
	[LANGUAGE] [nvarchar](3) NOT NULL,
 CONSTRAINT [PK_SPC_DOMAINS] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[SPC_FUNCTIONS](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[KOD] [nvarchar](100) NOT NULL,
	[ADDONID] [nvarchar](30) NOT NULL,
	[ISSYSTEM] [char](1) NOT NULL,
	[FUNCID] [nvarchar](30) NOT NULL,
	[ISVALID] [char](1) NOT NULL,
	[PARENTSBO] [nvarchar](50) NULL,
	[PARENTFUNC] [int] NULL,
	[FORMUID] [nvarchar](50) NULL,
	[NUM] [int] NOT NULL,
	[MENU_LABEL] [nvarchar](100) NULL,
	[CLASSNAME] [nvarchar](50) NULL,
	[PAGENAME] [nvarchar](30) NULL,
	[ARGS] [nvarchar](2000) NULL,
 CONSTRAINT [SPC_FUNCTIONS_PR] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[SPC_FUNCTIONS_LANG](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[KOD] [nvarchar](100) NOT NULL,
	[FUNC_ID] [int] NULL,
	[LANGCODE] [int] NULL,
	[MENU_LABEL] [nvarchar](100) NULL,
 CONSTRAINT [SPC_FUNCTIONS_LANG_PR] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[SPC_LOGS](
	[ID] [bigint] NOT NULL,
	[LOGLEVEL] [nvarchar](200) NULL,
	[TOKEN] [nvarchar](max) NULL,
	[LOGINNAME] [nvarchar](50) NULL,
	[SOURCE] [nvarchar](max) NULL,
	[EXCEPTIONMESSAGE] [nvarchar](max) NULL,
	[STACKTRACE] [nvarchar](max) NULL,
	[CREATEDDATE] [nvarchar](50) NULL,
	[USERID] [bigint] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[SPC_MESSAGES](
	[ID] [bigint] NULL,
	[TARGY] [nvarchar](500) NULL,
	[UZENET] [nvarchar](4000) NULL,
	[LETREHOZAS_DATUMA] [datetime] NULL,
	[KEZBESITES_DATUMA] [datetime] NULL,
	[KEZBESITVE] [nvarchar](1) NULL,
	[USER_ID_TO] [nvarchar](50) NULL,
	[USER_ID_FROM] [nvarchar](50) NULL,
	[PRIORITAS] [nvarchar](1) NULL,
	[TIPUS] [nvarchar](1) NULL
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[SPC_PARAMETERS](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[KOD] [nvarchar](100) NOT NULL,
	[DESCRIPT] [nvarchar](254) NOT NULL,
	[VAL] [nvarchar](254) NULL,
	[COMMENT] [ntext] NULL,
 CONSTRAINT [SPC_PARAMETERS_PR] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[SPC_PRR_ERTEKEK](
	[ID] [int] NOT NULL,
	[PRR_ID] [int] NOT NULL,
	[USERID] [int] NULL,
	[FORMUID] [nvarchar](100) NULL,
	[PAGENAME] [nvarchar](100) NULL,
	[LOCATOR] [nvarchar](100) NULL,
	[VAL] [nvarchar](254) NULL,
 CONSTRAINT [SPC_PRR_ERTEKEK_PK] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [SPC_PRR_ERTEKEK_UK1] UNIQUE NONCLUSTERED 
(
	[PRR_ID] ASC,
	[FORMUID] ASC,
	[PAGENAME] ASC,
	[LOCATOR] ASC,
	[USERID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

CREATE VIEW [dbo].[SPC_LOGIN_V] as
select 
OUSR.USERID ID
, OUSR.USERID
,	isnull(OUSR.U_NAME, ousr.USER_CODE) U_NAME
,	OUSR.USER_CODE 
, OSLP.SlpCode
, '03AC674216F3E15C761EE1A5E255F067953623C8B388B4459E13F978D7C846F4' U_pwd
, -1 as U_vezeto
,   '100' whscode
, SUBSTRING(OUSR.U_NAME,1,2) avatar
, isnull(ohem.mobile, '-') mobile
, isnull(ousr_vezeto.USERID, -1) userid_vezeto
from OHEM inner join OUSR on OHEM.userId = OUSR.USERID
left join  OSLP on OUSR.USER_CODE = OSLP.U_fnev
left join oslp oslp_vezeto on -10 = oslp_vezeto.SlpCode
left join ousr ousr_vezeto on ousr_vezeto.USER_CODE = oslp_vezeto.U_fnev
where ousr.Locked = 'N'
union all 
select 
OUSR.USERID ID
, OUSR.USERID
,	isnull(OUSR.U_NAME, ousr.USER_CODE)
,	OUSR.USER_CODE 
, oslp.SlpCode
, '03AC674216F3E15C761EE1A5E255F067953623C8B388B4459E13F978D7C846F4' U_pwd
, -1 as U_vezeto
,   '100' whscode
, SUBSTRING(OUSR.U_NAME,1,2) avatar
, isnull(ohem.mobile, '-') mobile
, isnull(ousr_vezeto.USERID, -1) userid_vezeto
from OUSR left join ohem on OHEM.userId = OUSR.USERID
left join  OSLP on OUSR.USER_CODE = OSLP.U_fnev
left join oslp oslp_vezeto on -10 = oslp_vezeto.SlpCode
left join ousr ousr_vezeto on ousr_vezeto.USER_CODE = oslp_vezeto.U_fnev
where ohem.userId is null
GO

CREATE view [dbo].[SPC_MESSAGES_V] as
select
msg.*
, fho.u_name USERNAME_TO
, fho2.u_name USERNAME_FROM
, SUBSTRING(fho.u_name,1,2) avatar_to
, SUBSTRING(fho2.u_name,1,2) avatar_from
, '' picture_to
, '' picture_from
from SPC_MESSAGES msg inner join spc_login_v fho on fho.userid = msg.user_id_to
left join spc_login_v fho2 on fho2.userid = msg.user_id_from

GO

CREATE UNIQUE NONCLUSTERED INDEX IX1_SPC_DOMAINS ON SPC_DOMAINS(TIPUS ASC, KOD ASC, "LANGUAGE" ASC)
GO

CREATE UNIQUE NONCLUSTERED INDEX IX1_SPC_PARAMETERS ON SPC_PARAMETERS(KOD ASC)
GO

CREATE UNIQUE NONCLUSTERED INDEX IX1_SPC_FUNCTIONS ON SPC_FUNCTIONS(KOD ASC)
GO

CREATE UNIQUE NONCLUSTERED INDEX IX2_SPC_FUNCTIONS ON SPC_FUNCTIONS(ADDONID ASC, ISSYSTEM ASC, FUNCID ASC)
GO

create proc [dbo].[SPC_DASHBOARD1_P] as
begin
  select year(ordr.DocDate) ev, sum(ordr.DocTotal) doctotal_ossz
  , (select isnull(sum(isnull(ife.doctotal,0)),0) from ordr ife where year(ife.docdate) = year(ordr.docdate)) ife_doctotal
  , (select isnull(sum(isnull(uk.doctotal,0)),0) from ordr uk where year(uk.docdate) = year(ordr.docdate)) uk_doctotal
 from ORDR group by year(ordr.DocDate) order by 1;
end;
GO

create proc [dbo].[SPC_DASHBOARD2_P] as
begin
  select MONTH(docdate) honap_ssz, upper(FORMAT(docdate, 'MMM', 'hu-HU')) honap, sum(doctotal) total from oinv where YEAR(docdate) = YEAR(getdate()) group by MONTH(docdate), FORMAT(docdate, 'MMM', 'hu-HU') order by 1;
end;
GO


insert into "SPC_PARAMETERS"("KOD", "DESCRIPT", "VAL", "COMMENT") values (N'BACKENDURL', N'Backend URL-je', N'http://localhost:4000/', null);
insert into "SPC_PARAMETERS"("KOD", "DESCRIPT", "VAL", "COMMENT") values (N'SB1FORMWIDTH', N'AddOn form szélessége', null, null);
insert into "SPC_PARAMETERS"("KOD", "DESCRIPT", "VAL", "COMMENT") values (N'SB1FORMHEIGHT', N'AddOn form height', null, null);
insert into "SPC_PARAMETERS"("KOD", "DESCRIPT", "VAL", "COMMENT") values (N'SB1FORMZOOM', N'AddOn form zoom', null, null);
GO

